<?php
/**
 * 2.5: O'quvchi hamyoni — balans, kirim/chiqim daftari (wallet_tx), to'lov cheklari (pay_requests), audit.
 * Qoidalar: pul faqat wallet_post() orqali o'zgaradi; har amal bitta tranzaksiyada, o'quvchi qatori qulflanadi (FOR UPDATE);
 * yozuv o'chirilmaydi va tahrirlanmaydi — tuzatish yangi yozuv bilan. students.balance — yozuvlar yig'indisining nusxasi.
 */
defined('APP_ROOT') || exit;

/** O'quvchi tanlaydigan to'lov usullari (chek bilan) va admin qo'lda kiritadiganlari */
const PAY_METHODS = ['karta' => 'Kartaga o\'tkazma', 'click' => 'Click', 'payme' => 'Payme', 'uzum' => 'Uzum', 'boshqa' => 'Boshqa'];
const PAY_ADMIN_METHODS = ['naqd' => 'Naqd', 'oqituvchi' => 'O\'qituvchiga to\'g\'ridan-to\'g\'ri', 'karta' => 'Kartaga o\'tkazma', 'click' => 'Click', 'payme' => 'Payme', 'boshqa' => 'Boshqa'];
const PAY_STATUS = ['pending' => 'Tekshirilmoqda', 'approved' => 'Tasdiqlandi', 'rejected' => 'Rad etildi', 'canceled' => 'Bekor qilindi'];
const PAY_REJECT_REASONS = ['summa' => 'Summa chekdagiga mos emas', 'oqilmaydi' => 'Chek o\'qilmaydi yoki to\'liq emas', 'takror' => 'Bu chek avval ishlatilgan',
                            'topilmadi' => 'Bu to\'lov hisobimizga tushmagan', 'boshqa' => 'Boshqa sabab'];
const PAY_MAX_AMOUNT = 10000000;          // bitta chek yoki amal uchun yuqori chegara (so'm)
const PAY_FILE_MAX = 8 * 1024 * 1024;     // chek fayli, bayt
const PAY_FILE_TYPES = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'];
const PAY_DAY_LIMIT = 10;                 // bir o'quvchi kuniga yuboradigan cheklar
/** Hamyon xabarlari (tg_queue.kind) — test_id ustunida chek/yozuv/test raqami */
const WALLET_TG_KINDS = ['payok', 'payno', 'payadm', 'wtop', 'regpd', 'regrf', 'regex'];

/** 50000 → «50 000 so'm» (bo'linmaydigan bo'sh joy bilan) */
function som(int $n): string
{
    return ($n < 0 ? '−' : '') . number_format(abs($n), 0, '.', "\u{00A0}") . "\u{00A0}so'm";
}

/** «50 000», «50.000», «50,000», «50000 so'm», «50000.00» → 50000 (noto'g'ri bo'lsa 0). Tiyin yo'q. */
function money_in($v): int
{
    $s = mb_strtolower(trim((string)$v));
    $s = trim((string)preg_replace('/(so.?m|sum|сум|uzs)$/u', '', $s));
    $s = (string)preg_replace('/[.,]0{1,2}$/', '', $s);   // «50000.00»
    $s = (string)preg_replace('/[\s\x{00A0}\x{202F},.\'’‘ʻʼ`]/u', '', $s);
    return preg_match('/^\d{1,9}$/', $s) ? (int)$s : 0;
}

/* ---------------- Sozlamalar ---------------- */

/** To'lov kartalari: [['no'=>'8600 …','owner'=>'…','bank'=>'…'], …] (ko'pi bilan 3) */
function pay_cards(): array
{
    $c = json_decode(app_setting('pay_cards'), true);
    if (!is_array($c)) return [];
    $out = [];
    foreach ($c as $x) {
        if (!is_array($x)) continue;
        $no = trim((string)($x['no'] ?? ''));
        if ($no === '') continue;
        $out[] = ['no' => $no, 'owner' => trim((string)($x['owner'] ?? '')), 'bank' => trim((string)($x['bank'] ?? ''))];
    }
    return array_slice($out, 0, 3);
}

function pay_card_label(array $c): string
{
    return trim($c['no'] . ($c['bank'] !== '' ? ' (' . $c['bank'] . ')' : '') . ($c['owner'] !== '' ? ' — ' . $c['owner'] : ''));
}

function pay_min(): int { $v = (int)app_setting('pay_min', '5000'); return $v >= 1000 ? min($v, 1000000) : 5000; }
/** O'quvchi o'zi bekor qilishi mumkin bo'lgan muddat (pul yechilgandan keyin, daqiqa); 0 — o'zi bekor qila olmaydi */
function pay_cancel_min(): int { $v = app_setting('pay_cancel_min', '60'); return ctype_digit($v) ? min((int)$v, 10080) : 60; }
function pay_max_pending(): int { $v = (int)app_setting('pay_max_pending', '3'); return $v >= 1 ? min($v, 10) : 3; }
function pay_note(): string { return trim(app_setting('pay_note')); }

/* ---------------- Yordamchilar ---------------- */

/** Tranzaksiya: ichma-ich chaqirilsa tashqisiga qo'shiladi (PDO ichma-ich tranzaksiyani bilmaydi) */
function db_tx(callable $fn)
{
    $pdo = db();
    if ($pdo->inTransaction()) return $fn();
    $pdo->beginTransaction();
    try {
        $r = $fn();
        $pdo->commit();
        return $r;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/** Amalni kim qildi: admin:ID | student:ID | system */
function actor_tag(): string
{
    $a = admin();
    if ($a) return 'admin:' . (int)$a['id'];
    $s = student();
    if ($s) return 'student:' . (int)$s['id'];
    return 'system';
}

/** «admin:3» → «Masud» (admin nomi), «student:5» → «o'quvchi», «system» → «tizim» */
function actor_label(string $a): string
{
    static $c = [];
    if (isset($c[$a])) return $c[$a];
    if (preg_match('/^(bot-)?admin:(\d+)$/', $a, $m)) {
        $u = row('SELECT name, login FROM users WHERE id=?', [(int)$m[2]]);
        return $c[$a] = ($u ? ((string)$u['name'] !== '' ? (string)$u['name'] : (string)$u['login']) : 'admin #' . $m[2]) . ($m[1] ? ' (bot)' : '');
    }
    if (strncmp($a, 'student:', 8) === 0) return $c[$a] = 'o\'quvchi';
    return $c[$a] = 'tizim';
}

function audit(string $action, string $entity, ?int $id, $before = null, $after = null, ?string $actor = null): void
{
    q('INSERT INTO audit_log (actor, action, entity, entity_id, before_json, after_json, ip) VALUES (?,?,?,?,?,?,?)', [
        mb_substr($actor ?? actor_tag(), 0, 24), mb_substr($action, 0, 32), mb_substr($entity, 0, 16), $id,
        $before === null ? null : json_encode($before, JSON_UNESCAPED_UNICODE), $after === null ? null : json_encode($after, JSON_UNESCAPED_UNICODE),
        PHP_SAPI === 'cli' ? 'cli' : mb_substr(client_ip(), 0, 45),
    ]);
}

/** Joriy admin moliya huquqiga egami (cheklarni tasdiqlash, balansni o'zgartirish) */
function can_finance(): bool
{
    static $c = null;
    $a = admin();
    if (!$a) return false;
    if ($c === null) $c = (int)val('SELECT can_finance FROM users WHERE id=?', [(int)$a['id']]) === 1;
    return $c;
}

function require_finance(): void
{
    if (!can_finance()) { flash('Bu bo\'lim uchun «Moliya» huquqi kerak (Sozlamalar → Administratorlar)', 'err'); redirect('dashboard'); }
}

/* ---------------- Hamyon daftari ---------------- */

function wallet_balance(int $sid): int
{
    return (int)val('SELECT balance FROM students WHERE id=?', [$sid]);
}

/**
 * Hamyonga yozuv. $amount > 0 — kirim, < 0 — chiqim. $kind: topup | charge | refund | adjust | withdraw | reverse.
 * $o: ref_type, ref_id, method, note, actor, allow_negative (faqat admin tuzatishi uchun).
 * Qaytaradi: ['ok'=>bool, 'tx_id'=>int, 'balance'=>int, 'error'=>string]
 */
function wallet_post(int $sid, int $amount, string $kind, array $o = []): array
{
    if ($amount === 0 || abs($amount) > PAY_MAX_AMOUNT * 10) return ['ok' => false, 'tx_id' => 0, 'balance' => wallet_balance($sid), 'error' => 'Summa noto\'g\'ri'];
    return db_tx(function () use ($sid, $amount, $kind, $o) {
        $cur = row('SELECT balance FROM students WHERE id=? FOR UPDATE', [$sid]);
        if (!$cur) return ['ok' => false, 'tx_id' => 0, 'balance' => 0, 'error' => 'O\'quvchi topilmadi'];
        $new = (int)$cur['balance'] + $amount;
        if ($new < 0 && $amount < 0 && empty($o['allow_negative'])) return ['ok' => false, 'tx_id' => 0, 'balance' => (int)$cur['balance'], 'error' => 'Balans yetarli emas'];
        q('INSERT INTO wallet_tx (student_id, amount, kind, ref_type, ref_id, method, balance_after, note, actor) VALUES (?,?,?,?,?,?,?,?,?)', [
            $sid, $amount, $kind, (string)($o['ref_type'] ?? ''), isset($o['ref_id']) ? (int)$o['ref_id'] : null, (string)($o['method'] ?? ''),
            $new, mb_substr((string)($o['note'] ?? ''), 0, 255), mb_substr((string)($o['actor'] ?? actor_tag()), 0, 24),
        ]);
        $tx = (int)db()->lastInsertId();
        q('UPDATE students SET balance=? WHERE id=?', [$new, $sid]);
        return ['ok' => true, 'tx_id' => $tx, 'balance' => $new, 'error' => ''];
    });
}

function wallet_history(int $sid, int $limit = 50): array
{
    return rows('SELECT * FROM wallet_tx WHERE student_id=? ORDER BY id DESC LIMIT ' . max(1, min(500, $limit)), [$sid]);
}

/** Yozuvning o'qiladigan izohi (MOCK nomi yozuvning o'zida saqlanadi — MOCK o'chirilsa ham tarix tushunarli) */
function wallet_tx_label(array $t): string
{
    $m = PAY_ADMIN_METHODS[$t['method']] ?? '';
    $note = (string)$t['note'];
    $ref = 'MOCK #' . (int)$t['ref_id'];
    switch ($t['kind']) {
        case 'topup':
            if ($t['ref_type'] === 'pay') return 'Hisob to\'ldirildi — chek #' . (int)$t['ref_id'] . ($note !== '' ? ' (' . $note . ')' : '');
            return 'Hisob to\'ldirildi' . ($m !== '' ? ' — ' . mb_strtolower($m) : '') . ($note !== '' ? ': ' . $note : '');
        case 'charge':   return 'MOCK uchun to\'lov: ' . ($note !== '' ? $note : $ref);
        case 'refund':   return 'Qaytarildi: ' . ($note !== '' ? $note : $ref);
        case 'withdraw': return 'Naqd qaytarib berildi' . ($note !== '' ? ': ' . $note : '');
        case 'reverse':  return 'Tasdiq bekor qilindi' . ($t['ref_type'] === 'pay' ? ' (chek #' . (int)$t['ref_id'] . ')' : '') . ($note !== '' ? ': ' . $note : '');
        default:         return 'Tuzatish' . ($note !== '' ? ': ' . $note : '');
    }
}

/** Pul tarixi bormi (bor bo'lsa o'quvchi o'chirilmaydi, faqat arxivlanadi) */
function wallet_has_history(int $sid): bool
{
    return (bool)val('SELECT 1 FROM wallet_tx WHERE student_id=? LIMIT 1', [$sid]) || (bool)val('SELECT 1 FROM pay_requests WHERE student_id=? LIMIT 1', [$sid]);
}

/**
 * Admin qo'lda: topup (to'ldirish — naqd yoki o'qituvchiga to'langan), adjust (tuzatish ±, izoh majburiy, qarzga ham), withdraw (naqd qaytarib berish).
 * Qaytaradi: ['ok', 'error', 'balance', 'settled'=>[…]]
 */
function wallet_admin_op(int $sid, string $op, int $amount, string $method, string $note, ?string $actor = null): array
{
    $note = mb_substr(trim($note), 0, 200);
    $actor = $actor ?? actor_tag();
    if (!row('SELECT id FROM students WHERE id=?', [$sid])) return ['ok' => false, 'error' => 'O\'quvchi topilmadi'];
    if ($op === 'topup') {
        if ($amount < 1 || $amount > PAY_MAX_AMOUNT) return ['ok' => false, 'error' => 'Summa 1 dan ' . som(PAY_MAX_AMOUNT) . ' gacha bo\'lsin'];
        if (!isset(PAY_ADMIN_METHODS[$method])) $method = 'naqd';
        $kind = 'topup'; $sum = $amount; $o = ['ref_type' => 'manual', 'method' => $method];
    } elseif ($op === 'adjust') {
        if ($amount === 0 || abs($amount) > PAY_MAX_AMOUNT) return ['ok' => false, 'error' => 'Tuzatish summasi noto\'g\'ri (masalan: 20000 yoki -20000)'];
        if (mb_strlen($note) < 3) return ['ok' => false, 'error' => 'Tuzatish sababini yozing'];
        $kind = 'adjust'; $sum = $amount; $o = ['ref_type' => 'manual', 'allow_negative' => true]; $method = '';
    } elseif ($op === 'withdraw') {
        if ($amount < 1 || $amount > PAY_MAX_AMOUNT) return ['ok' => false, 'error' => 'Summa noto\'g\'ri'];
        if (mb_strlen($note) < 3) return ['ok' => false, 'error' => 'Izoh yozing (kimga, qachon berildi)'];
        $kind = 'withdraw'; $sum = -$amount; $o = ['ref_type' => 'manual', 'method' => 'naqd']; $method = 'naqd';
    } else return ['ok' => false, 'error' => 'Noma\'lum amal'];
    $res = db_tx(function () use ($sid, $op, $kind, $sum, $o, $note, $actor, $method, $amount) {
        $r = wallet_post($sid, $sum, $kind, $o + ['note' => $note, 'actor' => $actor]);
        if (!$r['ok']) return ['ok' => false, 'error' => $r['error']];
        audit('wallet_' . $op, 'student', $sid, null, ['amount' => $amount, 'method' => $method, 'note' => $note, 'tx' => $r['tx_id'], 'balance' => $r['balance']], $actor);
        $settled = $sum > 0 ? mock_settle_unpaid($sid, $actor) : [];   // band qilingan MOCK lar avtomatik to'lanadi
        return ['ok' => true, 'error' => '', 'tx_id' => $r['tx_id'], 'settled' => $settled];
    });
    if (!$res['ok']) return $res;
    $bal = wallet_balance($sid);
    $txt = $op === 'topup' ? "💰 Hisobingiz to'ldirildi: <b>+" . tg_h(som($amount)) . "</b>"
        : ($op === 'withdraw' ? "💵 Hamyoningizdan naqd qaytarib berildi: <b>" . tg_h(som($amount)) . "</b>"
        : "🧾 Hamyoningizda tuzatish: <b>" . ($amount > 0 ? '+' : '') . tg_h(som($amount)) . "</b>");
    wallet_notify($sid, 'wtop', (int)$res['tx_id'], $txt . ($note !== '' ? "\nIzoh: " . tg_h($note) : '') . "\nBalans: <b>" . tg_h(som($bal)) . "</b>" . wallet_settled_text($res['settled']));
    return $res + ['balance' => $bal];
}

/* ---------------- Cheklar ---------------- */

function pay_dir(): string
{
    global $CONFIG;
    $d = (string)($CONFIG['pay_dir'] ?? '');
    return rtrim($d !== '' ? $d : APP_ROOT . '/uploads/pay', '/');
}

/**
 * Chek faylini tekshirib saqlaydi. $tmp — vaqtinchalik fayl yo'li. Qaytaradi: ['file','type','size','hash','phash'] yoki null ($err da sabab).
 * Fayl nomi tasodifiy va «.r» kengaytmali: nginx uni rasm sifatida to'g'ridan-to'g'ri bermaydi, Apache esa uploads/ ni yopadi.
 */
function pay_store_file(string $tmp, int $size, ?string &$err): ?array
{
    $err = '';
    if ($size <= 0 || !is_file($tmp)) { $err = 'Chek fayli yuklanmadi'; return null; }
    if ($size > PAY_FILE_MAX) { $err = 'Fayl juda katta (ko\'pi bilan 8 MB)'; return null; }
    $head = (string)file_get_contents($tmp, false, null, 0, 16);
    $type = '';
    if (strncmp($head, '%PDF-', 5) === 0) $type = 'application/pdf';
    else {
        $gi = @getimagesize($tmp);
        if ($gi && isset(PAY_FILE_TYPES[(string)($gi['mime'] ?? '')]) && (int)$gi[0] >= 50 && (int)$gi[1] >= 50) $type = (string)$gi['mime'];
    }
    if ($type === '') { $err = 'Faqat rasm (JPG, PNG, WebP) yoki PDF qabul qilinadi'; return null; }
    $hash = (string)hash_file('sha256', $tmp);
    $ph = $type !== 'application/pdf' ? pay_dhash($tmp, $type) : '';
    $sub = date('Y') . '/' . date('m');
    $dir = pay_dir() . '/' . $sub;
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) { $err = 'Faylni saqlab bo\'lmadi (papka)'; return null; }
    $name = bin2hex(random_bytes(16)) . '.r';
    $ok = is_uploaded_file($tmp) ? @move_uploaded_file($tmp, $dir . '/' . $name) : @copy($tmp, $dir . '/' . $name);
    if (!$ok) { $err = 'Faylni saqlab bo\'lmadi'; return null; }
    @chmod($dir . '/' . $name, 0644);
    return ['file' => $sub . '/' . $name, 'type' => $type, 'size' => $size, 'hash' => $hash, 'phash' => $ph];
}

/** Chek faylining to'liq yo'li (nomi kutilgan ko'rinishda bo'lsa) */
function pay_file_path(array $r): string
{
    $f = (string)$r['file'];
    return preg_match('#^\d{4}/\d{2}/[a-f0-9]{32}\.r$#', $f) ? pay_dir() . '/' . $f : '';
}

/** GD bilan rasmni ochish (EXIF bo'yicha to'g'rilab) */
function pay_gd_open(string $path, string $type)
{
    if (!function_exists('imagecreatetruecolor')) return false;
    $gi = @getimagesize($path);
    if (!$gi || (int)$gi[0] * (int)$gi[1] > 40000000) return false;   // juda katta rasm (xotira) — kichik nusxa va xeshsiz
    @ini_set('memory_limit', '256M');
    $im = $type === 'image/jpeg' ? @imagecreatefromjpeg($path) : ($type === 'image/png' ? @imagecreatefrompng($path) : ($type === 'image/webp' && function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($path) : false));
    if ($im && $type === 'image/jpeg' && function_exists('exif_read_data')) {
        $o = (int)(@exif_read_data($path)['Orientation'] ?? 1);
        $deg = [3 => 180, 6 => -90, 8 => 90][$o] ?? 0;
        if ($deg) { $r = imagerotate($im, $deg, 0); if ($r) $im = $r; }
    }
    return $im;
}

/** Kichik nusxa (eng uzun tomoni 520 px, JPEG): fayl yonida «.t» bo'lib keshlanadi. Bo'lmasa — '' */
function pay_thumb(string $path, string $type): string
{
    $th = substr($path, 0, -2) . '.t';
    if (is_file($th) && filemtime($th) >= filemtime($path)) return $th;
    $im = pay_gd_open($path, $type);
    if (!$im) return '';
    $w = imagesx($im); $h = imagesy($im);
    $k = min(1, 520 / max($w, $h));
    $nw = max(1, (int)round($w * $k)); $nh = max(1, (int)round($h * $k));
    $out = imagecreatetruecolor($nw, $nh);
    imagefill($out, 0, 0, imagecolorallocate($out, 255, 255, 255));   // shaffof PNG — oq fon
    imagecopyresampled($out, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
    $ok = @imagejpeg($out, $th, 80);
    if (PHP_VERSION_ID < 80000) { imagedestroy($im); imagedestroy($out); }
    return $ok ? $th : '';
}

/** Rasmning farq xeshi (dHash, 64 bit → 16 hex): qirqilgan, siqilgan yoki qayta saqlangan skrinshot ham o'xshash chiqadi */
function pay_dhash(string $path, string $type): string
{
    $src = pay_gd_open($path, $type);
    if (!$src) return '';
    $sm = imagecreatetruecolor(9, 8);
    imagecopyresampled($sm, $src, 0, 0, 0, 0, 9, 8, imagesx($src), imagesy($src));
    $bits = '';
    for ($y = 0; $y < 8; $y++) {
        $prev = 0.0;
        for ($x = 0; $x < 9; $x++) {
            $c = imagecolorat($sm, $x, $y);
            $g = (($c >> 16) & 255) * 0.299 + (($c >> 8) & 255) * 0.587 + ($c & 255) * 0.114;
            if ($x > 0) $bits .= $g > $prev ? '1' : '0';
            $prev = $g;
        }
    }
    if (PHP_VERSION_ID < 80000) { imagedestroy($src); imagedestroy($sm); }
    $hex = '';
    foreach (str_split($bits, 4) as $nib) $hex .= dechex((int)bindec($nib));
    return $hex;
}

function pay_hamming(string $a, string $b): int
{
    if (strlen($a) !== 16 || strlen($b) !== 16) return 64;
    $d = 0;
    for ($i = 0; $i < 16; $i++) { $x = hexdec($a[$i]) ^ hexdec($b[$i]); $d += substr_count(decbin($x), '1'); }
    return $d;
}

/**
 * O'quvchining cheki. $d: amount, method, card_to, paid_at ('Y-m-d H:i' yoki ''), receipt_no, note. $file: ['tmp','size'].
 * Qaytaradi: ['ok'=>bool, 'id'=>int, 'error'=>string]
 */
function pay_request_create(int $sid, array $d, array $file, string $source = 'web'): array
{
    $amount = money_in($d['amount'] ?? '');
    if ($amount < pay_min() || $amount > PAY_MAX_AMOUNT) return ['ok' => false, 'id' => 0, 'error' => 'Summani to\'g\'ri yozing: ' . som(pay_min()) . ' dan ' . som(PAY_MAX_AMOUNT) . ' gacha'];
    $method = isset(PAY_METHODS[(string)($d['method'] ?? '')]) ? (string)$d['method'] : 'karta';
    $cards = array_map('pay_card_label', pay_cards());
    $cardTo = (string)($d['card_to'] ?? '');
    if ($cardTo !== '' && !in_array($cardTo, $cards, true)) $cardTo = '';
    $cardTo = mb_substr($cardTo, 0, 160);
    $paidAt = null;
    $pa = str_replace('T', ' ', trim((string)($d['paid_at'] ?? '')));
    if ($pa !== '' && ($ts = strtotime($pa)) !== false) $paidAt = date('Y-m-d H:i:s', $ts);
    $rno = mb_substr(trim((string)preg_replace('/\s+/u', ' ', (string)($d['receipt_no'] ?? ''))), 0, 64);
    $note = mb_substr(trim((string)($d['note'] ?? '')), 0, 255);
    $st = row('SELECT id, archived_at FROM students WHERE id=?', [$sid]);
    if (!$st || $st['archived_at'] !== null) return ['ok' => false, 'id' => 0, 'error' => 'Hisob topilmadi'];
    if ((int)val('SELECT COUNT(*) FROM pay_requests WHERE student_id=? AND status="pending"', [$sid]) >= pay_max_pending())
        return ['ok' => false, 'id' => 0, 'error' => 'Sizda tekshirilayotgan cheklar bor (' . pay_max_pending() . ' ta). Admin ko\'rib chiqqach yangisini yuboring.'];
    if ((int)val('SELECT COUNT(*) FROM pay_requests WHERE student_id=? AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [$sid]) >= PAY_DAY_LIMIT)
        return ['ok' => false, 'id' => 0, 'error' => 'Bugun juda ko\'p chek yuborildi. Ertaga urinib ko\'ring yoki markazga murojaat qiling.'];
    $err = '';
    $f = pay_store_file((string)($file['tmp'] ?? ''), (int)($file['size'] ?? 0), $err);
    if (!$f) return ['ok' => false, 'id' => 0, 'error' => $err];
    q('INSERT INTO pay_requests (student_id, amount, method, card_to, paid_at, receipt_no, file, file_type, file_size, file_hash, phash, status, source, note)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [$sid, $amount, $method, $cardTo, $paidAt, $rno, $f['file'], $f['type'], $f['size'], $f['hash'], $f['phash'], 'pending', $source === 'bot' ? 'bot' : 'web', $note]);
    $id = (int)db()->lastInsertId();
    audit('pay_create', 'pay', $id, null, ['amount' => $amount, 'method' => $method, 'source' => $source], 'student:' . $sid);
    pay_notify_admins($id);
    return ['ok' => true, 'id' => $id, 'error' => ''];
}

/** O'quvchi o'z kutilayotgan chekini bekor qiladi */
function pay_request_cancel(int $id, int $sid): bool
{
    $n = q('UPDATE pay_requests SET status="canceled", reviewed_at=NOW(), reviewed_by=? WHERE id=? AND student_id=? AND status="pending"', ['student:' . $sid, $id, $sid])->rowCount();
    if ($n) { audit('pay_cancel', 'pay', $id, null, null, 'student:' . $sid); mock_expire_unpaid(null, $sid); }
    return $n > 0;
}

/**
 * Chekni tekshirishga yordam — ogohlantirishlar: [['lvl'=>'warn|info', 'text'=>…], …]. Qaror — adminniki.
 */
function pay_flags(array $r): array
{
    $out = [];
    foreach (rows('SELECT p.id, p.status, p.created_at, s.full_name, s.code FROM pay_requests p JOIN students s ON s.id=p.student_id
                   WHERE p.file_hash=? AND p.id<>? ORDER BY p.id LIMIT 3', [(string)$r['file_hash'], (int)$r['id']]) as $x)
        $out[] = ['lvl' => 'warn', 'ref' => (int)$x['id'], 'text' => 'Aynan shu fayl avval yuborilgan: #' . $x['id'] . ' — ' . $x['full_name'] . ' (' . $x['code'] . '), ' . date('d.m.Y H:i', strtotime((string)$x['created_at'])) . ' · ' . mb_strtolower(PAY_STATUS[$x['status']] ?? $x['status'])];
    // O'xshash rasm (dHash) belgisi hozircha ko'rsatilmaydi: bitta to'lov ilovasining turli cheklari ham bir-biriga «o'xshash» chiqadi.
    // phash saqlanadi — haqiqiy cheklarda sozlangach (2.5.2) yoqiladi. Aynan bir xil fayl va chek raqami takrori yuqorida tekshiriladi.
    if ((string)$r['receipt_no'] !== '') {
        foreach (rows('SELECT p.id, p.status, s.full_name FROM pay_requests p JOIN students s ON s.id=p.student_id WHERE p.receipt_no=? AND p.id<>? AND p.status<>"canceled" LIMIT 3', [(string)$r['receipt_no'], (int)$r['id']]) as $x)
            $out[] = ['lvl' => 'warn', 'ref' => (int)$x['id'], 'text' => 'Chek raqami takrorlangan: #' . $x['id'] . ' — ' . $x['full_name'] . ' · ' . mb_strtolower(PAY_STATUS[$x['status']] ?? $x['status'])];
    }
    $a = (int)$r['amount'];
    if ($a % 1000 !== 0) $out[] = ['lvl' => 'info', 'text' => 'Summa yaxlit emas: ' . som($a)];
    if ($a >= 2000000) $out[] = ['lvl' => 'info', 'text' => 'Katta summa: ' . som($a)];
    if (!empty($r['paid_at'])) {
        $pt = strtotime((string)$r['paid_at']);
        if ($pt > time() + 600) $out[] = ['lvl' => 'warn', 'text' => 'To\'lov vaqti kelajakda ko\'rsatilgan: ' . date('d.m.Y H:i', $pt)];
        elseif ($pt < time() - 7 * 86400) $out[] = ['lvl' => 'info', 'text' => 'To\'lov 7 kundan ilgari qilingan: ' . date('d.m.Y H:i', $pt)];
    }
    $rej = (int)val('SELECT COUNT(*) FROM pay_requests WHERE student_id=? AND status="rejected" AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY) AND id<>?', [(int)$r['student_id'], (int)$r['id']]);
    if ($rej) $out[] = ['lvl' => 'info', 'text' => 'Bu o\'quvchining so\'nggi 30 kunda rad etilgan cheklari: ' . $rej . ' ta'];
    return $out;
}

/**
 * Admin qarori: approve (summa o'zgartirilishi mumkin) yoki reject (sabab bilan). Birinchi qaror kuchda — qayta bosilsa xato qaytadi.
 * Qaytaradi: ['ok'=>bool, 'error'=>string, 'status'=>string, 'balance'=>int, 'settled'=>[…]]
 */
function pay_request_decide(int $id, string $decision, int $amount, string $note, ?string $actor = null): array
{
    $actor = $actor ?? actor_tag();
    $note = mb_substr(trim($note), 0, 255);
    if ($decision === 'approve' && ($amount < 1 || $amount > PAY_MAX_AMOUNT)) return ['ok' => false, 'error' => 'Tasdiqlanadigan summa noto\'g\'ri', 'status' => ''];
    if ($decision === 'reject' && $note === '') return ['ok' => false, 'error' => 'Rad etish sababini tanlang yoki yozing', 'status' => ''];
    if ($decision !== 'approve' && $decision !== 'reject') return ['ok' => false, 'error' => 'Noma\'lum qaror', 'status' => ''];
    $res = db_tx(function () use ($id, $decision, $amount, $note, $actor) {
        $r = row('SELECT * FROM pay_requests WHERE id=? FOR UPDATE', [$id]);
        if (!$r) return ['ok' => false, 'error' => 'Chek topilmadi', 'status' => ''];
        if ($r['status'] !== 'pending')
            return ['ok' => false, 'error' => 'Bu chek allaqachon ko\'rib chiqilgan: ' . mb_strtolower(PAY_STATUS[$r['status']] ?? $r['status'])
                . ($r['reviewed_by'] !== '' ? ' — ' . actor_label((string)$r['reviewed_by']) : '') . ($r['reviewed_at'] ? ', ' . date('d.m.Y H:i', strtotime((string)$r['reviewed_at'])) : ''), 'status' => (string)$r['status']];
        if ($decision === 'reject') {
            q('UPDATE pay_requests SET status="rejected", review_note=?, reviewed_by=?, reviewed_at=NOW() WHERE id=?', [$note, mb_substr($actor, 0, 24), $id]);
            audit('pay_reject', 'pay', $id, ['status' => 'pending'], ['status' => 'rejected', 'note' => $note], $actor);
            return ['ok' => true, 'error' => '', 'status' => 'rejected', 'sid' => (int)$r['student_id'], 'req' => $r];
        }
        $w = wallet_post((int)$r['student_id'], $amount, 'topup', ['ref_type' => 'pay', 'ref_id' => $id, 'method' => (string)$r['method'],
            'note' => $amount !== (int)$r['amount'] ? 'o\'quvchi yozgan: ' . som((int)$r['amount']) : '', 'actor' => $actor]);
        if (!$w['ok']) return ['ok' => false, 'error' => $w['error'], 'status' => 'pending'];
        q('UPDATE pay_requests SET status="approved", approved_amount=?, review_note=?, reviewed_by=?, reviewed_at=NOW(), tx_id=? WHERE id=?', [$amount, $note, mb_substr($actor, 0, 24), $w['tx_id'], $id]);
        audit('pay_approve', 'pay', $id, ['status' => 'pending', 'amount' => (int)$r['amount']], ['status' => 'approved', 'amount' => $amount, 'tx' => $w['tx_id']], $actor);
        $settled = mock_settle_unpaid((int)$r['student_id'], $actor);   // band qilingan MOCK lar shu tranzaksiyada to'lanadi
        return ['ok' => true, 'error' => '', 'status' => 'approved', 'sid' => (int)$r['student_id'], 'req' => $r, 'settled' => $settled];
    });
    if (!$res['ok']) return $res;
    $sid = (int)$res['sid'];
    $r = $res['req'];
    if ($res['status'] === 'approved') {
        $settled = $res['settled'];
        $res['balance'] = wallet_balance($sid);
        $part = $amount !== (int)$r['amount'] ? "\n(Siz " . tg_h(som((int)$r['amount'])) . " deb yozgansiz" . ($note !== '' ? ': ' . tg_h($note) : '') . ")" : ($note !== '' ? "\nIzoh: " . tg_h($note) : '');
        wallet_notify($sid, 'payok', $id, "✅ To'lovingiz tasdiqlandi (chek #" . $id . "): <b>+" . tg_h(som($amount)) . "</b>" . $part
            . "\nBalans: <b>" . tg_h(som($res['balance'])) . "</b>" . wallet_settled_text($settled));
    } else {
        $res['settled'] = [];
        $res['balance'] = wallet_balance($sid);
        wallet_notify($sid, 'payno', $id, "❌ Chekingiz (#" . $id . ", " . tg_h(som((int)$r['amount'])) . ") qabul qilinmadi.\nSabab: <b>" . tg_h($note) . "</b>\n\nTo'g'ri chekni saytdagi «Hamyon» sahifasidan qayta yuborishingiz mumkin.");
    }
    mock_expire_unpaid(null, $sid);   // kutilayotgan chek qolmagan bo'lsa — yopilgan ro'yxatdagi to'lanmagan bandlar bekor bo'ladi
    return $res;
}

/** Avtomatik to'langan MOCK lar haqida qator (bot xabari uchun) */
function wallet_settled_text(array $settled): string
{
    if (!$settled) return '';
    $s = "\n\nBand qilingan MOCK lar to'landi:";
    foreach ($settled as $x) $s .= "\n• " . tg_h($x['title']) . ' — ' . tg_h(som((int)$x['price']));
    return $s;
}

/** Kutilayotgan cheklar soni (menyu belgisi uchun, so'rov boshiga bir marta) */
function pay_pending_count(): int
{
    static $n = null;
    if ($n === null) { try { $n = (int)val('SELECT COUNT(*) FROM pay_requests WHERE status="pending"'); } catch (Throwable $e) { $n = 0; } }
    return $n;
}

/* ---------------- Xabarlar ---------------- */

/** O'quvchiga bot xabari (ulangan bo'lsa). $refId — chek/yozuv/test raqami (navbatda takrorlanmasligi uchun) */
function wallet_notify(int $sid, string $kind, int $refId, string $html): void
{
    if (!function_exists('tg_ready') || !tg_ready()) return;
    $chat = val('SELECT tg_chat_id FROM students WHERE id=? AND archived_at IS NULL', [$sid]);
    if (!$chat) return;
    q('DELETE FROM tg_queue WHERE kind=? AND test_id=? AND student_id=?', [$kind, $refId, $sid]);   // xuddi shu MOCK bo'yicha yangi hodisa eski (hali ketmagan) xabarning o'rnini oladi
    tg_enqueue($kind, $refId, $sid, (int)$chat, ['html' => $html]);
}

/** Yangi chek haqida admin chatiga xabar (2.5.0: Sozlamalar → Telegram dagi admin chat; 2.5.1 da — har bir admin, tugmalar bilan) */
function pay_notify_admins(int $id): void
{
    if (!function_exists('tg_ready') || !tg_ready()) return;
    $chat = (int)tg_meta('admin_chat');
    if (!$chat) return;
    $r = row('SELECT p.*, s.full_name, s.code, s.group_name, s.balance FROM pay_requests p JOIN students s ON s.id=p.student_id WHERE p.id=?', [$id]);
    if (!$r) return;
    $flags = pay_flags($r);
    $url = tg_site_url() !== '' ? tg_site_url() . '/index.php?p=pay&id=' . $id : '';
    $s = "🧾 <b>Yangi to'lov cheki #" . $id . "</b>\n" . tg_h($r['full_name']) . " (ID " . tg_h($r['code']) . ")" . ($r['group_name'] !== '' ? ', ' . tg_h($r['group_name']) : '')
        . "\nSumma: <b>" . tg_h(som((int)$r['amount'])) . "</b> · " . tg_h(PAY_METHODS[$r['method']] ?? $r['method'])
        . ($r['card_to'] !== '' ? "\nKartaga: " . tg_h($r['card_to']) : '') . "\nHozirgi balans: " . tg_h(som((int)$r['balance']));
    foreach (array_slice($flags, 0, 3) as $f) $s .= "\n⚠️ " . tg_h($f['text']);
    tg_enqueue('payadm', $id, 0, $chat, ['html' => $s . ($url !== '' ? "\n\nKo'rish va tasdiqlash: " . tg_h($url) : '')]);
}

/** Navbatdagi hamyon xabarini yuborish (tg_run_job dan) */
function wallet_run_job(array $j): array
{
    $p = json_decode((string)$j['payload'], true) ?: [];
    $html = (string)($p['html'] ?? '');
    if ($html === '') return ['ok' => true, 'skip' => 'bo\'sh'];
    return tg_send((int)$j['chat_id'], $html);
}
