<?php
defined('APP_ROOT') || exit;
$centers = centers_list();
$groups = groups_list();

/** Arxivlashda: hali topshirmagan MOCK ro'yxatlaridan chiqarish va yuborilmagan bot/SMS xabarlarini bekor qilish (natijalar saqlanadi) */
function student_archive_cleanup(array $ids): void
{
    if (!$ids) return;
    $in = implode(',', array_fill(0, count($ids), '?'));
    // 2.5: hali o'tkazilmagan MOCK uchun to'langan bo'lsa — pul hamyonga qaytadi (balans saqlanadi; admin naqd qaytarib berishi mumkin)
    foreach (rows("SELECT g.test_id, g.student_id, t.published, t.online, t.online_end, t.test_date FROM test_registrations g JOIN tests t ON t.id=g.test_id
                   WHERE g.student_id IN ($in) AND g.pay_status='paid' AND g.paid_amount>0 AND NOT EXISTS (SELECT 1 FROM responses r WHERE r.test_id=g.test_id AND r.student_id=g.student_id)", $ids) as $g)
        if (!mock_is_over($g)) mock_cancel((int)$g['student_id'], (int)$g['test_id'], 'admin', ['refund' => true, 'note' => 'o\'quvchi arxivlandi', 'notify' => false]);
    // to'langan qatorlar o'chirilmaydi: o'tkazilmaganlari yuqorida qaytarilgan, o'tgan MOCK lardagisi — to'lov izi bo'lib qoladi
    q("DELETE g FROM test_registrations g WHERE g.student_id IN ($in) AND g.pay_status<>'paid' AND NOT EXISTS (SELECT 1 FROM responses r WHERE r.test_id=g.test_id AND r.student_id=g.student_id)", $ids);
    q("DELETE FROM tg_queue WHERE sent_at IS NULL AND student_id IN ($in)", $ids);
}

function student_form_data(): array
{
    $cid = (int)($_POST['center_id'] ?? 0);
    return [
        'last' => trim($_POST['last_name'] ?? ''), 'first' => trim($_POST['first_name'] ?? ''), 'middle' => trim($_POST['middle_name'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''), 'school' => trim($_POST['school'] ?? ''), 'grade_level' => trim($_POST['grade_level'] ?? ''),
        'group' => trim($_POST['group_name'] ?? ''), 'center' => $cid ?: null,
        'pname' => trim($_POST['parent_name'] ?? ''), 'pphone' => trim($_POST['parent_phone'] ?? ''), 'pphone2' => trim($_POST['parent_phone2'] ?? ''),
    ];
}
function student_save(array $d, int $id): ?string
{
    $phone = $d['phone'] === '' ? '' : norm_phone($d['phone']);
    if ($d['phone'] !== '' && $phone === '') return 'Telefon raqam noto\'g\'ri: ' . $d['phone'];
    if ($phone !== '' && val('SELECT 1 FROM students WHERE phone=? AND id<>?', [$phone, $id])) return 'Bu telefon raqam boshqa o\'quvchida bor';
    $pp = $d['pphone'] === '' ? '' : norm_phone($d['pphone']);
    if ($d['pphone'] !== '' && $pp === '') return 'Ota-ona telefoni noto\'g\'ri: ' . $d['pphone'];
    $pp2 = $d['pphone2'] === '' ? '' : norm_phone($d['pphone2']);
    if ($d['pphone2'] !== '' && $pp2 === '') return 'Ota-onaning 2-telefoni noto\'g\'ri: ' . $d['pphone2'];
    if ($id === 0) return null;   // faqat tekshirish
    $oldPhone = (string)val('SELECT phone FROM students WHERE id=?', [$id]);
    if ($d['group'] !== '') q('INSERT IGNORE INTO study_groups (name) VALUES (?)', [$d['group']]);
    q('UPDATE students SET last_name=?, first_name=?, middle_name=?, full_name=?, phone=?, school=?, grade_level=?, group_name=?, center_id=?, parent_name=?, parent_phone=?, parent_phone2=? WHERE id=?',
        [$d['last'], $d['first'], $d['middle'], compose_name($d['last'], $d['first'], $d['middle']), $phone, $d['school'], $d['grade_level'], $d['group'], $d['center'], mb_substr($d['pname'], 0, 120), $pp, $pp2, $id]);
    if ($oldPhone !== $phone) q('UPDATE students SET phone_verified_at=NULL WHERE id=?', [$id]);   // telefon o'zgarsa tasdiq bekor bo'ladi
    return null;
}

if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    if ($act === 'add') {
        $d = student_form_data();
        if ($d['last'] === '' && $d['first'] === '') { flash('Familiya va ismni kiriting', 'err'); redirect('students'); }
        $code = preg_replace('/\D/', '', (string)($_POST['code'] ?? ''));
        if ($code !== '' && val('SELECT 1 FROM students WHERE code=?', [$code])) { flash('ID ' . $code . ' boshqa o\'quvchida bor — bo\'sh qoldiring (avtomatik beriladi)', 'err'); redirect('students'); }
        $pre = student_save($d, 0);   // avval telefonlarni tekshiramiz, keyin yozamiz (yarim yozilgan yozuv qolmasin)
        if ($pre !== null) { flash($pre, 'err'); redirect('students'); }
        $s = find_or_create_student($code, compose_name($d['last'], $d['first'], $d['middle']), $d['group'], $d['center']);
        $err = student_save($d, (int)$s['id']);
        $s = row('SELECT id, code, pin FROM students WHERE id=?', [$s['id']]);
        flash($err ?: ('O\'quvchi saqlandi: ID ' . $s['code'] . ($s['pin'] !== '' ? ', vaqtinchalik parol ' . $s['pin'] : '')), $err ? 'err' : 'ok');
        redirect('students', ['edit' => $s['id']]);
    }
    if ($act === 'edit') {
        $err = student_save(student_form_data(), (int)$_POST['id']);
        flash($err ?: 'Saqlandi', $err ? 'err' : 'ok');
        redirect('students', ['edit' => (int)$_POST['id']]);
    }
    if ($act === 'bulk') {
        $n = 0;
        $group = trim($_POST['group_name'] ?? '');
        $cid = (int)($_POST['center_id'] ?? 0) ?: null;
        foreach (preg_split('/\R/u', (string)$_POST['names']) as $line) {
            $line = trim($line);
            if ($line === '') continue;
            $parts = array_map('trim', preg_split('/[;\t]/', $line));
            if ($parts[0] === '') continue;   // ismsiz qator
            $s = find_or_create_student('', $parts[0], ($parts[1] ?? '') ?: $group, $cid);
            if (!$s) continue;
            if (!empty($parts[2]) && ($ph = norm_phone($parts[2])) && !val('SELECT 1 FROM students WHERE phone=?', [$ph])) q('UPDATE students SET phone=? WHERE id=?', [$ph, $s['id']]);
            if (!empty($parts[3]) && ($pp = norm_phone($parts[3]))) q('UPDATE students SET parent_phone=? WHERE id=?', [$pp, $s['id']]);
            if (!empty($parts[4])) q('UPDATE students SET parent_name=? WHERE id=?', [mb_substr($parts[4], 0, 120), $s['id']]);
            $n++;
        }
        flash("$n ta o'quvchi qo'shildi");
        redirect('students', ['group' => $group]);
    }
    if ($act === 'mass') {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
        if (!$ids) { flash('O\'quvchi tanlanmagan', 'warn'); redirect('students'); }
        $in = implode(',', array_fill(0, count($ids), '?'));
        $op = $_POST['op'] ?? '';
        if ($op === 'group') {
            $g = trim($_POST['to_group'] ?? '');
            q("UPDATE students SET group_name=? WHERE id IN ($in)", array_merge([$g], $ids));
            flash(count($ids) . ' ta o\'quvchi "' . ($g ?: 'guruhsiz') . '" ga o\'tkazildi');
        } elseif ($op === 'center') {
            $c = (int)($_POST['to_center'] ?? 0) ?: null;
            q("UPDATE students SET center_id=? WHERE id IN ($in)", array_merge([$c], $ids));
            flash(count($ids) . ' ta o\'quvchining markazi o\'zgartirildi');
        } elseif ($op === 'moc') {
            $tid = (int)($_POST['to_test'] ?? 0);
            $mode = (string)($_POST['to_pay'] ?? 'auto');
            if (!in_array($mode, can_finance() ? ['auto', 'unpaid', 'cash', 'waive'] : ['auto', 'unpaid'], true)) $mode = 'auto';
            if ($tid && val('SELECT 1 FROM tests WHERE id=?', [$tid])) {
                $cnt = ['free' => 0, 'paid' => 0, 'unpaid' => 0, 'waived' => 0, 'exists' => 0, 'error' => 0];
                foreach ($ids as $sid) {
                    try { $r = mock_register($sid, $tid, 'admin', ['pay' => $mode, 'force' => true]); }
                    catch (Throwable $ex) { error_log('[MOCK moc-bulk] ' . $ex->getMessage()); $r = ['ok' => false, 'status' => 'error']; }
                    $k = $r['ok'] ? $r['status'] : 'error';
                    $cnt[isset($cnt[$k]) ? $k : 'error']++;
                }
                $n = $cnt['free'] + $cnt['paid'] + $cnt['unpaid'] + $cnt['waived'];
                flash("$n ta o'quvchi MOCK ro'yxatiga qo'shildi" . ($cnt['paid'] ? ", to'langan: " . $cnt['paid'] : '') . ($cnt['unpaid'] ? ", band (to'lov kutilmoqda): " . $cnt['unpaid'] : '')
                    . ($cnt['waived'] ? ', imtiyoz: ' . $cnt['waived'] : '') . ($cnt['exists'] ? ' (' . $cnt['exists'] . ' tasi avval qo\'shilgan edi)' : '') . ($cnt['error'] ? ', xato: ' . $cnt['error'] . ' (arxivdagi o\'quvchilar qo\'shilmaydi)' : ''));
            } else flash('MOCK tanlanmagan', 'warn');
        } elseif ($op === 'sendtemp') {
            $n = 0; $skip = 0; $none = 0;
            foreach (rows("SELECT * FROM students WHERE id IN ($in)", $ids) as $s) {
                if ((int)$s['must_change'] !== 1 || (string)$s['pin'] === '') { $skip++; continue; }
                if (msg_queue_temp($s) === '') $none++; else $n++;
            }
            if ($n) tg_tick(25);
            flash("Vaqtinchalik parol navbatga qo'yildi: $n ta" . ($skip ? ", o'z parolini belgilaganlar o'tkazildi: $skip" : '') . ($none ? ", bot/telefon yo'q: $none" : ''), $n ? 'ok' : 'warn');
        } elseif ($op === 'archive' || $op === 'unarchive') {
            $n = q($op === 'archive' ? "UPDATE students SET archived_at=NOW() WHERE archived_at IS NULL AND id IN ($in)" : "UPDATE students SET archived_at=NULL WHERE archived_at IS NOT NULL AND id IN ($in)", $ids)->rowCount();
            if ($op === 'archive') student_archive_cleanup($ids);
            flash($op === 'archive' ? "$n ta o'quvchi arxivlandi — ro'yxatlar, topshiriqlar va bot xabarlarida chiqmaydi, kabinetga kira olmaydi. Natijalari saqlanadi." : "$n ta o'quvchi arxivdan chiqarildi");
        } elseif ($op === 'delete') {
            // 2.5: pul tarixi (hamyon yozuvi yoki chek) bor o'quvchi o'chirilmaydi — faqat arxivlanadi
            $keep = array_map('intval', array_column(rows("SELECT DISTINCT student_id FROM wallet_tx WHERE student_id IN ($in) UNION SELECT DISTINCT student_id FROM pay_requests WHERE student_id IN ($in)", array_merge($ids, $ids)), 'student_id'));
            $del = array_values(array_diff($ids, $keep));
            if ($del) q('DELETE FROM students WHERE id IN (' . implode(',', array_fill(0, count($del), '?')) . ')', $del);
            flash(count($del) . ' ta o\'quvchi o\'chirildi' . ($keep ? '. ' . count($keep) . ' tasida pul tarixi bor — o\'chirilmadi (arxivlash mumkin)' : ''), $keep ? 'warn' : 'ok');
        }
        redirect('students', array_filter(['group' => $_POST['f_group'] ?? '', 's' => $_POST['f_s'] ?? '', 'arch' => $_POST['f_arch'] ?? '']));
    }
    if ($act === 'archive' || $act === 'unarchive') {
        q('UPDATE students SET archived_at=' . ($act === 'archive' ? 'NOW()' : 'NULL') . ' WHERE id=?', [(int)$_POST['id']]);
        if ($act === 'archive') student_archive_cleanup([(int)$_POST['id']]);
        flash($act === 'archive' ? 'O\'quvchi arxivlandi. Natijalari saqlanadi; kabinetga kira olmaydi, ro\'yxat va topshiriqlarda chiqmaydi.' : 'O\'quvchi arxivdan chiqarildi');
        redirect('students', ['edit' => (int)$_POST['id']] + ($act === 'archive' ? ['arch' => '1'] : []));
    }
    if ($act === 'tg_unlink') {
        q('UPDATE students SET tg_chat_id=NULL, tg_username="", tg_linked_at=NULL WHERE id=?', [(int)$_POST['id']]);
        flash('Telegram ulanishi uzildi');
        redirect('students', ['edit' => (int)$_POST['id']]);
    }
    if ($act === 'temp') {   // yangi vaqtinchalik parol: eski parol ishlamaydi, o'quvchi kirgach yangisini belgilaydi
        $np = gen_temp_pass();
        student_set_pass((int)$_POST['id'], $np, true);
        flash('Yangi vaqtinchalik parol: ' . $np . ' — o\'quvchiga bering yoki «Botga/SMS ga yuborish» tugmasini bosing. Eski parol endi ishlamaydi.');
        redirect('students', ['edit' => (int)$_POST['id']]);
    }
    if ($act === 'send_temp') {
        $s = row('SELECT * FROM students WHERE id=?', [(int)$_POST['id']]);
        if (!$s) redirect('students');
        if ((int)$s['must_change'] !== 1 || (string)$s['pin'] === '') {   // o'quvchi o'z parolini belgilagan — yangisini yaratish kerak
            $np = gen_temp_pass(); student_set_pass((int)$s['id'], $np, true);
            $s = row('SELECT * FROM students WHERE id=?', [$s['id']]);
        }
        $via = msg_queue_temp($s);
        if ($via === '') flash('Yuborib bo\'lmadi: o\'quvchi botga ulanmagan va SMS uchun telefon/Eskiz yo\'q. Parol: ' . $s['pin'], 'err');
        else { tg_tick(15); flash('Vaqtinchalik parol ' . ($via === 'bot' ? 'Telegram bot' : 'SMS') . ' orqali yuborildi' . ' (navbat: «Sozlamalar» da holatini ko\'rish mumkin)'); }
        redirect('students', ['edit' => (int)$s['id']]);
    }
    if ($act === 'delete') {
        if (wallet_has_history((int)$_POST['id'])) { flash('Bu o\'quvchida pul tarixi (hamyon yozuvlari yoki cheklar) bor — o\'chirib bo\'lmaydi, faqat arxivlash mumkin.', 'err'); redirect('students', ['edit' => (int)$_POST['id']]); }
        q('DELETE FROM students WHERE id=?', [(int)$_POST['id']]);
        flash('O\'chirildi');
        redirect('students');
    }
    if ($act === 'delete_demo') {
        $ids = array_column(rows('SELECT DISTINCT student_id FROM responses WHERE source="demo"'), 'student_id');
        q('DELETE FROM tests WHERE id IN (SELECT test_id FROM (SELECT DISTINCT test_id FROM responses WHERE source="demo") x)');
        foreach ($ids as $id) if (!wallet_has_history((int)$id)) q('DELETE FROM students WHERE id=? AND NOT EXISTS (SELECT 1 FROM responses WHERE student_id=?)', [$id, $id]);
        flash('Namuna ma\'lumotlar o\'chirildi');
        redirect('students');
    }
}
$search = trim($_GET['s'] ?? '');
$group = trim($_GET['group'] ?? '');
$center = $_GET['center'] ?? '';
$source = $_GET['source'] ?? '';
$arch = ($_GET['arch'] ?? '') === '1' ? '1' : '';
$where = [$arch ? 'archived_at IS NOT NULL' : 'archived_at IS NULL']; $par = [];
if ($search !== '') { [$sw, $sp] = student_search_sql($search); $where[] = str_replace('s.', '', $sw); $par = array_merge($par, $sp); }   // raqamsiz qidiruvda telefon sharti qo'shilmaydi (aks holda hammasi chiqardi)
if ($group !== '') { $where[] = 'group_name=?'; $par[] = $group; }
if ($center === 'own') $where[] = 'center_id IS NULL';
elseif ($center !== '') { $where[] = 'center_id=?'; $par[] = (int)$center; }
if ($source !== '') { $where[] = 'source=?'; $par[] = $source; }
$total = (int)val('SELECT COUNT(*) FROM students WHERE ' . implode(' AND ', $where), $par);
$list = rows('SELECT s.*, (SELECT COUNT(*) FROM responses r WHERE r.student_id=s.id) n FROM students s WHERE ' . implode(' AND ', $where)
    . ($arch ? ' ORDER BY s.archived_at DESC, s.full_name' : ' ORDER BY s.created_at DESC, s.full_name') . ' LIMIT 1000', $par);
$nArch = (int)val('SELECT COUNT(*) FROM students WHERE archived_at IS NOT NULL');
$editing = isset($_GET['edit']) ? row('SELECT * FROM students WHERE id=?', [(int)$_GET['edit']]) : null;
$hasDemo = (bool)val('SELECT 1 FROM responses WHERE source="demo" LIMIT 1');
$nReg = (int)val('SELECT COUNT(*) FROM students WHERE source="register" AND archived_at IS NULL');
$nAll = (int)val('SELECT COUNT(*) FROM students WHERE archived_at IS NULL');
$nPhone = (int)val('SELECT COUNT(*) FROM students WHERE phone<>"" AND archived_at IS NULL');

function student_fields(?array $s, array $groups, array $centers, string $defGroup = ''): void
{ ?>
  <div class="grid3">
    <label>Familiya <input name="last_name" value="<?= e($s['last_name'] ?? '') ?>" required></label>
    <label>Ism <input name="first_name" value="<?= e($s['first_name'] ?? '') ?>" required></label>
    <label>Otasining ismi <input name="middle_name" value="<?= e($s['middle_name'] ?? '') ?>"></label>
  </div>
  <div class="grid2">
    <label>Telefon <input name="phone" value="<?= e($s ? fmt_phone($s['phone']) : '') ?>" placeholder="+998 90 123 45 67" inputmode="tel"></label>
    <label>Maktab <input name="school" value="<?= e($s['school'] ?? '') ?>"></label>
    <label>Sinf <input name="grade_level" value="<?= e($s['grade_level'] ?? '') ?>" placeholder="11-sinf"></label>
    <label>Guruh <input name="group_name" value="<?= e($s['group_name'] ?? $defGroup) ?>" list="groups"></label>
  </div>
  <input type="hidden" name="center_id" value="<?= (int)($s['center_id'] ?? 0) ?>">
  <fieldset class="parent-fs"><legend>Ota-ona (natija SMS uchun)</legend>
    <div class="grid3">
      <label>Ism <input name="parent_name" value="<?= e($s['parent_name'] ?? '') ?>" maxlength="120" placeholder="Karimov Anvar"></label>
      <label>Telefon <input name="parent_phone" value="<?= e(!empty($s['parent_phone']) ? fmt_phone($s['parent_phone']) : '') ?>" placeholder="+998 90 123 45 67" inputmode="tel"></label>
      <label>2-telefon <input name="parent_phone2" value="<?= e(!empty($s['parent_phone2']) ? fmt_phone($s['parent_phone2']) : '') ?>" placeholder="ixtiyoriy" inputmode="tel"></label>
    </div>
  </fieldset>
<?php }

page_header('O\'quvchilar');
?>
<div class="page-head">
  <div><h1>O'quvchilar<?= $arch ? ' — arxiv' : '' ?></h1><p class="muted" style="margin:0"><?= $nAll ?> ta faol · <?= $nReg ?> ta onlayn ro'yxatdan o'tgan · <?= $nPhone ?> ta telefon raqamli
    · <?= $arch ? '<a href="' . e(url('students')) . '">← faol o\'quvchilar</a>' : '<a href="' . e(url('students', ['arch' => '1'])) . '">arxivda: ' . $nArch . ' ta</a>' ?></p></div>
  <div class="row gap wrap">
    <a class="btn ghost" href="<?= e(url('groups')) ?>"><?= icon('users', 16) ?>Guruhlar</a>
    <a class="btn ghost" target="_blank" href="<?= e(url('cards', ['group' => $group])) ?>"><?= icon('print', 16) ?>ID va parol kartochkalari</a>
    <a class="btn ghost" href="<?= e(url('export', array_filter(['what' => 'students', 'group' => $group, 'source' => $source, 'arch' => $arch]))) ?>"><?= icon('download', 16) ?>Excel</a>
  </div>
</div>
<form class="row gap wrap filter" method="get">
  <input type="hidden" name="p" value="students"><?php if ($arch): ?><input type="hidden" name="arch" value="1"><?php endif; ?>
  <input name="s" value="<?= e($search) ?>" placeholder="Ism, ID, telefon yoki maktab" aria-label="Qidirish">
  <select name="group" aria-label="Guruh"><option value="">Barcha guruhlar</option><?php foreach ($groups as $g): ?><option <?= $g === $group ? 'selected' : '' ?>><?= e($g) ?></option><?php endforeach; ?></select>
  <select name="source" aria-label="Manba"><option value="">Barcha manbalar</option><option value="register" <?= $source === 'register' ? 'selected' : '' ?>>Onlayn ro'yxat</option><option value="admin" <?= $source === 'admin' ? 'selected' : '' ?>>Admin qo'shgan</option></select>
  <button class="btn">Filtr</button>
  <span class="muted small"><?= $total ?> ta topildi</span>
</form>
<div class="grid-side">
<form method="post" id="massForm">
  <?= csrf_field() ?><input type="hidden" name="action" value="mass">
  <input type="hidden" name="f_group" value="<?= e($group) ?>"><input type="hidden" name="f_s" value="<?= e($search) ?>"><input type="hidden" name="f_arch" value="<?= e($arch) ?>">
  <div class="mass-bar card soft">
    <label class="check"><input type="checkbox" id="checkAll"> Barchasi</label>
    <select name="op" id="massOp" aria-label="Amal"><option value="group">Guruhga o'tkazish</option><?php if ($arch): ?><option value="unarchive">Arxivdan chiqarish</option><?php else: ?><option value="moc">MOCK ga biriktirish</option><option value="sendtemp">Vaqtinchalik parolni yuborish (bot/SMS)</option><option value="archive">Arxivlash</option><?php endif; ?><option value="delete">O'chirish</option></select>
    <select name="to_group" class="op-group" aria-label="Qaysi guruhga"><option value="">— guruhsiz —</option><?php foreach ($groups as $g): ?><option><?= e($g) ?></option><?php endforeach; ?></select>
    <select name="to_test" class="op-moc" hidden aria-label="Qaysi MOCK ga"><?php foreach (rows('SELECT id, title, price FROM tests ORDER BY id DESC') as $tt): ?><option value="<?= (int)$tt['id'] ?>"><?= e($tt['title']) ?><?= (int)$tt['price'] > 0 ? ' — ' . e(som((int)$tt['price'])) : '' ?></option><?php endforeach; ?></select>
    <select name="to_pay" class="op-moc" hidden aria-label="To'lov (pullik MOCK uchun)" title="Faqat pullik MOCK uchun; bepulda e'tiborga olinmaydi">
      <option value="auto">Hamyondan (yetmasa — band)</option><option value="unpaid">Band — to'lov kutiladi</option>
      <?php if (can_finance()): ?><option value="cash">Naqd to'langan</option><option value="waive">Bepul (imtiyoz)</option><?php endif; ?>
    </select>
    <button class="btn sm" onclick="return document.getElementById('massOp').value!=='delete' || confirm('Tanlangan o\'quvchilar va ularning javoblari o\'chirilsinmi?')">Bajarish</button>
    <span class="muted small" id="selCount">0 ta tanlangan</span>
  </div>
  <div class="table-wrap"><table class="tbl compact-tbl stu-tbl">
    <thead><tr><th></th><th>ID</th><th>F.I.Sh</th><th>Telefon</th><th>Guruh</th><th>Parol</th><th class="num">Testlar</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($list as $s): ?>
      <tr>
        <td><input type="checkbox" name="ids[]" value="<?= (int)$s['id'] ?>" class="rowchk" aria-label="Belgilash"></td>
        <td class="mono"><?= e($s['code']) ?></td>
        <td><?= e($s['full_name']) ?><?php if ($s['source'] === 'register'): ?> <span class="tag blue" title="Onlayn ro'yxatdan o'tgan">onlayn</span><?php endif; ?><?php if ($s['tg_chat_id'] !== null): ?> <span class="tag green" title="Telegram botga ulangan<?= $s['tg_username'] ? ': @' . e($s['tg_username']) : '' ?>">TG</span><?php endif; ?>
          <?php if ($s['school'] || $s['grade_level']): ?><div class="small muted"><?= e(trim($s['school'] . ' · ' . $s['grade_level'], ' ·')) ?></div><?php endif; ?></td>
        <td class="nowrap small"><?= e($s['phone'] ? fmt_phone($s['phone']) : '—') ?></td>
        <td class="small"><?= e($s['group_name'] ?: '—') ?><?php if ($s['archived_at']): ?><div class="muted">arxiv: <?= e(date('d.m.Y', strtotime((string)$s['archived_at']))) ?></div><?php endif; ?></td>
        <td class="mono small"><?php if ($s['pin'] !== '' && (int)$s['must_change'] === 1): ?><?= e($s['pin']) ?> <span class="tag" title="Vaqtinchalik — o'quvchi hali almashtirmagan">vaqtinchalik</span><?php else: ?><span class="muted" title="O'quvchi o'zi belgilagan">o'zi belgilagan</span><?php endif; ?></td>
        <td class="num"><?= (int)$s['n'] ?></td>
        <td class="right"><a class="btn sm ghost" href="<?= e(url('students', ['edit' => $s['id']])) ?>">Tahrirlash</a></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$list): ?><tr><td colspan="8" class="empty">O'quvchi topilmadi</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</form>
<div>
  <?php if ($editing): ?>
  <div class="card">
    <h2>Tahrirlash — ID <?= e($editing['code']) ?><?= $editing['archived_at'] ? ' <span class="tag red">arxivda</span>' : '' ?> <a class="btn sm ghost" href="<?= e(url('qb_mastery', ['sid' => $editing['id']])) ?>">O'zlashtirish →</a></h2>
    <form method="post" class="form">
      <?= csrf_field() ?><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="<?= (int)$editing['id'] ?>">
      <?php student_fields($editing, $groups, $centers); ?>
      <p class="small">Hamyon: <b><?= e(som((int)$editing['balance'])) ?></b><?php $pend = (int)val('SELECT COUNT(*) FROM pay_requests WHERE student_id=? AND status="pending"', [$editing['id']]); ?><?= $pend ? ' · <span class="tag amber">' . $pend . ' ta chek kutilmoqda</span>' : '' ?>
        <?php if (can_finance()): ?>· <a href="<?= e(url('wallets', ['sid' => $editing['id']])) ?>">Hamyon va to'lovlar →</a><?php endif; ?></p>
      <p class="small">Telegram: <?php if ($editing['tg_chat_id'] !== null): ?><span class="tag green">ulangan</span> <?= $editing['tg_username'] ? '@' . e($editing['tg_username']) : '' ?> <span class="muted"><?= e(substr((string)$editing['tg_linked_at'], 0, 16)) ?></span><?php else: ?><span class="muted">ulanmagan — o'quvchi botga ID va parol yuborsin yoki kabinetdagi «Telegramni ulash» tugmasini bossin</span><?php endif; ?></p>
      <p>Parol: <?php if ($editing['pin'] !== '' && (int)$editing['must_change'] === 1): ?><b class="mono"><?= e($editing['pin']) ?></b> <span class="tag">vaqtinchalik</span><?php else: ?><span class="muted">o'quvchi o'zi belgilagan</span><?php endif; ?>
        <span class="muted small">· <?= $editing['source'] === 'register' ? 'onlayn ro\'yxatdan o\'tgan' : 'admin qo\'shgan' ?> · <?= e(substr((string)$editing['created_at'], 0, 16)) ?><?= $editing['last_login'] ? ' · oxirgi kirish ' . e(substr((string)$editing['last_login'], 0, 16)) : ' · hali kirmagan' ?></span>
        <?php if ($editing['parent_tg_chat'] !== null): ?><br><span class="small"><span class="tag green">ota-ona Telegrami ulangan</span></span><?php endif; ?>
        <?php if ($editing['parent_optout']): ?><br><span class="small"><span class="tag red">ota-ona natija olishni rad etgan</span></span><?php endif; ?>
        <?php if ($editing['phone'] !== ''): ?><br><span class="small"><?= $editing['phone_verified_at'] ? '<span class="tag green">telefon tasdiqlangan</span>' : '<span class="muted">telefon tasdiqlanmagan</span>' ?></span><?php endif; ?></p>
      <button class="btn primary">Saqlash</button>
    </form>
    <div class="row gap mt">
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="temp"><input type="hidden" name="id" value="<?= (int)$editing['id'] ?>"><button class="btn sm" onclick="return confirm('Yangi vaqtinchalik parol yaratilsinmi? Eski parol ishlamay qoladi.')">Yangi vaqtinchalik parol</button></form>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="send_temp"><input type="hidden" name="id" value="<?= (int)$editing['id'] ?>"><button class="btn sm ghost" title="Botga ulangan bo'lsa botga, aks holda SMS bilan">Parolni botga/SMS ga yuborish</button></form>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="<?= $editing['archived_at'] ? 'unarchive' : 'archive' ?>"><input type="hidden" name="id" value="<?= (int)$editing['id'] ?>"><button class="btn sm ghost" title="<?= $editing['archived_at'] ? '' : 'Bitirgan / ketgan o\'quvchi: natijalari saqlanadi, lekin ro\'yxat, topshiriq va bot xabarlarida chiqmaydi, kabinetga kira olmaydi' ?>"><?= $editing['archived_at'] ? 'Arxivdan chiqarish' : 'Arxivlash' ?></button></form>
      <form method="post" onsubmit="return confirm('O\'quvchi va uning barcha javoblari o\'chirilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$editing['id'] ?>"><button class="btn sm danger-ghost">O'chirish</button></form>
      <?php if ($editing['tg_chat_id'] !== null): ?><form method="post" onsubmit="return confirm('Telegram ulanishi uzilsinmi? O\'quvchi botga xabar ololmaydi.')"><?= csrf_field() ?><input type="hidden" name="action" value="tg_unlink"><input type="hidden" name="id" value="<?= (int)$editing['id'] ?>"><button class="btn sm ghost">TG ni uzish</button></form><?php endif; ?>
    </div>
  </div>
  <?php endif; ?>
  <details class="card" <?= $editing ? '' : 'open' ?>>
    <summary><h2 style="display:inline">Bitta o'quvchi qo'shish</h2></summary>
    <form method="post" class="form mt">
      <?= csrf_field() ?><input type="hidden" name="action" value="add">
      <?php student_fields(null, $groups, $centers, $group); ?>
      <label>ID (ixtiyoriy) <input name="code" maxlength="6" placeholder="avtomatik"></label>
      <button class="btn primary">Qo'shish</button>
    </form>
  </details>
  <details class="card">
    <summary><h2 style="display:inline">Ro'yxatni qo'shish</h2></summary>
    <form method="post" class="form mt">
      <?= csrf_field() ?><input type="hidden" name="action" value="bulk">
      <label>Har qatorda bitta o'quvchi: <code>F.I.Sh</code> yoki <code>F.I.Sh; Guruh; Telefon; Ota-ona telefoni; Ota-ona ismi</code>
        <textarea name="names" rows="7" placeholder="Karimov Aziz Anvar o'g'li&#10;Rahimova Dilnoza; 11-B; +998901234567; +998931112233; Rahimov Anvar"></textarea></label>
      <div class="grid2">
        <label>Guruh (standart) <input name="group_name" list="groups" value="<?= e($group) ?>"></label>

      </div>
      <button class="btn primary">Qo'shish</button>
    </form>
  </details>
  <?php if ($hasDemo): ?>
  <form method="post" class="card" onsubmit="return confirm('Namuna test va sinov o\'quvchilari o\'chirilsinmi?')">
    <?= csrf_field() ?><input type="hidden" name="action" value="delete_demo">
    <p class="small muted">O'rnatishda qo'shilgan namuna ma'lumotlarni o'chirish.</p>
    <button class="btn sm danger-ghost">Namuna ma'lumotlarni o'chirish</button>
  </form>
  <?php endif; ?>
</div>
</div>
<datalist id="groups"><?php foreach ($groups as $g): ?><option><?= e($g) ?></option><?php endforeach; ?></datalist>
<script>
(function(){
  const all=document.getElementById('checkAll'), boxes=[...document.querySelectorAll('.rowchk')], cnt=document.getElementById('selCount');
  const upd=()=>cnt.textContent=boxes.filter(b=>b.checked).length+' ta tanlangan';
  all.addEventListener('change',()=>{boxes.forEach(b=>b.checked=all.checked);upd();});
  boxes.forEach(b=>b.addEventListener('change',upd));
  const op=document.getElementById('massOp');
  op.addEventListener('change',()=>{document.querySelector('.op-group').hidden=op.value!=='group';document.querySelectorAll('.op-moc').forEach(x=>x.hidden=op.value!=='moc');});
})();
</script>
<?php page_footer();
