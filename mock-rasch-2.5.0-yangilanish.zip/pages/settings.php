<?php
defined('APP_ROOT') || exit;
$me = admin();
if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    if ($act === 'general') {
        set_app_setting('center', trim($_POST['center'] ?? ''));
        $pu = trim($_POST['public_url'] ?? '');
        if ($pu !== '' && !preg_match('#^https?://[^\s]+$#i', $pu)) { flash('Sayt manzili http:// yoki https:// bilan boshlansin', 'err'); redirect('settings'); }
        set_app_setting('public_url', $pu);
        if (isset($_POST['qb_wm'])) set_app_setting('qb_wm', mb_substr(trim((string)preg_replace('/\s+/u', ' ', (string)$_POST['qb_wm'])), 0, 40));
        flash('Sozlamalar saqlandi');
    }
    if ($act === 'rooms') {
        if (isset($_POST['rooms'])) {   // eski (matnli) forma — orqaga moslik
            [$list, $bad] = center_rooms_parse((string)$_POST['rooms']);
            $draft = [];
        } else {                         // 2.3: jadval — har qator: nomi, sig'imi, nazoratchi
            [$list, $bad, $draft] = center_rooms_rows((array)($_POST['rname'] ?? []), (array)($_POST['rcap'] ?? []), (array)($_POST['rproc'] ?? []));
        }
        if ($bad) {
            flash('Xonalar saqlanmadi: ' . implode('; ', array_slice($bad, 0, 4)) . '. Qizil qatorlarni tuzatib, qayta saqlang.', 'err');
            $_SESSION['rooms_draft'] = $draft;
            header('Location: ' . url('settings') . '#xonalar');
            exit;
        }
        q('DELETE FROM center_rooms');
        foreach ($list as $i => $r) q('INSERT INTO center_rooms (name, capacity, proctor, sort) VALUES (?,?,?,?)', [$r['name'], $r['capacity'], $r['proctor'], $i + 1]);
        flash($list ? count($list) . ' ta xona saqlandi (jami ' . array_sum(array_column($list, 'capacity')) . ' o\'rin). MOCK ning «Ro\'yxat» sahifasida «Markaz xonalarini qo\'shish» tugmasi bilan testga qo\'shiladi.' : 'Xonalar ro\'yxati tozalandi');
        header('Location: ' . url('settings') . '#xonalar');
        exit;
    }
    // 2.5: to'lov sozlamalari va «Moliya» huquqi — faqat moliya huquqi bor admin o'zgartiradi
    if ($act === 'pay' && can_finance()) {
        $before = ['cards' => pay_cards(), 'min' => pay_min(), 'cancel' => pay_cancel_min(), 'pending' => pay_max_pending()];
        $cards = [];
        $nos = (array)($_POST['card_no'] ?? []);
        foreach (array_slice($nos, 0, 3, true) as $i => $no) {
            $no = trim((string)preg_replace('/\s+/u', ' ', (string)$no));
            if ($no === '') continue;
            $dg = preg_replace('/\D/', '', $no);
            if (strlen($dg) === 16 && $dg === preg_replace('/[\s-]/', '', $no)) $no = implode(' ', str_split($dg, 4));   // 8600123412341234 → 8600 1234 1234 1234
            $cards[] = ['no' => mb_substr($no, 0, 40), 'owner' => mb_substr(trim((string)($_POST['card_owner'][$i] ?? '')), 0, 60), 'bank' => mb_substr(trim((string)($_POST['card_bank'][$i] ?? '')), 0, 30)];
        }
        set_app_setting('pay_cards', json_encode($cards, JSON_UNESCAPED_UNICODE));
        set_app_setting('pay_note', mb_substr(trim((string)($_POST['pay_note'] ?? '')), 0, 1000));
        set_app_setting('pay_min', (string)max(1000, min(1000000, money_in($_POST['pay_min'] ?? '5000') ?: 5000)));
        set_app_setting('pay_cancel_min', (string)max(0, min(10080, (int)($_POST['pay_cancel_min'] ?? 60))));
        set_app_setting('pay_max_pending', (string)max(1, min(10, (int)($_POST['pay_max_pending'] ?? 3))));
        audit('settings_pay', 'settings', null, $before, ['cards' => $cards, 'min' => $_POST['pay_min'] ?? '', 'cancel' => $_POST['pay_cancel_min'] ?? '', 'pending' => $_POST['pay_max_pending'] ?? '']);
        flash('To\'lov sozlamalari saqlandi');
        header('Location: ' . url('settings') . '#tolov');
        exit;
    }
    if ($act === 'finance' && can_finance()) {
        $uid = (int)($_POST['id'] ?? 0);
        $on = (int)val('SELECT can_finance FROM users WHERE id=?', [$uid]);
        if ($on && (int)val('SELECT COUNT(*) FROM users WHERE can_finance=1') <= 1) flash('Kamida bitta administratorda «Moliya» huquqi qolishi kerak', 'err');
        else {
            q('UPDATE users SET can_finance=? WHERE id=?', [$on ? 0 : 1, $uid]);
            audit('finance_toggle', 'user', $uid, ['can_finance' => $on], ['can_finance' => $on ? 0 : 1]);
            flash($on ? '«Moliya» huquqi olindi' : '«Moliya» huquqi berildi');
        }
        redirect('settings');
    }
    if (tg_settings_post($act)) redirect('settings');
    if (msg_settings_post($act)) redirect('settings');
    if ($act === 'password') {
        $u = row('SELECT * FROM users WHERE id=?', [$me['id']]);
        $new = (string)($_POST['new'] ?? '');
        if (!password_verify((string)($_POST['old'] ?? ''), $u['pass_hash'])) flash('Joriy parol noto\'g\'ri', 'err');
        elseif (strlen($new) < 8) flash('Yangi parol kamida 8 belgidan iborat bo\'lsin', 'err');
        elseif ($new !== ($_POST['new2'] ?? '')) flash('Yangi parollar mos emas', 'err');
        else {
            $nh = password_hash($new, PASSWORD_DEFAULT);
            q('UPDATE users SET pass_hash=? WHERE id=?', [$nh, $me['id']]);
            session_regenerate_id(true);
            $_SESSION['admin']['sig'] = admin_session_sig($nh);   // joriy sessiya qoladi, boshqa qurilmalardagilar tugaydi
            flash('Parol o\'zgartirildi. Boshqa qurilmalardagi sessiyalar yopildi.');
        }
    }
    if ($act === 'add_admin') {
        $login = trim($_POST['login'] ?? '');
        $pass = (string)($_POST['pass'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_.-]{3,32}$/', $login)) flash('Login: 3–32 lotin harf/raqam', 'err');
        elseif (strlen($pass) < 8) flash('Parol kamida 8 belgi', 'err');
        elseif (val('SELECT 1 FROM users WHERE login=?', [$login])) flash('Bunday login bor', 'err');
        else {
            // 2.5: «Moliya» huquqini faqat moliya huquqi bor admin bera oladi (aks holda yangi admin orqali o'ziga huquq olib bo'lardi)
            $fin = can_finance() && !empty($_POST['finance']) ? 1 : 0;
            q('INSERT INTO users (login, pass_hash, name, role, can_finance) VALUES (?,?,?,?,?)', [$login, password_hash($pass, PASSWORD_DEFAULT), trim($_POST['name'] ?? ''), 'admin', $fin]);
            audit('admin_add', 'user', (int)db()->lastInsertId(), null, ['login' => $login, 'can_finance' => $fin]);
            flash('Administrator qo\'shildi' . ($fin ? ' («Moliya» huquqi bilan)' : ''));
        }
    }
    if ($act === 'del_admin') {
        $id = (int)$_POST['id'];
        if ($id === (int)$me['id']) flash('O\'zingizni o\'chira olmaysiz', 'err');
        elseif ((int)val('SELECT COUNT(*) FROM users') <= 1) flash('Oxirgi administratorni o\'chirib bo\'lmaydi', 'err');
        elseif ((int)val('SELECT can_finance FROM users WHERE id=?', [$id]) === 1 && !can_finance()) flash('«Moliya» huquqi bor administratorni faqat moliya huquqi bor administrator o\'chiradi', 'err');
        elseif ((int)val('SELECT can_finance FROM users WHERE id=?', [$id]) === 1 && (int)val('SELECT COUNT(*) FROM users WHERE can_finance=1') <= 1) flash('Bu — «Moliya» huquqi bor yagona administrator. Avval boshqasiga huquq bering.', 'err');
        else { q('DELETE FROM users WHERE id=?', [$id]); audit('admin_del', 'user', $id, null, null); flash('Administrator o\'chirildi'); }
    }
    redirect('settings');
}
$users = rows('SELECT id, login, name, last_login, created_at, can_finance FROM users ORDER BY id');
$fin = can_finance();
$fails = rows('SELECT kind, ident, ip, COUNT(*) n, MAX(created_at) last FROM login_attempts WHERE created_at > ? AND kind IN ("admin","student") GROUP BY kind, ident, ip ORDER BY last DESC LIMIT 15', [date('Y-m-d H:i:s', time() - 86400)]);
$installExists = is_file(APP_ROOT . '/install.php');
page_header('Sozlamalar');
?>
<div class="page-head"><div><h1>Sozlamalar</h1><p class="muted" style="margin:0">Markaz ma'lumotlari, administratorlar va xavfsizlik.</p></div></div>
<?php if ($installExists): ?><div class="alert warn"><?= icon('alert') ?><span><b>install.php</b> fayli hali serverda turibdi. U <code>config.php</code> bor paytda ishlamaydi, lekin hostingga chiqarganda uni o'chirib qo'yish tavsiya etiladi.</span></div><?php endif; ?>
<?php if (!is_https() && !in_array($_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1'], true) && !str_starts_with((string)($_SERVER['HTTP_HOST'] ?? ''), 'localhost:')): ?>
  <div class="alert warn"><?= icon('alert') ?><span>Sayt <b>HTTPS</b> siz ishlayapti. Internetga chiqarilganda parollar ochiq uzatiladi — hostingda bepul SSL (Let's Encrypt) ni yoqing.</span></div>
<?php endif; ?>
<div class="grid2 settings-grid">
  <div class="card">
    <h2>Markaz</h2>
    <form method="post" class="form">
      <?= csrf_field() ?><input type="hidden" name="action" value="general">
      <label>O'quv markazi nomi <input name="center" value="<?= e(app_setting('center')) ?>"></label>
      <label>Sayt manzili (internetda) <input name="public_url" value="<?= e(app_setting('public_url')) ?>" placeholder="https://moc.markazim.uz"></label>
      <p class="small muted" style="margin-top:-.4rem">Sertifikatdagi QR va ro'yxat havolasi shu manzil bilan yasaladi. Bo'sh bo'lsa — joriy manzil (localhost) ishlatiladi, u telefondan ochilmaydi.</p>
      <label>Testlarda fon yozuvi <input name="qb_wm" value="<?= e(qb_watermark()) ?>" maxlength="40" placeholder="bo'sh — yozuvsiz"></label>
      <p class="small muted" style="margin-top:-.4rem">Savollar PDF lari (mashq, topshiriq, bo'lim) va sinf testi varaqlarining orqa fonida och rangda qiya yoziladi. Bo'sh qoldirilsa — yozuvsiz.</p>
      <button class="btn primary">Saqlash</button>
    </form>
  </div>
  <div class="card">
    <h2>Parolni o'zgartirish</h2>
    <form method="post" class="form" autocomplete="off">
      <?= csrf_field() ?><input type="hidden" name="action" value="password">
      <label>Joriy parol <input type="password" name="old" required autocomplete="current-password"></label>
      <label>Yangi parol (≥ 8 belgi) <input type="password" name="new" required minlength="8" autocomplete="new-password"></label>
      <label>Yangi parol (takror) <input type="password" name="new2" required minlength="8" autocomplete="new-password"></label>
      <button class="btn primary">O'zgartirish</button>
    </form>
  </div>
  <?php
  $cr = center_rooms();
  $draft = $_SESSION['rooms_draft'] ?? null; unset($_SESSION['rooms_draft']);
  $roomRows = is_array($draft) && $draft ? $draft : array_map(fn($r) => ['name' => $r['name'], 'capacity' => (string)(int)$r['capacity'], 'proctor' => $r['proctor'], 'err' => ''], $cr);
  $roomRows[] = ['name' => '', 'capacity' => '', 'proctor' => '', 'err' => ''];   // yangi xona uchun bo'sh qator
  if (count($roomRows) < 3) $roomRows[] = ['name' => '', 'capacity' => '', 'proctor' => '', 'err' => ''];
  ?>
  <div class="card rooms-card" id="xonalar">
    <div class="card-head"><h2>Xonalar va sig'im</h2><span class="rooms-total" id="roomsTotal"><?= $cr ? count($cr) . ' ta xona · ' . array_sum(array_map(fn($r) => (int)$r['capacity'], $cr)) . ' o\'rin' : 'xona kiritilmagan' ?></span></div>
    <p class="small muted">Markazingizdagi imtihon xonalari: nomi va nechta o'quvchi sig'ishi. Bir marta kiritasiz — har bir MOCK ning «Ro'yxat» sahifasida «Markaz xonalarini qo'shish» tugmasi shu ro'yxatni testga ko'chiradi, so'ng o'quvchilar xonalarga avtomatik joylashtiriladi.</p>
    <form method="post" class="form" id="roomsForm">
      <?= csrf_field() ?><input type="hidden" name="action" value="rooms">
      <div class="table-wrap"><table class="tbl rooms-tbl">
        <thead><tr><th class="num">№</th><th>Xona nomi</th><th>Sig'imi</th><th>Nazoratchi <span class="muted small">(ixtiyoriy)</span></th><th><span class="sr-only">Amallar</span></th></tr></thead>
        <tbody id="roomsBody">
        <?php foreach ($roomRows as $i => $r): ?>
          <tr class="croom<?= $r['err'] !== '' ? ' bad' : '' ?>">
            <td class="num rn"><?= $i + 1 ?></td>
            <td><input name="rname[]" value="<?= e($r['name']) ?>" maxlength="60" placeholder="masalan: 1-xona" aria-label="Xona nomi"><?php if ($r['err'] !== ''): ?><small class="critical-t"><?= e($r['err']) ?></small><?php endif; ?></td>
            <td><span class="cap-in"><input type="number" name="rcap[]" value="<?= e($r['capacity']) ?>" min="1" max="500" placeholder="30" aria-label="Sig'imi"><span class="muted small">o'rin</span></span></td>
            <td><input name="rproc[]" value="<?= e($r['proctor']) ?>" maxlength="120" placeholder="F.I.Sh" aria-label="Nazoratchi"></td>
            <td class="nowrap right room-ops"><button type="button" class="btn sm ghost" data-a="up" title="Yuqoriga" aria-label="Yuqoriga">↑</button><button type="button" class="btn sm ghost" data-a="down" title="Pastga" aria-label="Pastga">↓</button><button type="button" class="btn sm danger-ghost" data-a="del" title="Qatorni o'chirish" aria-label="Qatorni o'chirish">✕</button></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
      <div class="row gap wrap center-v">
        <button type="button" class="btn" id="roomAdd"><?= icon('plus', 16) ?>Xona qo'shish</button>
        <button class="btn primary">Saqlash</button>
        <span class="small muted">Bo'sh qatorlar hisobga olinmaydi. Tartib — joylashtirish tartibi.</span>
      </div>
    </form>
  </div>
  <script>
  (function () {
    var body = document.getElementById('roomsBody'), tot = document.getElementById('roomsTotal');
    if (!body) return;
    function refresh() {
      var n = 0, cap = 0;
      [].forEach.call(body.rows, function (tr, i) {
        tr.querySelector('.rn').textContent = i + 1;
        var nm = tr.querySelector('[name="rname[]"]').value.trim(), c = parseInt(tr.querySelector('[name="rcap[]"]').value, 10);
        if (nm !== '' && c > 0) { n++; cap += Math.min(500, c); }
      });
      tot.textContent = n ? n + ' ta xona · ' + cap + ' o\'rin' : 'xona kiritilmagan';
    }
    function blank(tr) { tr.classList.remove('bad'); tr.querySelectorAll('input').forEach(function (i) { i.value = ''; }); var m = tr.querySelector('small'); if (m) m.remove(); }
    document.getElementById('roomAdd').addEventListener('click', function () {
      var last = body.rows[body.rows.length - 1], tr = last.cloneNode(true);
      blank(tr); body.appendChild(tr); refresh(); tr.querySelector('input').focus();
    });
    body.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-a]'); if (!b) return;
      var tr = b.closest('tr'), a = b.getAttribute('data-a');
      if (a === 'del') { if (body.rows.length > 1) tr.remove(); else blank(tr); }
      else if (a === 'up' && tr.previousElementSibling) body.insertBefore(tr, tr.previousElementSibling);
      else if (a === 'down' && tr.nextElementSibling) body.insertBefore(tr.nextElementSibling, tr);
      refresh();
    });
    body.addEventListener('input', refresh);
    refresh();
  })();
  </script>
  <div class="card">
    <h2>Administratorlar</h2>
    <table class="tbl compact-tbl"><thead><tr><th>Login</th><th>Ism</th><th>Oxirgi kirish</th><th title="Cheklarni tasdiqlash, balans va narxlarni o'zgartirish">Moliya</th><th></th></tr></thead><tbody>
      <?php foreach ($users as $u): ?>
        <tr><td class="mono"><?= e($u['login']) ?></td><td><?= e($u['name']) ?></td><td class="small muted"><?= e($u['last_login'] ?? '—') ?></td>
          <td><?php if ($fin): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="finance"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="btn sm <?= (int)$u['can_finance'] ? '' : 'ghost' ?>" title="<?= (int)$u['can_finance'] ? 'Huquqni olish' : 'Huquq berish' ?>"><?= (int)$u['can_finance'] ? '✓ bor' : 'yo\'q' ?></button></form><?php else: ?><?= (int)$u['can_finance'] ? '✓' : '—' ?><?php endif; ?></td>
          <td class="right"><?php if ((int)$u['id'] !== (int)$me['id']): ?><form method="post" class="inline" onsubmit="return confirm('Administrator o\'chirilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="del_admin"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="btn sm danger-ghost">×</button></form><?php else: ?><span class="tag">siz</span><?php endif; ?></td></tr>
      <?php endforeach; ?>
    </tbody></table>
    <form method="post" class="form mt" autocomplete="off">
      <?= csrf_field() ?><input type="hidden" name="action" value="add_admin">
      <div class="grid3"><label>Login <input name="login" required pattern="[A-Za-z0-9_.\-]{3,32}"></label><label>Ism <input name="name"></label><label>Parol <input type="password" name="pass" required minlength="8" autocomplete="new-password"></label></div>
      <?php if (can_finance()): ?><label class="check"><input type="checkbox" name="finance" value="1"> «Moliya» huquqi — cheklarni tasdiqlash, balans va narxlarni o'zgartirish</label><?php endif; ?>
      <button class="btn">Administrator qo'shish</button>
    </form>
  </div>
  <div class="card">
    <h2>Xavfsizlik</h2>
    <ul class="check-list small">
      <li>Parollar <b>bcrypt</b> bilan xeshlanadi, ochiq saqlanmaydi.</li>
      <li>Kirish: 15 daqiqada 5 ta xato urinishdan keyin shu login/ID + IP juftligi bloklanadi (login/ID bo'yicha jami 20, IP bo'yicha 30).</li>
      <li>Barcha formalar CSRF tokeni bilan himoyalangan; SQL so'rovlar parametrlangan (SQL injection yo'q).</li>
      <li>Sessiya cookie: HttpOnly, SameSite; admin 4 soat harakatsiz bo'lsa chiqariladi. Parol o'zgarsa yoki admin o'chirilsa — uning barcha sessiyalari darhol tugaydi.</li>
      <li>HTTP sarlavhalar: CSP, X-Frame-Options, nosniff; <code>inc/</code>, <code>pages/</code>, <code>config.php</code> ga to'g'ridan-to'g'ri kirish yopiq.</li>
      <li>Savollar PDF fayli faqat admin va testni boshlagan o'quvchiga (vaqti tugaguncha) beriladi — to'g'ridan-to'g'ri havola ishlamaydi.</li>
      <li>Sertifikat tekshiruvi: ism va ball faqat QR yoki hujjatdagi o'quvchi ID bilan ochiladi.</li>
      <li>Excel eksportida formula-injeksiyadan himoya; yuklangan PDF haqiqiyligi tekshiriladi.</li>
      <?php if (!behind_trusted_proxy()): ?><li class="muted">Sayt Cloudflare/nginx proksi orqasida bo'lsa <code>config.php</code> ga <code>'trusted_proxy' =&gt; true</code> qo'shing — aks holda barcha tashrifchilar bitta IP ko'rinadi va cheklovlar noto'g'ri ishlaydi.</li><?php endif; ?>
    </ul>
    <h3 class="mt">So'nggi 24 soatdagi xato kirishlar</h3>
    <?php if (!$fails): ?><p class="small muted">Yo'q.</p><?php else: ?>
    <table class="tbl compact-tbl"><thead><tr><th>Tur</th><th>Login/ID</th><th>IP</th><th class="num">Soni</th><th>Oxirgi</th></tr></thead><tbody>
      <?php foreach ($fails as $f): ?><tr class="<?= $f['n'] >= 5 ? 'flag-red' : '' ?>"><td><?= $f['kind'] === 'admin' ? 'Admin' : 'O\'quvchi' ?></td><td class="mono"><?= e($f['ident']) ?></td><td class="mono small"><?= e($f['ip']) ?></td><td class="num"><?= (int)$f['n'] ?></td><td class="small muted"><?= e(substr($f['last'], 11, 5)) ?></td></tr><?php endforeach; ?>
    </tbody></table>
    <?php endif; ?>
  </div>
  <?php if ($fin): $pc = pay_cards(); while (count($pc) < 3) $pc[] = ['no' => '', 'owner' => '', 'bank' => '']; ?>
  <div class="card" id="tolov">
    <h2><?= icon('wallet', 18) ?> To'lov</h2>
    <p class="small muted">O'quvchilar hisobini to'ldirish uchun pul o'tkazadigan kartalar (1–3 ta) va yo'riqnoma. O'quvchi chek yuboradi — siz «Moliya → To'lovlar» da tasdiqlaysiz. MOCK narxi — test sozlamalarida.</p>
    <form method="post" class="form">
      <?= csrf_field() ?><input type="hidden" name="action" value="pay">
      <div class="pay-cards-edit">
        <?php foreach ($pc as $i => $c): ?>
          <div class="pc-row">
            <label>Karta <?= $i + 1 ?> <input name="card_no[]" value="<?= e($c['no']) ?>" maxlength="40" inputmode="numeric" placeholder="8600 0000 0000 0000" class="mono"></label>
            <label>Egasi <input name="card_owner[]" value="<?= e($c['owner']) ?>" maxlength="60" placeholder="Masud M."></label>
            <label>Bank / tur <input name="card_bank[]" value="<?= e($c['bank']) ?>" maxlength="30" placeholder="Uzcard, Humo…"></label>
          </div>
        <?php endforeach; ?>
      </div>
      <label>O'quvchiga yo'riqnoma <span class="muted">(ixtiyoriy)</span><textarea name="pay_note" rows="3" maxlength="1000" placeholder="Masalan: izohga ID raqamingizni yozing. Naqd to'lov — markazda, dushanba–shanba 9:00–18:00."><?= e(pay_note()) ?></textarea></label>
      <div class="grid3">
        <label>Eng kam summa, so'm <input name="pay_min" value="<?= e(number_format(pay_min(), 0, '.', ' ')) ?>" inputmode="numeric"></label>
        <label>Qaytarish muddati, daqiqa <input type="number" name="pay_cancel_min" value="<?= pay_cancel_min() ?>" min="0" max="10080" title="To'lovdan keyin shu vaqt ichida o'quvchi MOCK dan o'zi chiqsa, pul hamyonga to'liq qaytadi. 0 — faqat admin orqali."></label>
        <label title="Bir o'quvchida bir vaqtda tekshirilayotgan cheklar soni">Kutilayotgan chek, max <input type="number" name="pay_max_pending" value="<?= pay_max_pending() ?>" min="1" max="10"></label>
      </div>
      <p class="small muted" style="margin-top:-.3rem">«Qaytarish muddati»: to'lovdan keyin shu vaqt ichida o'quvchi MOCK dan o'zi chiqsa, pul hamyoniga to'liq qaytadi; keyin — faqat admin orqali (0 — o'zi chiqa olmaydi).</p>
      <button class="btn primary">Saqlash</button>
    </form>
  </div>
  <?php endif; ?>
  <?php msg_settings_card(); ?>
  <?php tg_settings_card(); ?>
</div>
<?php page_footer();
