/* 2.5.2: O'quvchilar va MOCK ro'yxati — o'quvchini oynada tahrirlash, guruhga biriktirish, belgilash paneli.
   Sahifalar: ?p=students va ?p=registrations («Ro'yxatdagilar» jadvali). Boshlang'ich ma'lumot — <script id="stuData">.
   Server: index.php?p=stu_api (faqat POST, X-CSRF). JS siz ham hammasi oddiy havola va formalar bilan ishlaydi. */
(function () {
  'use strict';
  const dataEl = document.getElementById('stuData');
  if (!dataEl) return;
  let D;
  try { D = JSON.parse(dataEl.textContent || '{}'); } catch (e) { return; }
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.prototype.slice.call((r || document).querySelectorAll(s));
  const TOKEN = (document.querySelector('meta[name="csrf"]') || {}).content || '';
  const API = 'index.php?p=stu_api';
  const STU = D.page === 'students';
  let G = Array.isArray(D.groups) ? D.groups : [];   // [{name, n}] — guruhlar va faol o'quvchilar soni
  const canModal = typeof HTMLDialogElement === 'function' && typeof HTMLDialogElement.prototype.showModal === 'function';
  const SVG = p => '<svg class="ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
  const ICO_OK = SVG('<path d="M5 12.5l4.5 4.5L19 7.5"/>'), ICO_ERR = SVG('<path d="M12 3 2.5 20h19z"/><path d="M12 10v4M12 17.5v.01"/>');
  const DIRTY_Q = 'Saqlanmagan o\'zgarishlar bor. Oyna yopilsinmi?';

  // ---------- server ----------
  async function api(action, body) {
    let fd;
    if (body instanceof FormData) fd = body;
    else {
      fd = new FormData();
      Object.keys(body || {}).forEach(k => {
        const v = body[k];
        if (Array.isArray(v)) v.forEach(x => fd.append(k + '[]', String(x)));
        else if (v !== undefined && v !== null) fd.append(k, String(v));
      });
    }
    fd.set('action', action);
    let r;
    try { r = await fetch(API, { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF': TOKEN, 'Accept': 'application/json' } }); }
    catch (e) { throw new Error('Server bilan aloqa yo\'q — internetni tekshirib, qayta urinib ko\'ring'); }
    let j = null;
    try { j = await r.json(); } catch (e) { j = null; }
    if (!j) throw new Error(r.ok ? 'Sessiya tugagan — sahifani yangilab, qayta kiring' : 'Server xatosi (' + r.status + '). Sahifani yangilab ko\'ring.');
    if (!j.ok) { const er = new Error(j.error || 'Bajarib bo\'lmadi'); er.field = j.field || ''; throw er; }
    return j;
  }

  // ---------- kichik xabar (pastki burchakda) ----------
  function toast(msg, type) {
    let w = $('.stu-toast');
    if (!w) {
      w = document.createElement('div');
      w.className = 'flash-toast stu-toast';
      w.setAttribute('role', 'status');
      w.setAttribute('aria-live', 'polite');
      document.body.appendChild(w);
    }
    const a = document.createElement('div');
    a.className = 'alert ' + (type || 'ok');
    a.innerHTML = (type === 'err' || type === 'warn' ? ICO_ERR : ICO_OK) + '<span></span>';
    a.lastChild.textContent = msg;
    a.addEventListener('click', () => a.remove());
    w.appendChild(a);
    setTimeout(() => { a.classList.add('out'); setTimeout(() => a.remove(), 450); }, type === 'err' ? 7000 : 3800);
  }
  function flashRow(tr) {
    if (!tr) return;
    tr.classList.remove('row-flash');
    void tr.offsetWidth;   // animatsiya qaytadan boshlansin
    tr.classList.add('row-flash');
    setTimeout(() => tr.classList.remove('row-flash'), 1800);
  }

  // ---------- oynalar (dialog) ----------
  const isDirty = d => !!d.querySelector('form.dirty');
  const firstField = d => $$('input:not([type=hidden]):not([type=radio]):not([type=checkbox]):not([disabled]), textarea:not([disabled]), select:not([disabled])', d)
    .filter(x => !x.closest('[hidden]') && x.getClientRects().length > 0)[0] || null;
  function dlgOpen(d, focusEl) {
    if (!d.open) { if (canModal) d.showModal(); else d.setAttribute('open', ''); }
    const f = focusEl || firstField(d);
    if (f) { try { f.focus(); } catch (e) { /* yashirin */ } }
  }
  function dlgClose(d) {
    if (!d.open) return true;
    if (isDirty(d) && !confirm(DIRTY_Q)) return false;
    d.close();
    return true;
  }
  function cleanUrl() {   // ?edit=ID / ?add=1 — oyna yopilgach manzildan olinadi (yangilansa qayta ochilmasin)
    try {
      const u = new URL(location.href);
      if (!u.searchParams.has('edit') && !u.searchParams.has('add')) return;
      u.searchParams.delete('edit');
      u.searchParams.delete('add');
      history.replaceState(null, '', u.pathname + u.search + u.hash);
    } catch (e) { /* eski brauzer */ }
  }
  const isStuDlg = d => d && d.tagName === 'DIALOG' && d.classList.contains('stu-dlg');
  // Esc — o'zgarish bo'lsa so'raladi
  document.addEventListener('cancel', e => {
    const d = e.target;
    if (isStuDlg(d) && isDirty(d) && !confirm(DIRTY_Q)) e.preventDefault();
  }, true);
  document.addEventListener('close', e => {
    const d = e.target;
    if (!isStuDlg(d)) return;
    if (d._init) { d._init = false; return; }   // JS siz kartani modal oynaga aylantirish (yopib, qayta ochiladi)
    $$('form.dirty', d).forEach(f => f.classList.remove('dirty'));
    cleanUrl();
    const back = d._back; d._back = null;
    if (back && document.contains(back) && !back.hidden) { try { back.focus(); } catch (x) { /* */ } }
  }, true);
  // fon (backdrop) bosilsa — yopiladi (bosish oyna tashqarisida boshlanib, tashqarida tugasa; o'zgarish bo'lsa yopilmaydi)
  let downOn = null;
  document.addEventListener('pointerdown', e => { downOn = e.target; }, true);
  const outside = (d, e) => { const r = d.getBoundingClientRect(); return e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom; };
  document.addEventListener('click', e => {
    const t = e.target;
    if (isStuDlg(t) && downOn === t && outside(t, e) && !isDirty(t)) t.close();
  });
  // «×», «Bekor qilish»
  document.addEventListener('click', e => {
    const c = e.target.closest && e.target.closest('[data-close]');
    if (!c) return;
    const d = c.closest('dialog');
    if (!isStuDlg(d) || d.classList.contains('static')) return;   // JS siz karta — havola bo'yicha ro'yxatga
    e.preventDefault();
    dlgClose(d);
  });
  // «O'quvchi qo'shish», «Ro'yxatni qo'shish»
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('[data-dlg]');
    if (!b || !canModal || e.ctrlKey || e.metaKey || e.shiftKey) return;
    const d = document.getElementById(b.dataset.dlg);
    if (!d) return;
    e.preventDefault();
    dlgOpen(d);
  });
  // forma o'zgardi — tasodifan yopib yuborilmasin
  document.addEventListener('input', e => {
    const f = e.target.form;
    if (f && f.closest && f.closest('.stu-dlg') && !f.closest('.gdlg')) f.classList.add('dirty');
  }, true);
  // Tahrirlash oynasidagi parol / arxiv / o'chirish tugmalari sahifani yangilaydi — saqlanmagan o'zgarish bo'lsa ogohlantiramiz
  document.addEventListener('submit', e => {
    const f = e.target;
    if (!f.closest || !f.closest('.stu-acts')) return;
    const d = f.closest('dialog');
    if (d && $('.stu-edit-form.dirty', d) && !confirm('Formadagi o\'zgarishlar saqlanmagan — ular yo\'qoladi. Davom etasizmi?')) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);

  // JS siz ochilgan kartalar (?edit=ID, ?add=1, ?add=list) → modal oyna; sahifadagi xabarlar oyna ichiga ko'chiriladi
  if (canModal) {
    let first = null;
    $$('dialog.stu-dlg.static').forEach(d => {
      d.classList.remove('static');
      if (d.open) { d._init = true; d.close(); if (!first) first = d; }
    });
    if (first) {
      const msgs = $$('main > .alert');
      if (msgs.length) {
        const box = document.createElement('div');
        box.className = 'dlg-msgs';
        msgs.forEach(m => box.appendChild(m));
        const h = $('.dlg-h', first);
        if (h) h.after(box); else first.prepend(box);
      }
      dlgOpen(first);
    }
  }

  // ---------- guruh ma'lumotlari ----------
  function applyCounts(j) {
    if (Array.isArray(j.groups)) G = j.groups;
    if (typeof j.none === 'number') {
      D.none = j.none;
      $$('[data-none-count]').forEach(x => { x.textContent = j.none; const a = x.closest('.gx-none'); if (a) a.classList.toggle('zero', j.none === 0); });
    }
    if (typeof j.reg_none === 'number') regChip(j.reg_none);
    const dl = document.getElementById('groups');   // forma maydonlaridagi takliflar
    if (dl) { dl.textContent = ''; G.forEach(g => { const o = document.createElement('option'); o.value = g.name; dl.appendChild(o); }); }
    const fs = $('#stuFilter select[name="group"]');   // O'quvchilar: guruh filtri (sonlari bilan)
    if (fs && fs.options.length >= 2) {
      const cur = fs.value, cnt = !D.arch;
      while (fs.options.length > 2) fs.remove(2);
      if (cnt) fs.options[1].textContent = 'Guruhsizlar (' + D.none + ')';
      G.forEach(g => fs.add(new Option(g.name + (cnt ? ' (' + g.n + ')' : ''), g.name)));
      fs.value = cur;
      if (fs.value !== cur) { fs.add(new Option(cur, cur)); fs.value = cur; }
    }
  }
  function regChip(n) {   // Ro'yxat sahifasi: «Guruhsiz: N»
    const box = document.getElementById('regChips');
    if (!box) return;
    let a = $('a.gx-chip', box);
    if (!a && n > 0) {
      a = document.createElement('a');
      a.className = 'gx-chip';
      a.href = '#regList';
      a.dataset.fg = '@none';
      a.title = 'Faqat guruhga biriktirilmaganlarni ko\'rsatish';
      a.innerHTML = 'Guruhsiz: <b></b>';
      box.appendChild(a);
    }
    if (!a) return;
    if (n === 0 && !a.classList.contains('on')) { a.remove(); return; }
    const b = $('b', a);
    if (b) b.textContent = n;
  }
  function setChip(c, g) {
    c.dataset.g = g;
    c.textContent = g || 'guruhsiz';
    c.classList.toggle('none', !g);
    c.title = g ? 'Guruhni o\'zgartirish' : 'Guruhga biriktirish';
  }
  async function setGroup(ids, name) {
    const body = { ids: ids, group: name };
    if (D.test) body.test = D.test;
    const j = await api('set_group', body);
    applyCounts(j);
    (j.ids || ids).forEach(id => $$('.gchip[data-sid="' + id + '"]').forEach(c => { setChip(c, j.group); flashRow(c.closest('tr')); }));
    return j;
  }
  const nameOf = tr => {
    const c = tr && (tr.querySelector('.stu-name') || tr.cells[2]);
    if (!c) return '';
    const t = c.firstChild && c.firstChild.nodeType === 3 ? c.firstChild.textContent : c.textContent;
    return t.trim();
  };

  // ---------- jadvaldagi guruh katagi: bosilsa — tanlov ----------
  let inl = null;
  function closeInline() {
    if (!inl) return;
    const c = inl.chip, s = inl.sel;
    inl = null;
    s.remove();
    c.hidden = false;
  }
  function openInline(chip) {
    closeInline();
    const sel = document.createElement('select');
    sel.className = 'gsel';
    sel.setAttribute('aria-label', 'Guruhni tanlang');
    const cur = chip.dataset.g || '';
    const add = (v, t) => sel.add(new Option(t, v));
    add('', '— guruhsiz —');
    let found = cur === '';
    G.forEach(g => { add(g.name, g.name); if (g.name === cur) found = true; });
    if (!found) add(cur, cur);
    add('@new', '➕ Yangi guruh…');
    sel.value = cur;
    chip.hidden = true;
    chip.after(sel);
    inl = { chip: chip, sel: sel };
    sel.focus();
    try { if (sel.showPicker) sel.showPicker(); } catch (x) { /* eski brauzer — ro'yxat bosilganda ochiladi */ }
    sel.addEventListener('change', async () => {
      const v = sel.value;
      if (v === '@new') { closeInline(); openGroupDlg([chip.dataset.sid], { fresh: true, back: chip }); return; }
      if (v === cur) { closeInline(); chip.focus(); return; }
      sel.disabled = true;
      try { const j = await setGroup([chip.dataset.sid], v); closeInline(); toast(j.msg); chip.focus(); }
      catch (x) { closeInline(); toast(x.message, 'err'); }
    });
    sel.addEventListener('keydown', ev => { if (ev.key === 'Escape') { ev.preventDefault(); ev.stopPropagation(); closeInline(); chip.focus(); } });
    sel.addEventListener('blur', () => setTimeout(() => { if (inl && inl.sel === sel && !sel.disabled && document.activeElement !== sel) closeInline(); }, 200));
  }
  document.addEventListener('click', e => {
    const chip = e.target.closest && e.target.closest('.gchip');
    if (!chip) return;
    e.preventDefault();
    openInline(chip);
  });

  // ---------- «Guruhga biriktirish» oynasi (bir nechta o'quvchi yoki yangi guruh) ----------
  let gd = null, gIds = [];
  function groupDlg() {
    if (gd) return gd;
    gd = document.createElement('dialog');
    gd.className = 'qb-dlg stu-dlg gdlg';
    gd.id = 'grpDlg';
    gd.setAttribute('aria-labelledby', 'grpDlgT');
    gd.innerHTML = '<form class="form" novalidate>'
      + '<div class="dlg-h"><h3 id="grpDlgT">Guruhga biriktirish</h3><button type="button" class="btn sm ghost dlg-x" data-close aria-label="Yopish" title="Yopish (Esc)">×</button></div>'
      + '<p class="small gdlg-who"></p>'
      + '<input type="search" class="gdlg-q" placeholder="Guruhni qidirish…" aria-label="Guruhni qidirish" autocomplete="off">'
      + '<div class="gpick" role="radiogroup" aria-label="Guruh"></div>'
      + '<label class="gdlg-new" hidden>Yangi guruh nomi <input name="newg" maxlength="80" autocomplete="off" placeholder="Masalan: 11-A, Kechki guruh"></label>'
      + '<p class="small muted gdlg-hint" aria-live="polite"></p>'
      + '<div class="alert err gdlg-err" role="alert" hidden></div>'
      + '<div class="dlg-foot"><button class="btn primary">Biriktirish</button><button type="button" class="btn ghost" data-close>Bekor qilish</button></div>'
      + '</form>';
    document.body.appendChild(gd);
    const f = $('form', gd), q = $('.gdlg-q', gd), nl = $('.gdlg-new', gd), ni = $('input', nl), hint = $('.gdlg-hint', gd), err = $('.gdlg-err', gd);
    const pick = () => { const r = $('input[name="g"]:checked', gd); return r ? r.value : null; };
    const showErr = m => { err.textContent = m; err.hidden = false; };
    const sync = () => {
      const v = pick();
      nl.hidden = v !== '@new';
      $$('.gopt', gd).forEach(l => l.classList.toggle('on', $('input', l).checked));
      let h = '';
      if (v === '@new') {
        const t = ni.value.trim(), ex = t ? G.filter(g => g.name.toLowerCase() === t.toLowerCase())[0] : null;
        h = !t ? 'Yangi guruh nomini yozing' : (ex ? '«' + ex.name + '» guruhi bor — o\'quvchilar unga qo\'shiladi' : '«' + t + '» — yangi guruh yaratiladi');
      } else if (v === '') h = 'O\'quvchilar guruhdan chiqariladi (guruhsiz bo\'ladi)';
      hint.textContent = h;
      err.hidden = true;
    };
    gd.addEventListener('change', e => { if (e.target.name === 'g') { sync(); if (e.target.value === '@new') ni.focus(); } });
    ni.addEventListener('input', () => { const r = $('input[name="g"][value="@new"]', gd); if (r && !r.checked) r.checked = true; sync(); });
    q.addEventListener('input', () => {
      const t = q.value.trim().toLowerCase();
      $$('.gopt[data-name]', gd).forEach(l => { l.hidden = t !== '' && l.dataset.name.toLowerCase().indexOf(t) < 0; });
    });
    q.addEventListener('keydown', e => {   // Enter: bittasi qolsa — tanlanadi, hech biri bo'lmasa — yangi guruh nomi bo'ladi
      if (e.key !== 'Enter') return;
      e.preventDefault();
      const vis = $$('.gopt[data-name]', gd).filter(l => !l.hidden);
      if (vis.length === 1) { $('input', vis[0]).checked = true; sync(); $('input', vis[0]).focus(); }
      else if (!vis.length && q.value.trim()) { $('input[name="g"][value="@new"]', gd).checked = true; ni.value = q.value.trim(); sync(); ni.focus(); }
    });
    f.addEventListener('submit', async e => {
      e.preventDefault();
      const v = pick(), btn = $('button.primary', f);
      let name;
      if (v === null) { showErr('Guruhni tanlang yoki yangi nom yozing'); return; }
      if (v === '@new') { name = ni.value.trim(); if (!name) { showErr('Yangi guruh nomini yozing'); ni.focus(); return; } }
      else name = v;
      if (btn.disabled) return;
      btn.disabled = true;
      try {
        const j = await setGroup(gIds, name);
        const done = gd._done;
        gd.close();
        toast(j.msg);
        if (done) done(j);
      } catch (x) { showErr(x.message); }
      finally { btn.disabled = false; }
    });
    gd._sync = sync;
    return gd;
  }
  function openGroupDlg(ids, o) {
    o = o || {};
    const d = groupDlg();
    gIds = ids.map(String);
    const who = $('.gdlg-who', d);
    if (gIds.length === 1) { const tr = $('tr[data-sid="' + gIds[0] + '"]'); who.textContent = 'O\'quvchi: ' + (tr ? nameOf(tr) : 'ID ' + gIds[0]); }
    else who.innerHTML = '<b>' + gIds.length + '</b> ta o\'quvchi tanlangan';
    const box = $('.gpick', d);
    box.textContent = '';
    const opt = (v, label, n, cls) => {
      const l = document.createElement('label');
      l.className = 'gopt' + (cls ? ' ' + cls : '');
      if (!cls) l.dataset.name = v;
      l.innerHTML = '<input type="radio" name="g"><span></span>' + (n !== null ? '<small></small>' : '');
      $('input', l).value = v;
      $('span', l).textContent = label;
      if (n !== null) $('small', l).textContent = n;
      box.appendChild(l);
    };
    G.forEach(g => opt(g.name, g.name, g.n, ''));
    opt('@new', '➕ Yangi guruh', null, 'gnew');
    opt('', '— guruhsiz', null, 'gnone');
    const q = $('.gdlg-q', d), ni = $('.gdlg-new input', d);
    q.value = '';
    q.hidden = G.length <= 8;
    ni.value = '';
    $('.gdlg-err', d).hidden = true;
    let pre = o.fresh ? '@new' : null;
    if (pre === null) {   // hammasi bitta guruhda bo'lsa — o'sha belgilanadi
      const gs = gIds.map(id => { const c = $('.gchip[data-sid="' + id + '"]'); return c ? c.dataset.g : null; });
      if (gs.length && gs[0] && gs.every(g => g === gs[0])) pre = gs[0];
    }
    const r = pre === null ? null : $$('input[name="g"]', d).filter(x => x.value === pre)[0];
    if (r) r.checked = true;
    d._done = o.done || null;
    d._back = o.back || document.activeElement;
    d._sync();
    dlgOpen(d, pre === '@new' ? ni : (!q.hidden ? q : (r || $('input[name="g"]', d))));
  }

  // ---------- o'quvchini tahrirlash oynasi (O'quvchilar sahifasi) ----------
  const ed = document.getElementById('stuEdit'), edBody = document.getElementById('stuEditBody');
  let edSeq = 0;
  async function openEdit(sid, href) {
    if (!ed || !edBody || !canModal) { location.href = href; return; }
    const seq = ++edSeq;
    ed.dataset.sid = sid;
    edBody.innerHTML = '<div class="dlg-h"><h3 id="stuEditT">Tahrirlash</h3><button type="button" class="btn sm ghost dlg-x" data-close aria-label="Yopish" title="Yopish (Esc)">×</button></div><p class="muted stu-loading">Yuklanmoqda…</p>';
    dlgOpen(ed, $('.dlg-x', ed));
    try {
      const j = await api('form', { id: sid });
      if (seq !== edSeq || !ed.open) return;   // boshqasi ochilgan yoki yopilgan
      edBody.innerHTML = j.html;
      dlgOpen(ed);   // birinchi maydon (Familiya)
    } catch (x) {
      if (seq !== edSeq) return;
      const p = $('.stu-loading', edBody);
      if (p) { p.className = 'alert err stu-loading'; p.textContent = x.message; }
    }
  }
  document.addEventListener('click', e => {
    const a = e.target.closest && e.target.closest('a.js-edit');
    if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;   // yangi oynada ochish — odatdagidek
    e.preventDefault();
    openEdit(a.dataset.sid, a.href);
  });
  function replaceRow(id, html) {
    const old = $('.stu-tbl tr[data-sid="' + id + '"]');
    if (!old || !html) return;
    const tb = document.createElement('tbody');
    tb.innerHTML = String(html).trim();
    const nw = tb.querySelector('tr');
    if (!nw) return;
    const a = $('.rowchk', old), b = $('.rowchk', nw);
    if (a && b) b.checked = a.checked;
    old.replaceWith(nw);
    flashRow(nw);
    updSel();
  }
  document.addEventListener('submit', async e => {
    const f = e.target;
    if (!f.classList || !f.classList.contains('stu-edit-form')) return;
    const d = f.closest('dialog');
    if (!canModal || !d || d.classList.contains('static')) return;   // JS siz — oddiy POST
    e.preventDefault();
    const btn = $('button.primary', f), err = $('.stu-err', f);
    if (btn.disabled) return;
    btn.disabled = true;
    err.hidden = true;
    $$('.bad', f).forEach(x => x.classList.remove('bad'));
    try {
      const j = await api('edit', new FormData(f));
      f.classList.remove('dirty');
      d.close();
      applyCounts(j);
      replaceRow(j.id, j.row);
      toast(j.msg || 'Saqlandi');
    } catch (x) {
      err.textContent = x.message;
      err.hidden = false;
      const fld = x.field ? f.elements[x.field] : null;
      if (fld && fld.classList) { fld.classList.add('bad'); fld.focus(); }
      err.scrollIntoView({ block: 'nearest' });
    } finally { btn.disabled = false; }
  });

  // ---------- belgilash va amallar paneli (O'quvchilar sahifasi) ----------
  const bar = document.getElementById('stuBar');
  const boxes = () => $$('.stu-tbl .rowchk');
  let last = null;
  function updSel() {
    if (!STU || !bar) return;
    const bx = boxes(), n = bx.filter(b => b.checked).length, all = document.getElementById('checkAll'), sn = document.getElementById('selN');
    bx.forEach(b => { const tr = b.closest('tr'); if (tr) tr.classList.toggle('sel', b.checked); });
    if (sn) sn.textContent = n;
    bar.classList.toggle('on', n > 0);
    document.body.classList.toggle('stu-has-sel', n > 0);
    if (all) { all.checked = n > 0 && n === bx.length; all.indeterminate = n > 0 && n < bx.length; }
  }
  const setRange = (from, to, state) => {
    const bx = boxes(), a = bx.indexOf(from), b = bx.indexOf(to);
    if (a < 0 || b < 0) return;
    bx.slice(Math.min(a, b), Math.max(a, b) + 1).forEach(x => { x.checked = state; });
  };
  if (STU && bar) {
    bar.classList.add('js');
    const tbl = $('.stu-tbl'); if (tbl) tbl.classList.add('js-sel');   // qatorni bosib belgilash
    ['grpBtn', 'selClear'].forEach(id => { const b = document.getElementById(id); if (b) b.hidden = false; });
    const op = document.getElementById('massOp'), doBtn = document.getElementById('massDo');
    if (op) {   // guruhga o'tkazish — alohida tugma va oyna orqali; qolgan amallar — «Boshqa amallar…» ro'yxatida
      const og = op.querySelector('option[value="group"]'); if (og) og.remove();
      const tg = $('.op-group', bar); if (tg) tg.remove();
      op.insertBefore(new Option('Boshqa amallar…', ''), op.firstChild);
      op.value = '';
      const sync = () => {
        $$('.op-moc', bar).forEach(x => { x.hidden = op.value !== 'moc'; });
        if (doBtn) doBtn.disabled = op.value === '';
      };
      op.addEventListener('change', sync);
      sync();
    }
    const all = document.getElementById('checkAll');
    if (all) all.addEventListener('change', () => { boxes().forEach(b => { b.checked = all.checked; }); last = null; updSel(); });
    document.addEventListener('click', e => {
      const t = e.target;
      if (t.classList && t.classList.contains('rowchk') && t.closest('.stu-tbl')) {   // katakchaning o'zi (Shift bilan — oraliq)
        if (e.shiftKey && last && last !== t) setRange(last, t, t.checked);
        last = t; updSel(); return;
      }
      const tr = t.closest && t.closest('.stu-tbl tbody tr');   // qatorning bo'sh joyi
      if (!tr || t.closest('input, select, button, a, label, textarea')) return;
      const cb = $('.rowchk', tr);
      if (!cb) return;
      if (e.shiftKey && last) { if (window.getSelection) window.getSelection().removeAllRanges(); setRange(last, cb, !cb.checked); }
      else { if (window.getSelection && String(window.getSelection()) !== '') return; cb.checked = !cb.checked; }   // matn belgilanayotgan bo'lsa — tegmaymiz
      last = cb; updSel();
    });
    document.getElementById('selClear').addEventListener('click', () => { boxes().forEach(b => { b.checked = false; }); last = null; updSel(); });
    document.getElementById('grpBtn').addEventListener('click', e => {
      const ids = boxes().filter(b => b.checked).map(b => b.value);
      if (ids.length) openGroupDlg(ids, { back: e.currentTarget, done: () => { boxes().forEach(b => { b.checked = false; }); last = null; updSel(); } });
    });
    const sf = document.getElementById('stuFilter');   // filtr: tanlov o'zgarsa — darhol
    if (sf) sf.addEventListener('change', e => { if (e.target.tagName === 'SELECT') sf.submit(); });
    window.addEventListener('pageshow', updSel);   // orqaga qaytilganda brauzer tiklagan belgilar
    updSel();
  }

  // ---------- MOCK ro'yxati: «Guruhga biriktirish» (belgilanganlar) ----------
  if (!STU) document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('#regGrpBtn');
    if (!b || b.disabled) return;
    const ids = $$('.reg-tbl .rowchk:checked').map(x => x.value);
    if (ids.length) openGroupDlg(ids, { back: b, done: () => { if (window.regReload) window.regReload(); } });
  });
})();
