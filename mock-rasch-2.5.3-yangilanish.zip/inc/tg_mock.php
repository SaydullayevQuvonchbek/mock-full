<?php
defined('APP_ROOT') || exit;
/**
 * 2.5.2: botning «Faqat MOCK» rejimi (Sozlamalar → Telegram → «Bot rejimi»; standart shu). O'quvchi botda faqat MOCK ga
 * ro'yxatdan o'tadi va to'lov qiladi:  📝 MOCK ga yozilish · 🗓 MOCKlarim · 💳 To'lov · 👤 Mening ma'lumotim · ℹ️ Yordam.
 *
 * Yangi foydalanuvchi botning o'zida ro'yxatdan o'tadi: familiya → ism → telefon («📱 Raqamni yuborish» yoki yozib) → tasdiq.
 * Hisob yaratiladi: login — 6 xonali ID, parol — vaqtinchalik (saytga kirganda almashtiriladi); ikkalasi «Mening ma'lumotim» da.
 * Raqam bazada bo'lsa: Telegram tasdiqlagan o'z raqami (kontakt) — «Bu sizmisiz?» bilan o'sha hisobga ulanadi; yozilgan raqam — rad
 * (ID va parol bilan ulanish yoki boshqa raqam). Avval ro'yxatdan o'tganlar «123456 parol» bilan ulanadi (eski yo'l).
 *
 * To'lov — MOCK narxi (balans ko'rsatilmaydi; avvalgi to'lovdan qolgan mablag' bo'lsa — hisobga olinadi): kartaga o'tkazib, chek shu
 * yerga yuboriladi. To'lanmaguncha o'quvchi ro'yxatda, lekin joy band qilinmaydi (xonaga joylanmaydi). Admin chekni tasdiqlagach
 * joy band bo'ladi: xonalar qo'shilgan bo'lsa o'rin o'sha zahoti beriladi va tasdiq xabarida yuboriladi (inc/rooms.php: mock_seat_auto).
 * Pul qoidalari o'zgarmagan: ichkarida hamyon (wallet_post), mock_register / pay_request_create / pay_request_decide.
 *
 * Ro'yxatdan o'tish holatlari (tg_state.step, 6 soat): rln — familiya, rfn — ism, rph — telefon, rok — tasdiq, rme — mavjud hisobga ulash.
 * Tugmalar: r:* — ro'yxatdan o'tish (ulanmagan chat), m:* — MOCK bo'limlari (ulangan o'quvchi).
 */

const TG_MENU_MOCK = ['📝 MOCK ga yozilish' => '/yozilish', '🗓 MOCKlarim' => '/mening', '💳 To‘lov' => '/tolov', '👤 Mening ma’lumotim' => '/malumot', 'ℹ️ Yordam' => '/help'];
const TG_MENU_MOCK_V = 51;   // «Faqat MOCK» menyusining versiyasi (to'liq rejimniki — TG_MENU_V): rejim almashsa o'quvchiga bir marta yangi menyu boradi
const TG_REG_STEPS = ['rln', 'rfn', 'rph', 'rok', 'rme'];
const TG_MOCK_HIDDEN = ['/mashq', '/practice', '/topshiriq', '/ozlashtirish', '/hamyon', '/kabinet', '/sayt'];

function tg_mode(): string { return app_setting('tg_mode', 'mock') === 'full' ? 'full' : 'mock'; }
function tg_mock_on(): bool { return tg_mode() === 'mock'; }
function tg_menu_ver(): int { return tg_mock_on() ? TG_MENU_MOCK_V : TG_MENU_V; }
function tg_cmds_v(): string { return TG_CMDS_V . '-' . tg_mode(); }

function tg_menu_mock_kb(): array
{
    $b = array_map(fn($t) => ['text' => $t], array_keys(TG_MENU_MOCK));
    return ['keyboard' => [[$b[0], $b[1]], [$b[2], $b[3]], [$b[4]]], 'resize_keyboard' => true, 'is_persistent' => true];
}

function tg_m_help(bool $linked): string
{
    $s = "ℹ️ <b>Yordam</b>\nBu bot orqali MOCK imtihoniga ro‘yxatdan o‘tasiz va to‘lov qilasiz.\n\n";
    if (!$linked) $s .= "Ro‘yxatdan o‘tish: /start — familiya, ism va telefon raqamingizni yuborasiz.\nAvval ro‘yxatdan o‘tgan bo‘lsangiz — ID va parolingizni yuboring: <code>123456 parol</code>\n\n";
    return $s . "📝 <b>MOCK ga yozilish</b> — ro‘yxati ochiq MOCK lar: sana va narx\n"
        . "🗓 <b>MOCKlarim</b> — ro‘yxatingiz, to‘lov holati, xona va o‘rin\n"
        . "💳 <b>To‘lov</b> — kartaga o‘tkazib, chek rasmini shu yerga yuborasiz\n"
        . "👤 <b>Mening ma’lumotim</b> — F.I.Sh, telefon, login va parol\n\n"
        . "To‘lov qilinmaguncha joy band qilinmaydi. Admin chekni tasdiqlagach joyingiz band bo‘ladi va xona/o‘rningiz shu yerga yuboriladi.";
}

/** «10.11.2026, markazda» / «10.11.2026 09:00, onlayn» */
function tg_m_when(array $t): string
{
    if (!empty($t['online'])) return (!empty($t['online_start']) ? tg_dt((string)$t['online_start']) : 'vaqti keyinroq') . ', onlayn';
    return !empty($t['test_date']) ? date('d.m.Y', strtotime((string)$t['test_date'])) . ', markazda' : 'sana keyinroq e’lon qilinadi';
}

/** Onlayn MOCK ni boshlab bo'lmasa — sabab (MOCK rejimida «band» va «hamyon» so'zlarisiz) */
function tg_m_start_reason(array $can): string
{
    if (!tg_mock_on()) return (string)$can['reason'];
    if (($can['code'] ?? '') === 'unpaid') return 'To‘lov qilinmagani uchun joyingiz band qilinmagan. «💳 To‘lov» orqali to‘lang.';
    if (($can['code'] ?? '') === 'noreg') return 'Bu MOCK ga ro‘yxatdan o‘tmagansiz: «📝 MOCK ga yozilish».';
    return (string)$can['reason'];
}

function tg_m_pay_kb(int $tid): array
{
    return ['inline_keyboard' => [[['text' => '💳 To‘lov qilish', 'callback_data' => 'm:p:' . $tid]]]];
}

/** O'quvchining to'lov kutayotgan (o'tib ketmagan) ro'yxatlari — eng yaqin MOCK birinchi */
function tg_m_unpaid(int $sid): array
{
    $u = array_values(array_filter(mock_student_list($sid), fn($x) => $x['pay_status'] === 'unpaid' && !$x['over']));
    $key = fn($x) => (string)(!empty($x['online']) ? ($x['online_start'] ?? '') : ($x['test_date'] ?? '')) ?: '9999';
    usort($u, fn($a, $b) => strcmp($key($a), $key($b)) ?: ((int)$a['id'] <=> (int)$b['id']));
    return $u;
}

/* ---------------- Kiruvchi xabar (MOCK rejimi) ---------------- */

/**
 * «Faqat MOCK» rejimidagi xabar. true — ishlandi; false — eski yo'l davom etadi (havola bilan /start, ID+parol bilan ulanish,
 * ota-ona chati, natijalar, ulanishni uzish, PDF javoblari, botdagi test/topshiriq, to'lov cheki fayli).
 */
function tg_m_update(int $chat, ?array $st, array $m, string $text, string $cmd, array $from): bool
{
    $file = !empty($m['photo']) || !empty($m['document']);
    $contact = isset($m['contact']) && is_array($m['contact']) ? $m['contact'] : null;
    if ($cmd === '/start' && trim((string)preg_replace('/^\/start(@\S+)?/i', '', $text)) !== '') return false;   // /start <havola> — kabinet yoki ota-ona havolasi
    if (!$st) return tg_reg_update($chat, $text, $cmd, $from, $contact, $file);
    if ($contact) { tg_send($chat, 'Siz ro‘yxatdan o‘tgansiz. Ma’lumotlaringiz — «👤 Mening ma’lumotim».', tg_menu_kb()); return true; }
    if ($file) return false;   // to'lov cheki — tg_w_file (MOCK rejimidagi farqlari o'sha yerda)
    $sid = (int)$st['id'];
    if ($cmd === '/start') {
        q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);   // eski holatlar (chek kutish, mashq) — /start dan keyin tushunarsiz qolmasin
        tg_send($chat, "Siz ro‘yxatdan o‘tgansiz: <b>" . tg_h($st['full_name']) . "</b> (ID " . tg_h($st['code']) . ").\nPastdagi tugmalardan foydalaning 👇", tg_menu_kb());
        return true;
    }
    if ($cmd === '/help') { tg_send($chat, tg_m_help(true), tg_menu_kb()); return true; }
    if ($cmd === '/menu') {
        q('DELETE FROM tg_state WHERE chat_id=? AND step IN ("qb","qbkeys","qbsec","qbcnt","ans","wamt","wcard","wfile","wfid","wdone")', [$chat]);
        tg_send($chat, 'Menyu 👇', tg_menu_kb());
        return true;
    }
    if ($cmd === '/yozilish') { [$s, $kb] = tg_m_open_view($sid); tg_send($chat, $s, $kb); return true; }
    if ($cmd === '/mening' || $cmd === '/my') { [$s, $kb] = tg_m_list($sid); tg_send($chat, $s, $kb); return true; }
    if ($cmd === '/tolov') { tg_m_pay_start($chat, $st, 0); return true; }
    if ($cmd === '/malumot') { [$s, $kb] = tg_m_me_view($st); tg_send($chat, $s, $kb); return true; }
    if (in_array($cmd, ['/natija', '/result', '/uzish', '/unlink'], true)) return false;   // MOCK natijalari, ulanishni uzish — eski yo'l
    if ($cmd !== '') {
        tg_send($chat, (in_array($cmd, TG_MOCK_HIDDEN, true) ? "Bu bo‘lim hozir botda yo‘q.\n\n" : '') . tg_m_help(true), tg_menu_kb());
        return true;
    }
    // Oddiy matn. PDF javoblari («#123 …»), botdagi test yoki topshiriq (admin yuborgan) — eski yo'l
    $state = row('SELECT step, updated_at FROM tg_state WHERE chat_id=?', [$chat]);
    $step = (string)($state['step'] ?? '');
    if (in_array($step, ['qb', 'qbkeys', 'qbsec', 'qbcnt'], true) && !empty($state['updated_at']) && time() - strtotime((string)$state['updated_at']) > 6 * 3600) {
        q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
        $step = '';
    }
    if (preg_match('/^(#[Aa]?\d{1,9})(?!\d)/', $text) || in_array($step, ['qb', 'qbkeys', 'qbsec', 'qbcnt', 'ans'], true)) return false;
    if (in_array($step, TG_W_STEPS, true) && ($ws = tg_w_state($chat))) {
        if ($ws['step'] === 'wfile') { tg_send($chat, "🧾 Endi to‘lov chekini yuboring: skrinshot (rasm) yoki PDF — 📎 tugmasi orqali.\nBekor qilish: /menu"); return true; }
        if ($ws['step'] === 'wfid' && empty($ws['d']['g0']) && preg_match('/\d/', $text)) {   // «Bu … uchun chekmi?» — summa yozilmaydi, MOCK tugma bilan tanlanadi
            tg_send($chat, "Chek qaysi MOCK uchun — yuqoridagi tugmani bosing. Chek bo‘lmasa: /menu");
            return true;
        }
        if (tg_w_text($chat, $st, $ws, $text)) return true;
    }
    tg_send($chat, "Tushunmadim 🙂 Pastdagi tugmalardan foydalaning:\n📝 MOCK ga yozilish · 🗓 MOCKlarim · 💳 To‘lov · 👤 Mening ma’lumotim", tg_menu_kb());
    return true;
}

/* ---------------- Ro'yxatdan o'tish (ulanmagan chat) ---------------- */

function tg_reg_set(int $chat, string $step, array $d): void
{
    q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, $step, json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
}

/** Ro'yxatdan o'tish holati (6 soatdan eski bo'lsa o'chiriladi) */
function tg_reg_state(int $chat): ?array
{
    $s = row('SELECT * FROM tg_state WHERE chat_id=?', [$chat]);
    if (!$s || !in_array($s['step'], TG_REG_STEPS, true)) return null;
    if (!empty($s['updated_at']) && time() - strtotime((string)$s['updated_at']) > 6 * 3600) {
        q('DELETE FROM tg_state WHERE chat_id=? AND step=?', [$chat, $s['step']]);
        return null;
    }
    $s['d'] = json_decode((string)$s['data'], true) ?: [];
    return $s;
}

function tg_reg_update(int $chat, string $text, string $cmd, array $from, ?array $contact, bool $file): bool
{
    $state = tg_reg_state($chat);
    $parent = (bool)val('SELECT 1 FROM students WHERE parent_tg_chat=? LIMIT 1', [$chat]);
    if ($cmd === '/start') { tg_reg_begin($chat); return true; }
    if ($cmd === '/help') { tg_send($chat, tg_m_help(false)); return true; }
    if (in_array($cmd, ['/uzish', '/unlink', '/natija', '/result'], true)) return false;   // ota-ona chati yoki «siz ulanmagansiz» — eski yo'l
    if ($cmd !== '') {
        tg_send($chat, "Avval ro‘yxatdan o‘ting: /start\n\nAvval ro‘yxatdan o‘tgan bo‘lsangiz — ID va parolingizni yuboring, masalan: <code>123456 parol</code>");
        return true;
    }
    if ($file) {
        if ($parent) return false;
        tg_send($chat, 'Avval ro‘yxatdan o‘ting: /start. To‘lov chekini ro‘yxatdan o‘tib, MOCK ni tanlagach yuborasiz.');
        return true;
    }
    // Avval ro'yxatdan o'tganlar: «123456 parol» yoki ikki bosqichda (ID, so'ng parol) — eski yo'l (tg_try_link)
    if (!$contact) {
        $raw = row('SELECT step FROM tg_state WHERE chat_id=?', [$chat]);
        if ($raw && $raw['step'] === 'pass') return false;
        if (preg_match('/^\d{6}[\s,;:\/]+\S{4,64}$/u', $text)) return false;
        if ((!$state || $state['step'] === 'rln') && preg_match('/^\d{6}$/', $text)) return false;
    }
    if (!$state) {
        if ($parent && !$contact) return false;   // ota-ona chati — natijalar haqida (eski yo'l); ro'yxatdan o'tish /start bilan
        tg_reg_begin($chat);
        return true;
    }
    tg_reg_step($chat, $state, $text, $contact, $from);
    return true;
}

function tg_reg_begin(int $chat): void
{
    tg_reg_set($chat, 'rln', []);
    tg_send($chat, "Assalomu alaykum! 👋\nBu bot orqali <b>MOCK imtihoniga ro‘yxatdan o‘tasiz</b> va to‘lov qilasiz.\n\n1️⃣ <b>Familiyangizni</b> yozing (masalan: <i>Aliyev</i>):\n\n"
        . "Avval ro‘yxatdan o‘tgan bo‘lsangiz, ID va parolingizni yuboring: <code>123456 parol</code>", ['remove_keyboard' => true]);
}

/** «Aliyev», «Aliyev Vali», «Aliyev Vali Anvar o‘g‘li» → so'zlar (bosh harf bilan) yoki null. Har so'zda kamida 2 harf */
function tg_reg_words(string $text): ?array
{
    $t = trim((string)preg_replace('/\s+/u', ' ', $text));
    if (!name_ok($t)) return null;
    $w = explode(' ', name_cap($t));
    foreach ($w as $x) if (mb_strlen((string)preg_replace("/[ʻʼ'‘’`\\-]/u", '', $x)) < 2) return null;   // «A», «-» kabi bo'laklar
    return $w;
}

/** Saqlashdan oldin F.I.Sh qismlari (tg_reg_words bilan bir xil qoida) */
function tg_reg_name_valid(string $l, string $f, string $m): bool
{
    foreach ([$l, $f, $m] as $i => $x) {
        if ($x === '' && $i === 2) continue;
        if (tg_reg_words($x) === null) return false;
    }
    return true;
}

function tg_reg_phone_kb(): array
{
    return ['keyboard' => [[['text' => '📱 Raqamni yuborish', 'request_contact' => true]]], 'resize_keyboard' => true, 'one_time_keyboard' => true];
}

function tg_reg_step(int $chat, array $state, string $text, ?array $contact, array $from): void
{
    $d = $state['d'];
    $step = $state['step'];
    if ($step === 'rln' || $step === 'rfn') {
        if ($contact) { tg_send($chat, $step === 'rln' ? 'Avval <b>familiyangizni</b> yozing.' : 'Avval <b>ismingizni</b> yozing.'); return; }
        $w = tg_reg_words($text);
        if ($w === null) {
            tg_send($chat, ($step === 'rln' ? 'Familiyani' : 'Ismni') . " harflar bilan to‘liq yozing (har so‘z kamida 2 harf), masalan: <i>" . ($step === 'rln' ? 'Aliyev' : 'Vali') . "</i>");
            return;
        }
        if ($step === 'rln') {
            $d = ['l' => $w[0]];
            if (count($w) >= 2) {   // «Familiya Ism» bitta xabarda
                $d['f'] = $w[1];
                $d['m'] = implode(' ', array_slice($w, 2));
                tg_reg_ask_phone($chat, $d, true);
                return;
            }
            tg_reg_set($chat, 'rfn', $d);
            tg_send($chat, "2️⃣ <b>Ismingizni</b> yozing (masalan: <i>Vali</i>):");
            return;
        }
        $d['f'] = $w[0];
        $d['m'] = implode(' ', array_slice($w, 1));
        tg_reg_ask_phone($chat, $d, false);
        return;
    }
    if ($step === 'rph' || $contact) {
        // Raqam faqat «📱 Raqamni yuborish» tugmasi orqali: Telegram uni shu foydalanuvchiniki deb tasdiqlaydi (birovning raqamini egallab
        // bo'lmaydi, bazada qaysi raqam borligini bilib bo'lmaydi)
        if (!$contact) { tg_send($chat, "Raqamingizni pastdagi «📱 Raqamni yuborish» tugmasi orqali yuboring — Telegram raqamingizni tasdiqlaydi.", tg_reg_phone_kb()); return; }
        $uid = (int)($contact['user_id'] ?? 0);
        if ($uid === 0 || $uid !== (int)($from['id'] ?? 0)) { tg_send($chat, "Faqat o‘z raqamingizni yuboring — pastdagi «📱 Raqamni yuborish» tugmasi orqali.", tg_reg_phone_kb()); return; }
        $phone = norm_phone((string)($contact['phone_number'] ?? ''));
        if ($phone === '') {
            $site = tg_site_url();
            tg_send($chat, "Telegram raqamingiz O‘zbekiston raqami (+998) emas. Ro‘yxatdan o‘tish uchun o‘quv markaziga murojaat qiling" . ($site !== '' ? " yoki saytda ro‘yxatdan o‘ting: " . tg_h($site) : '') . ".", ['remove_keyboard' => true]);
            return;
        }
        tg_reg_phone($chat, $d, $phone);
        return;
    }
    if ($step === 'rok') { tg_reg_confirm($chat, $d); return; }   // tugma kutilmoqda — kartani qayta ko'rsatamiz
    if ($step === 'rme') {
        $s = row('SELECT id, code, full_name FROM students WHERE id=? AND archived_at IS NULL', [(int)($d['sid'] ?? 0)]);
        if ($s) { tg_reg_me_ask($chat, $s); return; }
        tg_reg_begin($chat);
    }
}

function tg_reg_ask_phone(int $chat, array $d, bool $both): void
{
    tg_reg_set($chat, 'rph', $d);
    $who = $both ? "Familiya: <b>" . tg_h($d['l']) . "</b>, ism: <b>" . tg_h(trim($d['f'] . ' ' . $d['m'])) . "</b>.\n\n" : '';
    tg_send($chat, $who . "3️⃣ <b>Telefon raqamingizni</b> yuboring: pastdagi «📱 Raqamni yuborish» tugmasini bosing.", tg_reg_phone_kb());
}

/** Telefon olindi (Telegram tasdiqlagan o'z raqami): bazada yo'q — tasdiq kartasi; bitta o'quvchida bor — «Bu sizmisiz?»; bir nechtasida — ID bilan */
function tg_reg_phone(int $chat, array $d, string $phone): void
{
    $ex = rows('SELECT id, code, full_name FROM students WHERE phone=? AND archived_at IS NULL ORDER BY id LIMIT 3', [$phone]);
    $d['p'] = $phone;
    $d['v'] = 1;
    if (!$ex) {
        tg_reg_set($chat, 'rok', $d);
        tg_reg_confirm($chat, $d);
        return;
    }
    if (count($ex) === 1) {
        $d['sid'] = (int)$ex[0]['id'];
        tg_reg_set($chat, 'rme', $d);
        tg_reg_me_ask($chat, $ex[0]);
        return;
    }
    unset($d['p'], $d['v'], $d['sid']);
    tg_reg_set($chat, 'rph', $d);
    tg_send($chat, "Bu raqamga bir nechta o‘quvchi bog‘langan. ID va parolingizni yuboring: <code>123456 parol</code> — yoki o‘quv markaziga murojaat qiling.", ['remove_keyboard' => true]);
}

function tg_reg_confirm(int $chat, array $d): void
{
    tg_send($chat, "Ma’lumotlaringizni tekshiring:\n\n👤 <b>" . tg_h(compose_name((string)$d['l'], (string)$d['f'], (string)($d['m'] ?? ''))) . "</b>\n📱 " . tg_h(fmt_phone((string)$d['p']))
        . "\n\nF.I.Sh imtihon varaqasi va sertifikatda shu ko‘rinishda yoziladi.\n<i>Tasdiqlasangiz, ma’lumotlaringiz o‘quv markazida saqlanishiga rozilik bildirasiz.</i>",
        ['inline_keyboard' => [[['text' => '✅ Tasdiqlash', 'callback_data' => 'r:ok']], [['text' => '✏️ Qaytadan yozish', 'callback_data' => 'r:re']]]]);
}

function tg_reg_me_ask(int $chat, array $s): void
{
    tg_send($chat, "Bu raqam bilan avval ro‘yxatdan o‘tilgan: <b>" . tg_h($s['full_name'] ?: 'o‘quvchi') . "</b> (ID " . tg_h($s['code']) . ").\nBu sizmisiz?",
        ['inline_keyboard' => [[['text' => '✅ Ha, bu men', 'callback_data' => 'r:me']], [['text' => '➕ Yo‘q, boshqa odamni ro‘yxatdan o‘tkazaman', 'callback_data' => 'r:new']]]]);
}

/** r:ok — hisob yaratish, r:re — qaytadan, r:me — mavjud hisobga ulash (Telegram tasdiqlagan raqam), r:new — boshqa odam (boshqa raqam) */
function tg_reg_cb(int $chat, array $from, string $data, callable $ans, int $mid): void
{
    if (row('SELECT id FROM students WHERE tg_chat_id=?', [$chat])) { $ans('Siz ro‘yxatdan o‘tgansiz', true); tg_drop_kb($chat, $mid); return; }
    if ($data === 'r:re') { $ans(); tg_drop_kb($chat, $mid); tg_reg_begin($chat); return; }
    $state = tg_reg_state($chat);
    $d = $state['d'] ?? [];
    if ($data === 'r:ok') {
        if (!$state || $state['step'] !== 'rok') { $ans('Bu so‘rov eskirgan — /start ni bosing', true); tg_drop_kb($chat, $mid); return; }
        $ans();
        tg_drop_kb($chat, $mid);
        tg_reg_create($chat, $from, $d);
        return;
    }
    if ($data === 'r:me' || $data === 'r:new') {
        if (!$state || $state['step'] !== 'rme' || empty($d['sid'])) { $ans('Bu so‘rov eskirgan — /start ni bosing', true); tg_drop_kb($chat, $mid); return; }
        $ans();
        tg_drop_kb($chat, $mid);
        if ($data === 'r:new') {   // raqam bitta hisobga; boshqa odam o'z Telegramidan (o'z raqami bilan) ro'yxatdan o'tadi
            tg_send($chat, "Bu raqam boshqa hisobga bog‘langan. Boshqa odam uchun — u o‘z Telegramidan /start bosib ro‘yxatdan o‘tadi.\nBu sizning hisobingiz bo‘lsa — «✅ Ha, bu men».",
                ['inline_keyboard' => [[['text' => '✅ Ha, bu men', 'callback_data' => 'r:me']], [['text' => '✏️ Qaytadan boshlash', 'callback_data' => 'r:re']]]]);
            return;
        }
        $s = row('SELECT * FROM students WHERE id=? AND phone=? AND archived_at IS NULL', [(int)$d['sid'], (string)($d['p'] ?? '')]);
        if (!$s || empty($d['v'])) { q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); tg_send($chat, 'Hisob topilmadi. Qaytadan boshlang: /start'); return; }
        // Raqam ilgari tasdiqlanmagan (saytda yoki admin yozgan) — hisobni raqam egasi oladi: yangi vaqtinchalik parol, eski parol va saytdagi
        // sessiyalar bekor (raqamni boshqa kishi yozib qo'ygan bo'lsa ham, endi u kira olmaydi)
        $newPass = '';
        if (empty($s['phone_verified_at'])) {
            $newPass = gen_temp_pass();
            student_set_pass((int)$s['id'], $newPass, true);
            q('UPDATE students SET phone_verified_at=NOW() WHERE id=?', [$s['id']]);
        }
        audit('tg_link_contact', 'student', (int)$s['id'], null, ['chat' => $chat, 'new_pass' => $newPass !== ''], 'student:' . (int)$s['id']);
        tg_link_student($chat, $from, $s);
        if ($newPass !== '') tg_send($chat, "🔐 Xavfsizlik uchun yangi parol berildi (eski parol endi ishlamaydi):\n🆔 Login (ID): <code>" . tg_h($s['code']) . "</code>\n🔑 Parol: <code>" . tg_h($newPass) . "</code>\n\nIkkalasi «👤 Mening ma’lumotim» da ham turadi.");
        return;
    }
    $ans();
}

/** Hisob yaratish: ID (login) va vaqtinchalik parol, chat ulanadi. Bitta Telegramdan sutkasiga ko'pi bilan 3 ta hisob */
function tg_reg_create(int $chat, array $from, array $d): void
{
    $l = (string)($d['l'] ?? '');
    $f = (string)($d['f'] ?? '');
    $mid = (string)($d['m'] ?? '');
    $phone = norm_phone((string)($d['p'] ?? ''));
    if (!tg_reg_name_valid($l, $f, $mid) || $phone === '') { tg_reg_begin($chat); return; }
    if ((int)val('SELECT COUNT(*) FROM login_attempts WHERE kind="tgreg" AND ident=? AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [(string)$chat]) >= 3) {
        tg_send($chat, 'Bu Telegramdan bugun bir necha marta ro‘yxatdan o‘tildi. Ertaga urinib ko‘ring yoki o‘quv markaziga murojaat qiling.');
        return;
    }
    $lk = false;
    try { $lk = (int)val('SELECT GET_LOCK("mock_tgreg", 5)') === 1; } catch (Throwable $e) {}
    if (!$lk) { tg_send($chat, '⏳ Hozir band — birozdan keyin «✅ Tasdiqlash» ni qayta bosing.', ['inline_keyboard' => [[['text' => '✅ Tasdiqlash', 'callback_data' => 'r:ok']]]]); return; }
    try {
        if (row('SELECT id FROM students WHERE tg_chat_id=?', [$chat])) { q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); tg_send($chat, 'Siz ro‘yxatdan o‘tgansiz.', tg_menu_kb()); return; }
        if (val('SELECT 1 FROM students WHERE phone=? AND archived_at IS NULL', [$phone])) {   // shu orada boshqa chatdan
            unset($d['p'], $d['v']);
            tg_reg_set($chat, 'rph', $d);
            tg_send($chat, 'Bu raqam bilan hozirgina ro‘yxatdan o‘tildi. «📱 Raqamni yuborish» ni qayta bosing yoki ID va parol bilan ulaning: <code>123456 parol</code>', tg_reg_phone_kb());
            return;
        }
        $code = gen_student_code();
        $pass = gen_temp_pass();
        $name = compose_name($l, $f, $mid);
        q('INSERT INTO students (code, full_name, last_name, first_name, middle_name, phone, phone_verified_at, pin, pass_hash, must_change, pass_changed_at,
                                 source, created_ip, tg_chat_id, tg_username, tg_linked_at, tg_menu_v)
           VALUES (?,?,?,?,?,?,IF(?=1,NOW(),NULL),?,?,1,NOW(),?,?,?,?,NOW(),?)',
            [$code, $name, $l, $f, $mid, $phone, 1, $pass, password_hash($pass, PASSWORD_DEFAULT), 'bot', 'tg', $chat, mb_substr((string)($from['username'] ?? ''), 0, 64), tg_menu_ver()]);
        $sid = (int)db()->lastInsertId();
    } finally {
        if ($lk) { try { q('SELECT RELEASE_LOCK("mock_tgreg")')->fetchAll(); } catch (Throwable $e) {} }
    }
    q('INSERT INTO login_attempts (kind, ident, ip) VALUES ("tgreg",?,"tg")', [(string)$chat]);
    q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
    audit('student_bot_reg', 'student', $sid, null, ['code' => $code, 'via' => 'bot', 'phone_verified' => !empty($d['v'])], 'student:' . $sid);
    tg_log('in', $chat, 'reg', true, 'student ' . $sid);
    tg_send($chat, "✅ <b>Ro‘yxatdan o‘tdingiz!</b>\n\n👤 " . tg_h($name) . "\n🆔 Login (ID): <code>" . tg_h($code) . "</code>\n🔑 Parol: <code>" . tg_h($pass) . "</code>\n\n"
        . "Login va parol doim «👤 Mening ma’lumotim» bo‘limida turadi.", tg_menu_kb());
    $open = mock_open_list($sid);
    if (count($open) === 1) { tg_m_join_card($chat, $sid, (int)$open[0]['id']); return; }
    [$s, $kb] = tg_m_open_view($sid);
    tg_send($chat, $s, $kb);
}

/* ---------------- 👤 Mening ma'lumotim ---------------- */

function tg_m_me_view(array $st): array
{
    $s = row('SELECT * FROM students WHERE id=?', [(int)$st['id']]) ?: $st;
    $temp = (int)$s['must_change'] === 1 && (string)$s['pin'] !== '';
    $t = "👤 <b>Mening ma’lumotim</b>\n\nF.I.Sh: <b>" . tg_h($s['full_name'] ?: '—') . "</b>"
        . "\nTelefon: " . ((string)$s['phone'] !== '' ? tg_h(fmt_phone((string)$s['phone'])) : 'kiritilmagan')
        . "\n\n🆔 Login (ID): <code>" . tg_h($s['code']) . "</code>"
        . "\n🔑 Parol: " . ($temp ? "<code>" . tg_h($s['pin']) . "</code>" : "o‘zingiz belgilagansiz (unutgan bo‘lsangiz — «🔑 Yangi parol»)");
    $site = tg_site_url();
    if ($site !== '') $t .= "\n🌐 Sayt: " . tg_h(preg_replace('#^https?://#i', '', $site)) . " (login — ID yoki telefon)";
    $t .= "\n\nF.I.Sh xato bo‘lsa, o‘quv markaziga ayting — imtihon varaqasi va sertifikatda shu ism yoziladi.";
    return [$t, ['inline_keyboard' => [[['text' => '🔑 Yangi parol', 'callback_data' => 'm:pw'], ['text' => '🗓 MOCKlarim', 'callback_data' => 'm:l']]]]];
}

/** Yangi vaqtinchalik parol (sutkasiga ko'pi bilan 3 marta). Eski parol va saytdagi ochiq sessiyalar bekor bo'ladi */
function tg_m_new_pass(int $chat, array $st): void
{
    $sid = (int)$st['id'];
    if ((int)val('SELECT COUNT(*) FROM login_attempts WHERE kind="tgpw" AND ident=? AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [(string)$sid]) >= 3) {
        tg_send($chat, 'Bugun parol bir necha marta yangilandi. Ertaga urinib ko‘ring yoki o‘quv markaziga murojaat qiling.');
        return;
    }
    $p = gen_temp_pass();
    student_set_pass($sid, $p, true);
    q('INSERT INTO login_attempts (kind, ident, ip) VALUES ("tgpw",?,"tg")', [(string)$sid]);
    audit('student_pass_bot', 'student', $sid, null, ['temp' => true], 'student:' . $sid);
    tg_send($chat, "🔑 <b>Yangi parol:</b> <code>" . tg_h($p) . "</code>\n🆔 Login (ID): <code>" . tg_h($st['code']) . "</code>\n\nEski parol endi ishlamaydi.", ['inline_keyboard' => [[['text' => '👤 Mening ma’lumotim', 'callback_data' => 'm:i']]]]);
}

/* ---------------- 📝 MOCK ga yozilish, 🗓 MOCKlarim ---------------- */

function tg_m_open_view(int $sid): array
{
    $open = mock_open_list($sid);
    if (!$open) return ["📝 Hozir ro‘yxati ochiq MOCK yo‘q.\nYangi MOCK e’lon qilinganda shu bo‘limda ko‘rinadi.", ['inline_keyboard' => [[['text' => '🗓 MOCKlarim', 'callback_data' => 'm:l']]]]];
    $s = "📝 <b>MOCK ga yozilish</b>\nQaysi MOCK ga yozilasiz?";
    $kb = [];
    foreach (array_slice($open, 0, 12) as $t) {
        $s .= "\n\n• <b>" . tg_h($t['title']) . "</b>\n   📅 " . tg_h(tg_m_when($t)) . "\n   💰 " . tg_h(mock_price_label($t));
        $kb[] = [['text' => '📝 ' . mb_substr((string)$t['title'], 0, 34), 'callback_data' => 'm:j:' . (int)$t['id']]];
    }
    if (count($open) > 12) $s .= "\n\n…va yana " . (count($open) - 12) . " ta (keyinroq bo‘ladiganlari).";
    return [$s . "\n\nTanlash uchun tugmani bosing 👇", ['inline_keyboard' => $kb]];
}

/** MOCK kartasi: sana, narx va «Ro'yxatdan o'tish» tugmasi (narx tugmada — o'zgarsa qayta tasdiqlatiladi). Ro'yxatda bo'lsa — holati */
function tg_m_join_card(int $chat, int $sid, int $tid, string $pre = ''): void
{
    $t = mock_test_row($tid);
    if (!$t) { tg_send($chat, 'MOCK topilmadi.'); return; }
    $reg = mock_reg_row($sid, $tid);
    if ($reg) { tg_m_status_send($chat, $sid, $t, $reg); return; }
    if (!(int)$t['reg_open'] || mock_is_over($t)) { tg_send($chat, '«' . tg_h($t['title']) . '» ga ro‘yxat yopilgan.'); return; }
    tg_send($chat, $pre . "📝 <b>" . tg_h($t['title']) . "</b>\n📅 " . tg_h(tg_m_when($t)) . "\n💰 Narxi: <b>" . tg_h(mock_price_label($t)) . "</b>\n\nShu MOCK ga ro‘yxatdan o‘tasizmi?",
        ['inline_keyboard' => [[['text' => '✅ Ro‘yxatdan o‘tish', 'callback_data' => 'm:jc:' . $tid . ':' . mock_price($t)]], [['text' => 'Bekor qilish', 'callback_data' => 'm:x']]]]);
}

/** Mavjud ro'yxat holati: to'lanmagan — joy band emas (to'lov tugmasi); boshqasi — joy band (xona/o'rin) */
function tg_m_status_send(int $chat, int $sid, array $t, array $reg): void
{
    $title = '«' . tg_h($t['title']) . '»';
    if ($reg['pay_status'] === 'unpaid') {
        tg_send($chat, "📝 " . $title . " — siz ro‘yxatdasiz.\n⚠️ To‘lov qilinmagani uchun joy hali band qilinmagan (" . tg_h(som(mock_price($t))) . ").", tg_m_pay_kb((int)$t['id']));
        return;
    }
    tg_send($chat, "✅ " . $title . " — joyingiz band." . tg_m_seat_lines((int)$t['id'], $sid), ['inline_keyboard' => [[['text' => '🗓 MOCKlarim', 'callback_data' => 'm:l']]]]);
}

/** m:jc:<id>:<narx> — ro'yxatdan o'tish. To'lanmagan bo'lsa shu xabarning o'zida to'lov yo'riqnomasi */
function tg_m_join(int $chat, array $st, int $tid, int $seen, callable $ans, int $mid): void
{
    $sid = (int)$st['id'];
    $t = mock_test_row($tid);
    if (!$t) { $ans('MOCK topilmadi', true); return; }
    $r = mock_register($sid, $tid, 'bot', ['pay' => 'auto', 'actor' => 'student:' . $sid, 'expect_price' => $seen]);
    if ($r['status'] === 'price') { $ans(); tg_drop_kb($chat, $mid); tg_m_join_card($chat, $sid, $tid, "⚠️ Narx o‘zgardi.\n"); return; }
    if (!$r['ok']) { $ans(mb_substr($r['error'] !== '' ? $r['error'] : 'Xatolik', 0, 190), true); return; }
    $ans($r['status'] === 'exists' ? '' : '✅ Ro‘yxatdan o‘tdingiz');
    tg_drop_kb($chat, $mid);
    $reg = mock_reg_row($sid, $tid);
    if (!$reg) return;
    if ($r['status'] === 'exists') { tg_m_status_send($chat, $sid, $t, $reg); return; }
    $title = '«' . tg_h($t['title']) . '»';
    if ($reg['pay_status'] === 'unpaid') {
        tg_m_pay_start($chat, $st, $tid, false, "✅ <b>" . $title . " ga ro‘yxatdan o‘tdingiz.</b>\n⚠️ To‘lov qilinmagani uchun joy hali band qilinmadi.\n\n");
        return;
    }
    tg_m_send_reserved($chat, $sid, $tid, "✅ <b>" . $title . " ga ro‘yxatdan o‘tdingiz.</b>\n"
        . ($r['status'] === 'paid' ? "To‘lov avvalgi to‘lovingizdan qolgan mablag‘ hisobidan qilindi — joyingiz band qilindi." : "Joyingiz band qilindi."), $r['seat'] ?? null);
}

/** 🗓 MOCKlarim: holat, to'lov va xona/o'rin */
function tg_m_list(int $sid): array
{
    $mine = array_values(array_filter(mock_student_list($sid), fn($x) => !$x['over']));
    $kb = []; $outKb = [];
    if (!$mine) {
        $s = "🗓 Siz hali MOCK ga yozilmagansiz.";
        $kb[] = [['text' => '📝 MOCK ga yozilish', 'callback_data' => 'm:o']];
        return [$s, ['inline_keyboard' => $kb]];
    }
    $s = "🗓 <b>Mening MOCK larim</b>";
    $more = count($mine) - 10;
    $mine = array_slice($mine, 0, 10);   // xabar 4096 belgidan oshmasin
    foreach ($mine as $t) {
        $s .= "\n\n• <b>" . tg_h($t['title']) . "</b>\n   📅 " . tg_h(tg_m_when($t));
        if ($t['rstatus'] === 'submitted') { $s .= "\n   ✅ Topshirildi"; continue; }
        if ($t['pay_status'] === 'unpaid') {
            $s .= "\n   ⚠️ To‘lov qilinmagan — joy band qilinmagan (" . tg_h(som(mock_price($t))) . ")";
            if (count($kb) < 4) $kb[] = [['text' => '💳 To‘lash: ' . mb_substr((string)$t['title'], 0, 28), 'callback_data' => 'm:p:' . (int)$t['id']]];
            if ($t['rstatus'] === null && !empty($t['cancel']['ok']) && count($outKb) < 3) $outKb[] = [['text' => '↩️ Ro‘yxatdan chiqish: ' . mb_substr((string)$t['title'], 0, 24), 'callback_data' => 'jout:' . (int)$t['id']]];
            continue;
        }
        $s .= "\n   ✅ Joyingiz band" . ($t['pay_status'] === 'paid' ? ' (to‘langan)' : ($t['pay_status'] === 'waived' ? ' (imtiyoz)' : ''));
        if ($t['room'] !== null && $t['seat'] !== null) $s .= "\n   📍 Xona: <b>" . tg_h($t['room']) . "</b> · 💺 O‘rin: <b>" . (int)$t['seat'] . "</b>";
        elseif (empty($t['online'])) $s .= "\n   📍 Xona va o‘rin imtihondan oldin shu yerga yuboriladi";
    }
    if ($more > 0) $s .= "\n\n…va yana " . $more . " ta.";
    $pend = rows('SELECT id, amount FROM pay_requests WHERE student_id=? AND status="pending" ORDER BY id LIMIT 3', [$sid]);
    foreach ($pend as $p) $s .= "\n\n⏳ Chek tekshirilmoqda: #" . (int)$p['id'] . " · " . tg_h(som((int)$p['amount']));
    $kb = array_merge($kb, $outKb);
    if (mock_open_list($sid)) $kb[] = [['text' => '📝 Boshqa MOCK ga yozilish', 'callback_data' => 'm:o']];
    return [$s, $kb ? ['inline_keyboard' => $kb] : null];
}

/* ---------------- 💳 To'lov ---------------- */

/** To'lov yo'riqnomasi: summa, karta(lar), chek */
function tg_m_pay_block(int $amount, array $t): string
{
    $cards = pay_cards();
    $s = "💳 <b>To‘lov: " . tg_h(som($amount)) . "</b> — «" . tg_h($t['title']) . "»";
    if ($cards) {
        $s .= "\n\n1️⃣ Shu summani kartaga o‘tkazing (Click, Payme yoki bank ilovasi orqali):";
        foreach ($cards as $c) {
            $no = preg_match('/^[\d\s-]{12,}$/', $c['no']) ? (string)preg_replace('/[\s-]+/', '', $c['no']) : $c['no'];
            $s .= "\n💳 <code>" . tg_h($no) . "</code>" . ($c['owner'] !== '' || $c['bank'] !== '' ? " — " . tg_h(trim($c['owner'] . ($c['owner'] !== '' && $c['bank'] !== '' ? ', ' : '') . $c['bank'])) : '');
        }
        $s .= "\n<i>Raqamni bossangiz, nusxa olinadi.</i>\n2️⃣ To‘lov chekini — skrinshot yoki PDF ni <b>shu yerga yuboring</b>.";
    } else {
        $s .= "\n\nKarta raqamini o‘quv markazidan so‘rang yoki naqd to‘lang (naqd to‘lovni admin o‘zi kiritadi). Kartaga o‘tkazsangiz — chekni shu yerga yuboring.";
    }
    if (pay_note() !== '') $s .= "\n\nℹ️ " . tg_h(mb_substr(pay_note(), 0, 600));
    return $s . "\n\nAdmin chekni tasdiqlagach, joyingiz band qilinadi" . (empty($t['online']) ? " va xona/o‘rningiz shu yerga yuboriladi." : " — xabar shu yerga keladi.");
}

/**
 * To'lovni boshlash ($tid = 0 — to'lanmagan MOCK lardan; bir nechta bo'lsa tanlatadi). Avvalgi to'lovdan qolgan mablag' yetsa — darhol
 * to'lanadi; tekshirilayotgan chek bo'lsa — shu haqda ($force — baribir yangi chek); aks holda yo'riqnoma va chek kutiladi (wfile).
 */
function tg_m_pay_start(int $chat, array $st, int $tid, bool $force = false, string $pre = ''): void
{
    $sid = (int)$st['id'];
    $unpaid = tg_m_unpaid($sid);
    if ($tid > 0) {
        $one = array_values(array_filter($unpaid, fn($x) => (int)$x['id'] === $tid));
        if (!$one) {
            $reg = mock_reg_row($sid, $tid);
            $t = mock_test_row($tid);
            if ($reg && $t && $reg['pay_status'] !== 'unpaid') { tg_m_status_send($chat, $sid, $t, $reg); return; }
            tg_send($chat, $t && mock_is_over($t) ? '«' . tg_h($t['title']) . '» o‘tib bo‘lgan.' : 'Bu MOCK uchun to‘lov kutilmayapti. «🗓 MOCKlarim» da holatni ko‘ring.', ['inline_keyboard' => [[['text' => '🗓 MOCKlarim', 'callback_data' => 'm:l']]]]);
            return;
        }
        $unpaid = $one;
    }
    if (!$unpaid) {
        tg_send($chat, $pre . "To‘lov kutilayotgan MOCK yo‘q.\nAvval «📝 MOCK ga yozilish» orqali MOCK ni tanlang.", ['inline_keyboard' => [[['text' => '📝 MOCK ga yozilish', 'callback_data' => 'm:o']]]]);
        return;
    }
    if (count($unpaid) > 1) {
        $s = "💳 <b>Qaysi MOCK uchun to‘laysiz?</b>";
        $kb = [];
        foreach (array_slice($unpaid, 0, 6) as $u) {
            $s .= "\n• " . tg_h($u['title']) . " — " . tg_h(som(mock_price($u)));
            $kb[] = [['text' => '💳 ' . mb_substr((string)$u['title'], 0, 30) . ' · ' . som(mock_price($u)), 'callback_data' => 'm:p:' . (int)$u['id']]];
        }
        tg_send($chat, $pre . $s, ['inline_keyboard' => $kb]);
        return;
    }
    $u = $unpaid[0];
    $tid = (int)$u['id'];
    $price = mock_price($u);
    $title = '«' . tg_h($u['title']) . '»';
    $bal = wallet_balance($sid);
    if ($bal >= $price) {   // avvalgi to'lovdan qolgan (qaytarilgan yoki ortiqcha to'langan) mablag' yetadi
        $r = mock_pay_unpaid($sid, $tid, 'student:' . $sid, $price);
        if ($r['ok']) {
            q('DELETE FROM tg_state WHERE chat_id=? AND step IN ("wamt","wcard","wfile","wfid")', [$chat]);
            tg_m_send_reserved($chat, $sid, $tid, $pre . "✅ " . $title . " — to‘lov avvalgi to‘lovingizdan qolgan mablag‘ hisobidan qilindi. Joyingiz band qilindi."
                . "\n<i>Pulni allaqachon o‘tkazgan bo‘lsangiz, chekni baribir yuboring — mablag‘ saqlanadi.</i>", $r['seat'] ?? null);
            return;
        }
    }
    $pendAll = rows('SELECT id, amount, test_id FROM pay_requests WHERE student_id=? AND status="pending" ORDER BY id', [$sid]);
    $pend = array_values(array_filter($pendAll, fn($p) => (int)$p['test_id'] === $tid));   // faqat shu MOCK uchun yuborilgan cheklar
    if ($pend && !$force) {
        $s = $pre . "⏳ <b>Chekingiz tekshirilmoqda</b>";
        foreach ($pend as $p) $s .= "\n• #" . (int)$p['id'] . " · " . tg_h(som((int)$p['amount']));
        $s .= "\n\nAdmin tasdiqlagach, " . $title . " uchun joyingiz band qilinadi — xabar shu yerga keladi.";
        $kb = [[['text' => '➕ Yana chek yuborish', 'callback_data' => 'm:pn:' . $tid]]];
        foreach (array_slice($pend, 0, 2) as $p) $kb[] = [['text' => '🚫 Chek #' . (int)$p['id'] . ' ni bekor qilish', 'callback_data' => 'w:c:' . (int)$p['id']]];
        tg_send($chat, $s, ['inline_keyboard' => $kb]);
        return;
    }
    if (count($pendAll) >= pay_max_pending()) { tg_send($chat, "⏳ Sizda " . count($pendAll) . " ta chek tekshirilmoqda. Admin ko‘rib chiqqach yangisini yuborishingiz mumkin — natija shu yerga keladi."); return; }
    $amount = max($price - $bal, pay_min());   // qolgan mablag' hisobga olinadi (qarz bo'lsa — qo'shiladi)
    $extra = $bal > 0 ? "\n<i>Avvalgi to‘lovingizdan " . tg_h(som($bal)) . " hisobga olindi.</i>" : ($bal < 0 ? "\n<i>Avvalgi qarzingiz bilan (" . tg_h(som(-$bal)) . ").</i>" : '');
    tg_w_set($chat, 'wfile', ['a' => $amount, 'm' => $tid]);
    tg_send($chat, $pre . tg_m_pay_block($amount, $u) . $extra, ['inline_keyboard' => [[['text' => 'Keyinroq to‘layman', 'callback_data' => 'm:later']]]]);
}

/** Kontekstsiz rasm (MOCK rejimi): to'lov kutayotgan MOCK bo'lsa — «Bu … uchun chekmi?», bo'lmasa — qabul qilinmaydi */
function tg_m_receipt_ask(int $chat, array $st, array $f): void
{
    $unpaid = tg_m_unpaid((int)$st['id']);
    if (!$unpaid) {   // to'lov kutilayotgan MOCK yo'q — lekin o'tkazilgan pul yo'qolmasin: summa so'raladi, mablag' saqlanadi
        tg_w_set($chat, 'wfid', $f + ['g0' => 1]);
        tg_send($chat, "🧾 Hozir to‘lov kutilayotgan MOCK yo‘q. Bu to‘lov chekimi?\nPul o‘tkazgan bo‘lsangiz — qancha o‘tkazganingizni raqam bilan yozing (masalan: <code>50000</code>): admin tekshirgach mablag‘ keyingi MOCK uchun saqlanadi.\n\nMOCK ga yozilish: «📝 MOCK ga yozilish».",
            ['inline_keyboard' => [[['text' => 'Yo‘q, bu chek emas', 'callback_data' => 'w:x']], [['text' => '📝 MOCK ga yozilish', 'callback_data' => 'm:o']]]]);
        return;
    }
    tg_w_set($chat, 'wfid', $f);
    $kb = [];
    foreach (array_slice($unpaid, 0, 3) as $u) $kb[] = [['text' => '✅ Ha — «' . mb_substr((string)$u['title'], 0, 26) . '» uchun', 'callback_data' => 'm:y:' . (int)$u['id']]];
    $kb[] = [['text' => 'Yo‘q, bu chek emas', 'callback_data' => 'w:x']];
    tg_send($chat, count($unpaid) === 1 ? "🧾 Bu «" . tg_h($unpaid[0]['title']) . "» uchun to‘lov chekimi? (" . tg_h(som(mock_price($unpaid[0]))) . ")" : "🧾 Bu to‘lov chekimi? Qaysi MOCK uchun?", ['inline_keyboard' => $kb]);
}

/* ---------------- Joy band bo'ldi: xona/o'rin xabari ---------------- */

/** Sana va o'rin qatorlari (bot xabari uchun). $seat berilmasa — bazadan; o'rin yo'q — «keyinroq yuboriladi»; onlayn — boshlanish vaqti */
function tg_m_seat_lines(int $tid, int $sid, ?array $seat = null): string
{
    $t = mock_test_row($tid);
    if (!$t) return '';
    if (!empty($t['online'])) return !empty($t['online_start']) ? "\n💻 Onlayn: <b>" . tg_h(tg_dt((string)$t['online_start'])) . "</b>" . ((int)$t['tg_enabled'] ? " — savollar shu botga keladi" : '') : '';
    $s = !empty($t['test_date']) ? "\n📅 Sana: <b>" . date('d.m.Y', strtotime((string)$t['test_date'])) . "</b>" : '';
    if ($seat === null) {
        $g = row('SELECT g.seat, r.id rid, r.name FROM test_registrations g JOIN test_rooms r ON r.id=g.room_id WHERE g.test_id=? AND g.student_id=? AND g.seat IS NOT NULL', [$tid, $sid]);
        if ($g) $seat = ['room' => (string)$g['name'], 'seat' => (int)$g['seat'], 'room_id' => (int)$g['rid']];
    }
    if (!$seat) return $s . "\n📍 Xona va o‘rningiz imtihondan oldin shu yerga yuboriladi.";
    $code = (string)val('SELECT code FROM students WHERE id=?', [$sid]);
    return $s . "\n📍 Xona: <b>" . tg_h($seat['room']) . "</b>\n💺 O‘rin: <b>" . (int)$seat['seat'] . "</b>\n\nImtihonga 15 daqiqa oldin keling; ID raqamingiz (<b>" . tg_h($code) . "</b>) va qalam olib keling.";
}

/** Xabarda yuborilgan o'rinlar: «xona haqida xabar» qayta ketmasin (o'rin shu orada o'zgarmagan bo'lsa). $nt: [[test, xona, o'rin], …] */
function tg_m_mark_notified(int $sid, array $nt): void
{
    foreach ($nt as $x) {
        if (!is_array($x) || count($x) < 3) continue;
        q('UPDATE test_registrations SET notified_at=NOW() WHERE test_id=? AND student_id=? AND room_id=? AND seat=?', [(int)$x[0], $sid, (int)$x[1], (int)$x[2]]);
    }
}

/** «Joyingiz band qilindi» — darhol (botdagi amalga javob) */
function tg_m_send_reserved(int $chat, int $sid, int $tid, string $head, ?array $seat): void
{
    $seat = $seat ?? mock_seat_auto($tid, $sid);
    $r = tg_send($chat, $head . tg_m_seat_lines($tid, $sid, $seat), ['inline_keyboard' => [[['text' => '🗓 MOCKlarim', 'callback_data' => 'm:l']]]]);
    if (!empty($r['ok']) && $seat) tg_m_mark_notified($sid, [[$tid, (int)$seat['room_id'], (int)$seat['seat']]]);
}

/**
 * To'lov tasdiqlandi (chek yoki admin qabul qilgan naqd): to'langan MOCK lar — joy band, xona/o'rin; yetmagani — qancha kerakligi.
 * $settled: mock_settle_unpaid natijasi (+ 'seat'). Qaytaradi: [html, klaviatura, nt]
 */
function tg_m_paid_msg(int $sid, string $head, array $settled, string $tail = ''): array
{
    $nt = [];
    $s = $head;
    foreach ($settled as $x) {
        $s .= "\n\n«<b>" . tg_h($x['title']) . "</b>» — joyingiz band qilindi." . tg_m_seat_lines((int)$x['test_id'], $sid, $x['seat'] ?? null);
        if (!empty($x['seat'])) $nt[] = [(int)$x['test_id'], (int)$x['seat']['room_id'], (int)$x['seat']['seat']];
    }
    $kb = null;
    $unpaid = tg_m_unpaid($sid);
    if ($unpaid) {
        $u = $unpaid[0];
        $need = max(0, mock_price($u) - wallet_balance($sid));
        $s .= "\n\n⚠️ «" . tg_h($u['title']) . "» uchun yana <b>" . tg_h(som($need)) . "</b> kerak — joy hali band qilinmadi.";
        $kb = tg_m_pay_kb((int)$u['id']);
    } elseif (!$settled) {
        $s .= "\nMablag‘ saqlanadi — keyingi MOCK ga yozilganingizda shundan to‘lanadi.";
    }
    $s .= $tail;
    return [$s, $kb ?? ['inline_keyboard' => [[['text' => '🗓 MOCKlarim', 'callback_data' => 'm:l']]]], $nt];
}

/* ---------------- Tugmalar (ulangan o'quvchi) ---------------- */

function tg_m_cb(int $chat, array $st, string $data, callable $ans, int $mid): void
{
    $sid = (int)$st['id'];
    if ($data === 'm:o') { $ans(); [$s, $kb] = tg_m_open_view($sid); tg_send($chat, $s, $kb); return; }
    if ($data === 'm:l') { $ans(); [$s, $kb] = tg_m_list($sid); tg_send($chat, $s, $kb); return; }
    if ($data === 'm:i') { $ans(); [$s, $kb] = tg_m_me_view($st); tg_send($chat, $s, $kb); return; }
    if ($data === 'm:x') { $ans('Bekor qilindi'); tg_drop_kb($chat, $mid); return; }
    if ($data === 'm:later') {
        q('DELETE FROM tg_state WHERE chat_id=? AND step IN ("wamt","wcard","wfile","wfid")', [$chat]);
        $ans('Mayli. To‘lov qilganingizda «💳 To‘lov» tugmasini bosing');
        tg_drop_kb($chat, $mid);
        return;
    }
    if ($data === 'm:pw') {
        $ans();
        tg_send($chat, "🔑 Yangi parol yaratilsinmi? Eski parol ishlamay qoladi (saytda ochiq bo‘lsangiz — chiqib ketasiz).",
            ['inline_keyboard' => [[['text' => '✅ Ha, yangi parol', 'callback_data' => 'm:pwc'], ['text' => 'Yo‘q', 'callback_data' => 'm:x']]]]);
        return;
    }
    if ($data === 'm:pwc') { $ans(); tg_drop_kb($chat, $mid); tg_m_new_pass($chat, $st); return; }
    if (preg_match('/^m:j:(\d+)$/', $data, $mm)) { $ans(); tg_m_join_card($chat, $sid, (int)$mm[1]); return; }
    if (preg_match('/^m:jc:(\d+):(\d+)$/', $data, $mm)) { tg_m_join($chat, $st, (int)$mm[1], (int)$mm[2], $ans, $mid); return; }
    if (preg_match('/^m:(p|pn):(\d+)$/', $data, $mm)) { $ans(); if ($mm[1] === 'pn') tg_drop_kb($chat, $mid); tg_m_pay_start($chat, $st, (int)$mm[2], $mm[1] === 'pn'); return; }
    if (preg_match('/^m:y:(\d+)$/', $data, $mm)) {   // kontekstsiz rasm: «Ha — «…» uchun»
        $state = tg_w_state($chat);
        if (!$state || $state['step'] !== 'wfid' || empty($state['d']['f'])) { $ans('Bu so‘rov eskirgan — chekni qayta yuboring', true); tg_drop_kb($chat, $mid); return; }
        $tid = (int)$mm[1];
        $u = array_values(array_filter(tg_m_unpaid($sid), fn($x) => (int)$x['id'] === $tid));
        if (!$u) { $ans('Bu MOCK uchun to‘lov kutilmayapti', true); tg_drop_kb($chat, $mid); q('DELETE FROM tg_state WHERE chat_id=? AND step="wfid"', [$chat]); return; }
        $ans();
        tg_drop_kb($chat, $mid);
        $dup = val('SELECT id FROM pay_requests WHERE student_id=? AND test_id=? AND status="pending" ORDER BY id DESC LIMIT 1', [$sid, $tid]);
        if ($dup) {   // bitta o'tkazmaning ikkinchi skrinshoti ikkinchi chek bo'lmasin
            q('DELETE FROM tg_state WHERE chat_id=? AND step="wfid"', [$chat]);
            tg_send($chat, "⏳ «" . tg_h($u[0]['title']) . "» uchun chek #" . (int)$dup . " tekshirilmoqda — bu rasm qo‘shilmadi.\nBu boshqa (yana bir) o‘tkazma bo‘lsa — «➕ Yana chek yuborish».",
                ['inline_keyboard' => [[['text' => '➕ Yana chek yuborish', 'callback_data' => 'm:pn:' . $tid]]]]);
            return;
        }
        $price = mock_price($u[0]);
        $bal = wallet_balance($sid);
        $d = $state['d'];
        $d['m'] = $tid;
        unset($d['sa'], $d['g0']);
        tg_topup_amount($chat, $st, $bal >= $price ? $price : max($price - $bal, pay_min()), $d);   // o'tkazilgan pul har doim chek bo'lib yoziladi
        return;
    }
    $ans();
}

/**
 * MOCK rejimida eski xabarlardagi tugmalar (hamyon, «Qatnashaman», «To'lash»): mos MOCK bo'limiga. true — ishlandi.
 * w:c / w:cc (chekni bekor qilish), w:k (karta), w:n, w:x, w:y, w:a — holatga bog'liq, eski yo'l bilan ishlaydi.
 */
function tg_m_legacy_cb(int $chat, array $st, string $data, callable $ans, int $mid): bool
{
    $sid = (int)$st['id'];
    if (preg_match('/^join([crx]?):(\d+)/', $data, $mm)) {
        if ($mm[1] === 'x') { $ans('Bekor qilindi'); tg_drop_kb($chat, $mid); return true; }
        $ans();
        $tid = (int)$mm[2];
        $reg = mock_reg_row($sid, $tid);
        if ($reg && $reg['pay_status'] === 'unpaid') tg_m_pay_start($chat, $st, $tid);
        else tg_m_join_card($chat, $sid, $tid);
        return true;
    }
    if (in_array($data, ['w:b', 'w:h', 'w:m', 'w:s'], true)) { $ans(); [$s, $kb] = tg_m_list($sid); tg_send($chat, $s, $kb); return true; }
    if ($data === 'w:p') { $ans(); [$s, $kb] = tg_m_me_view($st); tg_send($chat, $s, $kb); return true; }
    if (preg_match('/^w:t(?::\d{1,9})?$/', $data)) { $ans(); tg_m_pay_start($chat, $st, 0); return true; }
    return false;
}
