<?php
defined('APP_ROOT') || exit;
require_once APP_ROOT . '/inc/students_lib.php';   // 2.5.2: forma, saqlash, guruhga biriktirish, jadval qatori (stu_api bilan umumiy)
$centers = centers_list();
$groups = groups_list();
// 2.5.2: ro'yxat filtrlari — amal bajarilgach (formalar joriy manzilga yuboriladi) va havolalarda shu ko'rinish saqlanadi
$gs = fn(string $k): string => is_string($_GET[$k] ?? null) ? trim($_GET[$k]) : '';
$keep = [];
foreach (['s', 'group', 'mock', 'source', 'center', 'arch'] as $k) if ($gs($k) !== '') $keep[$k] = $gs($k);

/** Arxivlashda: hali topshirmagan MOCK ro'yxatlaridan chiqarish va yuborilmagan bot/SMS xabarlarini bekor qilish (natijalar saqlanadi) */
function student_archive_cleanup(array $ids): void
{
    if (!$ids) return;
    $in = implode(',', array_fill(0, count($ids), '?'));
    // 2.5: hali o'tkazilmagan MOCK uchun to'langan bo'lsa — pul hamyonga qaytadi (balans saqlanadi; admin naqd qaytarib berishi mumkin)
    foreach (rows("SELECT g.test_id, g.student_id, t.published, t.online, t.online_end, t.test_date FROM test_registrations g JOIN tests t ON t.id=g.test_id
                   WHERE g.student_id IN ($in) AND g.pay_status='paid' AND g.paid_amount>0 AND NOT EXISTS (SELECT 1 FROM responses r WHERE r.test_id=g.test_id AND r.student_id=g.student_id)", $ids) as $g)
        if (!mock_is_over($g)) mock_cancel((int)$g['student_id'], (int)$g['test_id'], 'admin', ['refund' => true, 'note' => 'o\'quvchi arxivlandi', 'notify' => false]);
    // to'langan qatorlar o'chirilmaydi: o'tkazilmaganlari yuqorida qaytarilgan, o'tgan MOCK lardagisi — to'lov izi bo'lib qoladi
    q("DELETE g FROM test_registrations g WHERE g.student_id IN ($in) AND g.pay_status<>'paid' AND NOT EXISTS (SELECT 1 FROM responses r WHERE r.test_id=g.test_id AND r.student_id=g.student_id)", $ids);
    q("DELETE FROM tg_queue WHERE sent_at IS NULL AND student_id IN ($in) AND kind NOT IN ('payrq','payupd','payrem','paydig')", $ids);   // 2.5.1: admin ishlarida student_id — admin ID
}

if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    if ($act === 'add') {
        $d = student_form_data();
        $code = preg_replace('/\D/', '', (string)($_POST['code'] ?? ''));
        // 2.5.2: xato bo'lsa — qo'shish oynasi qayta ochiladi, kiritilganlar saqlanib qoladi
        $fail = function (string $msg) use ($keep): void {
            $f = [];
            foreach (['last_name', 'first_name', 'middle_name', 'phone', 'school', 'grade_level', 'group_name', 'parent_name', 'parent_phone', 'parent_phone2', 'code'] as $k)
                $f[$k] = is_string($_POST[$k] ?? null) ? mb_substr(trim($_POST[$k]), 0, 160) : '';
            $_SESSION['stu_add_form'] = $f;
            flash($msg, 'err');
            redirect('students', ['add' => '1'] + $keep);
        };
        if ($d['last'] === '' && $d['first'] === '') $fail('Familiya va ismni kiriting');
        if ($code !== '' && val('SELECT 1 FROM students WHERE code=?', [$code])) $fail('ID ' . $code . ' boshqa o\'quvchida bor — bo\'sh qoldiring (avtomatik beriladi)');
        $pre = student_save($d, 0);   // avval telefonlarni tekshiramiz, keyin yozamiz (yarim yozilgan yozuv qolmasin)
        if ($pre !== null) $fail($pre);
        $s = find_or_create_student($code, compose_name($d['last'], $d['first'], $d['middle']), $d['group'], $d['center']);
        $err = student_save($d, (int)$s['id']);
        $s = row('SELECT id, code, pin FROM students WHERE id=?', [$s['id']]);
        flash($err ?: ('O\'quvchi saqlandi: ID ' . $s['code'] . ($s['pin'] !== '' ? ', vaqtinchalik parol ' . $s['pin'] : '')), $err ? 'err' : 'ok');
        redirect('students', ['edit' => $s['id']] + $keep);
    }
    if ($act === 'edit') {   // JS siz (JS bilan — stu_api)
        $err = student_save(student_form_data(), (int)$_POST['id']);
        flash($err ?: 'Saqlandi', $err ? 'err' : 'ok');
        redirect('students', ['edit' => (int)$_POST['id']] + $keep);
    }
    if ($act === 'bulk') {
        $n = 0;
        $group = trim($_POST['group_name'] ?? '');
        $cid = (int)($_POST['center_id'] ?? 0) ?: null;
        foreach (preg_split('/\R/u', (string)$_POST['names']) as $line) {
            $line = trim($line);
            if ($line === '') continue;
            $parts = array_map('trim', preg_split('/[;\t]/', $line));
            if ($parts[0] === '') continue;   // ismsiz qator
            $s = find_or_create_student('', $parts[0], ($parts[1] ?? '') ?: $group, $cid);
            if (!$s) continue;
            if (!empty($parts[2]) && ($ph = norm_phone($parts[2])) && !val('SELECT 1 FROM students WHERE phone=?', [$ph])) q('UPDATE students SET phone=? WHERE id=?', [$ph, $s['id']]);
            if (!empty($parts[3]) && ($pp = norm_phone($parts[3]))) q('UPDATE students SET parent_phone=? WHERE id=?', [$pp, $s['id']]);
            if (!empty($parts[4])) q('UPDATE students SET parent_name=? WHERE id=?', [mb_substr($parts[4], 0, 120), $s['id']]);
            $n++;
        }
        flash("$n ta o'quvchi qo'shildi");
        redirect('students', ['group' => $group]);
    }
    if ($act === 'mass') {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
        $back = array_filter(['group' => $_POST['f_group'] ?? '', 's' => $_POST['f_s'] ?? '', 'arch' => $_POST['f_arch'] ?? '', 'source' => $_POST['f_source'] ?? '', 'mock' => $_POST['f_mock'] ?? ''], fn($v) => is_string($v) && $v !== '');
        if (!$ids) { flash('O\'quvchi tanlanmagan', 'warn'); redirect('students', $back); }
        $in = implode(',', array_fill(0, count($ids), '?'));
        $op = $_POST['op'] ?? '';
        if ($op === 'group') {   // JS siz (JS bilan — «Guruhga biriktirish» oynasi, stu_api)
            $g = trim($_POST['to_group'] ?? '');
            q("UPDATE students SET group_name=? WHERE id IN ($in)", array_merge([$g], $ids));
            flash(count($ids) . ' ta o\'quvchi "' . ($g ?: 'guruhsiz') . '" ga o\'tkazildi');
        } elseif ($op === 'center') {
            $c = (int)($_POST['to_center'] ?? 0) ?: null;
            q("UPDATE students SET center_id=? WHERE id IN ($in)", array_merge([$c], $ids));
            flash(count($ids) . ' ta o\'quvchining markazi o\'zgartirildi');
        } elseif ($op === 'moc') {
            $tid = (int)($_POST['to_test'] ?? 0);
            $mode = (string)($_POST['to_pay'] ?? 'auto');
            if (!in_array($mode, can_finance() ? ['auto', 'unpaid', 'cash', 'waive'] : ['auto', 'unpaid'], true)) $mode = 'auto';
            if ($tid && val('SELECT 1 FROM tests WHERE id=?', [$tid])) {
                $cnt = ['free' => 0, 'paid' => 0, 'unpaid' => 0, 'waived' => 0, 'exists' => 0, 'error' => 0];
                foreach ($ids as $sid) {
                    try { $r = mock_register($sid, $tid, 'admin', ['pay' => $mode, 'force' => true]); }
                    catch (Throwable $ex) { error_log('[MOCK moc-bulk] ' . $ex->getMessage()); $r = ['ok' => false, 'status' => 'error']; }
                    $k = $r['ok'] ? $r['status'] : 'error';
                    $cnt[isset($cnt[$k]) ? $k : 'error']++;
                }
                $n = $cnt['free'] + $cnt['paid'] + $cnt['unpaid'] + $cnt['waived'];
                flash("$n ta o'quvchi MOCK ro'yxatiga qo'shildi" . ($cnt['paid'] ? ", to'langan: " . $cnt['paid'] : '') . ($cnt['unpaid'] ? ", band (to'lov kutilmoqda): " . $cnt['unpaid'] : '')
                    . ($cnt['waived'] ? ', imtiyoz: ' . $cnt['waived'] : '') . ($cnt['exists'] ? ' (' . $cnt['exists'] . ' tasi avval qo\'shilgan edi)' : '') . ($cnt['error'] ? ', xato: ' . $cnt['error'] . ' (arxivdagi o\'quvchilar qo\'shilmaydi)' : ''));
            } else flash('MOCK tanlanmagan', 'warn');
        } elseif ($op === 'sendtemp') {
            $n = 0; $skip = 0; $none = 0;
            foreach (rows("SELECT * FROM students WHERE id IN ($in)", $ids) as $s) {
                if ((int)$s['must_change'] !== 1 || (string)$s['pin'] === '') { $skip++; continue; }
                if (msg_queue_temp($s) === '') $none++; else $n++;
            }
            if ($n) tg_tick(25);
            flash("Vaqtinchalik parol navbatga qo'yildi: $n ta" . ($skip ? ", o'z parolini belgilaganlar o'tkazildi: $skip" : '') . ($none ? ", bot/telefon yo'q: $none" : ''), $n ? 'ok' : 'warn');
        } elseif ($op === 'archive' || $op === 'unarchive') {
            $n = q($op === 'archive' ? "UPDATE students SET archived_at=NOW() WHERE archived_at IS NULL AND id IN ($in)" : "UPDATE students SET archived_at=NULL WHERE archived_at IS NOT NULL AND id IN ($in)", $ids)->rowCount();
            if ($op === 'archive') student_archive_cleanup($ids);
            flash($op === 'archive' ? "$n ta o'quvchi arxivlandi — ro'yxatlar, topshiriqlar va bot xabarlarida chiqmaydi, kabinetga kira olmaydi. Natijalari saqlanadi." : "$n ta o'quvchi arxivdan chiqarildi");
        } elseif ($op === 'delete') {
            // 2.5: pul tarixi (hamyon yozuvi yoki chek) bor o'quvchi o'chirilmaydi — faqat arxivlanadi
            $keepIds = array_map('intval', array_column(rows("SELECT DISTINCT student_id FROM wallet_tx WHERE student_id IN ($in) UNION SELECT DISTINCT student_id FROM pay_requests WHERE student_id IN ($in)", array_merge($ids, $ids)), 'student_id'));
            $del = array_values(array_diff($ids, $keepIds));
            if ($del) q('DELETE FROM students WHERE id IN (' . implode(',', array_fill(0, count($del), '?')) . ')', $del);
            flash(count($del) . ' ta o\'quvchi o\'chirildi' . ($keepIds ? '. ' . count($keepIds) . ' tasida pul tarixi bor — o\'chirilmadi (arxivlash mumkin)' : ''), $keepIds ? 'warn' : 'ok');
        }
        redirect('students', $back);
    }
    if ($act === 'archive' || $act === 'unarchive') {
        q('UPDATE students SET archived_at=' . ($act === 'archive' ? 'NOW()' : 'NULL') . ' WHERE id=?', [(int)$_POST['id']]);
        if ($act === 'archive') student_archive_cleanup([(int)$_POST['id']]);
        flash($act === 'archive' ? 'O\'quvchi arxivlandi. Natijalari saqlanadi; kabinetga kira olmaydi, ro\'yxat va topshiriqlarda chiqmaydi.' : 'O\'quvchi arxivdan chiqarildi');
        $k = $keep; unset($k['arch']);   // ro'yxat o'quvchi bilan birga arxivga / faollarga o'tadi
        redirect('students', ['edit' => (int)$_POST['id']] + ($act === 'archive' ? ['arch' => '1'] : []) + $k);
    }
    if ($act === 'tg_unlink') {
        q('UPDATE students SET tg_chat_id=NULL, tg_username="", tg_linked_at=NULL WHERE id=?', [(int)$_POST['id']]);
        flash('Telegram ulanishi uzildi');
        redirect('students', ['edit' => (int)$_POST['id']] + $keep);
    }
    if ($act === 'temp') {   // yangi vaqtinchalik parol: eski parol ishlamaydi, o'quvchi kirgach yangisini belgilaydi
        $np = gen_temp_pass();
        student_set_pass((int)$_POST['id'], $np, true);
        flash('Yangi vaqtinchalik parol: ' . $np . ' — o\'quvchiga bering yoki «Botga/SMS ga yuborish» tugmasini bosing. Eski parol endi ishlamaydi.');
        redirect('students', ['edit' => (int)$_POST['id']] + $keep);
    }
    if ($act === 'send_temp') {
        $s = row('SELECT * FROM students WHERE id=?', [(int)$_POST['id']]);
        if (!$s) redirect('students', $keep);
        if ((int)$s['must_change'] !== 1 || (string)$s['pin'] === '') {   // o'quvchi o'z parolini belgilagan — yangisini yaratish kerak
            $np = gen_temp_pass(); student_set_pass((int)$s['id'], $np, true);
            $s = row('SELECT * FROM students WHERE id=?', [$s['id']]);
        }
        $via = msg_queue_temp($s);
        if ($via === '') flash('Yuborib bo\'lmadi: o\'quvchi botga ulanmagan va SMS uchun telefon/Eskiz yo\'q. Parol: ' . $s['pin'], 'err');
        else { tg_tick(15); flash('Vaqtinchalik parol ' . ($via === 'bot' ? 'Telegram bot' : 'SMS') . ' orqali yuborildi' . ' (navbat: «Sozlamalar» da holatini ko\'rish mumkin)'); }
        redirect('students', ['edit' => (int)$s['id']] + $keep);
    }
    if ($act === 'delete') {
        if (wallet_has_history((int)$_POST['id'])) { flash('Bu o\'quvchida pul tarixi (hamyon yozuvlari yoki cheklar) bor — o\'chirib bo\'lmaydi, faqat arxivlash mumkin.', 'err'); redirect('students', ['edit' => (int)$_POST['id']] + $keep); }
        q('DELETE FROM students WHERE id=?', [(int)$_POST['id']]);
        flash('O\'chirildi');
        redirect('students', $keep);
    }
    if ($act === 'delete_demo') {
        $ids = array_column(rows('SELECT DISTINCT student_id FROM responses WHERE source="demo"'), 'student_id');
        q('DELETE FROM tests WHERE id IN (SELECT test_id FROM (SELECT DISTINCT test_id FROM responses WHERE source="demo") x)');
        foreach ($ids as $id) if (!wallet_has_history((int)$id)) q('DELETE FROM students WHERE id=? AND NOT EXISTS (SELECT 1 FROM responses WHERE student_id=?)', [$id, $id]);
        flash('Namuna ma\'lumotlar o\'chirildi');
        redirect('students');
    }
}
$search = $gs('s');
$group = $gs('group');   // '@none' — guruhsizlar
$center = $gs('center');
$source = $gs('source');
$mock = (int)$gs('mock');   // 2.5.2: shu MOCK ga ro'yxatdan o'tganlar
$arch = $gs('arch') === '1' ? '1' : '';
$where = [$arch ? 's.archived_at IS NOT NULL' : 's.archived_at IS NULL']; $par = [];
if ($search !== '') { [$sw, $sp] = student_search_sql($search); $where[] = $sw; $par = array_merge($par, $sp); }   // raqamsiz qidiruvda telefon sharti qo'shilmaydi (aks holda hammasi chiqardi)
if ($group === '@none') $where[] = "s.group_name=''";
elseif ($group !== '') { $where[] = 's.group_name=?'; $par[] = $group; }
if ($center === 'own') $where[] = 's.center_id IS NULL';
elseif ($center !== '') { $where[] = 's.center_id=?'; $par[] = (int)$center; }
if ($source !== '') { $where[] = 's.source=?'; $par[] = $source; }
if ($mock > 0) { $where[] = 'EXISTS (SELECT 1 FROM test_registrations g WHERE g.test_id=? AND g.student_id=s.id)'; $par[] = $mock; }
$W = implode(' AND ', $where);
$total = (int)val("SELECT COUNT(*) FROM students s WHERE $W", $par);
$list = rows("SELECT s.*, (SELECT COUNT(*) FROM responses r WHERE r.student_id=s.id) n FROM students s WHERE $W"
    . ($arch ? ' ORDER BY s.archived_at DESC, s.full_name' : ' ORDER BY s.created_at DESC, s.full_name') . ' LIMIT 1000', $par);
$filtered = $search !== '' || $group !== '' || $center !== '' || $source !== '' || $mock > 0;
$nArch = (int)val('SELECT COUNT(*) FROM students WHERE archived_at IS NOT NULL');
$editing = isset($_GET['edit']) ? row('SELECT * FROM students WHERE id=?', [(int)$_GET['edit']]) : null;
$hasDemo = (bool)val('SELECT 1 FROM responses WHERE source="demo" LIMIT 1');
$nReg = (int)val('SELECT COUNT(*) FROM students WHERE source="register" AND archived_at IS NULL');
$nBot = (int)val('SELECT COUNT(*) FROM students WHERE source="bot" AND archived_at IS NULL');   // 2.5.2: botda ro'yxatdan o'tganlar
$nAll = (int)val('SELECT COUNT(*) FROM students WHERE archived_at IS NULL');
$nPhone = (int)val('SELECT COUNT(*) FROM students WHERE phone<>"" AND archived_at IS NULL');
$nNone = students_none_count();   // 2.5.2: guruhsizlar (bot va saytda ro'yxatdan o'tganlar guruhsiz keladi)
$gc = group_counts();
if ($group !== '' && $group !== '@none' && !in_array(mb_strtolower($group), array_map(fn($g) => mb_strtolower($g['name']), $gc), true)) $gc[] = ['name' => $group, 'n' => 0];
// MOCK filtri: ro'yxati bor testlar (oxirgilari birinchi), har birida nechtasi guruhsiz
$mocks = rows("SELECT t.id, t.title, COUNT(*) n, SUM(s.group_name='') nog FROM tests t JOIN test_registrations g ON g.test_id=t.id JOIN students s ON s.id=g.student_id AND s.archived_at IS NULL
               GROUP BY t.id, t.title ORDER BY t.id DESC LIMIT 60");
if ($mock > 0 && !in_array($mock, array_map('intval', array_column($mocks, 'id')), true) && ($mt = val('SELECT title FROM tests WHERE id=?', [$mock])) !== null) $mocks[] = ['id' => $mock, 'title' => $mt, 'n' => 0, 'nog' => 0];
// Qo'shish oynasi: ?add=1 (bitta), ?add=list (ro'yxat); xato bo'lgan forma qaytadan to'ldiriladi
$addOpen = in_array($gs('add'), ['1', 'list'], true) ? $gs('add') : '';
$prefill = isset($_SESSION['stu_add_form']) && is_array($_SESSION['stu_add_form']) ? $_SESSION['stu_add_form'] : null;
unset($_SESSION['stu_add_form']);
if ($prefill) $addOpen = '1';
$listUrl = url('students', $keep);
$cardsGroup = $group;
$tests = rows('SELECT id, title, price FROM tests ORDER BY id DESC');

page_header('O\'quvchilar');
?>
<div class="page-head">
  <div><h1>O'quvchilar<?= $arch ? ' — arxiv' : '' ?></h1><p class="muted" style="margin:0"><?= $nAll ?> ta faol · <?= $nReg ?> ta onlayn ro'yxatdan o'tgan<?= $nBot ? ' · ' . $nBot . ' ta botda' : '' ?> · <?= $nPhone ?> ta telefon raqamli
    · <a class="gx-none<?= $nNone ? '' : ' zero' ?>" href="<?= e(url('students', ['group' => '@none'])) ?>" title="Guruhga biriktirilmagan faol o'quvchilar"><b data-none-count><?= $nNone ?></b> ta guruhsiz</a>
    · <?= $arch ? '<a href="' . e(url('students')) . '">← faol o\'quvchilar</a>' : '<a href="' . e(url('students', ['arch' => '1'])) . '">arxivda: ' . $nArch . ' ta</a>' ?></p></div>
  <div class="row gap wrap stu-head-acts">
    <a class="btn primary" href="<?= e(url('students', ['add' => '1'] + $keep)) ?>" data-dlg="stuAdd"><?= icon('plus', 16) ?>O'quvchi qo'shish</a>
    <a class="btn" href="<?= e(url('students', ['add' => 'list'] + $keep)) ?>" data-dlg="stuBulk"><?= icon('upload', 16) ?>Ro'yxatni qo'shish</a>
  </div>
</div>
<form class="row gap wrap center-v filter stu-filter" method="get" id="stuFilter">
  <input type="hidden" name="p" value="students"><?php if ($arch): ?><input type="hidden" name="arch" value="1"><?php endif; ?>
  <input type="search" name="s" value="<?= e($search) ?>" placeholder="Ism, ID, telefon yoki maktab" aria-label="Qidirish">
  <select name="group" aria-label="Guruh">
    <option value="">Barcha guruhlar</option>
    <option value="@none" <?= $group === '@none' ? 'selected' : '' ?>>Guruhsizlar<?= $arch ? '' : ' (' . $nNone . ')' ?></option>
    <?php foreach ($gc as $g): ?><option value="<?= e($g['name']) ?>" <?= $g['name'] === $group ? 'selected' : '' ?>><?= e($g['name']) ?><?= $arch ? '' : ' (' . (int)$g['n'] . ')' ?></option><?php endforeach; ?>
  </select>
  <?php if ($mocks): ?><select name="mock" aria-label="MOCK ro'yxati" title="Shu MOCK ga ro'yxatdan o'tganlar">
    <option value="">MOCK: hammasi</option>
    <?php foreach ($mocks as $m): ?><option value="<?= (int)$m['id'] ?>" <?= (int)$m['id'] === $mock ? 'selected' : '' ?>><?= e($m['title']) ?> — <?= (int)$m['n'] ?> ta<?= (int)$m['nog'] ? ', guruhsiz ' . (int)$m['nog'] : '' ?></option><?php endforeach; ?>
  </select><?php endif; ?>
  <select name="source" aria-label="Manba"><option value="">Barcha manbalar</option><option value="register" <?= $source === 'register' ? 'selected' : '' ?>>Onlayn ro'yxat</option><option value="bot" <?= $source === 'bot' ? 'selected' : '' ?>>Botda ro'yxatdan o'tgan</option><option value="admin" <?= $source === 'admin' ? 'selected' : '' ?>>Admin qo'shgan</option></select>
  <button class="btn">Filtr</button>
  <span class="muted small"><?= $total ?> ta topildi<?php if ($filtered): ?> · <a href="<?= e(url('students', $arch ? ['arch' => '1'] : [])) ?>">× tozalash</a><?php endif; ?></span>
  <span class="sf-tools">
    <a class="btn sm ghost" href="<?= e(url('groups')) ?>"><?= icon('users', 14) ?>Guruhlar</a>
    <a class="btn sm ghost" target="_blank" href="<?= e(url('cards', array_filter(['group' => $cardsGroup]))) ?>"><?= icon('print', 14) ?>ID va parol kartochkalari</a>
    <a class="btn sm ghost" href="<?= e(url('export', array_filter(['what' => 'students', 'group' => $group, 'source' => $source, 'mock' => $mock ?: '', 'arch' => $arch]))) ?>"><?= icon('download', 14) ?>Excel</a>
  </span>
</form>

<?php /* Oynalar. JS siz: ?edit=ID, ?add=1, ?add=list — sahifada karta bo'lib ochiladi (static); JS bilan — modal oyna */ ?>
<dialog class="qb-dlg stu-dlg wide<?= $editing ? ' static' : '' ?>" id="stuEdit" aria-labelledby="stuEditT"<?= $editing ? ' open data-sid="' . (int)$editing['id'] . '"' : '' ?>>
  <div id="stuEditBody"><?php if ($editing) student_edit_panel($editing, $listUrl); ?></div>
</dialog>
<dialog class="qb-dlg stu-dlg wide<?= $addOpen === '1' ? ' static' : '' ?>" id="stuAdd" aria-labelledby="stuAddT"<?= $addOpen === '1' ? ' open' : '' ?>>
  <div class="dlg-h"><h3 id="stuAddT">Bitta o'quvchi qo'shish</h3><a class="btn sm ghost dlg-x" href="<?= e($listUrl) ?>" data-close aria-label="Yopish" title="Yopish (Esc)">×</a></div>
  <form method="post" class="form" action="<?= e($listUrl) ?>">
    <?= csrf_field() ?><input type="hidden" name="action" value="add">
    <?php student_fields($prefill ? $prefill + ['center_id' => 0] : null, $groups, $centers, $group === '@none' ? '' : $group); ?>
    <label>ID (ixtiyoriy) <input name="code" maxlength="6" placeholder="avtomatik" inputmode="numeric" value="<?= e($prefill['code'] ?? '') ?>"></label>
    <p class="small muted">Saqlangach ID va vaqtinchalik parol beriladi — o'quvchi oynasi ochiladi.</p>
    <div class="dlg-foot"><button class="btn primary">Qo'shish</button><a class="btn ghost" href="<?= e($listUrl) ?>" data-close>Bekor qilish</a></div>
  </form>
</dialog>
<dialog class="qb-dlg stu-dlg wide<?= $addOpen === 'list' ? ' static' : '' ?>" id="stuBulk" aria-labelledby="stuBulkT"<?= $addOpen === 'list' ? ' open' : '' ?>>
  <div class="dlg-h"><h3 id="stuBulkT">Ro'yxatni qo'shish</h3><a class="btn sm ghost dlg-x" href="<?= e($listUrl) ?>" data-close aria-label="Yopish" title="Yopish (Esc)">×</a></div>
  <form method="post" class="form" action="<?= e($listUrl) ?>">
    <?= csrf_field() ?><input type="hidden" name="action" value="bulk">
    <label>Har qatorda bitta o'quvchi: <code>F.I.Sh</code> yoki <code>F.I.Sh; Guruh; Telefon; Ota-ona telefoni; Ota-ona ismi</code>
      <textarea name="names" rows="8" placeholder="Karimov Aziz Anvar o'g'li&#10;Rahimova Dilnoza; 11-B; +998901234567; +998931112233; Rahimov Anvar"></textarea></label>
    <div class="grid2">
      <label>Guruh (standart) <input name="group_name" list="groups" value="<?= e($group === '@none' ? '' : $group) ?>" autocomplete="off"></label>
    </div>
    <div class="dlg-foot"><button class="btn primary">Qo'shish</button><a class="btn ghost" href="<?= e($listUrl) ?>" data-close>Bekor qilish</a></div>
  </form>
</dialog>

<form method="post" id="massForm" class="stu-mass">
  <?= csrf_field() ?><input type="hidden" name="action" value="mass">
  <input type="hidden" name="f_group" value="<?= e($group) ?>"><input type="hidden" name="f_s" value="<?= e($search) ?>"><input type="hidden" name="f_arch" value="<?= e($arch) ?>"><input type="hidden" name="f_source" value="<?= e($source) ?>"><input type="hidden" name="f_mock" value="<?= $mock ?: '' ?>">
  <div class="table-wrap"><table class="tbl compact-tbl stu-tbl">
    <thead><tr><th class="chk-th"><input type="checkbox" id="checkAll" aria-label="Barchasini belgilash" title="Barchasini belgilash"></th><th>ID</th><th>F.I.Sh</th><th>Telefon</th><th>Guruh</th><th>Parol</th><th class="num">Testlar</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($list as $s) student_row($s, $keep); ?>
    <?php if (!$list): ?><tr><td colspan="8" class="empty">O'quvchi topilmadi</td></tr><?php endif; ?>
    </tbody>
  </table></div>
  <?php if ($total > count($list)): ?><p class="small muted">Birinchi <?= count($list) ?> tasi ko'rsatildi (jami <?= $total ?>) — qidiruv yoki filtrdan foydalaning.</p><?php endif; ?>
  <?php if ($list): ?><p class="small muted stu-hint">Qatorni bosib belgilang (<b>Shift</b> bilan — oraliqdagilar ham). Guruhni o'zgartirish uchun «Guruh» ustunidagi yozuvni bosing.</p><?php endif; ?>
  <div class="mass-bar stu-bar" id="stuBar" role="region" aria-label="Belgilanganlar bilan amallar">
    <span class="stu-bar-n"><b id="selN">0</b> ta tanlangan</span>
    <button type="button" class="btn sm primary" id="grpBtn" hidden><?= icon('users', 14) ?>Guruhga biriktirish</button>
    <button type="button" class="btn sm ghost stu-bar-x" id="selClear" hidden aria-label="Belgilashni bekor qilish" title="Belgilashni bekor qilish">×</button>
    <span class="stu-bar-ops" id="barOps">
      <select name="op" id="massOp" aria-label="Amal"><option value="group">Guruhga o'tkazish</option><?php if ($arch): ?><option value="unarchive">Arxivdan chiqarish</option><?php else: ?><option value="moc">MOCK ga biriktirish</option><option value="sendtemp">Vaqtinchalik parolni yuborish (bot/SMS)</option><option value="archive">Arxivlash</option><?php endif; ?><option value="delete">O'chirish</option></select>
      <select name="to_group" class="op-group" aria-label="Qaysi guruhga"><option value="">— guruhsiz —</option><?php foreach ($groups as $g): ?><option><?= e($g) ?></option><?php endforeach; ?></select>
      <select name="to_test" class="op-moc" hidden aria-label="Qaysi MOCK ga"><?php foreach ($tests as $tt): ?><option value="<?= (int)$tt['id'] ?>" <?= (int)$tt['id'] === $mock ? 'selected' : '' ?>><?= e($tt['title']) ?><?= (int)$tt['price'] > 0 ? ' — ' . e(som((int)$tt['price'])) : '' ?></option><?php endforeach; ?></select>
      <select name="to_pay" class="op-moc" hidden aria-label="To'lov (pullik MOCK uchun)" title="Faqat pullik MOCK uchun; bepulda e'tiborga olinmaydi">
        <option value="auto">Hamyondan (yetmasa — band)</option><option value="unpaid">Band — to'lov kutiladi</option>
        <?php if (can_finance()): ?><option value="cash">Naqd to'langan</option><option value="waive">Bepul (imtiyoz)</option><?php endif; ?>
      </select>
      <button class="btn sm" id="massDo" onclick="return document.getElementById('massOp').value!=='delete' || confirm('Tanlangan o\'quvchilar va ularning javoblari o\'chirilsinmi?')">Bajarish</button>
    </span>
  </div>
</form>
<?php if ($hasDemo): ?>
<form method="post" class="card stu-demo" onsubmit="return confirm('Namuna test va sinov o\'quvchilari o\'chirilsinmi?')">
  <?= csrf_field() ?><input type="hidden" name="action" value="delete_demo">
  <p class="small muted">O'rnatishda qo'shilgan namuna ma'lumotlarni o'chirish.</p>
  <button class="btn sm danger-ghost">Namuna ma'lumotlarni o'chirish</button>
</form>
<?php endif; ?>
<datalist id="groups"><?php foreach ($gc as $g): ?><option value="<?= e($g['name']) ?>"><?php endforeach; ?></datalist>
<script type="application/json" id="stuData"><?= json_encode(['page' => 'students', 'groups' => $gc, 'none' => $nNone, 'test' => 0, 'arch' => $arch === '1'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<?php page_footer(['assets/students.js']);
