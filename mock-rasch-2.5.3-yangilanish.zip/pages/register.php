<?php
defined('APP_ROOT') || exit;
/**
 * MOCK ga ro'yxatdan o'tish: 1) MOCK ni tanlash  2) shaxsiy ma'lumotlar.
 * Birinchi marta ro'yxatdan o'tganda ID beriladi va o'quvchi o'z parolini belgilaydi; keyingi MOCK larga ID/telefon + parol bilan (p=moc) ro'yxatdan o'tiladi.
 * Ochiq MOCK bo'lmasa — oldindan ro'yxatdan o'tish (baza uchun), MOCK tanlanmaydi.
 */
// Oldin ro'yxatdan o'tgan (kirgan) o'quvchi formani qayta to'ldirmaydi — MOCK tanlash sahifasiga o'tadi
if (student() && empty($_SESSION['just_registered'])) redirect('moc', !empty($_GET['test']) ? ['test' => (int)$_GET['test']] : []);
$openTests = mock_open_list(0);   // 2.5: ro'yxati ochiq va hali o'tmagan MOCK lar (narxi bilan)
$openIds = array_map('intval', array_column($openTests, 'id'));
$errors = [];
$f = [
    'last_name' => trim($_POST['last_name'] ?? ''), 'first_name' => trim($_POST['first_name'] ?? ''),
    'middle_name' => trim($_POST['middle_name'] ?? ''), 'phone' => trim($_POST['phone'] ?? ''),
    'school' => trim($_POST['school'] ?? ''), 'grade_level' => trim($_POST['grade_level'] ?? ''),
    'test_id' => (int)($_POST['test_id'] ?? ($_GET['test'] ?? 0)),
];
if (!in_array($f['test_id'], $openIds, true)) $f['test_id'] = 0;
if (!$f['test_id'] && count($openIds) === 1) $f['test_id'] = $openIds[0];   // bitta MOCK bo'lsa — o'zi tanlanadi
$nameOk = fn($s) => name_ok($s);
$cap = fn(string $s): string => name_cap($s);   // har so'z bosh harf bilan; "o'g'li", "qizi" kichik harfda (2.5.2: botdagi ro'yxatdan o'tish bilan bitta qoida)

if (is_post() && empty($_SESSION['just_registered'])) {
    csrf_check();
    if (!empty($_POST['website'])) { http_response_code(400); exit; }   // bot tuzog'i
    if (throttle_wait('register', client_ip(), 10, 10, 60)) $errors[] = 'Bu qurilmadan juda ko\'p ro\'yxatdan o\'tildi. Birozdan keyin urinib ko\'ring.';
    if (throttle_wait('register_err', client_ip(), 30, 30, 60)) $errors[] = 'Juda ko\'p xato urinish. Birozdan keyin urinib ko\'ring.';
    if ($openTests && !$f['test_id']) $errors[] = 'Qaysi MOCK ga ro\'yxatdan o\'tayotganingizni tanlang.';
    if (!$nameOk($f['last_name'])) $errors[] = 'Familiyani to\'g\'ri kiriting (faqat harflar).';
    if (!$nameOk($f['first_name'])) $errors[] = 'Ismni to\'g\'ri kiriting (faqat harflar).';
    if ($f['middle_name'] !== '' && !$nameOk($f['middle_name'])) $errors[] = 'Otasining ismini to\'g\'ri kiriting.';
    $phone = norm_phone($f['phone']);
    if ($phone === '') $errors[] = 'Telefon raqamni +998 XX XXX XX XX ko\'rinishida kiriting.';
    elseif (val('SELECT 1 FROM students WHERE phone=?', [$phone])) $errors[] = 'Bu telefon raqam bilan oldin ro\'yxatdan o\'tilgan. Formani qayta to\'ldirish shart emas — yuqoridagi "ID yoki telefon + parol bilan kiring" havolasi orqali kirib, MOCK ni tanlang. Parolni unutgan bo\'lsangiz, kirish sahifasidagi "Parolni unutdingizmi?" ni bosing.';
    $passIn = (string)($_POST['pass'] ?? '');
    if ($pp = pass_problem($passIn)) $errors[] = $pp;
    elseif ($passIn !== (string)($_POST['pass2'] ?? '')) $errors[] = 'Parollar mos kelmadi.';
    if (empty($_POST['consent'])) $errors[] = 'Shaxsiy ma\'lumotlarni qayta ishlashga rozilik bering.';
    if ($errors) throttle_fail('register_err', client_ip());   // telefon raqamlarni "tekshirib chiqish"ga yo'l qo'ymaslik
    if (!$errors) {
        throttle_fail('register', client_ip());   // ro'yxatdan o'tishlar sonini hisoblash uchun
        $l = $cap($f['last_name']); $fn = $cap($f['first_name']); $m = $cap($f['middle_name']);
        $code = gen_student_code();
        q('INSERT INTO students (code, full_name, last_name, first_name, middle_name, phone, school, grade_level, pin, pass_hash, must_change, pass_changed_at, source, created_ip)
           VALUES (?,?,?,?,?,?,?,?,?,?,0,NOW(),?,?)',
            [$code, compose_name($l, $fn, $m), $l, $fn, $m, $phone, mb_substr($f['school'], 0, 160), mb_substr($f['grade_level'], 0, 20), '', password_hash($passIn, PASSWORD_DEFAULT), 'register', client_ip()]);
        $sid = (int)db()->lastInsertId();
        // 2.5: yagona qoida — pullik MOCK da yangi o'quvchining joyi band qilinadi (balans 0), to'lov qadami yakunlash sahifasida
        $reg = $f['test_id'] ? mock_register($sid, $f['test_id'], 'register', ['pay' => 'auto']) : null;
        student_session_start(['id' => $sid, 'code' => $code, 'full_name' => compose_name($l, $fn, $m)], false);
        $t = $f['test_id'] ? row('SELECT title, test_date FROM tests WHERE id=?', [$f['test_id']]) : null;
        $_SESSION['just_registered'] = ['code' => $code, 'name' => compose_name($l, $fn, $m),
            'test' => $t['title'] ?? '', 'date' => $t['test_date'] ?? '',
            'price' => $reg ? (int)$reg['price'] : 0, 'unpaid' => $reg && $reg['ok'] && $reg['status'] === 'unpaid'];
        redirect('register');
    }
}
$done = $_SESSION['just_registered'] ?? null;
page_header('MOCK ga ro\'yxatdan o\'tish', ['main' => 'narrow-main']);
if ($done): unset($_SESSION['just_registered']); ?>
<div class="card narrow reg-done">
  <div class="eyebrow">Ro'yxatdan o'tdingiz</div>
  <h1><?= e($done['name']) ?></h1>
  <?php if ($done['test']): ?>
    <div class="moc-chosen"><small>MOCK</small><b><?= e($done['test']) ?></b><?php if ($done['date']): ?><span><?= e(date('d.m.Y', strtotime($done['date']))) ?></span><?php endif; ?></div>
    <?php if (!empty($done['unpaid'])): $cards = pay_cards(); ?>
    <div class="reg-pay">
      <div class="rp-h"><?= icon('wallet', 18) ?><b>To'lov: <?= e(som((int)$done['price'])) ?></b></div>
      <p class="small" style="margin:.3rem 0 .5rem">Joyingiz band qilindi. Ro'yxatda qolish uchun to'lovni amalga oshiring: <?= $cards ? 'quyidagi kartaga o\'tkazing va chekni yuboring' : 'o\'quv markaziga naqd to\'lang yoki karta raqamini so\'rang' ?>. Ro'yxat yopilguncha to'lanmasa, band bekor bo'ladi.</p>
      <?php foreach ($cards as $c): ?><div class="pay-card"><div><span class="pc-no mono"><?= e($c['no']) ?></span><small><?= e(trim($c['owner'] . ($c['bank'] !== '' ? ' · ' . $c['bank'] : ''), ' ·')) ?></small></div></div><?php endforeach; ?>
      <a class="btn primary wide mt" href="<?= e(url('student_wallet')) ?>#topup"><?= icon('upload', 16) ?>Chekni yuborish</a>
    </div>
    <?php else: ?>
    <p class="small muted">Javoblar varaqangiz shu MOCK uchun ismingiz va ID raqamingiz bilan tayyorlanadi.</p>
    <?php endif; ?>
  <?php else: ?><p class="muted">Ma'lumotlaringiz saqlandi. MOCK e'lon qilinganda shu ID (yoki telefon) va parolingiz bilan kirib, bir bosishda ro'yxatdan o'tasiz.</p><?php endif; ?>
  <div class="id-codes big">
    <div>ID raqam<b><?= e($done['code']) ?></b></div>
  </div>
  <div class="alert warn small"><?= icon('alert') ?><span><b>ID raqamingizni yozib oling.</b> Natijani ko'rish va onlayn testga kirish uchun ID (yoki telefon) va siz belgilagan parol kerak. Parolni unutsangiz — kirish sahifasida "Parolni unutdingizmi?" orqali tiklaysiz.</span></div>
  <a class="btn primary wide" href="<?= e(url('student_home')) ?>">Mening sahifamga o'tish</a>
</div>
<?php else: ?>
<div class="card narrow">
  <h1>MOCK ga ro'yxatdan o'tish</h1>
  <p class="small">Oldin ro'yxatdan o'tganmisiz? <a href="<?= e(url('student_login', ['next' => 'moc'] + ($f['test_id'] ? ['test' => $f['test_id']] : []))) ?>">ID yoki telefon + parol bilan kiring</a> — formani qayta to'ldirish shart emas.</p>
  <?php foreach ($errors as $er): ?><div class="alert err small"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" class="form" novalidate>
    <?= csrf_field() ?>
    <div class="hp" aria-hidden="true"><label>Veb-sayt <input name="website" tabindex="-1" autocomplete="off"></label></div>

    <?php if ($openTests): ?>
      <div class="form-step"><span>1</span>MOCK ni tanlang</div>
      <div class="moc-pick" role="radiogroup">
        <?php foreach ($openTests as $t): ?>
          <label class="moc-opt">
            <input type="radio" name="test_id" value="<?= (int)$t['id'] ?>" <?= $f['test_id'] === (int)$t['id'] ? 'checked' : '' ?> required>
            <span><b><?= e($t['title']) ?></b><small><?= e($t['subject']) ?> · <?= $t['test_date'] ? e(date('d.m.Y', strtotime($t['test_date']))) : 'sana keyinroq e\'lon qilinadi' ?><?= $t['online'] ? ' · onlayn' : '' ?> · <?= e(mock_price_label($t)) ?></small></span>
          </label>
        <?php endforeach; ?>
      </div>
      <div class="form-step"><span>2</span>Ma'lumotlaringiz</div>
    <?php else: ?>
      <div class="alert info small"><?= icon('alert') ?><span>Hozir ro'yxati ochiq MOCK yo'q. Ma'lumotlaringizni qoldiring — MOCK e'lon qilinganda ID va parol bilan bir bosishda ro'yxatdan o'tasiz.</span></div>
    <?php endif; ?>

    <label>Familiya * <input name="last_name" value="<?= e($f['last_name']) ?>" required maxlength="60" autocomplete="family-name"></label>
    <label>Ism * <input name="first_name" value="<?= e($f['first_name']) ?>" required maxlength="60" autocomplete="given-name"></label>
    <label>Otasining ismi <input name="middle_name" value="<?= e($f['middle_name']) ?>" maxlength="60" placeholder="Masalan: Anvar o'g'li"></label>
    <label>Telefon raqam * <input name="phone" value="<?= e($f['phone']) ?>" required inputmode="tel" placeholder="+998 90 123 45 67" autocomplete="tel"></label>
    <div class="grid2">
      <label>Maktab <input name="school" value="<?= e($f['school']) ?>" maxlength="160" placeholder="Masalan: 21-maktab"></label>
      <label>Sinf
        <select name="grade_level"><option value="">—</option>
          <?php foreach (['9-sinf', '10-sinf', '11-sinf', 'Litsey 1-kurs', 'Litsey 2-kurs', 'Bitiruvchi', 'Boshqa'] as $g): ?><option <?= $f['grade_level'] === $g ? 'selected' : '' ?>><?= $g ?></option><?php endforeach; ?>
        </select></label>
    </div>
    <div class="grid2">
      <label>Parol * (kamida 6 belgi) <input type="password" name="pass" required minlength="6" maxlength="64" autocomplete="new-password"></label>
      <label>Parol (takror) * <input type="password" name="pass2" required minlength="6" maxlength="64" autocomplete="new-password"></label>
    </div>
    <label class="check"><input type="checkbox" name="consent" value="1" <?= !empty($_POST['consent']) ? 'checked' : '' ?>> Ism, telefon va natijalarim o'quv markazi tomonidan saqlanishiga roziman</label>
    <button class="btn primary wide">Ro'yxatdan o'tish</button>
  </form>
</div>
<?php endif;
page_footer();
