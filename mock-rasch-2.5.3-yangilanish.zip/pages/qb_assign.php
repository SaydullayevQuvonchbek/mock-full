<?php
defined('APP_ROOT') || exit;
/** Admin: topshiriqlar — tuzish (savollar bazasidan), yuborish yoki sinf testi (qog'oz varaqlar), natijalar, savollar statistikasi */
qb_assign_tick();
$aid = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

if (is_post()) {
    csrf_check();
    $a = (string)($_POST['action'] ?? '');
    if ($a === 'create') {
        $dl = str_replace('T', ' ', trim((string)($_POST['deadline'] ?? '')));
        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $dl)) $dl .= ':00';
        $mode = (string)($_POST['aud'] ?? 'groups');
        $amode = ($_POST['mode'] ?? 'online') === 'paper' ? 'paper' : 'online';   // 2.4: sinf testi
        $stu = array_values(array_unique(array_filter(array_map('intval', array_filter((array)($_POST['stu'] ?? []), 'is_scalar')))));
        $anonN = (int)($_POST['anon_n'] ?? 0);   // 2.4.2: ismsiz variantlar soni
        if ($mode === 'anon' && $amode === 'paper') $aud = ['anon' => $anonN];
        elseif ($mode === 'all') $aud = ['all' => 1];
        elseif ($mode === 'students') $aud = ['students' => $stu];
        else $aud = ['groups' => array_values(array_filter(array_map(fn($g) => mb_substr(trim($g), 0, 80), array_filter((array)($_POST['groups'] ?? []), 'is_string'))))];
        $lvmode = ($_POST['lvmode'] ?? 'mix') === 'lv' ? 'lv' : 'mix';   // 2.3: darajalar bo'yicha soni
        $levels = [];
        if ($lvmode === 'lv') foreach ((array)($_POST['lvn'] ?? []) as $k => $c) if (isset(QB_LEVELS[(int)$k]) && (int)$c > 0) $levels[(int)$k] = (int)$c;
        if ($lvmode === 'lv' && !$levels) { $id = null; $err = 'Daraja bo\'yicha tuzish uchun kamida bitta darajaga savollar sonini kiriting'; $cnt = 0; }
        elseif ($lvmode === 'mix' && (int)($_POST['n'] ?? 0) < 1) { $id = null; $err = 'Savollar sonini kiriting (1–60)'; $cnt = 0; }
        else [$id, $err, $cnt] = qb_assign_create([
            'title' => (string)($_POST['title'] ?? ''), 'sections' => (array)($_POST['sec'] ?? []), 'n' => (int)($_POST['n'] ?? 10),
            'deadline' => $dl, 'review' => !empty($_POST['review']), 'aud' => $aud, 'notify' => !empty($_POST['notify']), 'levels' => $levels,
            'mode' => $amode, 'sheet' => (string)($_POST['sheet'] ?? 'bubble'),
            'closed' => !empty($_POST['closed']),   // 2.5.2: «Yopiq savollarni ham qo'shish» (odatda o'chiq)
        ]);
        if (!$id) {
            flash($err, 'err');
            $_SESSION['asg_draft'] = ['title' => mb_substr((string)($_POST['title'] ?? ''), 0, 150), 'sec' => array_map('intval', (array)($_POST['sec'] ?? [])), 'n' => (int)($_POST['n'] ?? 10),
                'deadline' => (string)($_POST['deadline'] ?? ''), 'lvmode' => $lvmode, 'lvn' => array_map('intval', (array)($_POST['lvn'] ?? [])), 'aud' => $mode,
                'groups' => array_values(array_filter((array)($_POST['groups'] ?? []), 'is_string')), 'review' => !empty($_POST['review']), 'notify' => !empty($_POST['notify']),
                'mode' => $amode, 'sheet' => (string)($_POST['sheet'] ?? 'bubble'), 'stu' => $stu, 'anon_n' => $anonN, 'closed' => !empty($_POST['closed'])];
            redirect('qb_assign');
        }
        if ($amode === 'paper') {
            flash(isset($aud['anon']) ? 'Sinf testi tayyor: ' . $cnt . ' ta variant — har birida savollar tartibi boshqa. Varaqlarni chop eting.'
                                      : 'Sinf testi tayyor: ' . $cnt . ' ta o\'quvchi — har biriga alohida variant. Varaqlarni chop eting.');
            redirect('qb_assign', ['id' => $id]);
        }
        $tg = (int)val('SELECT COUNT(*) FROM tg_queue WHERE kind="asg" AND test_id=?', [$id]);
        if ($tg && tg_ready()) tg_drain_now(10, 300);   // cron kutmasdan darhol yuborish
        flash('Topshiriq yuborildi: ' . $cnt . ' ta o\'quvchi' . ($tg ? ' (Telegramga xabar: ' . $tg . ' ta)' : ''));
        redirect('qb_assign', ['id' => $id]);
    }
    $as = $aid ? row('SELECT * FROM qb_assign WHERE id=?', [$aid]) : null;
    if (!$as) { flash('Topshiriq topilmadi', 'err'); redirect('qb_assign'); }
    $paperA = qb_assign_is_paper($as);
    if ($paperA && in_array($a, ['deadline', 'remind'], true)) $a = '';   // sinf testida muddat va eslatma yo'q
    if ($a === 'finish' && $paperA && $as['closed_at'] === null) {   // sinf testini yakunlash: javobi kiritilmaganlar — «kelmadi»
        $n = qb_assign_close($aid);
        $miss = (int)val('SELECT COUNT(*) FROM qb_tests WHERE assign_id=? AND status="missed"', [$aid]);
        if (function_exists('tg_drain_now') && tg_ready()) tg_drain_now(8, 200);
        if (qb_assign_is_anon($as)) flash('Sinf testi yakunlandi' . ($miss ? ' · ' . $miss . ' ta variantning natijasi kiritilmagan' : ''));
        else flash('Sinf testi yakunlandi' . ($miss ? ' · ' . $miss . ' ta o\'quvchi «kelmadi» deb belgilandi (natijasi kiritilmagan)' : '') . ((int)$as['review'] && val('SELECT 1 FROM qb_tests WHERE assign_id=? AND status="done" AND score_only=0 LIMIT 1', [$aid]) ? ' · o\'quvchilar endi xatolarini ko\'radi' : ''));
        redirect('qb_assign', ['id' => $aid]);
    }
    if ($a === 'addvar' && $paperA) {   // ismsiz sinf testiga yana variantlar
        $n = qb_paper_add_variants($aid, (int)($_POST['k'] ?? 0));
        flash($n ? $n . ' ta variant qo\'shildi — yangi varaqlarni chop eting.' : 'Variant qo\'shilmadi (bir yo\'la 1–100 ta, jami ' . QB_ANON_MAX . ' tagacha)', $n ? 'ok' : 'warn');
        redirect('qb_assign', ['id' => $aid]);
    }
    if ($a === 'addstu' && $paperA) {   // sinf testiga o'quvchi qo'shish — yangi variant bilan
        $n = qb_paper_add_students($aid, array_filter((array)($_POST['stu'] ?? []), 'is_scalar'));
        flash($n ? $n . ' ta o\'quvchi qo\'shildi — har biriga yangi variant. Varag\'ini chop eting.' : 'O\'quvchi tanlanmagan yoki allaqachon bor', $n ? 'ok' : 'warn');
        redirect('qb_assign', ['id' => $aid]);
    }
    if ($a === 'reopen' && $paperA && $as['closed_at'] !== null) {   // yakunlashni bekor qilish (javob kiritishni davom ettirish)
        q('UPDATE qb_assign SET closed_at=NULL WHERE id=?', [$aid]);
        q('UPDATE qb_tests SET status="open", correct=NULL, finished_at=NULL WHERE assign_id=? AND status="missed"', [$aid]);
        q('UPDATE qb_items i JOIN qb_tests t ON t.id=i.test_id SET i.ok=NULL WHERE t.assign_id=? AND t.status="open"', [$aid]);
        flash('Sinf testi qayta ochildi — natijalarni kiritishni davom ettirishingiz mumkin');
        redirect('qb_assign', ['id' => $aid]);
    }
    if ($a === 'deadline' && $as['closed_at'] === null) {
        $dl = str_replace('T', ' ', trim((string)($_POST['deadline'] ?? '')));
        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $dl)) $dl .= ':00';
        if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $dl) || strtotime($dl) <= time()) flash('Yangi muddat kelajakdagi vaqt bo\'lsin', 'err');
        else {
            q('UPDATE qb_assign SET deadline=? WHERE id=?', [$dl, $aid]);
            q('DELETE FROM tg_queue WHERE kind="asgr" AND test_id=? AND sent_at IS NOT NULL', [$aid]);   // yangi muddat uchun eslatma qayta ketadi
            flash('Muddat o\'zgartirildi: ' . date('d.m.Y H:i', strtotime($dl)));
        }
    } elseif ($a === 'remind' && $as['closed_at'] === null) {
        $n = 0;
        foreach (rows('SELECT t.student_id, s.tg_chat_id FROM qb_tests t JOIN students s ON s.id=t.student_id WHERE t.assign_id=? AND t.status="open" AND s.tg_chat_id IS NOT NULL', [$aid]) as $r) {
            q('DELETE FROM tg_queue WHERE kind="asgn" AND test_id=? AND student_id=?', [$aid, $r['student_id']]);
            if (tg_enqueue('asgn', $aid, (int)$r['student_id'], (int)$r['tg_chat_id'])) $n++;
        }
        if ($n) tg_drain_now(8, 200);
        flash($n ? $n . ' ta o\'quvchiga Telegramda eslatma yuborildi' : 'Telegramga ulangan, hali topshirmagan o\'quvchi yo\'q', $n ? 'ok' : 'warn');
    } elseif ($a === 'close' && $as['closed_at'] === null && !$paperA) {
        q('UPDATE qb_assign SET deadline=? WHERE id=?', [date('Y-m-d H:i:s'), $aid]);
        $n = qb_assign_close($aid);
        $miss = (int)val('SELECT COUNT(*) FROM qb_tests WHERE assign_id=? AND status="missed"', [$aid]);
        tg_drain_now(8, 200);
        flash('Topshiriq yopildi' . ($n ? ' · ' . ($n - $miss) . ' ta yakunlanmagan test saqlangan javoblar bilan tekshirildi' : '') . ($miss ? ' · ' . $miss . ' ta o\'quvchi topshirmadi' : ''));
    } elseif ($a === 'delete') {
        q('DELETE FROM qb_tests WHERE assign_id=?', [$aid]);
        q('DELETE FROM tg_queue WHERE kind IN ("asg","asgr","asgd","asgn") AND test_id=?', [$aid]);
        q('DELETE FROM qb_assign WHERE id=?', [$aid]);
        flash('Topshiriq o\'chirildi');
        redirect('qb_assign');
    }
    redirect('qb_assign', ['id' => $aid]);
}

/* ---------------- Bitta topshiriq ---------------- */
if ($aid) {
    $as = row('SELECT * FROM qb_assign WHERE id=?', [$aid]);
    if (!$as) { flash('Topshiriq topilmadi', 'err'); redirect('qb_assign'); }
    if (isset($_GET['pdf'])) {   // sinfda tarqatish uchun: savollar (javoblar varaqasi va kod bilan) yoki kalit bilan
        $key = $_GET['pdf'] === 'key';
        $qs = rows('SELECT ai.pos AS no, q.id, q.img, q.kind, q.nopt, q.answer, q.label FROM qb_assign_items ai JOIN qb_questions q ON q.id=ai.question_id WHERE ai.assign_id=? ORDER BY ai.pos', [$aid]);
        if (!$key) foreach ($qs as &$x) $x['answer'] = ''; unset($x);
        $pdf = $qs ? qb_pdf((string)$as['title'], 'Topshiriq · ' . (int)$as['n'] . ' ta savol · muddat: ' . date('d.m.Y H:i', strtotime((string)$as['deadline'])), $qs, $key, '#A' . $aid) : null;
        if ($pdf === null) { flash($qs ? 'PDF yaratib bo\'lmadi (serverda GD yo\'q)' : 'Topshiriqda savol qolmagan', 'err'); redirect('qb_assign', ['id' => $aid]); }
        session_write_close();
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="topshiriq-' . $aid . ($key ? '-kalit' : '') . '.pdf"');
        header('Content-Length: ' . strlen($pdf));
        header('Cache-Control: private, no-store');
        echo $pdf;
        exit;
    }
    $closed = $as['closed_at'] !== null;
    $tid = (int)($_GET['tid'] ?? 0);
    if ($tid) {   // bitta o'quvchining javoblari
        $t = row('SELECT t.*, s.full_name, s.code FROM qb_tests t LEFT JOIN students s ON s.id=t.student_id WHERE t.id=? AND t.assign_id=?', [$tid, $aid]);
        if (!$t) { flash('Test topilmadi', 'err'); redirect('qb_assign', ['id' => $aid]); }
        if ($t['student_id'] === null) { $t['full_name'] = 'Variant ' . (int)$t['var_no']; $t['code'] = ''; }   // ismsiz variant
        page_header('Javoblar — ' . $t['full_name']);
        ?>
<?= crumbs([['Topshiriqlar', url('qb_assign')], [$as['title'], url('qb_assign', ['id' => $aid])], $t['full_name']]) ?>
<h1><?= e($t['full_name']) ?><?= $t['code'] !== '' ? ' <span class="muted small">ID ' . e($t['code']) . '</span>' : '' ?></h1>
<p class="muted"><?= $t['status'] === 'done' ? 'Natija: <b>' . (int)$t['correct'] . ' / ' . (int)$t['n'] . '</b> · ' . e(date('d.m.Y H:i', strtotime((string)$t['finished_at']))) : ($t['status'] === 'missed' ? '<span class="tag red">Topshirmadi</span> — muddatda birorta javob yo\'q' : 'Hali yakunlanmagan') ?></p>
<?php if ((int)($t['score_only'] ?? 0)): ?><div class="alert info"><?= icon('alert') ?><span>Bu natijada faqat to'g'ri javoblar soni kiritilgan — savollar bo'yicha javoblar yo'q. Javoblarni kiritish: <a href="<?= e(url('qb_paper', ['id' => $aid, 'v' => 'entry', 'm' => 'ans'])) ?>">«Har savol javobi»</a>.</span></div><?php else: ?>
<div class="qb-review">
<?php foreach (qb_review_items($tid) as $it): $ok = $it['ok'] === null ? null : (int)$it['ok']; ?>
  <div class="card qb-rv <?= $ok === 1 ? 'good' : ($ok === 0 ? 'bad' : '') ?>">
    <div class="qb-rv-h"><b><?= (int)$it['pos'] ?>-savol</b> <span class="muted small"><?= e($it['section_name']) ?></span>
      <span class="right">Javob: <b class="mono"><?= $it['given'] !== '' && $it['given'] !== '-' ? e($it['given']) : '—' ?></b> · To'g'ri: <b class="mono"><?= e(qb_answer_show($it['kind'], $it['answer'])) ?></b> <?= $ok === 1 ? '✅' : ($ok === 0 ? '❌' : '') ?></span></div>
    <?php if ($it['img']): ?><img class="qb-qimg" loading="lazy" alt="<?= (int)$it['pos'] ?>-savol" src="<?= e(url('qb_img', ['id' => $it['question_id'], 'v' => substr((string)$it['img'], 1, 8)])) ?>"><?php else: ?><p class="muted small">Savol bazadan o'chirilgan — hisobga olinmadi.</p><?php endif; ?>
  </div>
<?php endforeach; ?>
</div>
<?php endif; ?>
        <?php
        page_footer();
        return;
    }
    // savollar bo'yicha: savol id si bo'yicha (sinf testida har o'quvchida tartib boshqa)
    $qstat = rows('SELECT ai.pos, ai.question_id, ai.section_name, q.img, q.kind, q.answer, q.level, q.closed, q.section_id,
                          SUM(i.ok=1) k, SUM(i.ok IS NOT NULL) n
                   FROM qb_assign_items ai LEFT JOIN qb_questions q ON q.id=ai.question_id
                   LEFT JOIN qb_items i ON i.question_id=ai.question_id AND i.test_id IN (SELECT id FROM qb_tests WHERE assign_id=? AND status="done")
                   WHERE ai.assign_id=? GROUP BY ai.pos, ai.question_id, ai.section_name, q.img, q.kind, q.answer, q.level, q.closed, q.section_id ORDER BY ai.pos', [$aid, $aid]);
    $closedSecs = qb_closed_sections();   // 2.5.2: yopiq savollar belgisi (admin uchun)
    $wrong = [];
    foreach (rows('SELECT i.question_id, i.given, COUNT(*) c FROM qb_items i JOIN qb_tests t ON t.id=i.test_id WHERE t.assign_id=? AND t.status="done" AND i.ok=0 AND i.given NOT IN ("","-") GROUP BY i.question_id, i.given ORDER BY c DESC', [$aid]) as $w)
        if (!isset($wrong[(int)$w['question_id']])) $wrong[(int)$w['question_id']] = $w['given'] . ' (' . (int)$w['c'] . ')';
    $secNames = [];
    foreach (array_filter(array_map('intval', explode(',', (string)$as['sections']))) as $x) if (($pth = qb_section_path($x)) !== '') $secNames[] = $pth;
    $lvA = qb_levels_parse((string)($as['levels'] ?? ''));
    $qTable = function () use ($qstat, $wrong, $closedSecs) {
        ?>
<div class="table-wrap"><table class="tbl qb-qtbl">
  <thead><tr><th class="num">№</th><th>Savol</th><th>Daraja</th><th>To'g'ri javob</th><th class="num">To'g'ri</th><th>Ko'p uchragan xato</th></tr></thead>
  <tbody>
  <?php foreach ($qstat as $q): $n = (int)$q['n']; $p = $n ? (int)round(100 * (int)$q['k'] / $n) : null; ?>
    <tr>
      <td class="num"><b><?= (int)$q['pos'] ?></b></td>
      <td><?php if ($q['img']): ?><img class="qb-thumb" loading="lazy" alt="<?= (int)$q['pos'] ?>-savol" src="<?= e(url('qb_img', ['id' => $q['question_id'], 'v' => substr((string)$q['img'], 1, 8)])) ?>"><?php else: ?><span class="muted small">o'chirilgan</span><?php endif; ?>
        <div class="small muted"><?= e($q['section_name']) ?></div></td>
      <td class="nowrap"><?= $q['img'] ? qb_level_tag((int)$q['level']) : '' ?><?= $q['img'] && ((int)$q['closed'] || isset($closedSecs[(int)$q['section_id']])) ? ' <span class="tag qb-lock in" title="Yopiq savol — o\'quvchiga mashqda chiqmaydi">🔒</span>' : '' ?></td>
      <td class="mono"><?= e(qb_answer_show($q['kind'], $q['answer'])) ?></td>
      <td class="num"><?= $p !== null ? '<span class="pct ' . pct_cls($p) . '">' . $p . '%</span> <span class="muted small">' . (int)$q['k'] . '/' . $n . '</span>' : '—' ?></td>
      <td class="mono small"><?= e($wrong[(int)$q['question_id']] ?? '') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
        <?php
    };

    /* ---------- Sinf testi (2.4) ---------- */
    if (qb_assign_is_paper($as)) {
        $vars = qb_paper_rows($aid);
        $anon = qb_assign_is_anon($as);   // ismsiz variantlar (o'quvchi tanlanmagan)
        $done = array_values(array_filter($vars, fn($t) => $t['status'] === 'done' && (int)$t['n'] > 0));
        $avg = $done ? round(100 * array_sum(array_map(fn($t) => (int)$t['correct'] / max(1, (int)$t['n']), $done)) / count($done)) : 0;
        $wait = count(array_filter($vars, fn($t) => $t['status'] === 'open'));
        $miss = count(array_filter($vars, fn($t) => $t['status'] === 'missed'));
        $pu = fn(string $v, array $x = []) => url('qb_paper', ['id' => $aid, 'v' => $v] + $x);
        page_header('Sinf testi — ' . $as['title']);
        ?>
<?= crumbs([['Topshiriqlar', url('qb_assign')], $as['title']]) ?>
<div class="page-head">
  <div>
    <h1><?= e($as['title']) ?></h1>
    <p class="muted"><span class="tag blue">Sinf testi</span> <?= (int)$as['n'] ?> ta savol<?= $lvA ? ' (' . e(qb_levels_label($lvA)) . ')' : '' ?> · <?= e($secNames ? implode(', ', $secNames) : 'barcha bo\'limlar') ?> · <?= $anon ? count($vars) . ' ta ismsiz variant — har birida savollar tartibi boshqa, o\'quvchi ismini varaqqa o\'zi yozadi' : count($vars) . ' ta o\'quvchi — har birida savollar tartibi boshqa' ?> · javob varag'i: <?= e(mb_strtolower(QB_SHEETS[(string)$as['sheet']] ?? QB_SHEETS['bubble'])) ?></p>
    <p><?= $closed ? '<span class="tag">Yakunlangan ' . e(date('d.m.Y H:i', strtotime((string)$as['closed_at']))) . '</span>' : '<span class="tag green">Natijalar kiritilmoqda</span>' ?> · tuzilgan: <?= e(date('d.m.Y H:i', strtotime((string)$as['created_at']))) ?>
      <?php if (!$anon): ?>· <?= (int)$as['review'] ? 'yakunlangach o\'quvchi xatolarini ko\'radi' : 'o\'quvchiga faqat natija soni ko\'rsatiladi' ?><?php endif; ?></p>
  </div>
</div>
<div class="pq-actions">
  <a class="pq-act" target="_blank" href="<?= e($pu('sheets')) ?>"><?= icon('print', 22) ?><b>Varaqlar</b><small><?= $anon ? 'har variant alohida varaqda — F.I.Sh yozish joyi va javob qatori bilan' : 'har o\'quvchiga ismli varaq — o\'z tartibida, javob qatori bilan' ?></small></a>
  <a class="pq-act" target="_blank" href="<?= e($pu('keys')) ?>"><?= icon('key', 22) ?><b>Kalitlar varag'i</b><small><?= $anon ? 'barcha variantlar kaliti bitta varaqda (variant raqami bo\'yicha)' : 'barcha o\'quvchilar kaliti bitta varaqda (ID bo\'yicha)' ?></small></a>
  <a class="pq-act" target="_blank" href="<?= e($pu('screen')) ?>"><?= icon('chart', 22) ?><b>Kalitlar — ekranga</b><small>proyektor uchun katta jadval yoki bittadan</small></a>
  <a class="pq-act primary" href="<?= e($pu('entry')) ?>"><?= icon('check', 22) ?><b>Natijalarni kiritish</b><small>to'g'ri javoblar soni yoki har savol javobi<?= $anon ? '' : ' (o\'zlashtirish uchun)' ?> · keyin Excel</small></a>
</div>

<?php if ($anon): ?>
<div class="stats4">
  <div class="stat"><span><?= count($vars) ?></span>Variantlar</div>
  <div class="stat"><span><?= count($done) ?></span>Tekshirildi</div>
  <div class="stat"><span><?= $wait + $miss ?></span>Natijasi kiritilmagan</div>
  <div class="stat accent"><span><?= $done ? $avg . '%' : '—' ?></span>O'rtacha natija</div>
</div>
<?php else: ?>
<div class="stats4 s5">
  <div class="stat"><span><?= count($vars) ?></span>O'quvchilar</div>
  <div class="stat"><span><?= count($done) ?></span>Tekshirildi</div>
  <div class="stat"><span><?= $wait ?></span>Natijasi kiritilmagan</div>
  <div class="stat"><span><?= $miss ?></span>Kelmadi</div>
  <div class="stat accent"><span><?= $done ? $avg . '%' : '—' ?></span>O'rtacha natija</div>
</div>
<?php endif; ?>

<div class="row between center-v wrap mt pq-res-h"><h2><?= $anon ? 'Variantlar' : 'O\'quvchilar' ?></h2>
  <a class="btn sm" href="<?= e($pu('xlsx')) ?>" title="Natijalar jadvali (.xlsx)"><?= icon('download', 14) ?>Excel</a></div>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th class="num">Variant</th><?php if (!$anon): ?><th>O'quvchi</th><th>Guruh</th><?php endif; ?><th>Holat</th><th class="num">Natija</th><th class="num">%</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($vars as $t): $p = (int)$t['n'] > 0 && $t['status'] === 'done' ? (int)round(100 * (int)$t['correct'] / (int)$t['n']) : null; ?>
    <tr>
      <td class="num"><b><?= (int)$t['var_no'] ?></b></td>
      <?php if (!$anon): ?><td><?= e($t['full_name']) ?> <span class="muted small mono"><?= e($t['code']) ?></span></td>
      <td><?= e($t['group_name']) ?></td><?php endif; ?>
      <td><?= $t['status'] === 'done' ? '<span class="tag green">tekshirildi</span>' . ((int)$t['score_only'] ? ' <span class="tag" title="Faqat to\'g\'ri javoblar soni kiritilgan">soni</span>' : '') : ($t['status'] === 'missed' && !$anon ? '<span class="tag red">kelmadi</span>' : '<span class="tag">natijasi kiritilmagan</span>') ?></td>
      <td class="num"><?= $t['status'] === 'done' ? '<b>' . (int)$t['correct'] . '</b> / ' . (int)$t['n'] : '—' ?></td>
      <td class="num"><?= $p !== null ? '<span class="pct ' . pct_cls($p) . '">' . $p . '%</span>' : '' ?></td>
      <td class="right nowrap"><a class="btn sm ghost" target="_blank" href="<?= e($pu('sheets', ['t' => $t['tid']])) ?>" title="<?= $anon ? 'Shu variant varag\'i' : 'Shu o\'quvchining varag\'i' ?>"><?= icon('print', 14) ?>Varaq</a><?php if ($t['status'] === 'done' && !(int)$t['score_only']): ?> <a class="btn sm ghost" href="<?= e(url('qb_assign', ['id' => $aid, 'tid' => $t['tid']])) ?>">Javoblari</a><?php endif; ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>

<?php if ($anon): ?>
<form method="post" class="card form row gap wrap center-v pq-add"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>"><input type="hidden" name="action" value="addvar">
  <label>Variant qo'shish <span class="muted small">— o'quvchi ko'proq bo'lsa; savollar o'sha, tartibi yangi</span>
    <input type="number" name="k" value="5" min="1" max="100" required style="width:7rem"></label>
  <button class="btn"><?= icon('plus', 16) ?>Qo'shish</button>
</form>
<?php endif; ?>
<?php $inQ = array_flip(array_map(fn($t) => (int)$t['student_id'], $vars));
      $others = $anon ? [] : array_values(array_filter(rows('SELECT id, code, full_name, group_name FROM students WHERE archived_at IS NULL ORDER BY group_name, full_name'), fn($s) => !isset($inQ[(int)$s['id']]))); ?>
<?php if ($others): ?>
<form method="post" class="card form row gap wrap center-v pq-add"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>"><input type="hidden" name="action" value="addstu">
  <label>O'quvchi qo'shish <span class="muted small">— kech kelgan yoki unutilgan; savollar o'sha, tartibi yangi variant</span>
    <select name="stu[]" required><option value="">— tanlang —</option>
      <?php $g0 = null; foreach ($others as $o): if ($o['group_name'] !== $g0): if ($g0 !== null): ?></optgroup><?php endif; $g0 = $o['group_name']; ?><optgroup label="<?= e($g0 !== '' ? $g0 : 'Guruhsiz') ?>"><?php endif; ?>
      <option value="<?= (int)$o['id'] ?>"><?= e($o['full_name']) ?> · <?= e($o['code']) ?></option>
      <?php endforeach; if ($g0 !== null): ?></optgroup><?php endif; ?>
    </select></label>
  <button class="btn"><?= icon('plus', 16) ?>Qo'shish</button>
</form>
<?php endif; ?>

<h2 class="mt">Savollar bo'yicha</h2>
<p class="muted small">Asl tartibda (<?= $anon ? 'variantlarda' : 'o\'quvchilarda' ?> joylari boshqa). Javoblari kiritilganlar orasida to'g'ri javob berganlar ulushi va eng ko'p uchragan xato javob.<?php
  $cntOnly = count(array_filter($vars, fn($t) => $t['status'] === 'done' && (int)$t['score_only'])); if ($cntOnly): ?> <b><?= $cntOnly ?> ta natijada faqat to'g'ri javoblar soni kiritilgan</b> — ular bu jadvalga kirmaydi.<?php endif; ?></p>
<?php $qTable(); ?>

<div class="row gap wrap mt">
  <?php if (!$closed): ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>"><button class="btn" name="action" value="finish" onclick="return confirm('Sinf testi yakunlansinmi?<?= $wait && !$anon ? ' Natijasi kiritilmagan ' . $wait . ' ta o\\\'quvchi «kelmadi» deb belgilanadi.' : '' ?>')"><?= icon('check', 16) ?>Yakunlash</button></form>
  <?php else: ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>"><button class="btn ghost" name="action" value="reopen">Qayta ochish (javob kiritishni davom ettirish)</button></form>
  <?php endif; ?>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>">
    <button class="btn danger-ghost" name="action" value="delete" onclick="return confirm('Sinf testi va kiritilgan javoblar o\'chirilsinmi?')">O'chirish</button></form>
</div>
        <?php
        page_footer();
        return;
    }

    $tests = rows('SELECT t.*, s.full_name, s.code, s.group_name, s.tg_chat_id, (SELECT COUNT(*) FROM qb_items i WHERE i.test_id=t.id AND i.given NOT IN ("","-")) answered
                   FROM qb_tests t JOIN students s ON s.id=t.student_id WHERE t.assign_id=? ORDER BY FIELD(t.status,"done","open","missed"), t.correct DESC, s.full_name', [$aid]);
    $done = array_values(array_filter($tests, fn($t) => $t['status'] === 'done' && (int)$t['n'] > 0));
    $avg = $done ? round(100 * array_sum(array_map(fn($t) => (int)$t['correct'] / max(1, (int)$t['n']), $done)) / count($done)) : 0;
    $started = count(array_filter($tests, fn($t) => $t['status'] === 'open' && (int)$t['answered'] > 0));
    $missed = count(array_filter($tests, fn($t) => $t['status'] === 'missed' || ($t['status'] === 'open' && (int)$t['answered'] === 0)));
    page_header('Topshiriq — ' . $as['title']);
    ?>
<?= crumbs([['Topshiriqlar', url('qb_assign')], $as['title']]) ?>
<div class="page-head">
  <div>
    <h1><?= e($as['title']) ?></h1>
    <p class="muted"><?= (int)$as['n'] ?> ta savol<?= $lvA ? ' (' . e(qb_levels_label($lvA)) . ')' : '' ?> · <?= e($secNames ? implode(', ', $secNames) : 'barcha bo\'limlar') ?> · <?= e(qb_assign_aud_label($as)) ?></p>
    <p><?= $closed ? '<span class="tag">Yopilgan ' . e(date('d.m.Y H:i', strtotime((string)$as['closed_at']))) . '</span>' : '<span class="tag green">Ochiq</span> muddat: <b>' . e(date('d.m.Y H:i', strtotime((string)$as['deadline']))) . '</b>' ?>
      · <?= (int)$as['review'] ? 'muddatdan keyin xatolar ko\'rsatiladi' : 'faqat natija soni ko\'rsatiladi' ?> · kod <b class="mono">#A<?= $aid ?></b></p>
  </div>
  <div class="row gap wrap">
    <a class="btn" target="_blank" href="<?= e(url('qb_assign', ['id' => $aid, 'pdf' => 'q'])) ?>" title="Savollar + javoblar varaqasi (kod #A<?= $aid ?>) — sinfda tarqatish uchun"><?= icon('download', 16) ?>PDF (savollar)</a>
    <a class="btn ghost" target="_blank" href="<?= e(url('qb_assign', ['id' => $aid, 'pdf' => 'key'])) ?>"><?= icon('download', 16) ?>PDF (kalit bilan)</a>
  </div>
</div>

<div class="stats4 s5">
  <div class="stat"><span><?= count($tests) ?></span>O'quvchilar</div>
  <div class="stat"><span><?= count($done) ?></span>Topshirdi</div>
  <div class="stat"><span><?= $started ?></span>Jarayonda</div>
  <div class="stat"><span><?= $missed ?></span><?= $closed ? 'Topshirmadi' : 'Boshlamagan' ?></div>
  <div class="stat accent"><span><?= $done ? $avg . '%' : '—' ?></span>O'rtacha natija <small class="muted">(topshirganlar)</small></div>
</div>

<?php if (!$closed): ?>
<div class="card row gap wrap center-v">
  <form method="post" class="row gap wrap center-v"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>"><input type="hidden" name="action" value="deadline">
    <label>Muddatni o'zgartirish <input type="datetime-local" name="deadline" value="<?= e(date('Y-m-d\TH:i', strtotime((string)$as['deadline']))) ?>" required></label>
    <button class="btn">Saqlash</button></form>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>"><button class="btn" name="action" value="remind" <?= tg_ready() ? '' : 'disabled title="Telegram bot ulanmagan"' ?>><?= icon('bell', 16) ?>Topshirmaganlarga eslatma (Telegram)</button></form>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>"><button class="btn danger-ghost" name="action" value="close" onclick="return confirm('Topshiriq hozir yopilsinmi? Yakunlanmagan testlar saqlangan javoblar bilan tekshiriladi.')">Hozir yopish</button></form>
</div>
<?php endif; ?>

<h2 class="mt">O'quvchilar</h2>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>O'quvchi</th><th>Guruh</th><th>Holat</th><th class="num">Natija</th><th class="num">%</th><th>Topshirgan vaqti</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($tests as $t): $p = (int)$t['n'] > 0 && $t['status'] === 'done' ? (int)round(100 * (int)$t['correct'] / (int)$t['n']) : null; ?>
    <tr>
      <td><?= e($t['full_name']) ?> <span class="muted small mono"><?= e($t['code']) ?></span><?= $t['tg_chat_id'] !== null ? ' <span class="tag blue" title="Telegram ulangan">TG</span>' : '' ?></td>
      <td><?= e($t['group_name']) ?></td>
      <td><?= $t['status'] === 'missed' ? '<span class="tag red">topshirmadi</span>' : ($t['status'] === 'done' ? '<span class="tag green">topshirdi</span>' : ((int)$t['answered'] > 0 ? '<span class="tag amber">jarayonda · ' . (int)$t['answered'] . '/' . (int)$t['n'] . '</span>' : '<span class="tag">boshlamagan</span>')) ?></td>
      <td class="num"><?= $t['status'] === 'done' ? '<b>' . (int)$t['correct'] . '</b> / ' . (int)$t['n'] : '—' ?></td>
      <td class="num"><?= $p !== null ? '<span class="pct ' . pct_cls($p) . '">' . $p . '%</span>' : '' ?></td>
      <td class="nowrap small"><?= $t['finished_at'] && $t['status'] === 'done' ? e(date('d.m.Y H:i', strtotime((string)$t['finished_at']))) : '' ?></td>
      <td class="right"><?php if ($t['status'] === 'done'): ?><a class="btn sm ghost" href="<?= e(url('qb_assign', ['id' => $aid, 'tid' => $t['id']])) ?>">Javoblari</a><?php endif; ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>

<h2 class="mt">Savollar bo'yicha</h2>
<p class="muted small">Qaysi savol qiyin bo'lganini ko'rsatadi: topshirganlar orasida to'g'ri javob berganlar ulushi va eng ko'p tanlangan xato javob.</p>
<?php $qTable(); ?>

<form method="post" class="mt"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>">
  <button class="btn danger-ghost" name="action" value="delete" onclick="return confirm('Topshiriq va o\'quvchilarning shu topshiriqdagi javoblari o\'chirilsinmi?')">Topshiriqni o'chirish</button></form>
    <?php
    page_footer();
    return;
}

/* ---------------- Ro'yxat va yangi topshiriq ---------------- */
$list = rows('SELECT a.*, (SELECT COUNT(*) FROM qb_tests t WHERE t.assign_id=a.id) total, (SELECT COUNT(*) FROM qb_tests t WHERE t.assign_id=a.id AND t.status="done") done,
                     (SELECT AVG(t.correct / NULLIF(t.n,0)) FROM qb_tests t WHERE t.assign_id=a.id AND t.status="done") avgp
              FROM qb_assign a ORDER BY a.id DESC LIMIT 100');
$tree = array_values(array_filter(qb_tree(), fn($s) => $s['ready_total'] > 0));
$groups = array_column(rows('SELECT DISTINCT group_name FROM students WHERE group_name<>"" AND archived_at IS NULL ORDER BY group_name'), 'group_name');
$studs = rows('SELECT id, code, full_name, group_name FROM students WHERE archived_at IS NULL ORDER BY full_name, id');
$dr = $_SESSION['asg_draft'] ?? null; unset($_SESSION['asg_draft']);   // xato bo'lsa forma qayta to'ldiriladi
$drSec = array_flip((array)($dr['sec'] ?? []));
$drGroups = array_flip((array)($dr['groups'] ?? []));
$drStu = array_flip(array_map('intval', (array)($dr['stu'] ?? [])));
$lvMode = ($dr['lvmode'] ?? 'mix') === 'lv' ? 'lv' : 'mix';
$aMode = ($dr['mode'] ?? 'online') === 'paper' ? 'paper' : 'online';
$audSel = in_array($dr['aud'] ?? '', ['groups', 'students', 'all', 'anon'], true) ? $dr['aud'] : 'groups';
$anonN = (int)($dr['anon_n'] ?? 0) ?: 30;
$sheetSel = isset(QB_SHEETS[(string)($dr['sheet'] ?? '')]) ? (string)$dr['sheet'] : 'bubble';
// bo'limlar bo'yicha kalitli savollar soni (darajalar kesimida) — tanlovga qarab «mavjud» sonini ko'rsatish uchun
$own = []; $ownC = [];   // 2.5.2: ownC — shulardan yopiqlari (o'zi yoki bo'limi yopiq): «Yopiq savollarni ham qo'shish» belgilanmasa olinmaydi
$closedSecs = qb_closed_sections();
foreach (rows("SELECT section_id, level, closed, COUNT(*) c FROM qb_questions WHERE answer<>'' GROUP BY section_id, level, closed") as $r) {
    $sx = (int)$r['section_id']; $lx = min(3, max(0, (int)$r['level']));
    $own[$sx] = $own[$sx] ?? [0, 0, 0, 0]; $own[$sx][$lx] += (int)$r['c'];
    if ((int)$r['closed'] || isset($closedSecs[$sx])) { $ownC[$sx] = $ownC[$sx] ?? [0, 0, 0, 0]; $ownC[$sx][$lx] += (int)$r['c']; }
}
$par = [];
foreach (rows('SELECT id, parent_id FROM qb_sections') as $r) $par[(int)$r['id']] = (int)($r['parent_id'] ?? 0);
page_header('Topshiriqlar');
?>
<div class="page-head">
  <div><h1>Topshiriqlar</h1>
    <p class="muted">Savollar bazasidan test tuzing: <b>onlayn</b> — guruhga yoki o'quvchilarga muddat bilan yuborasiz, o'quvchi saytda yoki Telegram botda yechadi; <b>sinf testi</b> — kerakli sondagi variant (masalan, 30 ta) yoki har o'quvchiga ismli varaq chop etiladi: savollar bir xil, har varaqda tartibi boshqa, kalitlari bitta varaqda. Savollar tanlangan bo'limlardan navbat bilan olinadi.</p></div>
  <a class="btn ghost" href="<?= e(url('qb_mastery')) ?>"><?= icon('chart', 16) ?>O'zlashtirish</a>
</div>

<?php if (!$tree): ?>
  <div class="card empty">Avval savollar bazasiga kalitli savollar qo'shing. <a href="<?= e(url('qb')) ?>">Savollar bazasi →</a></div>
<?php else: ?>
<details class="card" <?= $list && !$dr ? '' : 'open' ?>>
  <summary><b>+ Yangi topshiriq</b></summary>
  <form method="post" class="form mt" id="asgForm"><?= csrf_field() ?><input type="hidden" name="action" value="create">
    <div class="mode-pick" role="radiogroup" aria-label="Topshiriq turi">
      <label class="mode-opt"><input type="radio" name="mode" value="online" <?= $aMode === 'online' ? 'checked' : '' ?>><span><b>Onlayn topshiriq</b><small>saytda yoki Telegram botda yechiladi, muddat bilan; javoblar avtomatik tekshiriladi</small></span></label>
      <label class="mode-opt"><input type="radio" name="mode" value="paper" <?= $aMode === 'paper' ? 'checked' : '' ?>><span><b>Sinf testi (qog'ozda)</b><small>savollar bir xil, har varaqda tartibi boshqa; N ta variant yoki ismli varaqlar va bitta kalitlar varag'i</small></span></label>
    </div>
    <div class="grid2">
      <div>
        <label>Nomi <input name="title" maxlength="150" placeholder="masalan: Tenglamalar — 1-hafta" value="<?= e($dr['title'] ?? '') ?>"></label>
        <fieldset><legend>Bo'limlar <span class="muted small">— tanlanmasa, barcha bo'limlardan. Savollar navbat bilan olinadi: har bo'limdan bittadan, keyin yana birinchisidan</span></legend>
          <div class="qb-pick">
          <?php foreach ($tree as $s): ?>
            <label class="check" style="margin-left: <?= $s['depth'] * 1.3 ?>rem"><input type="checkbox" name="sec[]" value="<?= $s['id'] ?>" <?= isset($drSec[(int)$s['id']]) ? 'checked' : '' ?>><span><?= e($s['name']) ?> <?= (int)$s['level'] ? qb_level_tag((int)$s['level']) : '' ?> <span class="muted small">· <?= $s['ready_total'] ?></span><?php $kc = (int)$s['ready_total'] - (int)$s['ready_open_total']; ?>
              <?php if ($s['closed_by']): ?><span class="tag qb-lock<?= $s['closed'] ? '' : ' in' ?>" title="Yopiq bo'lim — savollari faqat «Yopiq savollarni ham qo'shish» belgilansa olinadi">🔒 yopiq</span><?php elseif ($kc > 0): ?><span class="tag qb-lock in" title="Shundan yopiq savollar — faqat «Yopiq savollarni ham qo'shish» belgilansa olinadi">🔒 <?= $kc ?></span><?php endif; ?></span></label>
          <?php endforeach; ?>
          </div>
        </fieldset>
        <label class="check asg-closed"><input type="checkbox" name="closed" value="1" <?= !empty($dr['closed']) ? 'checked' : '' ?>><span><b>Yopiq savollarni ham qo'shish</b> <span class="muted small" id="asgClosedN"></span><br><span class="muted small">🔒 Yopiq savollar o'quvchiga mashqda (sayt va bot) chiqmaydi; belgilansa — shu topshiriqqa olinadi</span></span></label>
      </div>
      <div>
        <label data-mode="online">Muddat <input type="datetime-local" name="deadline" value="<?= e(($dr['deadline'] ?? '') ?: date('Y-m-d\TH:i', strtotime('+3 days 21:00'))) ?>" required></label>
        <fieldset class="lv-box"><legend>Savollar soni va qiyinligi</legend>
          <label class="check"><input type="radio" name="lvmode" value="mix" <?= $lvMode === 'mix' ? 'checked' : '' ?>> Aralash — darajasidan qat'i nazar</label>
          <div class="lv-row" data-for="mix"><label>Savollar soni <span class="row gap center-v"><input type="number" name="n" value="<?= (int)($dr['n'] ?? 10) ?: 10 ?>" min="1" max="60" required style="width:6.5rem"><button type="button" class="btn sm ghost n-quick" data-n="10">10</button><button type="button" class="btn sm ghost n-quick" data-n="20">20</button></span></label></div>
          <label class="check"><input type="radio" name="lvmode" value="lv" <?= $lvMode === 'lv' ? 'checked' : '' ?>> Daraja bo'yicha — har darajadan nechta</label>
          <div class="lv-row lv-counts" data-for="lv">
            <?php foreach (QB_LEVELS as $k => $nm): ?>
              <label><span class="lv lv<?= $k ?>"><?= e($nm) ?></span><input type="number" name="lvn[<?= $k ?>]" value="<?= (int)($dr['lvn'][$k] ?? 0) ?>" min="0" max="60" data-lv="<?= $k ?>"><small class="lv-have" data-have="<?= $k ?>"></small></label>
            <?php endforeach; ?>
            <div class="lv-sum" id="lvSum" role="status"></div>
          </div>
          <p class="small muted" id="lvAvail" style="margin:.4rem 0 0"></p>
        </fieldset>
        <fieldset data-mode="paper"><legend>Javob varag'i</legend>
          <div class="mode-pick sheet-pick">
            <label class="mode-opt"><input type="radio" name="sheet" value="bubble" <?= $sheetSel === 'bubble' ? 'checked' : '' ?>><span><b>Bo'yash</b><small class="sheet-demo"><i>A</i><i class="on">B</i><i>C</i><i>D</i> — to'g'ri javob doirachasi bo'yaladi</small></span></label>
            <label class="mode-opt"><input type="radio" name="sheet" value="write" <?= $sheetSel === 'write' ? 'checked' : '' ?>><span><b>Yozish</b><small class="sheet-demo"><u>1</u><em>B</em><u>2</u><em></em><u>3</u><em></em> — katakka harf yoziladi</small></span></label>
          </div>
        </fieldset>
        <fieldset><legend>Kimga</legend>
          <div data-mode="paper">
            <label class="check"><input type="radio" name="aud" value="anon" <?= $audSel === 'anon' ? 'checked' : '' ?>> <span><b>Ismsiz variantlar</b> <span class="muted small">— o'quvchi tanlanmaydi: har variant alohida varaqda, ismini o'quvchi o'zi yozadi</span></span></label>
            <div class="anon-n" data-aud="anon"><label>Nechta variant (varaq)
              <span class="row gap center-v"><input type="number" name="anon_n" value="<?= $anonN ?>" min="1" max="<?= QB_ANON_MAX ?>" style="width:6.5rem" aria-label="Variantlar soni"><?php foreach ([15, 25, 30] as $q): ?><button type="button" class="btn sm ghost anon-quick" data-n="<?= $q ?>"><?= $q ?></button><?php endforeach; ?></span></label></div>
          </div>
          <label class="check"><input type="radio" name="aud" value="groups" <?= $audSel === 'groups' ? 'checked' : '' ?>> Tanlangan guruhlar</label>
          <div class="qb-pick" data-aud="groups" style="max-height:10rem">
            <?php foreach ($groups as $g): ?><label class="check"><input type="checkbox" name="groups[]" value="<?= e($g) ?>" <?= isset($drGroups[$g]) ? 'checked' : '' ?>><span><?= e($g) ?></span></label><?php endforeach; ?>
            <?php if (!$groups): ?><span class="muted small">Guruhlar yo'q — o'quvchilarga guruh biriktiring yoki boshqa usulni tanlang.</span><?php endif; ?>
          </div>
          <label class="check"><input type="radio" name="aud" value="students" <?= $audSel === 'students' ? 'checked' : '' ?>> Tanlangan o'quvchilar</label>
          <div class="stu-pick" data-aud="students">
            <div class="stu-tools">
              <select id="stuGrp" class="sel-sm" aria-label="Guruh bo'yicha"><option value="">Barcha guruhlar</option><?php foreach ($groups as $g): ?><option value="<?= e($g) ?>"><?= e($g) ?></option><?php endforeach; ?></select>
              <input type="search" id="stuQ" class="stu-q" placeholder="Ism yoki ID" aria-label="O'quvchini qidirish">
              <button type="button" class="btn sm ghost" id="stuAll">Ko'rinayotganlarni belgilash</button>
              <button type="button" class="btn sm ghost" id="stuNone">Tozalash</button>
            </div>
            <div class="qb-pick stu-list">
              <?php foreach ($studs as $st): ?><label class="check" data-g="<?= e($st['group_name']) ?>" data-q="<?= e(mb_strtolower($st['full_name'] . ' ' . $st['code'])) ?>"><input type="checkbox" name="stu[]" value="<?= (int)$st['id'] ?>" <?= isset($drStu[(int)$st['id']]) ? 'checked' : '' ?>><span><?= e($st['full_name']) ?> <span class="muted small mono"><?= e($st['code']) ?></span><?= $st['group_name'] !== '' ? ' <span class="muted small">· ' . e($st['group_name']) . '</span>' : '' ?></span></label><?php endforeach; ?>
              <?php if (!$studs): ?><span class="muted small">O'quvchilar yo'q.</span><?php endif; ?>
            </div>
            <p class="small" id="stuCnt" role="status"></p>
          </div>
          <label class="check"><input type="radio" name="aud" value="all" <?= $audSel === 'all' ? 'checked' : '' ?>> Barcha o'quvchilar</label>
        </fieldset>
        <label class="check" id="asgReview"><input type="checkbox" name="review" value="1" <?= !$dr || !empty($dr['review']) ? 'checked' : '' ?>> <span data-mode="online">Muddat tugagach o'quvchiga xatolari va to'g'ri javoblar ko'rsatilsin</span><span data-mode="paper">Test yakunlangach o'quvchiga xatolari va to'g'ri javoblar ko'rsatilsin (javoblari kiritilgan bo'lsa)</span></label>
        <label class="check" data-mode="online"><input type="checkbox" name="notify" value="1" <?= tg_ready() ? (!$dr || !empty($dr['notify']) ? 'checked' : '') : 'disabled' ?>> Telegram botga xabar yuborilsin <?= tg_ready() ? '' : '<span class="muted small">(bot ulanmagan)</span>' ?></label>
      </div>
    </div>
    <button class="btn primary" id="asgGo"><?= icon('check', 16) ?><span data-mode="online">Tuzish va yuborish</span><span data-mode="paper">Varaqlarni tayyorlash</span></button>
  </form>
</details>
<script>
(function () {
  var D = <?= json_encode(['own' => (object)$own, 'ownC' => (object)$ownC, 'par' => (object)$par], JSON_UNESCAPED_UNICODE) ?>;
  var NAMES = <?= json_encode(QB_LEVELS, JSON_UNESCAPED_UNICODE) ?>;
  var f = document.getElementById('asgForm'); if (!f) return;
  var kids = {}, audTouched = <?= $dr ? 'true' : 'false' ?>;
  Object.keys(D.par).forEach(function (id) { var p = D.par[id]; (kids[p] = kids[p] || []).push(+id); });
  function avail() {   // tanlangan bo'limlardagi kalitli savollar darajalar bo'yicha; yopiqlari faqat «Yopiq savollarni ham qo'shish» bilan
    var sel = [].slice.call(f.querySelectorAll('input[name="sec[]"]:checked')).map(function (c) { return +c.value; });
    var incl = !!(f.querySelector('input[name=closed]') || {}).checked;
    var seen = {}, stack = sel.length ? sel.slice() : Object.keys(D.par).map(Number), sum = [0, 0, 0, 0], cl = 0;
    while (stack.length) {
      var id = stack.pop(); if (seen[id]) continue; seen[id] = 1;
      var o = D.own[id], c = D.ownC[id];
      if (o) for (var i = 0; i < 4; i++) { var k = c ? c[i] : 0; cl += k; sum[i] += incl ? o[i] : o[i] - k; }
      (kids[id] || []).forEach(function (x) { stack.push(x); });
    }
    sum.closed = cl; sum.incl = incl;
    return sum;
  }
  function val(name) { return (f.querySelector('input[name=' + name + ']:checked') || {}).value; }
  function stuFilter() {
    var g = document.getElementById('stuGrp').value, q = document.getElementById('stuQ').value.trim().toLowerCase();
    f.querySelectorAll('.stu-list label').forEach(function (l) { l.hidden = (g !== '' && l.getAttribute('data-g') !== g) || (q !== '' && l.getAttribute('data-q').indexOf(q) < 0); });
  }
  function upd() {
    var mode = val('mode') || 'online', aud = val('aud') || 'groups';
    f.querySelectorAll('[data-mode]').forEach(function (el) {
      var on = el.getAttribute('data-mode') === mode; el.hidden = !on;
      el.querySelectorAll('input, select').forEach(function (i) { i.disabled = !on || (i.name === 'notify' && i.hasAttribute('data-off')); });
      if (el.matches('input, select')) el.disabled = !on;
    });
    f.querySelectorAll('[data-aud]').forEach(function (el) { el.hidden = el.getAttribute('data-aud') !== aud; });
    document.getElementById('asgReview').hidden = mode === 'paper' && aud === 'anon';   // ismsiz variantda o'quvchi yo'q
    var a = avail(), lvm = val('lvmode') || 'mix';
    f.querySelectorAll('.lv-row').forEach(function (r) { var on = r.getAttribute('data-for') === lvm; r.classList.toggle('off', !on); r.querySelectorAll('input').forEach(function (i) { i.disabled = !on; }); });
    var tot = a[0] + a[1] + a[2] + a[3];
    document.getElementById('lvAvail').textContent = 'Tanlangan bo\'limlarda kalitli savol: ' + tot + ' ta — oson ' + a[1] + ', o\'rta ' + a[2] + ', qiyin ' + a[3] + (a[0] ? ', darajasi belgilanmagan ' + a[0] + ' (daraja bo\'yicha tuzishda olinmaydi)' : '') + '.'
      + (a.closed ? (a.incl ? ' Yopiq savollar (' + a.closed + ' ta) ham hisobda.' : ' Yopiq savollar (' + a.closed + ' ta) olinmaydi.') : '');
    var cn = document.getElementById('asgClosedN'); if (cn) cn.textContent = a.closed ? '— tanlangan bo\'limlarda ' + a.closed + ' ta yopiq savol' : '— tanlangan bo\'limlarda yopiq savol yo\'q';
    var s = 0, bad = [];
    f.querySelectorAll('input[data-lv]').forEach(function (i) {
      var k = +i.getAttribute('data-lv'), v = Math.max(0, +i.value || 0); s += v;
      var over = lvm === 'lv' && v > a[k]; i.classList.toggle('bad', over); if (over) bad.push(NAMES[k]);
      var h = f.querySelector('[data-have="' + k + '"]'); if (h) h.textContent = 'bor: ' + a[k];
    });
    var out = document.getElementById('lvSum');
    out.textContent = lvm === 'lv' ? ('Jami: ' + s + ' ta savol' + (s > 60 ? ' — 60 tadan oshmasin' : '') + (bad.length ? ' · yetarli emas: ' + bad.join(', ') : '')) : '';
    out.classList.toggle('critical-t', lvm === 'lv' && (s > 60 || bad.length > 0 || s === 0));
    var n = f.querySelectorAll('.stu-list input:checked').length;
    document.getElementById('stuCnt').textContent = n ? 'Tanlandi: ' + n + ' ta o\'quvchi' + (mode === 'paper' ? ' — har biriga alohida variant' : '') : 'Hali hech kim tanlanmagan';
  }
  var notify = f.querySelector('input[name=notify]'); if (notify && notify.disabled) notify.setAttribute('data-off', '1');
  f.addEventListener('change', function (e) {
    if (e.target.name === 'aud') audTouched = true;
    if (e.target.name === 'mode') {   // sinf testida odatda — ismsiz variantlar; onlaynda ismsiz bo'lmaydi
      var cur = val('aud'), want = !audTouched ? (e.target.value === 'paper' ? 'anon' : 'groups') : (e.target.value === 'online' && cur === 'anon' ? 'groups' : '');
      var r = want ? f.querySelector('input[name=aud][value="' + want + '"]') : null; if (r) r.checked = true;
    }
    upd();
  });
  f.addEventListener('input', upd);
  f.querySelectorAll('.anon-quick').forEach(function (b) { b.addEventListener('click', function () { f.querySelector('input[name=anon_n]').value = b.getAttribute('data-n'); var r = f.querySelector('input[name=aud][value=anon]'); if (r) r.checked = true; upd(); }); });
  f.querySelectorAll('.n-quick').forEach(function (b) { b.addEventListener('click', function () { var i = f.querySelector('input[name=n]'); i.value = b.getAttribute('data-n'); var r = f.querySelector('input[name=lvmode][value=mix]'); if (r) r.checked = true; upd(); }); });
  document.getElementById('stuGrp').addEventListener('change', stuFilter);
  document.getElementById('stuQ').addEventListener('input', stuFilter);
  document.getElementById('stuAll').addEventListener('click', function () { f.querySelectorAll('.stu-list label:not([hidden]) input').forEach(function (c) { c.checked = true; }); upd(); });
  document.getElementById('stuNone').addEventListener('click', function () { f.querySelectorAll('.stu-list input').forEach(function (c) { c.checked = false; }); upd(); });
  upd();
})();
</script>
<?php endif; ?>

<?php if ($list): ?>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>Topshiriq</th><th>Kimga</th><th class="num">Savol</th><th>Muddat / sana</th><th class="num">Topshirdi</th><th class="num">O'rtacha</th></tr></thead>
  <tbody>
  <?php foreach ($list as $a): $p = $a['avgp'] !== null ? (int)round(100 * (float)$a['avgp']) : null; $isP = qb_assign_is_paper($a); ?>
    <tr>
      <td><a href="<?= e(url('qb_assign', ['id' => $a['id']])) ?>"><b><?= e($a['title']) ?></b></a><?= $isP ? ' <span class="tag blue">sinf testi</span>' : '' ?></td>
      <td class="small"><?= e(qb_assign_aud_label($a)) ?></td>
      <td class="num"><?= (int)$a['n'] ?><?php $la = qb_levels_parse((string)($a['levels'] ?? '')); if ($la): ?><div class="tiny muted nowrap"><?= e(qb_levels_label($la)) ?></div><?php endif; ?></td>
      <?php if ($isP): ?>
      <td class="nowrap small"><?= e(date('d.m.Y', strtotime((string)$a['created_at']))) ?> <?= $a['closed_at'] !== null ? '<span class="tag">yakunlangan</span>' : '<span class="tag green">kiritilmoqda</span>' ?></td>
      <?php else: ?>
      <td class="nowrap small"><?= e(date('d.m.Y H:i', strtotime((string)$a['deadline']))) ?> <?= $a['closed_at'] !== null ? '<span class="tag">yopilgan</span>' : '<span class="tag green">ochiq</span>' ?></td>
      <?php endif; ?>
      <td class="num"><?= (int)$a['done'] ?> / <?= (int)$a['total'] ?></td>
      <td class="num"><?= $p !== null ? '<span class="pct ' . pct_cls($p) . '">' . $p . '%</span>' : '—' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php elseif ($tree): ?><div class="card empty">Hali topshiriq yo'q.</div><?php endif; ?>
<?php page_footer();
