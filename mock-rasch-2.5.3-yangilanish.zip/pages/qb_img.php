<?php
defined('APP_ROOT') || exit;
/**
 * Savol rasmini berish: faqat admin yoki shu savol o'zining mashq testida bor o'quvchi. Rasmlar uploads/qb da to'g'ridan-to'g'ri ochilmaydi.
 * 2.5.2: yopiq savol rasmi o'quvchiga faqat admin bergan topshiriq / sinf testida bo'lsa beriladi (qb_student_can_see).
 */
$id = (int)($_GET['id'] ?? 0);
$r = $id ? row('SELECT img FROM qb_questions WHERE id=?', [$id]) : null;
if (admin()) require_admin(); elseif (student()) student_session_guard();   // eskirgan sessiya rasm ko'ra olmasin
$me = student();
$okAccess = admin() || ($me && qb_student_can_see((int)$me['id'], $id));
$file = $r ? qb_dir() . '/' . basename((string)$r['img']) : '';
if (!$r || !$okAccess || !preg_match('/^q[0-9a-f]{16}\.png$/', basename($file)) || !is_file($file)) {
    http_response_code($r && !$okAccess ? 403 : 404);
    header('Content-Type: text/plain; charset=utf-8');
    exit($r && !$okAccess ? 'Ruxsat yo\'q' : 'Topilmadi');
}
session_write_close();
header('Content-Type: image/png');
header('Content-Length: ' . filesize($file));
header('Cache-Control: private, max-age=3600');
header('X-Content-Type-Options: nosniff');
readfile($file);
exit;
