<?php
defined('APP_ROOT') || exit;
/** Savollar bazasi: bo'limlar daraxti (qo'shish — qiyinlik darajasi bilan, nomi/darajasini o'zgartirish, tartib, o'chirish) */
/** Shakldagi daraja qiymati: '1'–'3' yoki 'mix' (aralash = 0); noto'g'ri bo'lsa null */
$lvIn = function ($v): ?int {
    $v = is_string($v) ? $v : '';
    if ($v === 'mix') return 0;
    return in_array($v, ['1', '2', '3'], true) ? (int)$v : null;
};
if (is_post()) {
    csrf_check();
    $a = (string)($_POST['action'] ?? '');
    $id = (int)($_POST['id'] ?? 0);
    if ($a === 'add') {
        $name = trim(preg_replace('/\s+/u', ' ', (string)($_POST['name'] ?? '')));
        $parent = (int)($_POST['parent_id'] ?? 0);
        $lv = $lvIn($_POST['level'] ?? '');
        if ($name === '' || mb_strlen($name) > 120) flash('Bo\'lim nomini kiriting (120 belgigacha)', 'err');
        elseif ($lv === null) flash('Bo\'limning qiyinlik darajasini tanlang — yuklanadigan savollarga shu daraja qo\'yiladi', 'err');
        elseif ($parent && !row('SELECT 1 FROM qb_sections WHERE id=?', [$parent])) flash('Ota bo\'lim topilmadi', 'err');
        elseif ($parent && count(explode(' › ', qb_section_path($parent))) >= 5) flash('Bo\'limlar 5 darajadan chuqur bo\'lmasin', 'err');
        else {
            $sort = (int)val('SELECT COALESCE(MAX(sort),0) FROM qb_sections WHERE parent_id <=> ?', [$parent ?: null]) + 1;
            q('INSERT INTO qb_sections (parent_id, name, sort, level) VALUES (?,?,?,?)', [$parent ?: null, $name, $sort, $lv]);
            flash('Bo\'lim qo\'shildi: ' . $name . ' · ' . ($lv ? qb_level_name($lv) : 'aralash daraja'));
        }
    } elseif (($a === 'rename' || $a === 'edit') && $id) {
        $name = trim(preg_replace('/\s+/u', ' ', (string)($_POST['name'] ?? '')));
        $cur = row('SELECT * FROM qb_sections WHERE id=?', [$id]);
        $lv = isset($_POST['level']) ? $lvIn($_POST['level']) : ($cur ? (int)$cur['level'] : 0);
        if (!$cur) flash('Bo\'lim topilmadi', 'err');
        elseif ($name === '' || mb_strlen($name) > 120) flash('Bo\'lim nomi noto\'g\'ri', 'err');
        elseif ($lv === null) flash('Qiyinlik darajasini tanlang', 'err');
        else {
            $cl = $a === 'edit' ? (!empty($_POST['closed']) ? 1 : 0) : (int)$cur['closed'];   // 2.5.2: «Yopiq» — «⋯» oynasidagi belgi
            q('UPDATE qb_sections SET name=?, level=?, closed=? WHERE id=?', [$name, $lv, $cl, $id]);
            $msg = [];
            if ($name !== $cur['name']) $msg[] = 'nomi o\'zgartirildi';
            if ($lv !== (int)$cur['level']) $msg[] = 'darajasi: ' . ($lv ? qb_level_name($lv) : 'aralash');
            if ($cl !== (int)$cur['closed']) {
                $kids = (int)val('SELECT COUNT(*) FROM qb_sections WHERE parent_id=?', [$id]);
                $msg[] = $cl ? 'yopildi' . ($kids ? ' (ichki bo\'limlari bilan)' : '') . ' — o\'quvchiga (mashq va botda) chiqmaydi, faqat admin foydalanadi'
                             : 'ochildi' . (qb_section_closed($id) ? ', lekin ota bo\'limi yopiq — o\'quvchiga hali ham chiqmaydi' : ' — o\'quvchiga chiqadi');
            }
            if ($lv && $lv !== (int)$cur['level'] && !empty($_POST['apply'])) {   // daraja o'zgarganda — bo'limning o'z savollariga ham (ichki bo'limlarga tegilmaydi)
                $n = q('UPDATE qb_questions SET level=? WHERE section_id=? AND level<>?', [$lv, $id, $lv])->rowCount();
                if ($n) $msg[] = $n . ' ta savolning darajasi ham «' . qb_level_name($lv) . '» bo\'ldi';
            }
            flash($msg ? 'Saqlandi: ' . implode(', ', $msg) : 'O\'zgarish yo\'q');
        }
    } elseif (($a === 'up' || $a === 'down') && $id) {
        $me = row('SELECT id, parent_id, sort FROM qb_sections WHERE id=?', [$id]);
        if ($me) {
            // tengdosh bo'limlarni tartibda olib, ikkitasining o'rnini almashtiramiz (sort qiymatlari qayta raqamlanadi)
            $sib = rows('SELECT id FROM qb_sections WHERE parent_id <=> ? ORDER BY sort, name, id', [$me['parent_id']]);
            $ids = array_map('intval', array_column($sib, 'id'));
            $i = array_search($id, $ids, true);
            $j = $a === 'up' ? $i - 1 : $i + 1;
            if ($i !== false && isset($ids[$j])) { [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]]; }
            foreach ($ids as $k => $sid) q('UPDATE qb_sections SET sort=? WHERE id=?', [$k + 1, $sid]);
        }
    } elseif ($a === 'delete' && $id) {
        $n = qb_delete_section($id);
        flash('Bo\'lim o\'chirildi' . ($n > 1 ? ' (ichki bo\'limlar bilan: ' . $n . ' ta)' : ''));
    }
    redirect('qb');
}

$tree = qb_tree();
$lvMix = [];   // bo'lim → o'z savollari darajalari bo'yicha: [daraja => soni]
foreach (rows('SELECT section_id, level, COUNT(*) c FROM qb_questions GROUP BY section_id, level') as $r) $lvMix[(int)$r['section_id']][(int)$r['level']] = (int)$r['c'];
$totQ = (int)val('SELECT COUNT(*) FROM qb_questions');
$totR = (int)val("SELECT COUNT(*) FROM qb_questions WHERE answer<>''");
// 2.5.2: yopiq savollar (o'zi yoki bo'limi yopiq) o'quvchiga chiqmaydi — mashqqa chiqadiganlari alohida sanaladi
$totC = $totQ - (int)val('SELECT COUNT(*) FROM qb_questions WHERE ' . qb_open_sql(''));
$totRO = (int)val("SELECT COUNT(*) FROM qb_questions WHERE answer<>'' AND " . qb_open_sql(''));
$secName = array_column($tree, 'name', 'id');
$nTests = (int)val('SELECT COUNT(*) FROM qb_tests');
page_header('Savollar bazasi');
?>
<div class="page-head">
  <div><h1>Savollar bazasi</h1>
    <p class="muted">Bo'limlar tuzing, PDF dan savollarni qirqib yuklang, javob kalitini kiriting. O'quvchilar shu savollardan tasodifiy mashq testi tuzadi. <b>🔒 Yopiq</b> bo'lim va savollar o'quvchiga chiqmaydi — ulardan faqat siz foydalanasiz (topshiriq, sinf testi, PDF).</p></div>
</div>

<div class="stats4 qb-stats<?= $totC ? ' s5' : '' ?>">
  <div class="stat"><span><?= count($tree) ?></span>Bo'limlar</div>
  <div class="stat"><span><?= $totQ ?></span>Savollar</div>
  <div class="stat accent"><span><?= $totR ?></span>Kalitli savollar<small><?= $totC ? 'o\'quvchiga chiqadi: ' . $totRO . ' ta' : 'mashq testlarida ishlatiladi' ?></small></div>
  <?php if ($totC): ?><div class="stat qb-stat-closed"><span><?= $totC ?></span>🔒 Yopiq savollar<small>o'quvchiga chiqmaydi<?= $totR - $totRO ? ' · ' . ($totR - $totRO) . ' tasi kalitli' : '' ?></small></div><?php endif; ?>
  <div class="stat"><span><?= $nTests ?></span>O'quvchilar mashqlari</div>
</div>
<?php if ($totQ > $totR): ?><div class="alert warn"><?= icon('alert') ?><span><?= $totQ - $totR ?> ta savolga hali javob kaliti kiritilmagan — ular o'quvchilarga chiqmaydi.</span></div><?php endif; ?>

<div class="card">
  <div class="card-head"><h2>Bo'limlar</h2></div>
  <?php if (!$tree): ?><p class="empty">Hali bo'lim yo'q. Quyida birinchi bo'limni qo'shing (masalan, «Algebra» yoki «Geometriya»).</p><?php endif; ?>
  <?php if ($tree): ?>
  <div class="table-wrap"><table class="tbl qb-tbl">
    <thead><tr><th>Bo'lim</th><th>Daraja</th><th class="num">Savol</th><th class="num">Kalitli</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($tree as $s): $cby = (int)$s['closed_by']; ?>
      <tr id="s<?= $s['id'] ?>"<?= $cby ? ' class="qb-sec-closed"' : '' ?>>
        <td style="padding-left: <?= 0.85 + $s['depth'] * 1.4 ?>rem">
          <?php if ($s['depth']): ?><span class="muted">└ </span><?php endif; ?>
          <a href="<?= e(url('qb_questions', ['s' => $s['id']])) ?>"><b><?= e($s['name']) ?></b></a>
          <?php if ($s['closed']): ?><span class="tag qb-lock" title="O'quvchiga (mashq va botda) chiqmaydi, faqat admin foydalanadi — ichki bo'limlari ham">🔒 Yopiq</span>
          <?php elseif ($cby): ?><span class="tag qb-lock in" title="Ota bo'lim «<?= e($secName[$cby] ?? '') ?>» yopiq — bu bo'lim ham o'quvchiga chiqmaydi">🔒 Yopiq</span><?php endif; ?>
        </td>
        <td class="nowrap"><?= qb_section_level_tag((int)$s['level']) ?><?php $mx = $lvMix[(int)$s['id']] ?? []; $other = (int)$s['level'] ? array_sum($mx) - ($mx[(int)$s['level']] ?? 0) : 0; if ($other > 0): ?> <span class="muted small" title="Bo'lim darajasidan farqli savollar">(<?= $other ?> tasi boshqa)</span><?php endif; ?></td>
        <td class="num"><?= $s['own'] ?><?php if ($s['total'] > $s['own']): ?> <span class="muted small" title="ichki bo'limlar bilan">(<?= $s['total'] ?>)</span><?php endif; ?><?php if (!$cby && $s['nclosed']): ?> <span class="tag qb-lock in" title="Alohida yopilgan savollar — o'quvchiga chiqmaydi">🔒 <?= (int)$s['nclosed'] ?> ta yopiq</span><?php endif; ?></td>
        <td class="num"><?= $s['ready'] ?><?php if ($s['own'] > $s['ready']): ?> <span class="tag amber" title="kalitsiz savollar"><?= $s['own'] - $s['ready'] ?> kalitsiz</span><?php endif; ?></td>
        <td class="right nowrap">
          <a class="btn sm" href="<?= e(url('qb_import', ['s' => $s['id']])) ?>"><?= icon('upload', 14) ?>PDF dan yuklash</a>
          <a class="btn sm ghost" href="<?= e(url('qb_questions', ['s' => $s['id']])) ?>">Savollar</a>
          <?php if ($s['total']): ?><a class="btn sm ghost" target="_blank" href="<?= e(url('qb_pdf', ['s' => $s['id'], 'key' => 1])) ?>" title="Savollar va javoblar kaliti">PDF</a><?php endif; ?>
          <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $s['id'] ?>"><button class="btn sm ghost" name="action" value="up" title="Yuqoriga">↑</button><button class="btn sm ghost" name="action" value="down" title="Pastga">↓</button></form>
          <button type="button" class="btn sm ghost qb-more-btn" data-dlg="qbdlg<?= $s['id'] ?>" title="Nomini o'zgartirish / o'chirish">⋯</button>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php foreach ($tree as $s): ?>
  <dialog class="qb-dlg" id="qbdlg<?= $s['id'] ?>">
    <form method="dialog" class="qb-dlg-x"><button class="btn sm ghost" aria-label="Yopish">×</button></form>
    <h3><?= e($s['name']) ?></h3>
    <form method="post" class="form"><?= csrf_field() ?><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="<?= $s['id'] ?>">
      <label>Nomi<input name="name" value="<?= e($s['name']) ?>" maxlength="120" required></label>
      <label>Qiyinlik darajasi<?= qb_section_level_select('level', (int)$s['level']) ?></label>
      <?php if ($s['own']): ?><label class="check"><input type="checkbox" name="apply" value="1" checked><span>Daraja o'zgartirilsa — bo'limdagi <?= (int)$s['own'] ?> ta savolga ham qo'yilsin <span class="muted small">(«aralash» tanlansa, savollar o'zgarmaydi)</span></span></label><?php endif; ?>
      <label class="check qb-close-chk"><input type="checkbox" name="closed" value="1" <?= $s['closed'] ? 'checked' : '' ?>><span><b>🔒 Yopiq</b> — o'quvchiga chiqmaydi (mashq va botda), faqat admin foydalanadi <span class="muted small">(topshiriq, sinf testi, PDF; ichki bo'limlari ham yopiq bo'ladi)</span></span></label>
      <?php if (!$s['closed'] && $s['closed_by']): ?><p class="small muted qb-close-note">Ota bo'lim «<?= e($secName[(int)$s['closed_by']] ?? '') ?>» yopiq — bu bo'lim ham o'quvchiga chiqmaydi.</p><?php endif; ?>
      <button class="btn primary">Saqlash</button></form>
    <form method="post" class="mt" onsubmit="return confirm('«<?= e(addslashes($s['name'])) ?>» bo\'limi, ichki bo\'limlari va barcha savollari (<?= (int)$s['total'] ?> ta) o\'chiriladi. Davom etamizmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $s['id'] ?>">
      <button class="btn sm danger-ghost">Bo'limni o'chirish</button></form>
  </dialog>
  <?php endforeach; ?>
  <script>
  document.querySelectorAll('.qb-more-btn').forEach(b => b.addEventListener('click', () => { const d = document.getElementById(b.dataset.dlg); if (!d) return; if (d.showModal) d.showModal(); else d.setAttribute('open', ''); const i = d.querySelector('input[name=name]'); if (i) { i.focus(); i.select(); } }));
  document.querySelectorAll('.qb-dlg').forEach(d => d.addEventListener('click', e => { if (e.target === d) d.close(); }));
  </script>
  <?php endif; ?>
</div>

<div class="card">
  <h3>Yangi bo'lim</h3>
  <form method="post" class="form row gap wrap qb-add" id="qbAdd"><?= csrf_field() ?><input type="hidden" name="action" value="add">
    <label>Nomi<input name="name" maxlength="120" required placeholder="Masalan: Tenglamalar"></label>
    <label>Qayerga<select name="parent_id"><option value="0">— Asosiy bo'lim —</option>
      <?php foreach ($tree as $s): ?><option value="<?= $s['id'] ?>" data-lv="<?= (int)$s['level'] ? (int)$s['level'] : 'mix' ?>"><?= str_repeat('— ', $s['depth']) . e($s['name']) . ($s['closed_by'] ? ' 🔒' : '') ?></option><?php endforeach; ?></select></label>
    <label>Qiyinlik darajasi<?= qb_section_level_select('level', null) ?></label>
    <label>&nbsp;<button class="btn primary"><?= icon('plus', 16) ?>Qo'shish</button></label>
  </form>
  <p class="small muted qb-add-note">Bo'limga yuklangan savollarga shu daraja avtomatik qo'yiladi (PDF dan yuklashda har safar tanlash shart emas). Topshiriq tuzishda «3 ta qiyin bo'lim» — shu daraja bo'yicha. Bitta bo'limda har xil darajadagi savollar bo'lsa — «Aralash».</p>
  <script>
  (function () {   // ichki bo'lim — odatda ota bo'lim darajasida
    var f = document.getElementById('qbAdd'); if (!f) return;
    var par = f.querySelector('select[name=parent_id]'), lv = f.querySelector('select[name=level]'), touched = false;
    lv.addEventListener('change', function () { touched = true; });
    par.addEventListener('change', function () { var o = par.options[par.selectedIndex]; if (!touched && o && o.dataset.lv) lv.value = o.dataset.lv; });
  })();
  </script>
</div>
<?php page_footer();
