<?php
defined('APP_ROOT') || exit;
/**
 * 2.5.2: O'quvchilar uchun JSON API (assets/students.js) — faqat POST, CSRF tokeni X-CSRF sarlavhasida.
 *   form       id                      → tahrirlash oynasining HTML i
 *   edit       id + forma maydonlari    → saqlash (student_save bilan bir xil tekshiruv); jadvalning yangi qatori
 *   set_group  ids[], group[, test]     → guruhga biriktirish ('' — guruhsiz; yangi nom bo'lsa guruh yaratiladi)
 */
require_once APP_ROOT . '/inc/students_lib.php';
if (!is_post()) json_out(['ok' => false, 'error' => 'POST kerak'], 405);
$tok = $_SERVER['HTTP_X_CSRF'] ?? ($_POST['_csrf'] ?? '');
if (!hash_equals(csrf_token(), (string)$tok)) json_out(['ok' => false, 'error' => 'Xavfsizlik tokeni eskirgan. Sahifani yangilang.'], 400);
$a = (string)($_POST['action'] ?? '');
$obLvl = ob_get_level();
try {
    if ($a === 'form') {
        $s = row('SELECT * FROM students WHERE id=?', [(int)($_POST['id'] ?? 0)]);
        if (!$s) json_out(['ok' => false, 'error' => 'O\'quvchi topilmadi (o\'chirilgan bo\'lishi mumkin). Sahifani yangilang.'], 404);
        ob_start();
        student_edit_panel($s);
        json_out(['ok' => true, 'id' => (int)$s['id'], 'html' => ob_get_clean()]);
    }
    if ($a === 'edit') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0 || !val('SELECT 1 FROM students WHERE id=?', [$id])) json_out(['ok' => false, 'error' => 'O\'quvchi topilmadi (o\'chirilgan bo\'lishi mumkin). Sahifani yangilang.'], 404);
        $d = student_form_data();
        if ($d['last'] === '' && $d['first'] === '') json_out(['ok' => false, 'error' => 'Familiya va ismni kiriting', 'field' => 'last_name'], 400);
        $err = student_save($d, $id);
        if ($err !== null) {
            $field = strpos($err, 'Ota-onaning 2') === 0 ? 'parent_phone2' : (strpos($err, 'Ota-ona') === 0 ? 'parent_phone' : 'phone');
            json_out(['ok' => false, 'error' => $err, 'field' => $field], 400);
        }
        $s = row('SELECT s.*, (SELECT COUNT(*) FROM responses r WHERE r.student_id=s.id) n FROM students s WHERE s.id=?', [$id]);
        ob_start();
        student_row($s);
        $tr = ob_get_clean();
        json_out(['ok' => true, 'id' => $id, 'msg' => 'Saqlandi: ' . $s['full_name'], 'row' => $tr, 'group' => (string)$s['group_name'],
            'groups' => group_counts(), 'none' => students_none_count()]);
    }
    if ($a === 'set_group') {
        $ids = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['ids'] ?? [])), fn($v) => $v > 0)));
        if (count($ids) > 5000) json_out(['ok' => false, 'error' => 'Bir martada ko\'pi bilan 5000 ta o\'quvchi'], 400);
        if ($ids) $ids = array_map('intval', array_column(rows('SELECT id FROM students WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', $ids), 'id'));
        if (!$ids) json_out(['ok' => false, 'error' => 'O\'quvchi tanlanmagan'], 400);
        $raw = is_string($_POST['group'] ?? null) ? $_POST['group'] : '';
        if (trim($raw) !== '' && group_name_clean($raw) === '') json_out(['ok' => false, 'error' => 'Guruh nomini yozing'], 400);
        $r = students_set_group($ids, $raw);
        $who = count($ids) === 1 ? (string)val('SELECT full_name FROM students WHERE id=?', [$ids[0]]) : count($ids) . ' ta o\'quvchi';
        $msg = $r['group'] === '' ? $who . ' — guruhdan chiqarildi (guruhsiz)'
            : ($r['created'] ? '«' . $r['group'] . '» — yangi guruh yaratildi; ' . $who . ' biriktirildi' : $who . ' «' . $r['group'] . '» guruhiga biriktirildi');
        $out = ['ok' => true, 'ids' => $ids, 'group' => $r['group'], 'n' => $r['n'], 'created' => $r['created'], 'msg' => $msg,
            'groups' => group_counts(), 'none' => students_none_count()];
        $tid = (int)($_POST['test'] ?? 0);
        if ($tid > 0) $out['reg_none'] = reg_none_count($tid);
        json_out($out);
    }
} catch (Throwable $ex) {
    while (ob_get_level() > $obLvl) ob_end_clean();   // yarim chiqqan HTML JSON ga aralashmasin
    error_log('[MOCK stu_api] ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
    json_out(['ok' => false, 'error' => 'Server xatosi. Sahifani yangilab qayta urinib ko\'ring.'], 500);
}
json_out(['ok' => false, 'error' => 'Noma\'lum amal'], 400);
