<?php
defined('APP_ROOT') || exit;
if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    $name = trim($_POST['name'] ?? '');
    if ($act === 'add' && $name !== '') {
        q('INSERT IGNORE INTO study_groups (name, note) VALUES (?,?)', [mb_substr($name, 0, 80), trim($_POST['note'] ?? '')]);
        flash('Guruh qo\'shildi: ' . $name);
    }
    if ($act === 'edit') {
        $g = row('SELECT * FROM study_groups WHERE id=?', [(int)$_POST['id']]);
        if ($g && $name !== '') {
            if ($name !== $g['name'] && val('SELECT 1 FROM study_groups WHERE name=?', [$name])) { flash('Bunday nomli guruh bor', 'err'); redirect('groups'); }
            db()->beginTransaction();
            q('UPDATE study_groups SET name=?, note=? WHERE id=?', [$name, trim($_POST['note'] ?? ''), $g['id']]);
            q('UPDATE students SET group_name=? WHERE group_name=?', [$name, $g['name']]);
            db()->commit();
            flash('Guruh saqlandi');
        }
    }
    if ($act === 'delete') {
        $g = row('SELECT * FROM study_groups WHERE id=?', [(int)$_POST['id']]);
        if ($g) {
            q('UPDATE students SET group_name="" WHERE group_name=?', [$g['name']]);
            q('DELETE FROM study_groups WHERE id=?', [$g['id']]);
            flash('Guruh o\'chirildi (o\'quvchilar o\'chmadi, guruhsiz qoldi)');
        }
    }
    redirect('groups');
}
$list = rows('SELECT g.*, (SELECT COUNT(*) FROM students s WHERE s.group_name=g.name AND s.archived_at IS NULL) n FROM study_groups g ORDER BY g.name');
$noGroup = (int)val('SELECT COUNT(*) FROM students WHERE group_name="" AND archived_at IS NULL');
$edit = isset($_GET['edit']) ? row('SELECT * FROM study_groups WHERE id=?', [(int)$_GET['edit']]) : null;
page_header('Guruhlar');
?>
<div class="page-head">
  <div><?= crumbs([['O\'quvchilar', url('students')], 'Guruhlar']) ?><h1>Guruhlar</h1></div>
</div>
<div class="grid-side">
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>Guruh</th><th>Izoh</th><th class="num">O'quvchilar</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($list as $g): ?>
      <tr>
        <td><a href="<?= e(url('students', ['group' => $g['name']])) ?>"><b><?= e($g['name']) ?></b></a></td>
        <td class="muted small"><?= e($g['note']) ?></td>
        <td class="num"><?= (int)$g['n'] ?></td>
        <td class="right nowrap">
          <a class="btn sm ghost" href="<?= e(url('groups', ['edit' => $g['id']])) ?>">Tahrirlash</a>
          <a class="btn sm ghost" target="_blank" href="<?= e(url('cards', ['group' => $g['name']])) ?>"><?= icon('print', 14) ?>Kartochkalar</a>
          <form method="post" class="inline" onsubmit="return confirm('Guruh o\'chirilsinmi? O\'quvchilar guruhsiz qoladi.')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$g['id'] ?>"><button class="btn sm danger-ghost">×</button></form>
        </td>
      </tr>
    <?php endforeach; ?>
    <tr class="grp-none-row"><td><a href="<?= e(url('students', ['group' => '@none'])) ?>"><b>Guruhsiz</b></a></td><td class="muted small">Bot va saytda ro'yxatdan o'tganlar shu yerga tushadi</td><td class="num"><?= $noGroup ? '<span class="tag amber">' . $noGroup . '</span>' : '0' ?></td>
      <td class="right nowrap"><?php if ($noGroup): ?><a class="btn sm" href="<?= e(url('students', ['group' => '@none'])) ?>"><?= icon('users', 14) ?>Guruhga biriktirish</a><?php endif; ?></td></tr>
    </tbody>
  </table></div>
  <div>
    <div class="card">
      <h2><?= $edit ? 'Guruhni tahrirlash' : 'Yangi guruh' ?></h2>
      <form method="post" class="form">
        <?= csrf_field() ?><input type="hidden" name="action" value="<?= $edit ? 'edit' : 'add' ?>"><?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
        <label>Nomi <input name="name" value="<?= e($edit['name'] ?? '') ?>" required maxlength="80" placeholder="Masalan: 11-A, Kechki guruh"></label>
        <label>Izoh <input name="note" value="<?= e($edit['note'] ?? '') ?>" placeholder="O'qituvchi, dars vaqti…"></label>
        <button class="btn primary"><?= $edit ? 'Saqlash' : 'Qo\'shish' ?></button>
        <?php if ($edit): ?><a class="btn ghost" href="<?= e(url('groups')) ?>">Bekor qilish</a><?php endif; ?>
      </form>
      <p class="small muted mt">Guruh nomini o'zgartirsangiz, undagi barcha o'quvchilar yangi nomga o'tadi. O'quvchilarni guruhga o'tkazish — «O'quvchilar» sahifasida belgilab «Guruhga biriktirish» tugmasini bosing yoki jadvaldagi guruh yozuvini bosing. MOCK ro'yxatidagilarni — MOCK ning «Ro'yxat» sahifasida xuddi shunday.</p>
    </div>
  </div>
</div>
<?php page_footer();
