<?php
/**
 * Telegram webhook. Telegram har bir yangilanishni shu manzilga POST qiladi.
 * Faqat Sozlamalar → Telegram da o'rnatilgan maxfiy kalit (X-Telegram-Bot-Api-Secret-Token) bilan kelgan so'rov qabul qilinadi.
 */
declare(strict_types=1);
define('NO_SESSION', 1);
require __DIR__ . '/inc/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); exit; }
$secret = tg_meta('secret');
$given = (string)($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '');
if ($secret === '' || !hash_equals($secret, $given)) { http_response_code(403); exit; }
$update = json_decode((string)file_get_contents('php://input'), true);
if (!is_array($update)) { http_response_code(400); exit; }

// Telegramga darhol javob beramiz, ishni undan keyin bajaramiz (qayta yuborishlar bo'lmasin)
ignore_user_abort(true);
header('Content-Type: text/plain; charset=utf-8');
header('Connection: close');
header('Content-Length: 2');
echo 'ok';
while (ob_get_level() > 0) @ob_end_flush();
flush();
if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();

try {
    tg_handle_update($update);
} catch (Throwable $ex) {
    error_log('[MOCK Telegram] ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
    tg_log('in', null, 'error', false, $ex->getMessage());
}
try {
    tg_tick(8);   // cron bo'lmasa ham navbat sekin bo'lsa-da yurishda qoladi
} catch (Throwable $ex) {
    error_log('[MOCK Telegram tick] ' . $ex->getMessage());
}
