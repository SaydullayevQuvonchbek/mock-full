<?php
/**
 * Vaqtli ishlar: PDF yuborish, vaqti o'tgan testlarni yopish, natija xabarlari, navbat.
 * Hostingda har 1 daqiqada chaqirilsin:
 *   wget -q -O /dev/null "https://SAYT/cron.php?key=KALIT"     yoki     php /yo'l/cron.php
 * KALIT: Sozlamalar → Telegram da yaratiladi. Buyruq satridan (CLI) kalit talab qilinmaydi.
 */
declare(strict_types=1);
define('NO_SESSION', 1);
require __DIR__ . '/inc/bootstrap.php';

if (PHP_SAPI !== 'cli') {
    $key = app_setting('cron_key');
    if ($key === '' || !hash_equals($key, (string)($_GET['key'] ?? ''))) { http_response_code(403); exit('403'); }
    header('Content-Type: text/plain; charset=utf-8');
}
tg_meta_set('last_cron', (string)time());
try {
    $r = tg_tick(45);
} catch (Throwable $ex) {
    error_log('[MOCK cron] ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
    $r = ['error' => 'xato (server jurnaliga qarang)'];
}
echo json_encode($r, JSON_UNESCAPED_UNICODE), "\n";
