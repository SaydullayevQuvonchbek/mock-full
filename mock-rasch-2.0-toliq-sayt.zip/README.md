# MOCK Rasch 2.0

Matematika milliy sertifikat MOCK imtihonlarini **Rasch (1PL)** modeli bilan baholash platformasi.
PHP 7.4+ · MySQL/MariaDB · tashqi AI yo'q · baholash kodi (`inc/rasch.php`, `inc/scoring.php`) o'zgartirilmagan.

## 1. O'rnatish / yangilash
1. ZIP dagi fayllarni hostingdagi sayt papkasiga yuklang (mavjud fayllar ustiga yoziladi). **`config.php` va `uploads/` tegilmaydi** (ZIP da yo'q).
2. Saytni bir marta oching — baza o'zi **schema 9** ga yangilanadi (eski ma'lumotlar saqlanadi).
3. Yangi bazaga birinchi o'rnatish alohida o'rnatuvchi (`install.php`) orqali bajariladi — u bu ZIP ga kirmaydi; mavjud saytni yangilash uchun kerak emas.
4. Talab: PHP 7.4+, `pdo_mysql`, `mbstring`, `curl` (bot/SMS uchun), `gd` (mashq testi PDF si uchun), `iconv`.

## 2. Sozlamalar (admin → Sozlamalar)
| Karta | Nima qilinadi |
|---|---|
| **Markaz** | Markaz nomi va **sayt manzili (https://…)** — botdagi, SMS dagi va ota-ona havolalari shundan yasaladi. |
| **Telegram bot** | BotFather tokeni → «Webhook ulash» → cron kaliti → ispmanager «Планировщик» ga **har daqiqada** cron buyrug'i (kartada tayyor ko'rinadi). |
| **Xabarlar → Eskiz.uz** | my.eskiz.uz dagi email va API paroli, jo'natuvchi (standart 4546) → «Ulanishni tekshirish» (balans ko'rinadi) → «Sinov SMS». |
| **Xabarlar → Telegram Gateway** | gateway.telegram.org dagi token → «Tekshirish». Ixtiyoriy. |
| **Kod yuborish tartibi** | `bot → gateway → sms` (o'zgartirish mumkin). Bot bepul, shuning uchun birinchi. |

### Eskiz shablonlari (MUHIM)
Eskiz faqat **oldindan tasdiqlangan matnlarni** o'tkazadi. Quyidagi 4 matnni my.eskiz.uz → «Шаблоны» da tasdiqlating
(`{…}` o'rniga Eskiz o'zining o'zgaruvchisini qo'yadi; aniq matn Sozlamalar → Xabarlar kartasida ham bor):
- `MOCK Rasch: tasdiqlash kodi {code}. 5 daqiqa amal qiladi. Hech kimga bermang.`
- `MOCK Rasch: ID {id}, vaqtinchalik parol {pass}. Kirgach parolni almashtiring.`
- `MOCK Rasch: {test}, {date}. Siz {room}, {seat}-o'rin. 15 daqiqa oldin keling.`
- `MOCK Rasch: {name}, {test}: {ball} ball ({grade}), {rank}-o'rin. {url}`

Tasdiqlanmaguncha SMS lar Eskiz tomonidan rad etiladi (jurnalda xato ko'rinadi); Telegram yo'li shundan ta'sirlanmaydi.

## 3. Imkoniyatlar
**Parol va kirish.** PIN bekor: o'quvchi o'z parolini belgilaydi (≥ 6 belgi). Admin qo'shgan o'quvchiga *vaqtinchalik parol* beriladi — birinchi kirishda almashtirish majburiy. Eski PIN lar vaqtinchalik parol sifatida ishlayveradi. Kirish: **ID yoki telefon + parol**. Parol tiklash: ID/telefon → kod (bot / Telegram Gateway / SMS) → yangi parol; kod 5 daqiqa, 3 urinish; kuniga 5 kod raqamga, 20 kod IP ga.

**O'quvchi kabineti.** MOCK lar (xona va o'rin bilan), onlayn testlar, natijalar (ball, daraja, o'rin, bo'limlar bo'yicha to'g'ri javoblar, o'sish grafigi), profil (telefonni kod bilan tasdiqlash, ota-ona raqamlari, parol almashtirish), Telegramni bir bosishda ulash.

**Xonalar.** Test → Ro'yxat: xonalar, sig'im, nazoratchi; **avto-joylashtirish** (alifbo / guruhlar aralash / tasodifiy `seed` bilan), qo'lda ko'chirish; eshik ro'yxati, xona bo'yicha davomat ro'yxati, xona bo'yicha javob varaqasi; «Xona haqida xabar yuborish» (Telegram, bo'lmasa SMS).

**Ota-onalar.** O'quvchi kartasida ota-ona ismi va 2 ta telefon (import ustuni ham bor). Natijalar e'lon qilingach Test → «Ota-onalar» → oldindan ko'rish (nechta Telegram / SMS) → tasdiqlash → navbat → hisobot va «qayta yuborish». Natija havolasi — imzolangan, faqat shu o'quvchi uchun. Ota-ona xabardan voz kecha oladi.

**Savollar banki (Savollar banki menyusi).**
1. Bo'limlar daraxti (Algebra › Tenglamalar …).
2. **PDF dan yuklash**: PDF ni tanlang → brauzerda qirqiladi (avtomatik bo'sh joy bo'yicha / har sahifa=1 savol / sichqoncha bilan qo'lda; 2 ustunli sahifalar ham) → oldindan ko'rib, keraksizini belgisini olib tashlang, bo'laklarni «↓ birlashtirish» bilan tuzating → yuklang. Kalitni shu yerning o'zida (`ACDB…`) yoki keyin «Savollar» sahifasida kiriting. Savol raqami («5.») rasmda qolsa, qo'lda rejimda raqamdan keyingi joydan qirqing.
3. Kalitsiz savollar o'quvchilarga chiqmaydi. Ochiq savolda bir nechta to'g'ri variant `0.5;1/2` ko'rinishida.
4. **O'quvchi** «Mashq testlari» da bo'lim(lar) va savollar sonini tanlaydi → tizim tasodifiy test tuzadi (oxirgi 3 mashqdagi savollarni takrorlamaydi) → javob beradi → natijada **faqat nechta to'g'ri** (umumiy va bo'limlar bo'yicha); qaysi savol xato ekani va to'g'ri javoblar ko'rsatilmaydi. Testni **PDF** qilib yuklab olish (javoblar varaqasi bilan, kalitsiz). Admin bo'lim PDF ni kalit bilan oladi.
5. Telegram botda `/mashq` — rasmli savollar, A–D tugmalari, ochiq savolga matn, yakunda sonlar.
Rasmlar `uploads/qb/` da, to'g'ridan-to'g'ri ochilmaydi: faqat `index.php?p=qb_img` orqali (admin yoki shu savol o'z mashqida bor o'quvchi).

## 4. Telegram bot buyruqlari (o'quvchi)
`/start` ulanish · `/mening` · `/natija` · `/mashq` · `/uzish` · `/help`. Ulanish: kabinetdagi «Telegramni ulash» havolasi yoki bitta xabarda `ID parol`. Ota-ona: kabinet/karta havolasi orqali ulanadi, `/natija`, `/uzish`.

## 5. Xavfsizlik
Parollar bcrypt; sessiya parol o'zgarganda tugaydi; barcha formalarda CSRF; OTP kodlar HMAC bilan saqlanadi; CSP (`script-src 'self'`); yuklangan fayllar `.htaccess` bilan yopiq; token/parollar sahifalarda ko'rsatilmaydi; throttle: kirish, bot ulash, kod yuborish.

## 6. Muammolar
- **SMS ketmayapti** — Sozlamalar → Xabarlar jurnali: 4xx = shablon tasdiqlanmagan / balans yo'q. «Ulanishni tekshirish» ni bosing.
- **Navbat yurmayapti** — cron o'rnatilganini tekshiring (Sozlamalar → Telegram: «So'nggi chaqiruv»); aks holda «Navbatni hozir ishga tushirish».
- **Mashq PDF chiqmayapti** — serverda PHP `gd` yoqilmagan; sahifada yechish ishlayveradi.
- **PDF dan qirqish ishlamayapti** — brauzer eski; Chrome/Edge/Firefox yangilang. Rasm (PNG/JPG) yuklash ham mumkin.

## 7. Texnik
Schema: 8 — parol/OTP/navbat kanali/ota-ona/`tg_links`/nazoratchi; 9 — `qb_sections`, `qb_questions`, `qb_tests`, `qb_items`. Kirish nuqtasi `index.php?p=<sahifa>`; yo'nalishlar jadvali `index.php` da. PHP 7.4 mosligi uchun `inc/compat.php`; PHP 8 sintaksisi (`match`, `?->`, union turlar) ishlatilmagan.
