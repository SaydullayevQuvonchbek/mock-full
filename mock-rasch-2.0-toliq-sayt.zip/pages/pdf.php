<?php
defined('APP_ROOT') || exit;
/**
 * Savollar kitobi (PDF) ni faqat huquqi borlarga berish.
 * Admin — har doim; o'quvchi — faqat shu testni boshlagan va vaqti tugamagan bo'lsa.
 */
$test = test_by_id((int)($_GET['id'] ?? 0));
if (!$test || empty($test['pdf_file'])) { http_response_code(404); exit('Fayl topilmadi'); }
$allowed = false;
if (admin()) {
    $allowed = true;
} elseif ($s = student()) {
    $r = row('SELECT * FROM responses WHERE test_id=? AND student_id=?', [$test['id'], $s['id']]);
    $allowed = $r && $r['status'] === 'in_progress' && $test['online'] && time() <= online_deadline($test, $r) + 60;
}
if (!$allowed) { http_response_code(403); exit('Ruxsat yo\'q'); }

$name = basename((string)$test['pdf_file']);
$path = APP_ROOT . '/uploads/' . $name;
if (!preg_match('/^test_\d+_[a-f0-9]{12}\.pdf$/', $name) || !is_file($path)) { http_response_code(404); exit('Fayl topilmadi'); }

header('Content-Type: application/pdf');
header('Content-Length: ' . filesize($path));
header('Content-Disposition: inline; filename="savollar_' . (int)$test['id'] . '.pdf"');
header('Cache-Control: private, no-store');
header('X-Robots-Tag: noindex');
readfile($path);
exit;
