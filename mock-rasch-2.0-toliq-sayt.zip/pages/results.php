<?php
defined('APP_ROOT') || exit;
$test = get_test_or_404();
if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    if ($act === 'compute') {
        if (isset($_POST['method']) && isset(method_names()[$_POST['method']])) q('UPDATE tests SET method=? WHERE id=?', [$_POST['method'], $test['id']]);
        q('UPDATE tests SET cap75=?, t_mean=?, t_sd=? WHERE id=?', [isset($_POST['cap75']) ? 1 : 0,
            max(30, min(70, (float)str_replace(',', '.', $_POST['t_mean'] ?? 50))), max(5, min(20, (float)str_replace(',', '.', $_POST['t_sd'] ?? 10))), $test['id']]);
        $st = compute_test((int)$test['id']);
        flash('Rasch hisoblash bajarildi: ' . ($st['N'] ?? 0) . ' ta o\'quvchi, ' . ($st['iterations'] ?? 0) . ' iteratsiya');
    }
    if ($act === 'certs') {
        $n = issue_certificates($test);
        flash("$n ta hujjat tayyorlandi (sertifikat yoki natija varaqasi)");
        redirect('certificate', ['id' => $test['id'], 'all' => 1]);
    }
    if ($act === 'publish') {
        q('UPDATE tests SET published=? WHERE id=?', [(int)$_POST['v'], $test['id']]);
        flash((int)$_POST['v'] ? 'Natijalar e\'lon qilindi — o\'quvchilar o\'z sahifasida ko\'radi' : 'E\'lon bekor qilindi');
    }
    redirect('results', ['id' => $test['id']]);
}
$nResp = (int)val('SELECT COUNT(*) FROM responses WHERE test_id=? AND status="submitted"', [$test['id']]);
if (($test['dirty'] || !isset($test['stats']['methods'])) && $nResp > 0 && count($test['key']) > 0) {
    compute_test((int)$test['id']);
    $test = test_by_id((int)$test['id']);
}
$stats = $test['stats'];
$group = trim($_GET['group'] ?? '');
$center = $_GET['center'] ?? '';
$centers = centers_list();
$par = [$test['id']];
$sql = 'SELECT r.*, s.code, s.full_name, s.group_name, s.center_id FROM results r JOIN students s ON s.id=r.student_id WHERE r.test_id=?';
if ($group !== '') { $sql .= ' AND s.group_name=?'; $par[] = $group; }
if ($center === 'own') $sql .= ' AND s.center_id IS NULL';
elseif ($center !== '') { $sql .= ' AND s.center_id=?'; $par[] = (int)$center; }
$M = (float)($test['t_mean'] ?? 50); $S = (float)($test['t_sd'] ?? 10);
$shifted = ($stats['method'] ?? 'tscore') !== 'tscore' || abs($M - 50) > 1e-9 || abs($S - 10) > 1e-9;
$list = rows($sql . ' ORDER BY r.rank_no, r.ball_raw DESC, s.full_name', $par);
$groups = array_column(rows('SELECT DISTINCT s.group_name FROM results r JOIN students s ON s.id=r.student_id WHERE r.test_id=? AND s.group_name<>"" ORDER BY 1', [$test['id']]), 'group_name');
$allRaw = array_map('floatval', array_column(rows('SELECT COALESCE(ball_raw, ball) v FROM results WHERE test_id=?', [$test['id']]), 'v'));
$L = count(test_items($test));
$cap = (int)($test['cap75'] ?? 1) === 1;
$over = count(array_filter($allRaw, fn($v) => $v > MAX_BALL + 1e-9));
$atCap = (int)($stats['at_cap'] ?? 0);
page_header('Natijalar — ' . $test['title']);
test_tabs($test, 'results');
?>
<?php if (!count($test['key'])): ?>
  <div class="alert warn"><?= icon('alert') ?><span>Avval <a href="<?= e(url('test_edit', ['id' => $test['id']])) ?>">javoblar kalitini</a> kiriting.</span></div>
<?php endif; ?>
<?php if (!$nResp): ?>
  <div class="card empty">Hali javoblar yo'q. Javoblarni <a href="<?= e(url('scan', ['id' => $test['id']])) ?>">skanerlang</a>, <a href="<?= e(url('entry', ['id' => $test['id']])) ?>">qo'lda kiriting</a> yoki <a href="<?= e(url('import', ['id' => $test['id']])) ?>">Excel'dan yuklang</a>.</div>
<?php else: ?>
<div class="stats4">
  <div class="stat"><span><?= (int)($stats['N'] ?? 0) ?></span>Ishtirokchi</div>
  <div class="stat"><span><?= fmt($stats['ball_mean'] ?? null) ?></span>O'rtacha ball<small>± <?= fmt($stats['ball_sd'] ?? null) ?> (SD)</small></div>
  <div class="stat"><span><?= fmt($stats['raw_mean'] ?? null) ?> <small style="display:inline;font:500 .9rem var(--sans)">/ <?= $L ?></small></span>O'rtacha to'g'ri javob</div>
  <div class="stat"><span><?= fmt($stats['reliability'] ?? null, 2) ?></span>Ishonchlilik<small>Rasch person reliability</small></div>
</div>
<?php if (($stats['N'] ?? 0) < 30): ?>
  <div class="alert warn small"><?= icon('alert') ?><span>Ishtirokchilar soni <?= (int)($stats['N'] ?? 0) ?> ta. Rasch baholari 30 tadan kam ishtirokchida beqaror — 100+ ishtirokchi bilan natija ancha ishonchli.</span></div>
<?php endif; ?>

<div class="grid-side">
  <div class="card">
    <div class="card-head"><h2>Ballar taqsimoti</h2><span class="small muted"><?= $cap ? '75 bilan cheklangan' : 'cheklovsiz' ?></span></div>
    <?= svg_ball_histogram($allRaw) ?>
    <div class="legend">
      <span><i style="background:var(--g-ap)"></i>A+</span><span><i style="background:var(--g-a)"></i>A</span><span><i style="background:var(--g-bp)"></i>B+</span>
      <span><i style="background:var(--g-b)"></i>B</span><span><i style="background:var(--g-cp)"></i>C+</span><span><i style="background:var(--g-c)"></i>C</span>
      <span><i style="background:var(--g-none)"></i>Sertifikatsiz</span><span><i style="background:var(--accent)"></i>75 — e'lon qilingan "maksimal"</span>
    </div>
    <?php
      $need = [];
      if (($stats['method'] ?? '') !== 'weighted') {
          foreach ([['C', 46], ['C+', 50], ['B', 55], ['B+', 60], ['A', 65], ['A+', 70]] as [$g, $thr]) {
              foreach (($stats['score_table'] ?? []) as $k => $row) { if (($row['ball_raw'] ?? $row['ball']) !== null && ($row['ball_raw'] ?? $row['ball']) >= $thr - 1e-9) { $need[$g] = $k; break; } }
          }
      }
      if ($need): ?>
      <div class="need-row"><span class="muted small">Kamida kerakli to'g'ri javob:</span>
        <?php foreach ($need as $g => $k): ?><span class="need"><?= grade_badge($g) ?> <?= $k ?>/<?= $L ?></span><?php endforeach; ?>
      </div>
    <?php endif; ?>
    <?php if ($atCap > 0 && ($stats['method'] ?? 'tscore') === 'tscore'): ?>
      <div class="callout small mt">
        <b><?= $atCap ?> ta o'quvchining balli 75 ga yetdi yoki oshdi</b> (eng yuqorisi <?= fmt($stats['ball_raw_max'] ?? null) ?>).
        50 + 10·Z formulasida o'rtachadan 2,5σ dan yuqori natija 75 dan oshadi — rasmiy sertifikatlarda ham shunday ballar uchraydi (masalan 87.1). Foiz ko'rsatkichi 65 balldan boshlab 100%.
        <?= $cap ? 'Hozir 75 bilan cheklov yoqilgan: ular hammasi 75 oladi va bir nuqtada to\'planadi.' : '' ?>
      </div>
    <?php endif; ?>
  </div>
  <div class="card">
    <h2>Hisoblash sozlamalari</h2>
    <form method="post" class="form">
      <?= csrf_field() ?><input type="hidden" name="action" value="compute">
      <label>Ballga o'tkazish usuli
        <select name="method"><?php foreach (method_names() as $k => $v): ?><option value="<?= e($k) ?>" <?= $test['method'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></label>
      <div class="grid2">
        <label>O'rtacha M <input type="number" step="0.5" min="30" max="70" name="t_mean" value="<?= e((string)$M) ?>"></label>
        <label>Tarqoqlik S <input type="number" step="0.5" min="5" max="20" name="t_sd" value="<?= e((string)$S) ?>"></label>
      </div>
      <?php if (!empty($stats['m_preview'])): ?>
      <div class="m-preview small"><span class="muted">Sertifikat (≥ 46) oladiganlar, M bo'yicha:</span>
        <?php foreach ($stats['m_preview'] as $mv => $cnt): ?><span class="<?= abs($mv - $M) < 1e-9 ? 'on' : '' ?>">M=<?= $mv ?>: <b><?= $cnt ?></b></span><?php endforeach; ?>
      </div>
      <?php endif; ?>
      <label class="check"><input type="checkbox" name="cap75" <?= $cap ? 'checked' : '' ?>> Ballni 75 bilan cheklash (ixtiyoriy)</label>
      <p class="small muted" style="margin-top:-.4rem">Rasmiy sertifikatlarda ball 75 dan oshishi mumkin, shuning uchun standart holatda o'chiq.</p>
      <button class="btn primary"><?= icon('chart') ?>Qayta hisoblash</button>
    </form>
    <p class="small muted mt">Oxirgi hisob: <?= e($test['computed_at'] ?? '—') ?> · <?= (int)($stats['iterations'] ?? 0) ?> iteratsiya<?= !empty($stats['converged']) ? ', yaqinlashdi' : '' ?></p>
    <form method="post">
      <?= csrf_field() ?><input type="hidden" name="action" value="publish"><input type="hidden" name="v" value="<?= $test['published'] ? 0 : 1 ?>">
      <button class="btn <?= $test['published'] ? 'ghost' : 'success' ?> wide"><?= $test['published'] ? 'E\'lonni bekor qilish' : 'Natijalarni e\'lon qilish' ?></button>
    </form>
    <a class="btn wide mt" target="_blank" href="<?= e(url('results_list', array_filter(['id' => $test['id'], 'group' => $group, 'center' => $center]))) ?>"><?= icon('download', 16) ?>Natijalar ro'yxati (PDF)<?= $group !== '' || $center !== '' ? ' — filtr bo\'yicha' : '' ?></a>
    <div class="row gap mt wrap">
      <a class="btn sm ghost" href="<?= e(url('export', array_filter(['what' => 'results', 'id' => $test['id'], 'center' => $center, 'group' => $group]))) ?>"><?= icon('download', 15) ?>Natijalar (Excel)</a>
      <a class="btn sm ghost" href="<?= e(url('export', ['what' => 'matrix', 'id' => $test['id']])) ?>"><?= icon('download', 15) ?>0/1 matritsa</a>
    </div>
    <form method="post" class="mt"><?= csrf_field() ?><input type="hidden" name="action" value="certs">
      <button class="btn wide"><?= icon('print', 16) ?>Sertifikatlarni chop etish</button></form>
    <p class="small muted" style="margin:.4rem 0 0">46+ ball — sertifikat, qolganlarga — natija varaqasi. Har birida QR orqali tekshirish.</p>
  </div>
</div>

<?php if (!empty($stats['methods'])): $cur = $stats['method'] ?? 'tscore'; ?>
<div class="card">
  <div class="card-head"><h2>Usullarni solishtirish</h2><span class="small muted">bitta Rasch hisobi, uch xil shkala</span></div>
  <div class="table-wrap"><table class="tbl compact-tbl">
    <thead><tr><th>Usul</th><th class="num">O'rtacha</th><th class="num">Eng yuqori (cheklovsiz)</th><th class="num">≥ 75</th><th class="num">&gt; 75</th><th class="num">A+</th><th class="num">A / A+</th><th class="num">Sertifikat (≥ 46)</th></tr></thead>
    <tbody>
    <?php foreach ($stats['methods'] as $m => $r): ?>
      <tr<?= $m === $cur ? ' class="row-ok"' : '' ?>>
        <td><?= e(method_names()[$m] ?? $m) ?><?= $m === $cur ? ' <span class="tag green">tanlangan</span>' : '' ?></td>
        <td class="num"><?= fmt($r['mean']) ?></td><td class="num"><?= fmt($r['max']) ?></td>
        <td class="num"><?= (int)$r['at_cap'] ?></td><td class="num"><?= (int)$r['over'] ?></td>
        <td class="num"><?= (int)$r['aplus'] ?></td><td class="num"><?= (int)$r['a'] ?></td><td class="num"><?= (int)$r['cert'] ?> / <?= (int)$stats['N'] ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <p class="small muted" style="margin:0">Standart ball nisbiy (guruhga bog'liq) va 75 dan oshishi mumkin; chiziqli va vaznli usullar ta'rifiga ko'ra 0…75 oralig'ida qoladi.</p>
</div>
<?php endif; ?>

<div class="section-title">
  <h2>Reyting</h2>
  <form method="get" class="row gap filter" style="margin:0">
    <input type="hidden" name="p" value="results"><input type="hidden" name="id" value="<?= (int)$test['id'] ?>">
    <select name="group" onchange="this.form.submit()"><option value="">Barcha guruhlar</option>
      <?php foreach ($groups as $g): ?><option <?= $g === $group ? 'selected' : '' ?>><?= e($g) ?></option><?php endforeach; ?></select>
    <?php if ($centers): ?>
    <select name="center" onchange="this.form.submit()"><option value="">Barcha markazlar</option><option value="own" <?= $center === 'own' ? 'selected' : '' ?>>O'z markazimiz</option>
      <?php foreach ($centers as $cid => $cn): ?><option value="<?= $cid ?>" <?= (string)$cid === $center ? 'selected' : '' ?>><?= e($cn) ?></option><?php endforeach; ?></select>
    <?php if ($center !== '' && $center !== 'own'): ?><a class="btn sm" href="<?= e(url('center_report', ['id' => $test['id'], 'center' => $center])) ?>"><?= icon('chart', 14) ?>Markaz hisoboti</a><?php endif; ?>
    <?php endif; ?>
  </form>
</div>
<div class="table-wrap"><table class="tbl sortable">
  <thead><tr><th class="num">O'rin</th><th>O'quvchi</th><th class="num" title="55 ta baholanadigan element (item) bo'yicha">To'g'ri</th><th title="Bo'limlar: Y — yopiq, M — moslashtirish, O — ochiq qismlar, T — to'liq yechilgan topshiriqlar">Bo'limlar</th><th class="num" title="Qobiliyat, logit">θ ± SE</th><th class="num">Ball</th><th class="num" title="Umumiy ballga nisbatan foiz ko'rsatkichi: ball ÷ 65 × 100, ko'pi bilan 100%">Foiz</th><th>Daraja</th><?php if ($shifted): ?><th class="num" title="Rasmiy prognoz: 50 + 10·Z">Rasmiy prognoz</th><?php endif; ?><th title="Javoblar naqshi modelga mosligi (outfit MNSQ)">Moslik</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($list as $r):
      $of = $r['outfit']; $sc = section_counts($test, $r['scored']); $sec = $sc['sections'];
      $br = $r['ball_raw'] !== null ? (float)$r['ball_raw'] : (float)$r['ball']; ?>
    <tr>
      <td class="num"><?= (int)$r['rank_no'] ?></td>
      <td><b><?= e($r['full_name'] ?: '—') ?></b><div class="small muted"><span class="mono"><?= e($r['code']) ?></span><?= $r['group_name'] ? ' · ' . e($r['group_name']) : '' ?><?= $r['center_id'] ? ' · ' . e($centers[(int)$r['center_id']] ?? '') : '' ?></div></td>
      <td class="num raw-cell" data-v="<?= (int)$r['raw'] ?>"><b><?= (int)$r['raw'] ?></b><span class="muted">/<?= $L ?></span><span class="meter"><i style="width:<?= round($r['raw'] / max(1, $L) * 100) ?>%"></i></span></td>
      <td><div class="sec-mini">
        <?php if (isset($sec['closed'])): ?><span>Y <b><?= $sec['closed'][1] ?></b>/<?= $sec['closed'][2] ?></span><?php endif; ?>
        <?php if (isset($sec['match'])): ?><span>M <b><?= $sec['match'][1] ?></b>/<?= $sec['match'][2] ?></span><?php endif; ?>
        <?php if (isset($sec['open'])): ?><span>O <b><?= $sec['open'][1] ?></b>/<?= $sec['open'][2] ?></span><?php endif; ?>
        <span title="To'liq yechilgan topshiriqlar (ochiqlarda a va b ikkalasi)">T <b><?= $sc['tasks_full'] ?></b>/<?= $sc['tasks_total'] ?></span>
      </div></td>
      <td class="num nowrap" data-v="<?= $r['theta'] ?>"><?= fmt($r['theta'], 2) ?> <span class="muted small">± <?= fmt($r['se'], 2) ?></span></td>
      <td class="num nowrap" data-v="<?= $br ?>"><b><?= fmt($r['ball']) ?></b><?php if ($cap && $br > MAX_BALL + 1e-9): ?><span class="cap-note" title="Cheklovsiz hisoblangan qiymat">(<?= fmt($br) ?>)</span><?php endif; ?></td>
      <td class="num muted"><?= fmt(cert_percent((float)$r['ball']), 0) ?>%</td>
      <td><?= grade_badge($r['grade']) ?></td>
      <?php if ($shifted): ?><td class="num nowrap"><?= fmt($r['ball_official']) ?> <?= grade_badge($r['grade_official']) ?></td><?php endif; ?>
      <td><?php if ($of === null): ?><span class="muted small">—</span><?php elseif ($of > 2.0): ?><span class="tag red" title="Kutilmagan javoblar ko'p: taxmin, ko'chirish yoki e'tiborsizlik ehtimoli">shubhali <?= fmt($of, 2) ?></span><?php elseif ($of > 1.5): ?><span class="tag amber"><?= fmt($of, 2) ?></span><?php else: ?><span class="muted small"><?= fmt($of, 2) ?></span><?php endif; ?></td>
      <td class="right nowrap"><a class="btn sm ghost" href="<?= e(url('result_card', ['id' => $test['id'], 'sid' => $r['student_id']])) ?>">Batafsil</a> <a class="btn sm ghost" target="_blank" title="Sertifikat / natija varaqasi" href="<?= e(url('certificate', ['id' => $test['id'], 'sid' => $r['student_id']])) ?>"><?= icon('print', 14) ?></a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<p class="small muted">To'g'ri — 55 ta baholanadigan element bo'yicha (1–35 har biri bitta, 36–45 ning a va b qismlari alohida). Y/M/O — bo'limlar, T — 45 ta topshiriqdan to'liq yechilganlari (ochiq topshiriqda ikkala qism ham to'g'ri bo'lsa).</p>
<?php endif; ?>
<?php page_footer();
