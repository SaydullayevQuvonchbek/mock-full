<?php
defined('APP_ROOT') || exit;
/**
 * Parolni tiklash: 1) ID yoki telefon  2) 6 xonali kod (Telegram bot → Telegram Gateway → SMS)  3) yangi parol.
 * Hisob mavjudligi begonaga ko'rinmasligi uchun 2-qadam har doim bir xil xabar bilan chiqadi.
 */
if (student()) redirect('student_home');
$R = $_SESSION['rst'] ?? null;
$err = '';
$info = '';
$step = 'ident';
if ($R && !empty($R['ok']) && time() - (int)$R['ok'] < 600) $step = 'pass';
elseif ($R) $step = 'code';
$act = is_post() ? (string)($_POST['action'] ?? '') : '';

if (is_post()) {
    csrf_check();
    if ($act === 'restart') { unset($_SESSION['rst']); redirect('student_reset'); }
    $ipWait = throttle_wait('reset', client_ip(), 12, 12, 60);

    if ($act === 'ident' || $act === 'resend') {
        $s = null;
        if ($act === 'ident') {
            $ident = trim((string)($_POST['ident'] ?? ''));
            $s = $ident !== '' ? student_find_by_ident($ident) : null;
        } elseif ($R && $R['sid']) {
            $s = row('SELECT * FROM students WHERE id=?', [$R['sid']]);
        }
        if ($ipWait) { $err = "Juda ko'p urinish. $ipWait daqiqadan keyin qayta urinib ko'ring."; }
        elseif ($act === 'resend' && $R && time() - (int)($R['sent'] ?? 0) < 45) { $err = 'Kodni qayta yuborish uchun 45 soniya kuting.'; $step = 'code'; }
        else {
            throttle_fail('reset', client_ip());   // har so'rov hisoblanadi
            $new = ['sid' => 0, 'target' => '', 'ch' => '', 'sent' => time(), 'ok' => 0];
            if ($s) {
                $new['sid'] = (int)$s['id']; $new['target'] = (string)$s['code'];
                $chs = notify_channels($s);
                $via = (string)($_POST['via'] ?? '');
                if ($act === 'resend' && in_array($via, $chs, true)) $chs = array_merge([$via], array_diff($chs, [$via]));
                if (!$chs) {
                    $err = 'Bu hisobga kod yuborib bo\'lmaydi (telefon yoki Telegram ulanmagan). O\'quv markaziga murojaat qiling.';
                    $new = null;
                } elseif (!otp_allowed('reset', $new['target'])) {
                    $err = 'Bugun juda ko\'p kod so\'raldi. Ertaga qayta urinib ko\'ring yoki o\'quv markaziga murojaat qiling.';
                    $new = null;
                } else {
                    $code = otp_create('reset', $new['target'], (int)$s['id'], '');
                    $new['ch'] = otp_deliver($s, $code, $chs);
                    if ($new['ch'] === '') { $err = 'Kodni yuborib bo\'lmadi. Birozdan keyin qayta urinib ko\'ring yoki o\'quv markaziga murojaat qiling.'; $new = null; }
                }
            }
            if ($new) { $_SESSION['rst'] = $new; $R = $new; $step = 'code'; $info = 'Agar hisob mavjud bo\'lsa, 6 xonali kod Telegram yoki SMS orqali yuborildi. Kod 5 daqiqa amal qiladi.'; }
        }
    } elseif ($act === 'code' && $R) {
        if ($ipWait) $err = "Juda ko'p urinish. $ipWait daqiqadan keyin qayta urinib ko'ring.";
        elseif ($R['sid'] && otp_verify('reset', (string)$R['target'], (string)($_POST['code'] ?? ''))) {
            $_SESSION['rst']['ok'] = time(); $R = $_SESSION['rst']; $step = 'pass';
        } else { throttle_fail('reset', client_ip()); $err = 'Kod noto\'g\'ri yoki muddati o\'tgan. 3 marta xato kiritilsa, yangi kod so\'rash kerak.'; $step = 'code'; }
    } elseif ($act === 'pass' && $R && !empty($R['ok']) && time() - (int)$R['ok'] < 600) {
        $s = row('SELECT * FROM students WHERE id=?', [$R['sid']]);
        $new = (string)($_POST['new'] ?? '');
        if (!$s) { unset($_SESSION['rst']); redirect('student_reset'); }
        elseif ($p = pass_problem($new, (string)$s['code'])) { $err = $p; $step = 'pass'; }
        elseif ($new !== (string)($_POST['new2'] ?? '')) { $err = 'Parollar mos emas.'; $step = 'pass'; }
        else {
            student_set_pass((int)$s['id'], $new, false);
            q('UPDATE students SET phone_verified_at=IF(phone<>"" AND ?="sms", NOW(), phone_verified_at) WHERE id=?', [$R['ch'], $s['id']]);
            if (!empty($s['tg_chat_id']) && tg_ready()) tg_send((int)$s['tg_chat_id'], "🔑 Platformadagi parolingiz o‘zgartirildi. Bu siz bo‘lmasangiz, o‘quv markaziga xabar bering.");
            throttle_clear('student', (string)$s['code']);
            unset($_SESSION['rst']);
            flash('Parol yangilandi. Yangi parol bilan kiring.');
            redirect('student_login', ['ident' => $s['code']]);
        }
    }
}
$chsNow = [];
if ($step === 'code' && $R && $R['sid']) { $sx = row('SELECT * FROM students WHERE id=?', [$R['sid']]); $chsNow = $sx ? notify_channels($sx) : []; }
page_header('Parolni tiklash', ['main' => 'narrow-main']);
?>
<div class="card narrow">
  <h1>Parolni tiklash</h1>
  <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
  <?php if ($info): ?><div class="alert info small"><?= e($info) ?></div><?php endif; ?>

  <?php if ($step === 'ident'): ?>
    <p class="muted">ID raqamingiz yoki telefon raqamingizni kiriting — tasdiqlash kodi Telegramingizga (ulangan bo'lsa) yoki SMS orqali yuboriladi.</p>
    <form method="post" class="form">
      <?= csrf_field() ?><input type="hidden" name="action" value="ident">
      <label>ID yoki telefon <input name="ident" required autofocus class="big-input" maxlength="20" placeholder="123456 yoki +998 90 123 45 67" autocomplete="username"></label>
      <button class="btn primary wide">Kod yuborish</button>
    </form>
    <p class="small mt"><a href="<?= e(url('student_login')) ?>">← Kirish sahifasi</a></p>

  <?php elseif ($step === 'code'): ?>
    <?php if (!$info): ?><p class="muted">Yuborilgan 6 xonali kodni kiriting.</p><?php endif; ?>
    <form method="post" class="form">
      <?= csrf_field() ?><input type="hidden" name="action" value="code">
      <label>Tasdiqlash kodi <input name="code" required autofocus class="big-input" inputmode="numeric" maxlength="6" pattern="\d{6}" autocomplete="one-time-code" placeholder="••••••"></label>
      <button class="btn primary wide">Tasdiqlash</button>
    </form>
    <div class="row gap wrap mt small">
      <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="resend"><button class="btn sm ghost">Kodni qayta yuborish</button></form>
      <?php foreach ($chsNow as $c): if ($c === ($R['ch'] ?? '')) continue; ?>
        <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="resend"><input type="hidden" name="via" value="<?= e($c) ?>"><button class="btn sm ghost"><?= e(notify_channel_label($c)) ?> orqali yuborish</button></form>
      <?php endforeach; ?>
      <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="restart"><button class="btn sm ghost">Boshqa ID/telefon</button></form>
    </div>

  <?php else: ?>
    <p class="muted">Kod tasdiqlandi. Yangi parol belgilang (kamida 6 belgi).</p>
    <form method="post" class="form" autocomplete="off">
      <?= csrf_field() ?><input type="hidden" name="action" value="pass">
      <label>Yangi parol <input type="password" name="new" required minlength="6" maxlength="64" autofocus autocomplete="new-password"></label>
      <label>Yangi parol (takror) <input type="password" name="new2" required minlength="6" maxlength="64" autocomplete="new-password"></label>
      <button class="btn primary wide">Parolni saqlash</button>
    </form>
  <?php endif; ?>
</div>
<?php page_footer();
