<?php
defined('APP_ROOT') || exit;
$what = $_GET['what'] ?? '';
function csv_send(string $filename, array $rows): void
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    foreach ($rows as $r) fputcsv($out, array_map('csv_safe', $r), ';', '"', '\\');
    fclose($out);
    exit;
}
if ($what === 'students') {
    $rows = [['ID', 'Familiya', 'Ism', 'Otasining ismi', 'Telefon', 'Maktab', 'Sinf', 'Guruh', 'Markaz', 'Manba', 'Ro\'yxatdan o\'tgan', 'Vaqtinchalik parol', 'Ota-ona', 'Ota-ona telefoni', 'Ota-ona 2-telefon']];
    $w = []; $par = [];
    if (($g = trim($_GET['group'] ?? '')) !== '') { $w[] = 's.group_name=?'; $par[] = $g; }
    if (($c = $_GET['center'] ?? '') === 'own') $w[] = 's.center_id IS NULL'; elseif ($c !== '') { $w[] = 's.center_id=?'; $par[] = (int)$c; }
    if (($src = $_GET['source'] ?? '') !== '') { $w[] = 's.source=?'; $par[] = $src; }
    foreach (rows('SELECT s.*, c.name center FROM students s LEFT JOIN centers c ON c.id=s.center_id' . ($w ? ' WHERE ' . implode(' AND ', $w) : '') . ' ORDER BY s.group_name, s.full_name', $par) as $s)
        $rows[] = [$s['code'], $s['last_name'], $s['first_name'], $s['middle_name'], $s['phone'] ? fmt_phone($s['phone']) : '', $s['school'], $s['grade_level'], $s['group_name'], $s['center'] ?? '', $s['source'] === 'register' ? 'onlayn' : 'admin', substr((string)$s['created_at'], 0, 16), $s['pin'], $s['parent_name'], $s['parent_phone'] ? fmt_phone($s['parent_phone']) : '', $s['parent_phone2'] ? fmt_phone($s['parent_phone2']) : ''];
    csv_send('oquvchilar.csv', $rows);
}
$test = get_test_or_404();
$items = test_items($test);
$labels = array_column($items, 'label');
$slug = preg_replace('/[^A-Za-z0-9_-]+/', '_', $test['title']);
if ($what === 'template') {
    $rows = [array_merge(['ID', 'F.I.Sh', 'Guruh'], $labels)];
    $rows[] = array_merge(['123456', 'Namuna O\'quvchi', '11-A'], array_map(fn($it) => $it['type'] === 'mc' ? 'A' : '+', $items));
    csv_send('shablon_' . $slug . '.csv', $rows);
}
if ($what === 'results') {
    $rows = [array_merge(['O\'rin', 'ID', 'F.I.Sh', 'Guruh', 'To\'g\'ri (item)', 'Yopiq', 'Moslashtirish', 'Ochiq (a/b)', 'To\'liq topshiriq', 'θ (logit)', 'SE', 'Ball', 'Ball (cheklovsiz)', 'Foiz ko\'rsatkichi', 'Daraja', 'Rasmiy prognoz', 'Rasmiy daraja', 'Algebra balli', 'Geometriya balli'], $labels)];
    $w = ''; $par = [$test['id']];
    if (($g = trim($_GET['group'] ?? '')) !== '') { $w .= ' AND s.group_name=?'; $par[] = $g; }
    if (($c = $_GET['center'] ?? '') === 'own') $w .= ' AND s.center_id IS NULL'; elseif ($c !== '') { $w .= ' AND s.center_id=?'; $par[] = (int)$c; }
    foreach (rows('SELECT r.*, s.code, s.full_name, s.group_name FROM results r JOIN students s ON s.id=r.student_id WHERE r.test_id=?' . $w . ' ORDER BY r.rank_no', $par) as $r) {
        $sc = section_counts($test, $r['scored']); $sec = $sc['sections'];
        $f = fn($k) => isset($sec[$k]) ? $sec[$k][1] . '/' . $sec[$k][2] : '';
        $rows[] = array_merge([$r['rank_no'], $r['code'], $r['full_name'], $r['group_name'], $r['raw'] . '/' . count($items),
            $f('closed'), $f('match'), $f('open'), $sc['tasks_full'] . '/' . $sc['tasks_total'],
            number_format((float)$r['theta'], 3, ',', ''), number_format((float)$r['se'], 3, ',', ''),
            number_format((float)$r['ball'], 1, ',', ''), number_format((float)($r['ball_raw'] ?? $r['ball']), 1, ',', ''),
            number_format(cert_percent((float)$r['ball']), 2, ',', '') . '%', $r['grade'] === 'NB' ? '—' : $r['grade'],
            number_format((float)$r['ball_official'], 1, ',', ''), $r['grade_official'] === 'NB' ? '—' : $r['grade_official'],
            number_format((float)(($ss = section_scores($test, $r['scored'], (float)$r['ball']))['A']['ball'] ?? 0), 3, ',', ''), number_format((float)($ss['G']['ball'] ?? 0), 3, ',', '')], str_split($r['scored']));
    }
    csv_send('natijalar_' . $slug . '.csv', $rows);
}
if ($what === 'items') {
    $rows = [['Savol', 'Kalit', 'To\'g\'ri %', 'b (logit)', 'SE', 'Infit', 'Outfit', 'Point-biserial', 'Variantlar']];
    foreach (rows('SELECT * FROM item_stats WHERE test_id=? ORDER BY ord', [$test['id']]) as $r) {
        $rows[] = [$r['label'], $test['key'][$r['label']] ?? '', round($r['pvalue'] * 100, 1), number_format((float)$r['b'], 3, ',', ''),
            $r['se'] !== null ? number_format((float)$r['se'], 3, ',', '') : '', $r['infit'], $r['outfit'], $r['pbis'], $r['options_json']];
    }
    csv_send('savollar_tahlili_' . $slug . '.csv', $rows);
}
if ($what === 'registrations') {
    $rows = [['ID', 'Familiya', 'Ism', 'Otasining ismi', 'Telefon', 'Maktab', 'Sinf', 'Xona', "O'rin", 'Varaq chop etilgan', "Ro'yxatga qo'shilgan", 'Vaqtinchalik parol']];
    foreach (reg_students((int)$test['id'], ['order' => 'room']) as $s)
        $rows[] = [$s['code'], $s['last_name'], $s['first_name'], $s['middle_name'], $s['phone'] ? fmt_phone($s['phone']) : '', $s['school'], $s['grade_level'],
            $s['room_name'] ?? '', $s['seat'] ?? '', $s['printed_at'] ? substr((string)$s['printed_at'], 0, 16) : '', substr((string)$s['reg_at'], 0, 16), $s['pin']];
    csv_send('royxat_' . $slug . '.csv', $rows);
}
if ($what === 'matrix') {
    // Winsteps / R (eRm, TAM) uchun 0/1 matritsa
    $rows = [array_merge(['ID'], $labels)];
    foreach (rows('SELECT r.scored, s.code FROM results r JOIN students s ON s.id=r.student_id WHERE r.test_id=? ORDER BY s.code', [$test['id']]) as $r) {
        $rows[] = array_merge([$r['code']], str_split($r['scored']));
    }
    csv_send('matritsa_' . $slug . '.csv', $rows);
}
redirect('tests');
