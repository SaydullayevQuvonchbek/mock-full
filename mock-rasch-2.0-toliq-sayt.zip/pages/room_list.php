<?php
defined('APP_ROOT') || exit;
/** Xona bo'yicha davomat ro'yxatlari (chop etish uchun): har xona — alohida A4 sahifa */
$test = get_test_or_404();
$tid = (int)$test['id'];
$rooms = test_rooms($tid);
$only = (int)($_GET['room'] ?? 0);
$byRoom = [];
foreach (reg_students($tid, ['order' => 'room']) as $s) $byRoom[(int)$s['room_id']][] = $s;
$sections = [];
foreach ($rooms as $r) if (!$only || (int)$r['id'] === $only) $sections[] = ['title' => $r['name'], 'cap' => (int)$r['capacity'], 'proctor' => (string)$r['proctor'], 'list' => $byRoom[(int)$r['id']] ?? []];
if (!$only && !empty($byRoom[0])) $sections[] = ['title' => 'Xonasizlar', 'cap' => 0, 'proctor' => '', 'list' => $byRoom[0]];
$date = $test['test_date'] ? date('d.m.Y', strtotime($test['test_date'])) : '';
page_header('Xona ro\'yxatlari', ['bare' => true, 'body' => 'print-page roomlist-page']);
?>
<div class="no-print toolbar">
  <button class="btn primary" onclick="print()"><?= icon('print', 16) ?>Chop etish</button>
  <form method="get" class="row gap inline">
    <input type="hidden" name="p" value="room_list"><input type="hidden" name="id" value="<?= $tid ?>">
    <select name="room" onchange="this.form.submit()"><option value="">Barcha xonalar</option><?php foreach ($rooms as $r): ?><option value="<?= (int)$r['id'] ?>" <?= $only === (int)$r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?></select>
  </form>
  <a class="small" href="<?= e(url('registrations', ['id' => $tid])) ?>">← Ro'yxatga qaytish</a>
</div>
<?php if (!$sections): ?><div class="card narrow empty">Xonalar kiritilmagan. "Ro'yxat" bo'limida xona qo'shing va taqsimlang.</div><?php endif; ?>
<?php foreach ($sections as $sec): ?>
<section class="room-sheet">
  <header>
    <div><small><?= e(app_setting('center')) ?> · <?= e($test['title']) ?><?= $date ? ' · ' . e($date) : '' ?></small><h1><?= e($sec['title']) ?></h1></div>
    <div class="room-count"><b><?= count($sec['list']) ?></b><?= $sec['cap'] ? ' / ' . $sec['cap'] . ' o\'rin' : ' kishi' ?></div>
  </header>
  <table class="room-tbl">
    <thead><tr><th class="num">O'rin</th><th>ID</th><th>F.I.Sh</th><th>Maktab / sinf</th><th>Keldi</th><th>Imzo</th></tr></thead>
    <tbody>
    <?php foreach ($sec['list'] as $i => $s): ?>
      <tr><td class="num"><b><?= $s['seat'] ? (int)$s['seat'] : $i + 1 ?></b></td><td class="mono"><?= e($s['code']) ?></td><td><?= e($s['full_name']) ?></td><td><?= e(trim($s['school'] . ' · ' . $s['grade_level'], ' ·')) ?></td><td class="box-cell"><span></span></td><td class="sign-cell"></td></tr>
    <?php endforeach; ?>
    <?php if (!$sec['list']): ?><tr><td colspan="6" class="empty">Bu xonaga hali hech kim joylashtirilmagan</td></tr><?php endif; ?>
    </tbody>
  </table>
  <footer><span>Nazoratchi: <?= $sec['proctor'] !== '' ? '<b>' . e($sec['proctor']) . '</b>' : '______________________' ?></span><span>Imzo: ____________</span><span>Kelmaganlar soni: ______</span></footer>
</section>
<?php endforeach; ?>
<?php page_footer();
