<?php
defined('APP_ROOT') || exit;
/** Bo'limdagi savollar: rasm, turi, javob kaliti; tezkor kalit kiritish, ko'chirish, o'chirish */
$sid = (int)($_GET['s'] ?? $_POST['s'] ?? 0);
$sec = $sid ? row('SELECT * FROM qb_sections WHERE id=?', [$sid]) : null;
if (!$sec) { flash('Bo\'lim topilmadi', 'err'); redirect('qb'); }

$own = fn() => rows('SELECT * FROM qb_questions WHERE section_id=? ORDER BY sort, id', [$sid]);

if (is_post()) {
    csrf_check();
    $a = (string)($_POST['action'] ?? '');
    if (!empty($_POST['mv']) && preg_match('/^([ud])(\d+)$/', (string)$_POST['mv'], $mv)) $a = 'move_' . $mv[1];
    $list = $own();
    $byId = [];
    foreach ($list as $r) $byId[(int)$r['id']] = $r;
    $sel = array_values(array_filter(array_map('intval', (array)($_POST['sel'] ?? [])), fn($i) => isset($byId[$i])));

    // joriy sahifadagi tahrirlarni saqlash (↑/↓ bosilganda ham tahrirlar yo'qolmasin)
    $saveEdits = function () use ($byId) {
        $n = 0; $bad = 0;
        foreach ($byId as $id => $r) {
            if (!isset($_POST['kind'][$id])) continue;
            $kind = $_POST['kind'][$id] === 'open' ? 'open' : 'mc';
            $nopt = (int)($_POST['nopt'][$id] ?? 4) === 6 ? 6 : 4;
            $ans = qb_clean_answer($kind, $nopt, (string)($_POST['ans'][$id] ?? ''));
            if ($ans === null) { $bad++; $ans = ''; }
            $label = mb_substr(trim((string)($_POST['label'][$id] ?? '')), 0, 40);
            if ($kind !== $r['kind'] || $nopt !== (int)$r['nopt'] || $ans !== (string)$r['answer'] || $label !== (string)$r['label']) {
                q('UPDATE qb_questions SET kind=?, nopt=?, answer=?, label=? WHERE id=?', [$kind, $nopt, $ans, $label, $id]);
                $n++;
            }
        }
        return [$n, $bad];
    };
    if ($a === 'save') {
        [$n, $bad] = $saveEdits();
        flash($n . ' ta savol yangilandi' . ($bad ? ' · ' . $bad . ' ta noto\'g\'ri javob (A–D/A–F bo\'lishi kerak) bo\'sh qoldirildi' : ''), $bad ? 'warn' : 'ok');
    } elseif ($a === 'quick') {
        $key = qb_parse_key((string)($_POST['key'] ?? ''));
        $n = 0; $bad = [];
        foreach ($list as $i => $r) {
            if (!isset($key[$i + 1])) continue;
            $v = qb_clean_answer((string)$r['kind'], (int)$r['nopt'], (string)$key[$i + 1]);
            if ($v === null) { $bad[] = $i + 1; continue; }
            q('UPDATE qb_questions SET answer=? WHERE id=?', [$v, $r['id']]);
            $n++;
        }
        $extra = max(0, count($key) ? max(array_keys($key)) - count($list) : 0);
        flash($n . ' ta javob kiritildi' . ($bad ? ' · noto\'g\'ri: ' . implode(', ', array_slice($bad, 0, 12)) . '-savol' : '') . ($extra ? ' · kalitda ' . $extra . ' ta ortiqcha javob bor (savollar soni ' . count($list) . ')' : ''), ($bad || $extra) ? 'warn' : 'ok');
    } elseif ($a === 'delete') {
        foreach ($sel as $id) qb_delete_question($id);
        flash(count($sel) . ' ta savol o\'chirildi');
    } elseif ($a === 'move') {
        $to = (int)($_POST['to'] ?? 0);
        if (!$sel) flash('Savollarni belgilang', 'err');
        elseif (!$to || !row('SELECT 1 FROM qb_sections WHERE id=?', [$to])) flash('Qaysi bo\'limga ko\'chirish kerakligini tanlang', 'err');
        else {
            $sort = (int)val('SELECT COALESCE(MAX(sort),0) FROM qb_questions WHERE section_id=?', [$to]);
            foreach ($sel as $id) q('UPDATE qb_questions SET section_id=?, sort=? WHERE id=?', [$to, ++$sort, $id]);
            flash(count($sel) . ' ta savol ko\'chirildi: ' . qb_section_path($to));
        }
    } elseif ($a === 'setkind') {
        $v = (string)($_POST['kindset'] ?? '');
        if (!$sel || !in_array($v, ['mc4', 'mc6', 'open'], true)) flash('Savollarni belgilab, turini tanlang', 'err');
        else {
            foreach ($sel as $id) q('UPDATE qb_questions SET kind=?, nopt=?, answer="" WHERE id=?', [$v === 'open' ? 'open' : 'mc', $v === 'mc6' ? 6 : 4, $id]);
            flash(count($sel) . ' ta savol turi o\'zgartirildi (javoblari tozalandi — kalitni qayta kiriting)', 'warn');
        }
    } elseif ($a === 'move_u' || $a === 'move_d') {
        $saveEdits();
        $ids = array_keys($byId);
        $i = array_search((int)$mv[2], $ids, true);
        $j = $a === 'move_u' ? $i - 1 : $i + 1;
        if ($i !== false && isset($ids[$j])) { [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]]; foreach ($ids as $k => $qid) q('UPDATE qb_questions SET sort=? WHERE id=?', [$k + 1, $qid]); }
    }
    redirect('qb_questions', ['s' => $sid, 'pg' => max(1, (int)($_POST['pg'] ?? 1))]);
}

$all = $own();
$PER = 80;
$pages = max(1, (int)ceil(count($all) / $PER));
$pg = max(1, min($pages, (int)($_GET['pg'] ?? 1)));
$list = array_slice($all, ($pg - 1) * $PER, $PER, true);   // kalitlar — umumiy tartib raqamlari (0 dan)
$children = rows('SELECT id, name FROM qb_sections WHERE parent_id=? ORDER BY sort, name', [$sid]);
$ready = 0;
foreach ($all as $r) if ((string)$r['answer'] !== '') $ready++;
$allSecs = qb_tree();
page_header('Savollar — ' . $sec['name']);
?>
<div class="page-head">
  <div>
    <p class="small muted"><a href="<?= e(url('qb')) ?>">← Savollar banki</a> · <?= e(qb_section_path($sid)) ?></p>
    <h1><?= e($sec['name']) ?></h1>
    <p class="muted"><?= count($all) ?> ta savol, kalitli: <b><?= $ready ?></b><?= count($all) > $ready ? ' · <span class="critical-t">' . (count($all) - $ready) . ' tasida kalit yo\'q</span>' : '' ?></p>
  </div>
  <div class="row gap wrap">
    <a class="btn primary" href="<?= e(url('qb_import', ['s' => $sid])) ?>"><?= icon('upload', 16) ?>PDF dan yuklash</a>
    <?php if ($all): ?><a class="btn" target="_blank" href="<?= e(url('qb_pdf', ['s' => $sid, 'key' => 1])) ?>"><?= icon('download', 16) ?>PDF (kalit bilan)</a>
    <a class="btn ghost" target="_blank" href="<?= e(url('qb_pdf', ['s' => $sid])) ?>">PDF (kalitsiz)</a><?php endif; ?>
  </div>
</div>

<?php if ($children): ?><p class="small">Ichki bo'limlar: <?php foreach ($children as $c): ?><a class="tag blue" href="<?= e(url('qb_questions', ['s' => $c['id']])) ?>"><?= e($c['name']) ?></a><?php endforeach; ?></p><?php endif; ?>

<?php if (!$all): ?>
  <div class="card empty">Bu bo'limda hali savol yo'q. <a href="<?= e(url('qb_import', ['s' => $sid])) ?>">PDF dan yuklash →</a></div>
<?php else: ?>

<div class="card">
  <form method="post" class="form row gap wrap qb-quick"><?= csrf_field() ?><input type="hidden" name="s" value="<?= $sid ?>"><input type="hidden" name="pg" value="<?= $pg ?>"><input type="hidden" name="action" value="quick">
    <label style="flex:1 1 320px">Tezkor kalit kiritish <span class="muted small">— savollar tartibida: <code>ACDBBAD…</code> yoki <code>1:A 2:C 3:12 4:0.5;1/2</code></span>
      <input name="key" placeholder="ACDBBADC…" autocomplete="off" spellcheck="false"></label>
    <label>&nbsp;<button class="btn primary">Kalitni qo'llash</button></label>
  </form>
</div>

<?php if ($pages > 1): ?><p class="small qb-pages">Sahifa: <?php for ($i = 1; $i <= $pages; $i++): ?><a class="tag <?= $i === $pg ? 'blue' : '' ?>" href="<?= e(url('qb_questions', ['s' => $sid, 'pg' => $i])) ?>"><?= $i ?> (<?= ($i - 1) * $PER + 1 ?>–<?= min(count($all), $i * $PER) ?>)</a><?php endfor; ?></p><?php endif; ?>
<form method="post" class="card qb-list"><?= csrf_field() ?><input type="hidden" name="s" value="<?= $sid ?>"><input type="hidden" name="pg" value="<?= $pg ?>">
  <button type="submit" name="action" value="save" class="qb-defbtn" tabindex="-1" aria-hidden="true">Saqlash</button>
  <div class="table-wrap"><table class="tbl qb-qtbl">
    <thead><tr><th style="width:2rem"><input type="checkbox" aria-label="Hammasini belgilash" onclick="document.querySelectorAll('.qsel').forEach(c=>c.checked=this.checked)"></th><th class="num">№</th><th>Savol</th><th>Turi</th><th>Javob</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($list as $i => $r): $id = (int)$r['id']; ?>
      <tr class="<?= (string)$r['answer'] === '' ? 'qb-nokey' : '' ?>">
        <td><input class="qsel" type="checkbox" name="sel[]" value="<?= $id ?>"></td>
        <td class="num"><b><?= $i + 1 ?></b></td>
        <td><a href="<?= e(url('qb_img', ['id' => $id])) ?>" target="_blank"><img class="qb-thumb" loading="lazy" alt="Savol <?= $i + 1 ?>" src="<?= e(url('qb_img', ['id' => $id])) ?>"></a>
          <input class="qb-label" name="label[<?= $id ?>]" value="<?= e($r['label']) ?>" maxlength="40" placeholder="izoh (ixtiyoriy)" aria-label="Izoh"></td>
        <td class="nowrap">
          <select name="kind[<?= $id ?>]" aria-label="Savol turi" onchange="this.closest('tr').querySelector('.nopt').style.display = this.value==='open' ? 'none' : ''">
            <option value="mc" <?= $r['kind'] === 'mc' ? 'selected' : '' ?>>Test</option><option value="open" <?= $r['kind'] === 'open' ? 'selected' : '' ?>>Ochiq</option></select>
          <select class="nopt" name="nopt[<?= $id ?>]" aria-label="Variantlar soni" style="<?= $r['kind'] === 'open' ? 'display:none' : '' ?>"><option value="4" <?= (int)$r['nopt'] === 4 ? 'selected' : '' ?>>A–D</option><option value="6" <?= (int)$r['nopt'] === 6 ? 'selected' : '' ?>>A–F</option></select>
        </td>
        <td><input class="qb-ans mono" name="ans[<?= $id ?>]" value="<?= e($r['answer']) ?>" maxlength="80" aria-label="Javob" autocomplete="off" placeholder="<?= $r['kind'] === 'open' ? 'javob; variant' : 'A' ?>"></td>
        <td class="nowrap"><button class="btn sm ghost" name="mv" value="u<?= $id ?>" title="Yuqoriga">↑</button><button class="btn sm ghost" name="mv" value="d<?= $id ?>" title="Pastga">↓</button></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <div class="qb-bar row gap wrap center-v">
    <button class="btn primary" name="action" value="save">Saqlash</button>
    <span class="muted small">Belgilanganlar bilan:</span>
    <select name="to" aria-label="Ko'chirish"><option value="0">Ko'chirish…</option><?php foreach ($allSecs as $s): if ((int)$s['id'] === $sid) continue; ?><option value="<?= $s['id'] ?>"><?= str_repeat('— ', $s['depth']) . e($s['name']) ?></option><?php endforeach; ?></select>
    <button class="btn" name="action" value="move">Ko'chirish</button>
    <select name="kindset" aria-label="Turi"><option value="">Turini o'zgartirish…</option><option value="mc4">Test A–D</option><option value="mc6">Test A–F</option><option value="open">Ochiq javobli</option></select>
    <button class="btn" name="action" value="setkind">Qo'llash</button>
    <button class="btn danger-ghost" name="action" value="delete" onclick="return confirm('Belgilangan savollar o\'chirilsinmi?')">O'chirish</button>
  </div>
</form>
<?php endif; ?>
<?php page_footer();
