<?php
defined('APP_ROOT') || exit;
/** O'quvchining o'z mashq testini PDF qilib berish (javoblar varaqasi bilan; javob kaliti hech qachon berilmaydi) */
$me = student();
$t = row('SELECT * FROM qb_tests WHERE id=? AND student_id=?', [(int)($_GET['id'] ?? 0), (int)$me['id']]);
if (!$t) { flash('Mashq testi topilmadi', 'err'); redirect('student_practice'); }
$qs = rows("SELECT q.id, q.img, q.kind, q.nopt, '' AS answer, q.label FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? ORDER BY i.pos", [$t['id']]);
if (!$qs) { flash('Testda savol qolmagan', 'err'); redirect('student_practice'); }
$st = row('SELECT full_name, code FROM students WHERE id=?', [$me['id']]);
$pdf = qb_pdf($t['title'], trim(($st['full_name'] ?: 'O\'quvchi') . ' · ID ' . $st['code'] . ' · ' . date('d.m.Y', strtotime($t['created_at']))), $qs, false);
if ($pdf === null) { flash('PDF yaratish hozir mumkin emas (serverda GD yo\'q). Testni sahifada yeching.', 'err'); redirect('student_practice_do', ['id' => $t['id']]); }
session_write_close();
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="mashq-' . (int)$t['id'] . '.pdf"');
header('Content-Length: ' . strlen($pdf));
header('Cache-Control: private, no-store');
echo $pdf;
exit;
