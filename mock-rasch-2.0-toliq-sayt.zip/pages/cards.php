<?php
defined('APP_ROOT') || exit;
$group = trim($_GET['group'] ?? '');
$list = $group !== ''
    ? rows('SELECT * FROM students WHERE group_name=? ORDER BY full_name', [$group])
    : rows('SELECT * FROM students ORDER BY group_name, full_name');
global $CONFIG;
page_header('ID kartochkalar', ['bare' => true, 'body' => 'print-page']);
?>
<div class="no-print toolbar"><button class="btn primary" onclick="print()">🖨 Chop etish</button> <span class="muted"><?= count($list) ?> ta kartochka</span></div>
<div class="cards-print">
<?php foreach ($list as $s): ?>
  <div class="id-card">
    <div class="small muted"><?= e(app_setting('center')) ?> · MOCK</div>
    <div class="id-name"><?= e($s['full_name']) ?></div>
    <div class="small"><?= e($s['group_name']) ?></div>
    <div class="id-codes"><div>ID<b><?= e($s['code']) ?></b></div><div><?= $s['pin'] !== '' ? 'Parol' : '' ?><b><?= $s['pin'] !== '' ? e($s['pin']) : '' ?></b></div></div>
    <div class="tiny muted"><?= $s['pin'] !== '' ? 'Birinchi kirishda parolni o\'zingiz almashtirasiz. ' : 'Parol: o\'zingiz belgilagan. ' ?>Javoblar varaqasida ID ni bo'yang. Kirish: saytdagi "Kirish".</div>
  </div>
<?php endforeach; ?>
</div>
<?php page_footer();
