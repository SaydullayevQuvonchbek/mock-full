<?php
defined('APP_ROOT') || exit;
$me = student();
$test = test_by_id((int)($_GET['id'] ?? 0));
if (!$test || !$test['published']) { flash('Natija hali e\'lon qilinmagan', 'warn'); redirect('student_home'); }
page_header('Natijam — ' . $test['title']);
?>
<div class="row between center-v no-print">
  <a href="<?= e(url('student_home')) ?>">← Mening sahifam</a>
  <button class="btn ghost" onclick="print()">🖨 Chop etish</button>
</div>
<?php render_result_card($test, (int)$me['id'], true); ?>
<?php page_footer();
