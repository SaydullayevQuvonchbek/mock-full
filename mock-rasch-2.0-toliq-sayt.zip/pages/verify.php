<?php
defined('APP_ROOT') || exit;
$n = strtoupper(substr(trim((string)($_GET['n'] ?? '')), 0, 24));
$t = substr(trim((string)($_GET['t'] ?? '')), 0, 16);
$code = preg_replace('/\D/', '', (string)($_GET['c'] ?? ''));
$c = null; $err = ''; $full = false;
if ($n !== '') {
    if (throttle_wait('verify', client_ip(), 40, 40, 15)) $err = 'Juda ko\'p so\'rov. Birozdan keyin urinib ko\'ring.';
    else {
        $c = row('SELECT * FROM certificates WHERE number=?', [$n]);
        if ($c && $t !== '' && !hash_equals($c['token'], $t)) $c = null;   // QR dagi token noto'g'ri
        $dd = $c ? json_decode($c['data_json'], true) : null;
        if ($c && $code !== '' && !hash_equals((string)($dd['code'] ?? ''), $code)) $c = null;   // hujjatdagi ID mos emas
        if (!$c) { throttle_fail('verify', client_ip()); $err = 'Bunday hujjat topilmadi yoki ma\'lumotlar mos kelmadi.'; }
        // To'liq ma'lumot (ism, ball) faqat QR token yoki hujjatdagi o'quvchi ID bilan ochiladi —
        // raqamlar ketma-ket bo'lgani uchun faqat raqam bilan boshqalarning natijasini ko'rib chiqib bo'lmaydi
        $full = $c && ($t !== '' || $code !== '');
    }
}
$d = $c ? json_decode($c['data_json'], true) : null;
$mask = function (string $s): string { $s = trim($s); return $s === '' ? '' : mb_substr($s, 0, 1) . '.'; };
page_header('Sertifikatni tekshirish', ['main' => 'narrow-main']);
?>
<div class="card narrow">
  <div class="eyebrow">Tekshirish</div>
  <h1>Sertifikat haqiqiymi?</h1>
  <?php if ($c && $d): ?>
    <div class="alert ok"><?= icon('check') ?><span><b>Hujjat haqiqiy.</b> <?= e($d['issuer']) ?> tomonidan berilgan.</span></div>
    <div class="cert-rows verify-rows">
      <div class="cr"><span>Raqam</span><b><?= e($c['number']) ?></b></div>
      <div class="cr"><span>Turi</span><b><?= $c['kind'] === 'cert' ? 'Sertifikat' : 'Natija varaqasi' ?></b></div>
      <div class="cr"><span>Egasi</span><b><?= e($full ? $d['name'] : $mask((string)($d['last'] ?? '')) . ' ' . $mask((string)($d['first'] ?? ''))) ?></b></div>
      <div class="cr"><span>Test</span><b><?= e($d['test']) ?> (<?= e($d['date'] ?? '') ?>)</b></div>
      <?php if ($full): ?>
      <div class="cr"><span>Ball</span><b><?= fmt($d['ball']) ?> · <?= fmt($d['percent'], 1) ?>%</b></div>
      <div class="cr"><span>Daraja</span><b><?= $d['grade'] === 'NB' ? '—' : e($d['grade']) ?></b></div>
      <?php endif; ?>
      <div class="cr"><span>Berilgan</span><b><?= e(date('d.m.Y', strtotime($c['issued_at']))) ?></b></div>
    </div>
    <?php if (!$full): ?>
    <form method="get" class="form mt">
      <input type="hidden" name="p" value="verify"><input type="hidden" name="n" value="<?= e($n) ?>">
      <label>Ism va ballni ko'rish uchun hujjatdagi "O'quvchi ID" ni kiriting <input name="c" inputmode="numeric" maxlength="6" pattern="\d{6}" placeholder="6 xonali ID" required></label>
      <button class="btn primary wide">Ko'rsatish</button>
    </form>
    <?php endif; ?>
    <p class="small muted mt">Bu — o'quv markazining sinov imtihoni (MOCK) hujjati, rasmiy milliy sertifikat emas.</p>
  <?php else: ?>
    <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
    <form method="get" class="form">
      <input type="hidden" name="p" value="verify">
      <label>Sertifikat raqami <input name="n" value="<?= e($n) ?>" placeholder="M26-000123" required></label>
      <button class="btn primary wide">Tekshirish</button>
    </form>
    <p class="small muted">QR kodni telefon kamerasi bilan skanerlasangiz, natija to'g'ridan-to'g'ri ochiladi. Raqam bilan tekshirganda ism va ballni ko'rish uchun hujjatdagi o'quvchi ID ham so'raladi.</p>
  <?php endif; ?>
</div>
<?php page_footer();
