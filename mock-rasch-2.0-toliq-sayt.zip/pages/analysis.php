<?php
defined('APP_ROOT') || exit;
$test = get_test_or_404();
if ($test['dirty'] && val('SELECT COUNT(*) FROM responses WHERE test_id=?', [$test['id']]) && $test['key']) {
    compute_test((int)$test['id']);
    $test = test_by_id((int)$test['id']);
}
$stats = $test['stats'];
$items = rows('SELECT * FROM item_stats WHERE test_id=? ORDER BY ord', [$test['id']]);
$thetas = array_map('floatval', array_column(rows('SELECT theta FROM results WHERE test_id=?', [$test['id']]), 'theta'));
$N = (int)($stats['N'] ?? 0);

// Muammoli savollarni aniqlash
$flags = []; $flagCls = [];
foreach ($items as $it) {
    $lab = $it['label']; $f = [];
    $opts = json_decode($it['options_json'] ?: '{}', true) ?: [];
    $key = $test['key'][$lab] ?? '';
    if ($key === '') $f[] = ['red', 'Kalit kiritilmagan'];
    if ($it['pbis'] !== null && $it['pbis'] < 0) $f[] = ['red', 'Manfiy korrelyatsiya (' . fmt($it['pbis'], 2) . '): kuchli o\'quvchilar ko\'proq xato qilgan — kalit xato bo\'lishi mumkin'];
    elseif ($it['pbis'] !== null && $it['pbis'] < 0.15) $f[] = ['amber', 'Past ajratish kuchi (r = ' . fmt($it['pbis'], 2) . ')'];
    if (strlen($lab) <= 2 && ctype_digit($lab) && $key !== '' && $opts) {
        $keyCnt = $opts[$key] ?? 0;
        foreach ($opts as $o => $c) {
            if ($o === $key || $o === '—') continue;
            if ($c > $keyCnt) $f[] = ['red', "$o varianti to'g'ri javobdan ($key) ko'proq tanlangan: $c ta"];
            elseif ($N >= 30 && $c / $N < 0.02) $f[] = ['gray', "$o distraktori deyarli tanlanmagan"];
        }
    }
    if ($it['outfit'] !== null && ($it['outfit'] > 1.5 || $it['infit'] > 1.3)) $f[] = ['amber', 'Modelga mos emas (infit ' . fmt($it['infit'], 2) . ', outfit ' . fmt($it['outfit'], 2) . '): javoblar tasodifiyroq'];
    if ($it['infit'] !== null && $it['infit'] < 0.7) $f[] = ['gray', 'Haddan tashqari bashoratli (infit ' . fmt($it['infit'], 2) . ')'];
    if ($it['pvalue'] >= 0.95) $f[] = ['gray', 'Juda oson (' . round($it['pvalue'] * 100) . '% to\'g\'ri)'];
    if ($it['pvalue'] <= 0.05) $f[] = ['gray', 'Juda qiyin (' . round($it['pvalue'] * 100) . '% to\'g\'ri)'];
    if ($f) {
        $flags[$lab] = $f;
        $sev = in_array('red', array_column($f, 0), true) ? 'flag-red' : (in_array('amber', array_column($f, 0), true) ? 'flag-amber' : '');
        if ($sev) $flagCls[$lab] = $sev;
    }
}
$bMap = [];
foreach ($items as $it) $bMap[$it['label']] = (float)$it['b'];

// --- Savollar bo'yicha diagrammalar: qiyinlik (b) va ajratish kuchi (r_pb) ---
$nC = (int)$test['n_closed']; $nM = (int)$test['n_match'];
$secOf = fn(string $lab): int => ctype_digit($lab) ? ((int)$lab <= $nC ? 0 : ((int)$lab <= $nC + $nM ? 1 : 2)) : 2;
$secNames = ['Yopiq (A–D)', 'Moslashtirish (A–F)', 'Ochiq (a/b)'];
$secs = []; $diffRows = []; $pbRows = [];
$dCnt = ['d-easy' => 0, 'd-mid' => 0, 'd-hard' => 0]; $pbCnt = ['neg' => 0, 'low' => 0, 'mid' => 0, 'good' => 0];
foreach (array_values($items) as $i => $it) {
    $lab = $it['label']; $b = (float)$it['b']; $r = $it['pbis'] === null ? null : (float)$it['pbis'];
    $sc = $secOf($lab);
    if (!$secs || $secs[count($secs) - 1]['s'] !== $sc) $secs[] = ['s' => $sc, 'from' => $i, 'to' => $i, 'b' => [], 'r' => []];
    $k = count($secs) - 1; $secs[$k]['to'] = $i; $secs[$k]['b'][] = $b; if ($r !== null) $secs[$k]['r'][] = $r;
    [$dl, $dc] = difficulty_label($b); $dCnt[$dc]++;
    if ($r !== null) { $pk = $r < 0 ? 'neg' : ($r < 0.15 ? 'low' : ($r >= 0.3 ? 'good' : 'mid')); $pbCnt[$pk]++; }
    $head = $lab . '-savol';
    $diffRows[] = ['label' => $lab, 'v' => $b, 'cls' => $b < 0 ? 'b-neg' : 'b-pos',
        'tip' => "$head: b = " . fmt($b, 2) . " logit ($dl)" . ($it['se'] !== null ? ' · SE ' . fmt($it['se'], 2) : '')
            . " · to'g'ri javob: " . (int)$it['n_correct'] . "/$N (" . round($it['pvalue'] * 100) . '%)'
            . ($it['extreme'] ? " · taxminiy baho (hamma to'g'ri yoki hamma xato)" : '')];
    $pbRows[] = ['label' => $lab, 'v' => $r, 'cls' => $r !== null && $r < 0 ? 'b-crit' : 'b-norm',
        'tip' => $r === null ? "$head: r hisoblanmagan (hamma bir xil javob bergan)"
            : "$head: r = " . fmt($r, 2) . ($r < 0 ? ' — manfiy: kalitni tekshiring' : ($r < 0.15 ? ' — past ajratish' : ($r >= 0.3 ? ' — yaxshi ajratadi' : ' — o\'rtacha')))
              . ' · infit ' . fmt($it['infit'], 2) . ', outfit ' . fmt($it['outfit'], 2)];
}
$avg = fn(array $a) => $a ? array_sum($a) / count($a) : null;
$sgn = fn($v) => $v === null ? '—' : ($v > 0 ? '+' : ($v < 0 ? '−' : '')) . number_format(abs($v), 2, '.', '');
$diffSecs = array_map(fn($s) => [$s['from'], $s['to'], $secNames[$s['s']], "o'rtacha b: " . $sgn($avg($s['b']))], $secs);
$pbSecs = array_map(fn($s) => [$s['from'], $s['to'], $secNames[$s['s']], "o'rtacha r: " . ($s['r'] ? number_format($avg($s['r']), 2, '.', '') : '—')], $secs);
$maxAbsB = max(array_map(fn($x) => abs($x['v']), $diffRows) ?: [1]);
$bLim = max(2, min(5, (int)ceil($maxAbsB)));   // ±5 dan oshganlar (ekstremal savollar) kesib ko'rsatiladi
$byB = $diffRows; usort($byB, fn($a, $b) => $b['v'] <=> $a['v']);
$top = fn(array $list) => implode(', ', array_map(fn($x) => '<b>' . e($x['label']) . '</b> (' . $sgn($x['v']) . ')', $list));
$rVals = array_values(array_filter(array_column($pbRows, 'v'), fn($v) => $v !== null));
$rLo = min(-0.2, floor(min($rVals ?: [0]) * 10) / 10); $rHi = max(0.6, ceil(max($rVals ?: [0]) * 10) / 10);
page_header('Rasch tahlili — ' . $test['title']);
test_tabs($test, 'analysis');
if (!$items): ?>
  <div class="card empty">Tahlil uchun javoblar va kalit kerak.</div>
<?php page_footer(); return; endif; ?>

<div class="stats4">
  <div class="stat"><span><?= fmt($stats['reliability'] ?? null, 2) ?></span>O'quvchilar ishonchliligi<small>Rasch person reliability</small></div>
  <div class="stat"><span><?= fmt($stats['item_reliability'] ?? null, 2) ?></span>Savollar ishonchliligi<small>item reliability</small></div>
  <div class="stat"><span><?= fmt($stats['alpha'] ?? null, 2) ?></span>Cronbach α<small>KR-20</small></div>
  <div class="stat"><span><?= fmt($stats['theta_mean'] ?? null, 2) ?> ± <?= fmt($stats['theta_sd'] ?? null, 2) ?></span>θ o'rtacha ± SD<small>logit</small></div>
</div>

<div class="grid-side">
  <div class="card">
    <h2>Wright xaritasi</h2>
    <p class="small muted">O'quvchilar qobiliyati va savollar qiyinligi bitta logit shkalada. Savol o'quvchi bilan bir balandlikda bo'lsa — uni yechish ehtimoli 50%. Qizil — tekshirilishi kerak bo'lgan savollar.</p>
    <?= svg_wright_map($thetas, $bMap, ['flag' => $flagCls]) ?>
  </div>
  <div class="card">
    <h2>Diqqat talab qiladigan savollar</h2>
    <?php if (!$flags): ?><p class="muted">Muammoli savol topilmadi.</p><?php endif; ?>
    <ul class="flag-list">
    <?php foreach ($flags as $lab => $fs): ?>
      <li><b><?= e($lab) ?></b>
        <?php foreach ($fs as [$c, $msg]): ?><div class="flag <?= $c ?>"><?= e($msg) ?></div><?php endforeach; ?>
      </li>
    <?php endforeach; ?>
    </ul>
  </div>
</div>

<div class="card item-chart">
  <div class="card-head"><h2>Savollar qiyinligi (b, logit)</h2><label class="check small vals-toggle"><input type="checkbox" checked> Qiymatlar</label></div>
  <p class="small muted chart-sum">
    Oson (b &lt; −1): <b><?= $dCnt['d-easy'] ?></b> ta · O'rta: <b><?= $dCnt['d-mid'] ?></b> ta · Qiyin (b &gt; +1): <b><?= $dCnt['d-hard'] ?></b> ta.
    Eng qiyin: <?= $top(array_slice($byB, 0, 3)) ?>. Eng oson: <?= $top(array_slice(array_reverse($byB), 0, 3)) ?>.
  </p>
  <div class="chart-legend"><span style="display:inline-flex;align-items:center;gap:.4rem;margin-right:1.1rem"><i class="sw" style="display:inline-block;width:11px;height:11px;border-radius:3px;background:var(--div-neg,#2a78d6)"></i>oson (nol ostida)</span><span style="display:inline-flex;align-items:center;gap:.4rem;margin-right:1.1rem"><i class="sw" style="display:inline-block;width:11px;height:11px;border-radius:3px;background:var(--div-pos,#eb6834)"></i>qiyin (nol ustida)</span><span style="display:inline-flex;align-items:center;gap:.4rem;margin-right:1.1rem"><i class="ln" style="display:inline-block;width:16px;border-top:1.5px dashed #d4cfc0"></i>±1 — oson / qiyin chegarasi</span><?php if ($maxAbsB > 5): ?><span style="display:inline-flex;align-items:center;gap:.4rem;margin-right:1.1rem">⫽ ±5 dan oshgan ustun kesilgan (yonida haqiqiy qiymat) — hamma to'g'ri yoki hamma xato yechgan savol</span><?php endif; ?></div>
  <div class="chart-scroll"><?= svg_item_columns($diffRows, ['lo' => -$bLim, 'hi' => $bLim, 'step' => 1, 'dec' => 2, 'plus' => true, 'sym' => true, 'clip' => 5,
      'thr' => [[1, 'qiyin ↑'], [-1, 'oson ↓']], 'sections' => $diffSecs, 'ytitle' => 'logit', 'title' => 'Savollar qiyinligi, logit']) ?></div>
  <p class="small muted mt">0 — test o'rtacha qiyinligi. Ustun qancha baland bo'lsa, savol shuncha qiyin; nol ostidagilar — oson. Aniq qiymat va to'g'ri javoblar ulushi uchun ustunga sichqonchani olib boring.</p>
</div>

<div class="card item-chart">
  <div class="card-head"><h2>Ajratish kuchi (r<sub>pb</sub>)</h2><label class="check small vals-toggle"><input type="checkbox" checked> Qiymatlar</label></div>
  <p class="small muted chart-sum">
    Yaxshi (≥ 0.30): <b><?= $pbCnt['good'] ?></b> ta · O'rtacha: <b><?= $pbCnt['mid'] ?></b> ta · Past (&lt; 0.15): <b><?= $pbCnt['low'] ?></b> ta
    <?php if ($pbCnt['neg']): ?> · <span class="neg-note">⚠ Manfiy: <b><?= $pbCnt['neg'] ?></b> ta — kalitni tekshiring</span><?php endif; ?>.
  </p>
  <div class="chart-legend"><span style="display:inline-flex;align-items:center;gap:.4rem;margin-right:1.1rem"><i class="sw" style="display:inline-block;width:11px;height:11px;border-radius:3px;background:var(--viz-1,#3987e5)"></i>kuchli o'quvchilar ko'proq yechgan</span><span style="display:inline-flex;align-items:center;gap:.4rem;margin-right:1.1rem"><i class="sw" style="display:inline-block;width:11px;height:11px;border-radius:3px;background:var(--critical,#d03b3b)"></i>⚠ manfiy — kalit xato bo'lishi mumkin</span><span style="display:inline-flex;align-items:center;gap:.4rem;margin-right:1.1rem"><i class="sw" style="display:inline-block;width:11px;height:11px;border-radius:3px;background:var(--warn-bg,#fbf1dd);border:1px solid var(--warn-line,#f0d8a8)"></i>past ajratish zonasi</span></div>
  <div class="chart-scroll"><?= svg_item_columns($pbRows, ['lo' => $rLo, 'hi' => $rHi, 'step' => ($rHi - $rLo) > 1.2 ? 0.2 : 0.1, 'dec' => 2,
      'tlim' => [-1, 1], 'band' => [0, 0.15, 'past'], 'thr' => [[0.3, 'yaxshi ↑']], 'sections' => $pbSecs, 'ytitle' => 'r', 'title' => 'Savollarning ajratish kuchi']) ?></div>
  <p class="small muted mt">Savol natijasi bilan qolgan savollar yig'indisi orasidagi bog'liqlik: musbat va baland — savolni kuchli o'quvchilar yechgan, zaiflar yechmagan (yaxshi savol). Manfiy — aksincha: odatda kalit xato yoki savol noaniq.</p>
</div>

<div class="card">
  <div class="card-head"><h2>Har bir savolga to'g'ri javoblar</h2><span class="small muted"><?= $N ?> ishtirokchidan, qizil — tekshirilishi kerak</span></div>
  <div class="chart-scroll"><?= svg_item_bars($items, $N, $flagCls) ?></div>
</div>
<div class="section-title">
  <h2>Savollar parametrlari</h2>
  <a class="btn sm ghost" href="<?= e(url('export', ['what' => 'items', 'id' => $test['id']])) ?>">⬇ Excel (CSV)</a>
</div>
<div class="table-wrap"><table class="tbl sortable compact-tbl">
  <thead><tr><th>Savol</th><th>Kalit</th><th class="num" title="Shu savolga to'g'ri javob berganlar soni / jami ishtirokchi">To'g'ri javob bergan</th><th class="num">b (logit)</th><th class="num">SE</th><th class="num">Infit</th><th class="num">Outfit</th><th class="num">r<sub>pb</sub></th><th>Variantlar taqsimoti</th></tr></thead>
  <tbody>
  <?php foreach ($items as $it): $opts = json_decode($it['options_json'] ?: '{}', true) ?: []; $key = $test['key'][$it['label']] ?? ''; [$dl, $dc] = difficulty_label((float)$it['b']); ?>
    <tr class="<?= e($flagCls[$it['label']] ?? '') ?>">
      <td><b><?= e($it['label']) ?></b></td>
      <td class="mono small"><?= e(mb_strimwidth($key, 0, 14, '…')) ?></td>
      <td class="num" data-v="<?= $it['pvalue'] ?>"><b><?= (int)$it['n_correct'] ?></b><span class="muted">/<?= $N ?></span> <span class="small muted"><?= round($it['pvalue'] * 100) ?>%</span></td>
      <td class="num" data-v="<?= $it['b'] ?>"><span class="dtag <?= $dc ?>"><?= fmt($it['b'], 2) ?></span><?= $it['extreme'] ? ' <span class="muted small" title="Hamma to\'g\'ri yoki hamma xato — taxminiy baho">*</span>' : '' ?></td>
      <td class="num muted"><?= fmt($it['se'], 2) ?></td>
      <td class="num <?= ($it['infit'] !== null && ($it['infit'] > 1.3 || $it['infit'] < 0.7)) ? 'warn' : '' ?>"><?= fmt($it['infit'], 2) ?></td>
      <td class="num <?= ($it['outfit'] !== null && ($it['outfit'] > 1.5 || $it['outfit'] < 0.5)) ? 'warn' : '' ?>"><?= fmt($it['outfit'], 2) ?></td>
      <td class="num <?= ($it['pbis'] !== null && $it['pbis'] < 0.15) ? 'warn' : '' ?>"><?= fmt($it['pbis'], 2) ?></td>
      <td>
        <?php if (isset($opts['correct'])): ?>
          <span class="small">✓ <?= (int)$opts['correct'] ?> · bo'sh <?= (int)$opts['blank'] ?></span>
        <?php else: ?>
          <div class="dist"><?php foreach ($opts as $o => $c): $w = $N ? $c / $N * 100 : 0; ?>
            <span class="<?= $o === $key ? 'key' : '' ?>" title="<?= e($o) ?>: <?= $c ?> ta"><em><?= e($o) ?></em><i style="width:<?= round($w * 0.8) ?>px"></i><?= $c ?></span>
          <?php endforeach; ?></div>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>

<div class="grid2 mt">
  <div class="card">
    <h2>Xom ball → θ → ball jadvali</h2>
    <p class="small muted">Rasch modelida xom ball (to'g'ri javoblar soni) θ uchun yetarli statistika: bir xil sondagi to'g'ri javob bir xil θ beradi. θ ning qiymati esa savollar qiyinligiga bog'liq.</p>
    <?php if (($stats['method'] ?? '') === 'weighted'): ?><p class="small warn">Vaznli usulda ball qaysi savollar yechilganiga bog'liq, shuning uchun jadvalda faqat θ ko'rsatiladi.</p><?php endif; ?>
    <div class="table-wrap scroll-y"><table class="tbl compact-tbl">
      <thead><tr><th class="num">To'g'ri</th><th class="num">θ</th><th class="num">SE</th><th class="num">Ball</th><th>Daraja</th></tr></thead>
      <tbody>
      <?php foreach (($stats['score_table'] ?? []) as $k => $r): ?>
        <tr><td class="num"><?= $k ?></td><td class="num"><?= fmt($r['theta'], 2) ?></td><td class="num muted"><?= fmt($r['se'], 2) ?></td>
            <td class="num"><?= $r['ball'] === null ? '—' : fmt($r['ball']) ?></td><td><?= $r['ball'] === null ? '' : grade_badge(grade_for((float)$r['ball'])) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
  <div class="card">
    <h2>Ko'rsatkichlarni o'qish</h2>
    <dl class="gloss">
      <dt>b (logit)</dt><dd>Savol qiyinligi. 0 — o'rtacha; manfiy — oson, musbat — qiyin. Test markazi 0 ga tenglangan.</dd>
      <dt>θ (logit)</dt><dd>O'quvchi qobiliyati, savollar bilan bir shkalada. θ = b bo'lsa, to'g'ri yechish ehtimoli 50%.</dd>
      <dt>Infit / Outfit</dt><dd>Javoblar modelga qanchalik mos. 1.0 — ideal; 0.7–1.3 — yaxshi; &gt; 1.3 — tasodifiy javoblar ko'p (savol noaniq yoki "tuzoq"); &lt; 0.7 — haddan ortiq bashoratli.</dd>
      <dt>r<sub>pb</sub></dt><dd>Savol natijasining qolgan savollar yig'indisi bilan korrelyatsiyasi. &gt; 0.3 — yaxshi ajratadi; manfiy — odatda kalit xatosi.</dd>
      <dt>Ishonchlilik</dt><dd>0.8 dan yuqori — o'quvchilarni ishonchli ajratadi; 0.7 dan past — test qisqa yoki savollar bir xil.</dd>
    </dl>
  </div>
</div>
<?php page_footer();
