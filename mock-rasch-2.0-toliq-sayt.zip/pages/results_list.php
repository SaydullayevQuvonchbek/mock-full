<?php
defined('APP_ROOT') || exit;
/**
 * Natijalar ro'yxati — chop etish yoki PDF qilib saqlash uchun (yotiq A4).
 * Kim qanday daraja olgani reyting tartibida, qatorlar darajasiga qarab rangli.
 * Ustunlar: №, F.I.Sh, ID, umumiy ball, foiz, daraja, bo'limlar balli (Algebra / Geometriya), OTM ballari (1-fan, 2-fan).
 * OTM ballari: sertifikat olganlarga 1-fan = 93 × foiz + 11, 2-fan = 63 × foiz + 11; sertifikatsizlarga 0.
 */
$test = get_test_or_404();
$nResp = (int)val('SELECT COUNT(*) FROM responses WHERE test_id=? AND status="submitted"', [$test['id']]);
if ($test['dirty'] && $nResp > 0 && count($test['key']) > 0) {
    compute_test((int)$test['id']);
    $test = test_by_id((int)$test['id']);
}
$group = trim($_GET['group'] ?? '');
$center = (string)($_GET['center'] ?? '');
$centers = centers_list();
$hasGeo = in_array('G', test_sections($test), true);
$showSec = $hasGeo && ($_GET['sec'] ?? '1') !== '0';
$showOtm = ($_GET['otm'] ?? '1') !== '0';
$color = ($_GET['color'] ?? '1') !== '0';

$sql = 'SELECT r.*, s.code, s.full_name FROM results r JOIN students s ON s.id=r.student_id WHERE r.test_id=?';
$par = [$test['id']];
if ($group !== '') { $sql .= ' AND s.group_name=?'; $par[] = $group; }
if ($center === 'own') $sql .= ' AND s.center_id IS NULL';
elseif ($center !== '') { $sql .= ' AND s.center_id=?'; $par[] = (int)$center; }
$list = rows($sql . ' ORDER BY r.rank_no, r.ball_raw DESC, s.full_name', $par);

$gradeCls = ['A+' => 'rl-ap', 'A' => 'rl-a', 'B+' => 'rl-bp', 'B' => 'rl-b', 'C+' => 'rl-cp', 'C' => 'rl-c', 'NB' => 'rl-nc'];
$cnt = array_fill_keys(array_keys($gradeCls), 0);
foreach ($list as $r) $cnt[$r['grade']] = ($cnt[$r['grade']] ?? 0) + 1;
$nCert = count($list) - ($cnt['NB'] ?? 0);
$pct = fn(float $p) => rtrim(rtrim(number_format($p, 2, '.', ''), '0'), '.') . '%';   // 100% · 99.97% · 31.2%
$M = (float)($test['t_mean'] ?? 50); $S = (float)($test['t_sd'] ?? 10);
$shifted = ($test['stats']['method'] ?? 'tscore') !== 'tscore' || abs($M - 50) > 1e-9 || abs($S - 10) > 1e-9;
$date = $test['test_date'] ? date('d.m.Y', strtotime($test['test_date'])) : '';
$scope = trim(($group !== '' ? $group : '') . ($center !== '' ? ($group !== '' ? ' · ' : '') . ($center === 'own' ? 'O\'z markazimiz' : ($centers[(int)$center] ?? '')) : ''));
// PDF saqlanganda fayl nomi shu bo'ladi
$fileTitle = trim($test['title'] . ' natijalari' . ($date ? ' ' . $date : '') . ($scope !== '' ? ' (' . $scope . ')' : ''));
$keep = array_filter(['p' => 'results_list', 'id' => (int)$test['id'], 'group' => $group, 'center' => $center], fn($v) => $v !== '');

page_header($fileTitle, ['bare' => true, 'body' => 'print-page reslist-page']);
?>
<style>@page { size: A4 landscape; margin: 8mm; }</style>
<div class="no-print toolbar">
  <button class="btn primary" onclick="print()"><?= icon('print', 16) ?>PDF yuklab olish / chop etish</button>
  <form method="get" class="row gap inline center-v">
    <?php foreach ($keep as $k => $v): ?><input type="hidden" name="<?= e($k) ?>" value="<?= e((string)$v) ?>"><?php endforeach; ?>
    <?php if ($hasGeo): ?><input type="hidden" name="sec" value="0"><label class="check"><input type="checkbox" name="sec" value="1" <?= $showSec ? 'checked' : '' ?> onchange="this.form.submit()"> Algebra / Geometriya</label><?php endif; ?>
    <input type="hidden" name="otm" value="0"><label class="check"><input type="checkbox" name="otm" value="1" <?= $showOtm ? 'checked' : '' ?> onchange="this.form.submit()"> OTM ballari (1-fan, 2-fan)</label>
    <input type="hidden" name="color" value="0"><label class="check"><input type="checkbox" name="color" value="1" <?= $color ? 'checked' : '' ?> onchange="this.form.submit()"> Rangli</label>
  </form>
  <span class="muted small">PDF uchun: chop etish oynasida printer o'rniga <b>«PDF sifatida saqlash»</b> (Сохранить как PDF) ni tanlang.</span>
  <a class="small" href="<?= e(url('results', array_filter(['id' => (int)$test['id'], 'group' => $group, 'center' => $center], fn($v) => $v !== ''))) ?>">← Natijalarga qaytish</a>
</div>

<div class="reslist<?= $color ? ' rl-color' : '' ?>">
  <header class="rl-head">
    <div>
      <small><?= e(app_setting('center')) ?><?= $test['subject'] ? ' · ' . e($test['subject']) : '' ?></small>
      <h1><?= e($test['title']) ?> — natijalar</h1>
      <div class="rl-meta"><?= $date ? e($date) . ' · ' : '' ?><?= count($list) ?> ishtirokchi<?= $scope !== '' ? ' · ' . e($scope) : '' ?> · sertifikat olganlar: <b><?= $nCert ?></b> ta</div>
      <?php if ($shifted): ?><div class="rl-meta">Ball markaz shkalasida (M = <?= fmt($M) ?>, S = <?= fmt($S) ?>) hisoblangan.</div><?php endif; ?>
    </div>
    <div class="rl-sum">
      <?php foreach ($gradeCls as $g => $cls): ?><span class="<?= $cls ?>"><?= $g === 'NB' ? 'NC' : $g ?>: <b><?= (int)$cnt[$g] ?></b></span><?php endforeach; ?>
    </div>
  </header>
  <table class="rl-tbl">
    <thead><tr>
      <th class="n">№</th><th>Ism familiya</th><th>ID</th><th class="n">Umumiy ball</th><th class="n">Foiz</th><th>Daraja</th>
      <?php if ($showSec): ?><th class="n">Ball Alg.</th><th class="n">Ball Geo.</th><?php endif; ?>
      <?php if ($showOtm): ?><th class="n" title="93 × foiz + 11">1-Fan</th><th class="n" title="63 × foiz + 11">2-Fan</th><?php endif; ?>
    </tr></thead>
    <tbody>
    <?php foreach ($list as $i => $r):
        $ball = (float)$r['ball']; $p = cert_percent($ball); $cert = $r['grade'] !== 'NB';
        $ss = $showSec ? section_scores($test, (string)$r['scored'], $ball) : []; ?>
      <tr class="<?= $gradeCls[$r['grade']] ?? 'rl-nc' ?>">
        <td class="n"><?= $i + 1 ?></td>
        <td><?= e($r['full_name'] ?: '—') ?></td>
        <td class="mono"><?= e($r['code']) ?></td>
        <td class="n"><b><?= fmt($ball) ?></b></td>
        <td class="n"><?= $pct($p) ?></td>
        <td><b><?= $cert ? e($r['grade']) : 'NC' ?></b></td>
        <?php if ($showSec): ?><td class="n"><?= fmt($ss['A']['ball'] ?? 0, 2) ?></td><td class="n"><?= fmt($ss['G']['ball'] ?? 0, 2) ?></td><?php endif; ?>
        <?php if ($showOtm): ?><td class="n"><?= $cert ? fmt(93 * $p / 100 + 11, 2) : '0' ?></td><td class="n"><?= $cert ? fmt(63 * $p / 100 + 11, 2) : '0' ?></td><?php endif; ?>
      </tr>
    <?php endforeach; ?>
    <?php if (!$list): ?><tr><td colspan="10" class="empty">Natijalar hali yo'q — avval javoblarni kiriting va hisoblang.</td></tr><?php endif; ?>
    </tbody>
  </table>
  <p class="rl-foot">Foiz = ball ÷ 65 × 100 (ko'pi bilan 100%). Daraja: A+ ≥ 70 · A ≥ 65 · B+ ≥ 60 · B ≥ 55 · C+ ≥ 50 · C ≥ 46 · NC — 46 dan past (sertifikatsiz).<?= $showOtm ? ' OTM ballari: 1-fan = 93 × foiz + 11, 2-fan = 63 × foiz + 11 (sertifikatsizlarga 0).' : '' ?></p>
</div>
<script>document.title = <?= json_encode($fileTitle, JSON_UNESCAPED_UNICODE) ?>;</script>
<?php page_footer();
