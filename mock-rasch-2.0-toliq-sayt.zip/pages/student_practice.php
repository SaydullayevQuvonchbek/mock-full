<?php
defined('APP_ROOT') || exit;
/** O'quvchi: mashq testi tuzish (bo'limlar bo'yicha tasodifiy), mashqlar tarixi va bo'limlar bo'yicha umumiy natija */
$me = student();
$sid = (int)$me['id'];
if (is_post()) {
    csrf_check();
    $secs = array_values(array_filter(array_map('intval', (array)($_POST['sec'] ?? []))));
    $n = (int)($_POST['n'] ?? 10);
    $open = (int)val('SELECT COUNT(*) FROM qb_tests WHERE student_id=? AND status="open"', [$sid]);
    $today = (int)val('SELECT COUNT(*) FROM qb_tests WHERE student_id=? AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [$sid]);
    if ($open >= 8) flash('Yakunlanmagan mashqlaringiz ko\'p. Avval ularni topshiring yoki o\'chiring.', 'err');
    elseif ($today >= 40) flash('Bugungi mashq limiti tugadi. Ertaga davom eting.', 'warn');
    else {
        [$tid, $err] = qb_build_test($sid, $secs, $n, 'web');
        if ($tid) redirect('student_practice_do', ['id' => $tid]);
        flash($err, 'err');
    }
    redirect('student_practice');
}
$tree = qb_tree();
$tests = rows('SELECT * FROM qb_tests WHERE student_id=? ORDER BY id DESC LIMIT 20', [$sid]);
$by = rows('SELECT section_name, COUNT(*) n, SUM(i.ok=1) k FROM qb_items i JOIN qb_tests t ON t.id=i.test_id WHERE t.student_id=? AND t.status="done" GROUP BY i.section_id, i.section_name ORDER BY i.section_name', [$sid]);
$sumN = array_sum(array_map(fn($r) => (int)$r['n'], $by));
$sumK = array_sum(array_map(fn($r) => (int)$r['k'], $by));
$ready = array_filter($tree, fn($s) => $s['ready_total'] > 0);
page_header('Mashq testlari');
?>
<h1>Mashq testlari</h1>
<p class="muted">Bo'limlarni tanlang — tizim tasodifiy savollardan test tuzadi. Yakunda nechta savolni to'g'ri yechganingiz ko'rsatiladi.</p>

<?php if (!$ready): ?>
  <div class="card empty">Hozircha mashq savollari qo'shilmagan. Keyinroq qayta urinib ko'ring.</div>
<?php else: ?>
<form method="post" class="card form qb-build"><?= csrf_field() ?>
  <h3>Yangi mashq testi</h3>
  <fieldset><legend>Bo'limlar <span class="muted small">— hech narsa tanlanmasa, barcha bo'limlardan; bo'limni belgilasangiz, ichki bo'limlari ham kiradi</span></legend>
    <div class="qb-pick">
    <?php foreach ($ready as $s): ?>
      <label class="check" style="margin-left: <?= $s['depth'] * 1.3 ?>rem"><input type="checkbox" name="sec[]" value="<?= $s['id'] ?>">
        <span><?= e($s['name']) ?> <span class="muted small">· <?= $s['ready_total'] ?> ta savol</span></span></label>
    <?php endforeach; ?>
    </div>
  </fieldset>
  <div class="row gap wrap center-v">
    <label>Savollar soni
      <input type="number" name="n" id="qbN" value="10" min="5" max="60" style="width:6rem"></label>
    <div class="row gap wrap" style="margin-top:.2rem">
      <?php foreach ([5, 10, 20, 30, 45, 60] as $k): ?><button type="button" class="btn sm ghost" onclick="document.getElementById('qbN').value=<?= $k ?>"><?= $k ?></button><?php endforeach; ?>
    </div>
    <button class="btn primary"><?= icon('tests', 16) ?>Test tuzish</button>
  </div>
</form>
<?php endif; ?>

<?php if ($by): ?>
<div class="card">
  <div class="card-head"><h3>Bo'limlar bo'yicha natijalarim</h3><span class="small muted">Jami: <b><?= $sumK ?> / <?= $sumN ?></b> to'g'ri (<?= $sumN ? round(100 * $sumK / $sumN) : 0 ?>%)</span></div>
  <div class="qb-secbars">
  <?php foreach ($by as $r): $pct = (int)$r['n'] > 0 ? round(100 * (int)$r['k'] / (int)$r['n']) : 0; ?>
    <div class="qb-secbar"><span><?= e($r['section_name']) ?></span><div class="qb-track" role="img" aria-label="<?= $pct ?>%"><i style="width:<?= $pct ?>%" class="<?= $pct >= 70 ? 'hi' : ($pct >= 40 ? 'mid' : 'lo') ?>"></i></div><b><?= (int)$r['k'] ?> / <?= (int)$r['n'] ?></b></div>
  <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<h2 class="mt">Mashqlarim</h2>
<?php if (!$tests): ?><div class="card empty">Hali mashq testi yo'q.</div><?php else: ?>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>Sana</th><th>Test</th><th class="num">Savol</th><th class="num">To'g'ri</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($tests as $t): ?>
    <tr>
      <td class="nowrap"><?= e(date('d.m.Y H:i', strtotime($t['created_at']))) ?></td>
      <td><?= e($t['title']) ?></td>
      <td class="num"><?= (int)$t['n'] ?></td>
      <td class="num"><?= $t['status'] === 'done' ? '<b>' . (int)$t['correct'] . ' / ' . (int)$t['n'] . '</b>' : '<span class="tag amber">davom etmoqda</span>' ?></td>
      <td class="right nowrap">
        <a class="btn sm <?= $t['status'] === 'done' ? 'ghost' : 'primary' ?>" href="<?= e(url('student_practice_do', ['id' => $t['id']])) ?>"><?= $t['status'] === 'done' ? 'Natija' : 'Davom ettirish' ?></a>
        <a class="btn sm ghost" target="_blank" href="<?= e(url('student_practice_pdf', ['id' => $t['id']])) ?>">PDF</a>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php endif; ?>
<?php page_footer();
