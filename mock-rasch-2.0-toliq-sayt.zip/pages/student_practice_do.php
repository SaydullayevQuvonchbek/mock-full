<?php
defined('APP_ROOT') || exit;
/** Mashq testini yechish va natijani ko'rish. Natijada faqat to'g'ri javoblar soni (umumiy va bo'limlar bo'yicha) ko'rsatiladi. */
$me = student();
$sid = (int)$me['id'];
$tid = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$t = $tid ? row('SELECT * FROM qb_tests WHERE id=? AND student_id=?', [$tid, $sid]) : null;
if (!$t) { flash('Mashq testi topilmadi', 'err'); redirect('student_practice'); }

if (is_post()) {
    csrf_check();
    $a = (string)($_POST['action'] ?? 'submit');
    if ($a === 'submit' && $t['status'] === 'open') {
        $ans = [];
        foreach ((array)($_POST['a'] ?? []) as $pos => $v) if (is_scalar($v)) $ans[(int)$pos] = (string)$v;
        qb_finish($tid, $ans);
        flash('Test yakunlandi');
    } elseif ($a === 'delete' && $t['status'] === 'open') {
        q('DELETE FROM qb_tests WHERE id=? AND student_id=?', [$tid, $sid]);
        flash('Mashq o\'chirildi');
        redirect('student_practice');
    }
    redirect('student_practice_do', ['id' => $tid]);
}

if ($t['status'] === 'done') {
    $r = qb_result($tid);
    $pct = $r['total'] > 0 ? round(100 * $r['ok'] / $r['total']) : 0;
    $secIds = array_map('intval', array_column(rows('SELECT DISTINCT section_id FROM qb_items WHERE test_id=?', [$tid]), 'section_id'));
    page_header('Mashq natijasi');
    ?>
<p class="small muted"><a href="<?= e(url('student_practice')) ?>">← Mashq testlari</a></p>
<h1>Natija</h1>
<div class="card qb-score">
  <div class="qb-big"><b><?= $r['ok'] ?></b><span> / <?= $r['total'] ?></span></div>
  <div class="muted">ta savolga to'g'ri javob berdingiz · <b><?= $pct ?>%</b></div>
  <div class="qb-track lg" role="img" aria-label="<?= $pct ?>%"><i style="width:<?= $pct ?>%" class="<?= $pct >= 70 ? 'hi' : ($pct >= 40 ? 'mid' : 'lo') ?>"></i></div>
  <p class="small muted mt"><?= e($t['title']) ?> · <?= e(date('d.m.Y H:i', strtotime((string)$t['finished_at']))) ?></p>
</div>
<?php if (count($r['sections']) > 0): ?>
<div class="card">
  <h3>Bo'limlar bo'yicha</h3>
  <div class="qb-secbars">
  <?php foreach ($r['sections'] as $s): $p = $s['total'] > 0 ? round(100 * $s['ok'] / $s['total']) : 0; ?>
    <div class="qb-secbar"><span><?= e($s['name']) ?></span><div class="qb-track" role="img" aria-label="<?= $p ?>%"><i style="width:<?= $p ?>%" class="<?= $p >= 70 ? 'hi' : ($p >= 40 ? 'mid' : 'lo') ?>"></i></div><b><?= $s['ok'] ?> / <?= $s['total'] ?></b></div>
  <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>
<div class="row gap wrap">
  <form method="post" action="<?= e(url('student_practice')) ?>"><?= csrf_field() ?><input type="hidden" name="n" value="<?= (int)$t['n'] ?>">
    <?php foreach ($secIds as $x): ?><input type="hidden" name="sec[]" value="<?= $x ?>"><?php endforeach; ?>
    <button class="btn primary">Shu bo'limlardan yana mashq</button></form>
  <a class="btn" href="<?= e(url('student_practice')) ?>">Boshqa bo'limlar</a>
  <a class="btn ghost" target="_blank" href="<?= e(url('student_practice_pdf', ['id' => $tid])) ?>">Testni PDF yuklab olish</a>
</div>
<?php
    page_footer();
    return;
}

$items = rows('SELECT i.pos, i.question_id, i.given, q.kind, q.nopt, q.w, q.h FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? ORDER BY i.pos', [$tid]);
$missing = (int)$t['n'] - count($items);   // savol o'chirilgan bo'lishi mumkin
page_header('Mashq testi');
?>
<p class="small muted"><a href="<?= e(url('student_practice')) ?>">← Mashq testlari</a></p>
<div class="row between center-v wrap">
  <div><h1 style="margin-bottom:.2rem"><?= e($t['title']) ?></h1><p class="muted small"><?= count($items) ?> ta savol<?= $missing > 0 ? ' · ' . $missing . ' tasi bankdan olib tashlangan' : '' ?></p></div>
  <a class="btn ghost" target="_blank" href="<?= e(url('student_practice_pdf', ['id' => $tid])) ?>"><?= icon('download', 16) ?>PDF yuklab olish</a>
</div>
<?php if (!$items): ?>
  <div class="card empty">Bu testning savollari bankdan olib tashlangan. <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $tid ?>"><button class="btn sm" name="action" value="delete">Testni o'chirish</button></form></div>
<?php else: ?>
<form method="post" id="qbSolve" data-key="qbp<?= $tid ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $tid ?>">
  <div class="qb-sticky"><span>Javob berildi: <b id="qbDone">0</b> / <?= count($items) ?></span><button class="btn primary sm" name="action" value="submit" id="qbSubmit">Yakunlash va tekshirish</button></div>
  <?php foreach ($items as $it): $pos = (int)$it['pos']; ?>
  <div class="card qb-q" data-pos="<?= $pos ?>">
    <div class="qb-qn"><?= $pos ?></div>
    <img class="qb-qimg" loading="lazy" alt="<?= $pos ?>-savol" src="<?= e(url('qb_img', ['id' => $it['question_id']])) ?>">
    <?php if ($it['kind'] === 'open'): ?>
      <label class="qb-open">Javobingiz<input name="a[<?= $pos ?>]" value="<?= e($it['given']) ?>" maxlength="80" autocomplete="off" inputmode="text"></label>
    <?php else: ?>
      <div class="qb-opts" role="radiogroup" aria-label="<?= $pos ?>-savol variantlari">
      <?php for ($k = 0; $k < ((int)$it['nopt'] === 6 ? 6 : 4); $k++): $L = chr(65 + $k); ?>
        <label class="qb-opt"><input type="radio" name="a[<?= $pos ?>]" value="<?= $L ?>" <?= $it['given'] === $L ? 'checked' : '' ?>><span><?= $L ?></span></label>
      <?php endfor; ?>
        <button type="button" class="btn sm ghost qb-clear" title="Javobni tozalash">tozalash</button>
      </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
  <div class="row gap wrap">
    <button class="btn primary" name="action" value="submit">Yakunlash va tekshirish</button>
    <button class="btn danger-ghost" name="action" value="delete" formnovalidate onclick="return confirm('Bu mashq o\'chirilsinmi?')">Mashqni o'chirish</button>
  </div>
</form>
<?php endif; ?>
<?php page_footer(['assets/practice.js']);
