<?php
defined('APP_ROOT') || exit;
$test = get_test_or_404();
$items = array_values(array_filter(test_items($test), fn($i) => $i['type'] === 'open'));
$labels = array_column($items, 'label');
if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    $lab = (string)($_POST['label'] ?? '');
    if (!in_array($lab, $labels, true)) redirect('open_review', ['id' => $test['id']]);
    if ($act === 'accept' || $act === 'reject') {
        $ansTxt = trim((string)($_POST['answer'] ?? ''));
        $key = $test['key'];
        $alts = array_values(array_filter(array_map('trim', explode('|', (string)($key[$lab] ?? ''))), fn($x) => $x !== ''));
        if ($act === 'accept' && $ansTxt !== '') $alts[] = $ansTxt;
        if ($act === 'reject') $alts = array_values(array_filter($alts, fn($x) => norm_answer($x) !== norm_answer($ansTxt)));
        $key[$lab] = implode('|', array_unique($alts));
        if ($key[$lab] === '') unset($key[$lab]);
        q('UPDATE tests SET key_json=?, dirty=1 WHERE id=?', [json_encode($key, JSON_UNESCAPED_UNICODE), $test['id']]);
        flash($lab . ' kaliti: ' . ($key[$lab] ?? '(bo\'sh)'));
    }
    if ($act === 'override') {
        $r = row('SELECT id, overrides FROM responses WHERE id=? AND test_id=?', [(int)$_POST['rid'], $test['id']]);
        if ($r) {
            $ov = json_decode((string)$r['overrides'], true) ?: [];
            $v = (string)($_POST['v'] ?? '');
            if ($v === '1' || $v === '0') $ov[$lab] = (int)$v; else unset($ov[$lab]);
            q('UPDATE responses SET overrides=? WHERE id=?', [$ov ? json_encode($ov) : null, $r['id']]);
            q('UPDATE tests SET dirty=1 WHERE id=?', [$test['id']]);
        }
    }
    redirect('open_review', ['id' => $test['id'], 'item' => $lab, 'all' => $_POST['all'] ?? null]);
}
$showAll = !empty($_GET['all']);
$openItem = (string)($_GET['item'] ?? '');
$resp = rows('SELECT r.id, r.answers, r.overrides, s.code, s.full_name FROM responses r JOIN students s ON s.id=r.student_id WHERE r.test_id=? AND r.status="submitted" ORDER BY s.full_name', [$test['id']]);
$groups = []; $people = [];
foreach ($items as $it) { $groups[$it['label']] = ['judged1' => 0, 'judged0' => 0, 'blank' => 0, 'texts' => [], 'ov' => 0]; $people[$it['label']] = []; }
foreach ($resp as $r) {
    $a = json_decode($r['answers'] ?: '{}', true) ?: [];
    $ov = json_decode((string)$r['overrides'], true) ?: [];
    foreach ($items as $it) {
        $lab = $it['label'];
        $v = trim((string)($a[$lab] ?? ''));
        $g = &$groups[$lab];
        if (isset($ov[$lab])) $g['ov']++;
        if ($v === '') $g['blank']++;
        elseif ($v === '#1') $g['judged1']++;
        elseif ($v === '#0') $g['judged0']++;
        else {
            $n = norm_answer($v); $g['texts'][$n]['count'] = ($g['texts'][$n]['count'] ?? 0) + 1; $g['texts'][$n]['raw'] = $v;
            $auto = answer_matches($v, (string)($test['key'][$lab] ?? ''));
            $people[$lab][] = ['rid' => $r['id'], 'code' => $r['code'], 'name' => $r['full_name'], 'v' => $v, 'auto' => $auto, 'ov' => $ov[$lab] ?? null];
        }
        unset($g);
    }
}
page_header('Ochiq javoblar — ' . $test['title']);
test_tabs($test, 'open_review');
?>
<div class="card soft small">
  <b>Yozma javoblarni tekshirish.</b> Onlayn yoki Excel orqali kelgan javoblar kalit bilan avtomatik solishtiriladi:
  sonlar va ifodalar <b>qiymati</b> bo'yicha (<code>1/2</code> = <code>0,5</code>, <code>√12</code> = <code>2√3</code>, <code>π/2</code> = <code>pi/2</code>),
  bir nechta qiymatli javob <code>;</code> bilan va tartibsiz (<code>2;3</code> = <code>3;2</code>), <code>x=5</code> → <code>5</code>.
  Yaxlitlangan o'nli kasr (<code>2,67</code> ≠ <code>8/3</code>) to'g'ri hisoblanmaydi. Qolgan holatlarni shu yerda bir bosishda hal qilasiz:
  butun shaklni kalitga qo'shish yoki bitta o'quvchi javobini qo'lda ✓/✗ qilish.
</div>
<?php if (!$items): ?><div class="card empty">Bu testda ochiq topshiriq yo'q.</div><?php endif; ?>
<div class="open-review">
<?php foreach ($items as $it): $lab = $it['label']; $g = $groups[$lab]; $k = (string)($test['key'][$lab] ?? '');
  uasort($g['texts'], fn($x, $y) => $y['count'] <=> $x['count']);
  $list = $showAll ? $people[$lab] : array_values(array_filter($people[$lab], fn($p) => !$p['auto'] || $p['ov'] !== null)); ?>
  <div class="card" id="i<?= e($lab) ?>">
    <div class="card-head"><h3><?= e($lab) ?></h3><span class="mono small">Kalit: <?= e($k ?: '—') ?></span></div>
    <div class="small muted">Tekshiruvchi: ✓ <?= $g['judged1'] ?> · ✗ <?= $g['judged0'] ?> · bo'sh: <?= $g['blank'] ?><?= $g['ov'] ? ' · qo\'lda tuzatilgan: ' . $g['ov'] : '' ?></div>
    <?php if ($g['texts']): ?>
    <table class="tbl compact-tbl mt">
      <thead><tr><th>Javob shakli</th><th class="num">Soni</th><th></th></tr></thead>
      <?php foreach (array_slice($g['texts'], 0, 10, true) as $t): $ok = $k !== '' && answer_matches($t['raw'], $k); ?>
        <tr class="<?= $ok ? 'row-ok' : '' ?>">
          <td class="mono"><?= e($t['raw']) ?></td><td class="num"><?= $t['count'] ?></td>
          <td class="right">
            <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="label" value="<?= e($lab) ?>"><input type="hidden" name="answer" value="<?= e($t['raw']) ?>">
              <?php if ($ok): ?><input type="hidden" name="action" value="reject"><button class="btn sm ghost" title="Aynan shu shakl kalitda bo'lsa, olib tashlanadi">✓ qabul qilingan</button>
              <?php else: ?><input type="hidden" name="action" value="accept"><button class="btn sm">Kalitga qo'shish</button><?php endif; ?>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table>
    <details class="mt" <?= $openItem === $lab ? 'open' : '' ?>>
      <summary class="small"><b><?= $showAll ? 'Barcha' : 'Kalitga mos kelmagan' ?> javoblar — o'quvchilar bo'yicha (<?= count($list) ?>)</b></summary>
      <table class="tbl compact-tbl mt">
        <?php $lim = $openItem === $lab ? 2000 : 20; foreach (array_slice($list, 0, $lim) as $p): $final = $p['ov'] !== null ? (bool)$p['ov'] : $p['auto']; ?>
          <tr>
            <td class="small"><?= e($p['name']) ?> <span class="muted mono"><?= e($p['code']) ?></span></td>
            <td class="mono"><?= e($p['v']) ?></td>
            <td><?= $final ? '<span class="ok-mark">✓</span>' : '<span class="no-mark">✗</span>' ?><?= $p['ov'] !== null ? ' <span class="tag amber">qo\'lda</span>' : '' ?></td>
            <td class="right nowrap">
              <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="override"><input type="hidden" name="label" value="<?= e($lab) ?>"><input type="hidden" name="rid" value="<?= (int)$p['rid'] ?>"><input type="hidden" name="all" value="<?= $showAll ? 1 : '' ?>">
                <?php foreach (['1' => '✓', '0' => '✗', '' => 'avto'] as $v => $lbl): $on = $v === '' ? $p['ov'] === null : (string)$p['ov'] === $v; ?><button name="v" value="<?= $v ?>" class="btn sm <?= $on ? 'primary' : 'ghost' ?>"><?= $lbl ?></button><?php endforeach; ?>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$list): ?><tr><td class="muted small">Hammasi kalitga mos.</td></tr><?php endif; ?>
        <?php if (count($list) > $lim): ?><tr><td colspan="4" class="small"><a href="<?= e(url('open_review', ['id' => $test['id'], 'item' => $lab, 'all' => $showAll ? 1 : null])) ?>#i<?= e($lab) ?>">Yana <?= count($list) - $lim ?> ta — hammasini ko'rsatish</a></td></tr><?php endif; ?>
      </table>
    </details>
    <?php endif; ?>
  </div>
<?php endforeach; ?>
</div>
<p class="small"><a href="<?= e(url('open_review', ['id' => $test['id'], 'all' => $showAll ? null : 1])) ?>"><?= $showAll ? 'Faqat mos kelmaganlarni ko\'rsatish' : 'Barcha javoblarni ko\'rsatish' ?></a></p>
<?php page_footer();
