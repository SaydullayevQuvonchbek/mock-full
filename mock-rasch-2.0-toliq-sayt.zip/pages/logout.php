<?php
defined('APP_ROOT') || exit;
unset($_SESSION['admin']);
redirect('home');
