<?php
defined('APP_ROOT') || exit;
if (admin()) redirect('dashboard');
$err = '';
if (is_post()) {
    csrf_check();
    $login = trim($_POST['login'] ?? '');
    $wait = throttle_wait('admin', strtolower($login));
    if ($wait) {
        $err = "Juda ko'p noto'g'ri urinish. $wait daqiqadan keyin qayta urinib ko'ring.";
    } else {
        $u = row('SELECT * FROM users WHERE login=?', [$login]);
        if ($u && password_verify($_POST['password'] ?? '', $u['pass_hash'])) {
            throttle_clear('admin', strtolower($login));
            if (password_needs_rehash($u['pass_hash'], PASSWORD_DEFAULT)) q('UPDATE users SET pass_hash=? WHERE id=?', [password_hash($_POST['password'], PASSWORD_DEFAULT), $u['id']]);
            q('UPDATE users SET last_login=NOW() WHERE id=?', [$u['id']]);
            session_regenerate_id(true);
            unset($_SESSION['student']);
            $hash = (string)val('SELECT pass_hash FROM users WHERE id=?', [$u['id']]);
            $_SESSION['admin'] = ['id' => (int)$u['id'], 'login' => $u['login'], 'name' => $u['name'], 'role' => $u['role'] ?? 'admin', 'sig' => admin_session_sig($hash)];
            $_SESSION['admin_seen'] = time();
            redirect('dashboard');
        }
        throttle_fail('admin', strtolower($login));
        usleep(300000);
        $err = 'Login yoki parol noto\'g\'ri';
    }
}
page_header('Admin kirishi', ['main' => 'narrow-main']);
?>
<div class="card narrow">
  <h1>Admin kirishi</h1>
  <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
  <form method="post" class="form" autocomplete="on">
    <?= csrf_field() ?>
    <label>Login <input name="login" required autofocus autocomplete="username"></label>
    <label>Parol <input name="password" type="password" required autocomplete="current-password"></label>
    <button class="btn primary wide">Kirish</button>
  </form>
</div>
<?php page_footer();
