<?php
defined('APP_ROOT') || exit;
/** PDF (yoki rasm) dan savollarni qirqib bo'limga yuklash. Qirqish brauzerda bajariladi (pdf.js), serverga tayyor PNG rasmlar yuboriladi. */
$sid = (int)($_GET['s'] ?? 0);
$sec = $sid ? row('SELECT * FROM qb_sections WHERE id=?', [$sid]) : null;
$tree = qb_tree();
if (!$sec) {
    if (!$tree) { flash('Avval bo\'lim yarating', 'warn'); redirect('qb'); }
    $sid = (int)$tree[0]['id'];
    $sec = row('SELECT * FROM qb_sections WHERE id=?', [$sid]);
}
$have = (int)val('SELECT COUNT(*) FROM qb_questions WHERE section_id=?', [$sid]);
page_header('PDF dan yuklash — ' . $sec['name']);
?>
<div class="page-head">
  <div>
    <p class="small muted"><a href="<?= e(url('qb')) ?>">← Savollar banki</a></p>
    <h1>PDF dan savol yuklash</h1>
    <p class="muted">PDF ni tanlang — savollar avtomatik qirqiladi, siz tekshirib, yuklaysiz. Hammasi brauzeringizda bajariladi, faqat tayyor rasmlar serverga yuboriladi.</p>
  </div>
</div>

<div class="card qb-imp">
  <div class="grid2">
    <div class="form">
      <label>Bo'lim
        <select id="qbSec"><?php foreach ($tree as $s): ?><option value="<?= $s['id'] ?>" <?= (int)$s['id'] === $sid ? 'selected' : '' ?>><?= str_repeat('— ', $s['depth']) . e($s['name']) ?></option><?php endforeach; ?></select>
        <span class="small muted">Hozir bu bo'limda <?= $have ?> ta savol bor — yangilari oxiriga qo'shiladi.</span></label>
      <label>Fayl (PDF, PNG yoki JPG)
        <input type="file" id="qbFile" accept="application/pdf,.pdf,image/png,image/jpeg" multiple></label>
      <label>Savol turi
        <select id="qbKind"><option value="mc4">Test: A, B, C, D</option><option value="mc6">Test: A–F (6 variant)</option><option value="open">Ochiq javobli</option></select></label>
      <label>Javoblar kaliti <span class="muted small">(ixtiyoriy, yuklanadigan savollar tartibida)</span>
        <input id="qbKey" placeholder="ACDBBADC… yoki 1:A 2:C 3:12" autocomplete="off" spellcheck="false"></label>
    </div>
    <div class="form">
      <fieldset><legend>Qanday qirqiladi</legend>
        <label class="check"><input type="radio" name="qbMode" value="auto" checked> Avtomatik — savollar orasidagi bo'sh joy bo'yicha</label>
        <label class="check"><input type="radio" name="qbMode" value="page"> Har bir sahifa — bitta savol</label>
        <label class="check"><input type="radio" name="qbMode" value="manual"> Qo'lda — sichqoncha bilan chizib qirqaman</label>
      </fieldset>
      <div class="grid2 qb-iopts">
        <label>Ustunlar<select id="qbCols"><option value="1">1 ustun</option><option value="2">2 ustun (chap, keyin o'ng)</option></select></label>
        <label>Savollar orasidagi bo'sh joy, px<input type="number" id="qbGap" value="26" min="6" max="120"></label>
        <label>Yuqori chet, %<input type="number" id="qbTop" value="0" min="0" max="30"></label>
        <label>Pastki chet, %<input type="number" id="qbBot" value="0" min="0" max="30"></label>
      </div>
      <p class="small muted">Bo'sh joy kichik bo'lsa bitta savol bo'laklarga bo'linib ketadi — oynada "↓ birlashtirish" tugmasi bilan tuzatasiz. Sahifa sarlavhasi/raqami chiqsa, chet foizini oshiring yoki belgisini olib tashlang.</p>
    </div>
  </div>
  <div class="row gap wrap">
    <button type="button" class="btn primary" id="qbGo" disabled>Qirqish</button>
    <span id="qbStatus" class="muted small" role="status"></span>
  </div>
</div>

<div class="card" id="qbManual" hidden>
  <div class="card-head"><h3>Qo'lda qirqish</h3>
    <div class="row gap center-v"><button type="button" class="btn sm" id="qbPrev">←</button><span id="qbPageNo" class="small"></span><button type="button" class="btn sm" id="qbNext">→</button></div></div>
  <p class="small muted">Savol atrofida to'rtburchak chizing — avtomatik ro'yxatga qo'shiladi (atrofidagi bo'sh joy kesiladi).</p>
  <div class="qb-viewer"><canvas id="qbCanvas"></canvas><div id="qbSel" class="qb-selbox" hidden></div></div>
</div>

<div class="card" id="qbPieces" hidden>
  <div class="card-head"><h3>Qirqilgan savollar: <span id="qbCount">0</span></h3>
    <div class="row gap center-v wrap">
      <button type="button" class="btn sm ghost" id="qbAll">Hammasini belgilash</button>
      <button type="button" class="btn sm ghost" id="qbNone">Belgini olib tashlash</button>
      <button type="button" class="btn primary" id="qbUpload"><?= icon('upload', 16) ?>Tanlanganlarni yuklash</button></div></div>
  <progress id="qbProg" value="0" max="1" hidden style="width:100%"></progress>
  <div id="qbMsg" class="small" role="status"></div>
  <div class="qb-grid" id="qbGrid"></div>
</div>
<script>window.QB = <?= json_encode(['api' => url('qb_api'), 'list' => url('qb_questions', ['s' => '__S__']), 'pdfjs' => 'assets/pdfjs/pdf.min.js?v=3.11.174', 'worker' => 'assets/pdfjs/pdf.worker.min.js?v=3.11.174'], JSON_UNESCAPED_SLASHES) ?>;</script>
<?php page_footer(['assets/qb_import.js']);
