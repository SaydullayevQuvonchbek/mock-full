<?php
defined('APP_ROOT') || exit;
$test = get_test_or_404();
if (is_post()) {
    csrf_check();
    if (($_POST['action'] ?? '') === 'delete') {
        q('DELETE FROM responses WHERE id=? AND test_id=?', [(int)$_POST['rid'], $test['id']]);
        q('UPDATE tests SET dirty=1 WHERE id=?', [$test['id']]);
        flash('Javob o\'chirildi');
    }
    redirect('responses', ['id' => $test['id']]);
}
$items = test_items($test);
$list = rows('SELECT r.*, s.code, s.full_name, s.group_name FROM responses r JOIN students s ON s.id=r.student_id WHERE r.test_id=? ORDER BY s.full_name', [$test['id']]);
$srcNames = ['manual' => 'Qo\'lda', 'import' => 'Import', 'omr' => 'Skaner', 'online' => 'Onlayn', 'demo' => 'Namuna'];
page_header('Javoblar — ' . $test['title']);
test_tabs($test, 'responses');
?>
<p class="muted">Jami <?= count($list) ?> ta varaqa. Yashil — kalitga mos, qizil — xato, kulrang — bo'sh.</p>
<div class="table-wrap"><table class="tbl compact-tbl resp-tbl">
  <thead><tr><th>ID</th><th>F.I.Sh</th><th>Manba</th><th>Holat</th><th>Javoblar</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($list as $r): $ans = json_decode($r['answers'] ?: '{}', true) ?: []; ?>
    <tr>
      <td class="mono"><?= e($r['code']) ?></td>
      <td><?= e($r['full_name']) ?><div class="small muted"><?= e($r['group_name']) ?></div></td>
      <td><span class="tag"><?= e($srcNames[$r['source']] ?? $r['source']) ?></span></td>
      <td><?= $r['status'] === 'submitted' ? '<span class="tag green">topshirildi</span>' : '<span class="tag amber">jarayonda</span>' ?></td>
      <td class="ans-strip"><?php foreach ($items as $it):
          $v = (string)($ans[$it['label']] ?? '');
          $sc = score_item($it, $v, $test['key']);
          $cls = $v === '' ? 'blank' : ($sc ? 'ok' : 'bad');
          $txt = $it['type'] === 'mc' ? ($v ?: '·') : ($v === '#1' ? '+' : ($v === '#0' || $v === '' ? '·' : '✎'));
          echo '<i class="' . $cls . '" title="' . e($it['label'] . ': ' . ($v === '#1' ? 'to\'g\'ri (tekshiruvchi)' : ($v === '#0' ? 'noto\'g\'ri (tekshiruvchi)' : $v))) . '">' . e($txt) . '</i>';
      endforeach; ?></td>
      <td class="right nowrap">
        <a class="btn sm ghost" href="<?= e(url('entry', ['id' => $test['id'], 'student' => $r['code']])) ?>">Tahrirlash</a>
        <form method="post" class="inline" onsubmit="return confirm('Bu javob o\'chirilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="rid" value="<?= (int)$r['id'] ?>"><button class="btn sm danger-ghost">×</button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php page_footer();
