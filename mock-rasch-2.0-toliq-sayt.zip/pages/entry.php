<?php
defined('APP_ROOT') || exit;
$test = get_test_or_404();
$items = test_items($test);
$mc = array_values(array_filter($items, fn($i) => $i['type'] === 'mc'));
$op = array_values(array_filter($items, fn($i) => $i['type'] === 'open'));

if (is_post()) {
    csrf_check();
    $code = trim($_POST['code'] ?? '');
    $name = trim($_POST['full_name'] ?? '');
    $st = find_or_create_student($code, $name, trim($_POST['group_name'] ?? ''), (int)($_POST['center_id'] ?? 0) ?: null);
    if (!$st) { flash('O\'quvchi ID yoki ismini kiriting', 'err'); redirect('entry', ['id' => $test['id']]); }
    $ans = [];
    $str = strtoupper(preg_replace('/[^A-Fa-f_\-\.\s]/', '', $_POST['mc'] ?? ''));
    $str = preg_replace('/\s/', '', $str);
    foreach ($mc as $k => $it) {
        $ch = $str[$k] ?? '';
        $ans[$it['label']] = in_array($ch, $it['opts'], true) ? $ch : '';
    }
    foreach ($op as $it) {
        $v = trim((string)($_POST['o'][$it['label']] ?? ''));
        if ($v === '+') $v = '#1';
        elseif ($v === '-' || $v === '−') $v = '#0';
        $ans[$it['label']] = $v;
    }
    $_SESSION['entry_center'] = (int)($_POST['center_id'] ?? 0);
    save_response((int)$test['id'], (int)$st['id'], $ans, 'manual');
    flash('Saqlandi: ' . $st['code'] . ' — ' . ($st['full_name'] ?: 'ismsiz'));
    redirect('entry', ['id' => $test['id']]);
}

// Tahrirlash uchun mavjud javobni yuklash
$pre = null; $preStudent = null;
if (!empty($_GET['student'])) {
    $preStudent = row('SELECT * FROM students WHERE code=?', [$_GET['student']]);
    if ($preStudent) {
        $r = row('SELECT answers FROM responses WHERE test_id=? AND student_id=?', [$test['id'], $preStudent['id']]);
        $pre = $r ? (json_decode($r['answers'], true) ?: []) : null;
    }
}
$preMc = '';
if ($pre) foreach ($mc as $it) $preMc .= ($pre[$it['label']] ?? '') !== '' ? $pre[$it['label']] : '_';
$recent = rows('SELECT r.*, s.code, s.full_name FROM responses r JOIN students s ON s.id=r.student_id
                WHERE r.test_id=? ORDER BY r.updated_at DESC LIMIT 12', [$test['id']]);
page_header('Qo\'lda kiritish — ' . $test['title']);
test_tabs($test, 'entry');
?>
<div class="grid-side">
<form method="post" class="card form" id="entryForm" autocomplete="off">
  <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$test['id'] ?>">
  <h2>Javoblar varaqasini kiritish</h2>
  <div class="grid3">
    <label>O'quvchi ID <input name="code" id="code" maxlength="6" inputmode="numeric" class="mono big-input" value="<?= e($preStudent['code'] ?? '') ?>" autofocus></label>
    <label class="span2">F.I.Sh <input name="full_name" id="full_name" value="<?= e($preStudent['full_name'] ?? '') ?>" placeholder="ID topilmasa — yangi o'quvchi yaratiladi"></label>
  </div>
  <?php if ($cl = centers_list()): ?>
  <label>Markaz (yangi o'quvchi uchun) <select name="center_id"><option value="0">O'z markazimiz</option><?php foreach ($cl as $cid => $cn): ?><option value="<?= $cid ?>" <?= (int)($_SESSION['entry_center'] ?? 0) === $cid ? 'selected' : '' ?>><?= e($cn) ?></option><?php endforeach; ?></select></label>
  <?php endif; ?>
  <div id="studentInfo" class="small muted"></div>

  <label class="mt">Yopiq savollar 1–<?= count($mc) ?> (ketma-ket harflar, bo'sh qolgan savol uchun <code>_</code>)
    <input name="mc" id="mcStr" class="mono big-input" maxlength="<?= count($mc) ?>" value="<?= e($preMc) ?>" placeholder="ABCDABCD..."></label>
  <div class="key-grid compact" id="mcGrid">
    <?php foreach ($mc as $k => $it): ?>
      <div class="key-row" data-k="<?= $k ?>"><span class="qno"><?= e($it['label']) ?></span>
        <?php foreach ($it['opts'] as $o): ?><button type="button" class="bub-btn" data-v="<?= $o ?>"><?= $o ?></button><?php endforeach; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <?php if ($op): ?>
  <h3 class="mt">Ochiq topshiriqlar</h3>
  <p class="muted small"><b>+</b> — to'g'ri, <b>-</b> — noto'g'ri (tekshiruvchi bahosi), yoki o'quvchi yozgan javobni kiriting — kalit bilan avtomatik solishtiriladi.</p>
  <div class="open-key-grid">
    <?php foreach ($op as $it): $v = $pre[$it['label']] ?? ''; $v = $v === '#1' ? '+' : ($v === '#0' ? '-' : $v); ?>
      <label class="open-key"><span class="qno"><?= e($it['label']) ?></span><input name="o[<?= e($it['label']) ?>]" value="<?= e($v) ?>" class="mono open-in"></label>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <div class="row gap mt">
    <button class="btn primary">Saqlash (Ctrl+Enter)</button>
    <button type="button" class="btn ghost" onclick="document.querySelectorAll('.open-in').forEach(i=>{if(!i.value)i.value='-'})">Bo'sh ochiqlarni "-" qilish</button>
  </div>
</form>
<div class="card">
  <h2>So'nggi kiritilganlar</h2>
  <ul class="plain-list">
  <?php foreach ($recent as $r): ?>
    <li><a href="<?= e(url('entry', ['id' => $test['id'], 'student' => $r['code']])) ?>"><span class="mono"><?= e($r['code']) ?></span> <?= e($r['full_name']) ?></a> <span class="tag"><?= e($r['source']) ?></span></li>
  <?php endforeach; ?>
  <?php if (!$recent): ?><li class="muted">Hali yo'q</li><?php endif; ?>
  </ul>
</div>
</div>
<script>
(function(){
  const str = document.getElementById('mcStr');
  const rows = [...document.querySelectorAll('#mcGrid .key-row')];
  function paint(){
    const s = str.value.toUpperCase();
    rows.forEach((r,i)=>r.querySelectorAll('.bub-btn').forEach(b=>b.classList.toggle('on', b.dataset.v===s[i])));
  }
  str.addEventListener('input', ()=>{ str.value = str.value.toUpperCase().replace(/[^A-F_]/g,''); paint(); });
  rows.forEach((r,i)=>r.addEventListener('click', ev=>{
    const b = ev.target.closest('.bub-btn'); if(!b) return;
    let s = str.value.toUpperCase().padEnd(rows.length,'_').split('');
    s[i] = s[i]===b.dataset.v ? '_' : b.dataset.v;
    str.value = s.join('').replace(/_+$/,''); paint();
  }));
  paint();
  const code = document.getElementById('code'), info = document.getElementById('studentInfo'), fn = document.getElementById('full_name');
  code.addEventListener('change', async ()=>{
    if(code.value.length!==6){info.textContent='';return;}
    const r = await fetch('index.php?p=api&a=student&code='+encodeURIComponent(code.value)+'&test=<?= (int)$test['id'] ?>').then(r=>r.json());
    if(r.student){ fn.value = r.student.full_name; info.innerHTML = 'Topildi: <b>'+r.student.full_name+'</b> ('+(r.student.group_name||'guruhsiz')+')' + (r.has_response?' — <span class="warn">bu test uchun javob allaqachon bor, saqlasangiz yangilanadi</span>':''); }
    else info.textContent = 'Bunday ID yo\'q — saqlaganda yangi o\'quvchi yaratiladi.';
  });
  code.addEventListener('keydown', e=>{ if(e.key==='Enter'){e.preventDefault(); code.dispatchEvent(new Event('change')); str.focus();} });
  str.addEventListener('keydown', e=>{ if(e.key==='Enter'){e.preventDefault(); const f=document.querySelector('.open-in'); if(f) f.focus();} });
  document.querySelectorAll('.open-in').forEach((inp,i,all)=>inp.addEventListener('keydown', e=>{ if(e.key==='Enter' && !e.ctrlKey){e.preventDefault(); (all[i+1]||inp).focus();} }));
  document.getElementById('entryForm').addEventListener('keydown', e=>{ if(e.key==='Enter' && e.ctrlKey) e.currentTarget.submit(); });
})();
</script>
<?php page_footer();
