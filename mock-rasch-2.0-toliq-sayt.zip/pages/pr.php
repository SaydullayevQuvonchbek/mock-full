<?php
defined('APP_ROOT') || exit;
// Qisqa havola (SMS uchun): ?p=pr&c=ID.MOCK.token
require __DIR__ . '/parent_result.php';
