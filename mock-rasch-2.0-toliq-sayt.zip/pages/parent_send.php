<?php
defined('APP_ROOT') || exit;
/** Ota-onalarga natijani yuborish (admin tugmasi bilan): oldindan ko'rish, yuborish, yetkazish hisoboti */
$test = get_test_or_404();
$tid = (int)$test['id'];
$mode = in_array($_GET['mode'] ?? $_POST['mode'] ?? '', ['auto', 'sms', 'tg'], true) ? ($_GET['mode'] ?? $_POST['mode']) : 'auto';
$both = !empty($_GET['both'] ?? $_POST['both'] ?? '');
if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    if ($act === 'send') {
        if (!$test['published']) flash('Avval natijalarni e\'lon qiling', 'err');
        elseif (!tg_ready() && !sms_ready()) flash('Telegram bot yoki Eskiz SMS ulanmagan (Sozlamalar)', 'err');
        else {
            $n = parent_queue($test, $mode, $both, !empty($_POST['resend']));
            if ($n['tg'] + $n['sms'] > 0) { tg_tick(20); flash('Ota-onalarga yuborish boshlandi: Telegram ' . $n['tg'] . ', SMS ' . $n['sms'] . '. Holat quyidagi hisobotda.'); }
            else flash('Yuboriladigan xabar yo\'q', 'warn');
        }
    }
    if ($act === 'run') { $r = tg_tick(25); flash('Navbat ishlandi: yuborildi ' . ($r['sent'] ?? 0) . ', xato ' . ($r['failed'] ?? 0)); }
    if ($act === 'retry') {
        $n = q('UPDATE tg_queue SET attempts=0, send_at=NOW(), error="" WHERE test_id=? AND kind IN ("p1","p2","ptg") AND sent_at IS NULL AND attempts>=3', [$tid])->rowCount();
        if ($n) tg_tick(20);
        flash($n . ' ta xabar qayta urinildi');
    }
    redirect('parent_send', ['id' => $tid, 'mode' => $mode] + ($both ? ['both' => 1] : []));
}
$plan = $test['published'] ? parent_plan($test, $mode, $both, false) : null;
$nSms = 0; $nTg = 0;
if ($plan) foreach ($plan['jobs'] as $j) { if ($j[0] === 'ptg') $nTg++; else $nSms++; }
$rep = parent_report($tid);
$cnt = ['ok' => 0, 'fail' => 0, 'wait' => 0];
foreach ($rep as $r) { if ($r['sent_at'] && $r['error'] === '') $cnt['ok']++; elseif ($r['sent_at'] === null && (int)$r['attempts'] >= 3) $cnt['fail']++; elseif ($r['sent_at'] === null) $cnt['wait']++; }
$bal = sms_ready() ? sms_balance() : null;
page_header('Ota-onalar — ' . $test['title']);
test_tabs($test, 'parent_send');
?>
<div class="card">
  <h2>Natijani ota-onalarga yuborish</h2>
  <?php if (!$test['published']): ?>
    <p class="small muted">Natijalar hali e'lon qilinmagan. Avval «Natijalar» bo'limida e'lon qiling — keyin ota-onalarga yuborish mumkin bo'ladi.</p>
  <?php else: ?>
    <form method="get" class="row gap wrap filter">
      <input type="hidden" name="p" value="parent_send"><input type="hidden" name="id" value="<?= $tid ?>">
      <label>Kanal
        <select name="mode" onchange="this.form.submit()">
          <option value="auto" <?= $mode === 'auto' ? 'selected' : '' ?>>Avtomatik: Telegram bo'lsa Telegram, bo'lmasa SMS</option>
          <option value="sms" <?= $mode === 'sms' ? 'selected' : '' ?>>Faqat SMS</option>
          <option value="tg" <?= $mode === 'tg' ? 'selected' : '' ?>>Faqat Telegram (bepul)</option>
        </select></label>
      <label class="check"><input type="checkbox" name="both" value="1" <?= $both ? 'checked' : '' ?> onchange="this.form.submit()"> SMS ikkala raqamga ham</label>
    </form>
    <div class="stats4 mt" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">
      <div class="stat"><span><?= (int)$plan['total'] ?></span>Natijasi bor o'quvchi</div>
      <div class="stat"><span><?= (int)$plan['done'] ?></span>Allaqachon yuborilgan</div>
      <div class="stat"><span><?= $nTg ?></span>Yuboriladi: Telegram</div>
      <div class="stat"><span><?= $nSms ?></span>Yuboriladi: SMS</div>
      <div class="stat"><span class="<?= $plan['none'] ? 'warn-txt' : '' ?>"><?= count($plan['none']) ?></span>Yetkazib bo'lmaydi</div>
    </div>
    <?php if ($nSms): ?><p class="small muted">SMS pullik: <?= $nSms ?> ta xabar Eskiz hisobidan yechiladi<?= $bal !== null ? ' (hozirgi balans: ' . e(number_format($bal, 0, '.', ' ')) . ' so\'m)' : '' ?>. SMS matni — Eskizda tasdiqlangan «Natija (ota-onaga)» shabloni.</p><?php endif; ?>
    <?php if ($plan['none']): ?>
      <details class="small mt"><summary>Yetkazib bo'lmaydiganlar (<?= count($plan['none']) ?>) — ota-ona raqami yo'q yoki rad etgan</summary>
        <div class="muted"><?= e(implode('; ', array_map(fn($n) => $n[1] . ' (' . $n[2] . ')', array_slice($plan['none'], 0, 80)))) ?><?= count($plan['none']) > 80 ? ' …' : '' ?></div></details>
    <?php endif; ?>
    <div class="row gap wrap mt">
      <form method="post" onsubmit="return confirm('<?= $nTg ?> ta Telegram va <?= $nSms ?> ta SMS yuborilsinmi? Bu amalni bekor qilib bo\'lmaydi.')">
        <?= csrf_field() ?><input type="hidden" name="action" value="send"><input type="hidden" name="mode" value="<?= e($mode) ?>"><?php if ($both): ?><input type="hidden" name="both" value="1"><?php endif; ?>
        <button class="btn primary" <?= $nTg + $nSms ? '' : 'disabled' ?>>Ota-onalarga yuborish (<?= $nTg + $nSms ?>)</button>
      </form>
      <form method="post" onsubmit="return confirm('Avval yuborilganlarga ham qayta yuboriladi (SMS qayta yechiladi). Davom etasizmi?')">
        <?= csrf_field() ?><input type="hidden" name="action" value="send"><input type="hidden" name="resend" value="1"><input type="hidden" name="mode" value="<?= e($mode) ?>"><?php if ($both): ?><input type="hidden" name="both" value="1"><?php endif; ?>
        <button class="btn ghost">Hammasiga qayta yuborish</button>
      </form>
    </div>
    <p class="small muted mt" style="margin-bottom:0">Ota-ona raqamlari «O'quvchilar» sahifasida yoki o'quvchining o'z profilida kiritiladi. Ota-ona o'quvchi profilidan olingan havola orqali Telegramga ulansa — natija bepul botga keladi. Rad etgan ota-onalarga (profildagi belgi) hech narsa yuborilmaydi.</p>
  <?php endif; ?>
</div>

<div class="card">
  <div class="row between center-v wrap gap">
    <h2 style="margin:0">Yetkazish hisoboti</h2>
    <div class="row gap wrap">
      <span class="tag green">Yuborilgan: <b><?= $cnt['ok'] ?></b></span>
      <span class="tag">Navbatda: <b><?= $cnt['wait'] ?></b></span>
      <span class="tag <?= $cnt['fail'] ? 'red' : '' ?>">Xato: <b><?= $cnt['fail'] ?></b></span>
      <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="run"><button class="btn sm">Navbatni ishga tushirish</button></form>
      <?php if ($cnt['fail']): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="retry"><button class="btn sm ghost">Xatolarni qayta urinish</button></form><?php endif; ?>
    </div>
  </div>
  <?php if (!$rep): ?><p class="small muted mt">Hali hech narsa yuborilmagan.</p><?php else: ?>
  <div class="table-wrap mt"><table class="tbl compact-tbl">
    <thead><tr><th>O'quvchi</th><th>Qabul qiluvchi</th><th>Kanal</th><th>Holat</th><th>Vaqt</th></tr></thead>
    <tbody>
    <?php foreach ($rep as $r): $ok = $r['sent_at'] && $r['error'] === ''; $skip = $r['sent_at'] && $r['error'] !== ''; $fail = !$r['sent_at'] && (int)$r['attempts'] >= 3; ?>
      <tr>
        <td><?= e($r['full_name']) ?> <span class="mono small muted"><?= e($r['code']) ?></span></td>
        <td class="small mono"><?= $r['kind'] === 'ptg' ? 'Telegram' : e(mask_phone($r['phone'])) ?></td>
        <td class="small"><?= $r['kind'] === 'ptg' ? 'Telegram' : 'SMS' ?></td>
        <td><?= $ok ? '<span class="tag green">yuborildi</span>' : ($skip ? '<span class="tag">o\'tkazildi</span> <span class="small muted">' . e($r['error']) . '</span>' : ($fail ? '<span class="tag red">xato</span> <span class="small">' . e($r['error']) . '</span>' : '<span class="tag">navbatda</span>' . ($r['error'] ? ' <span class="small muted">' . e($r['error']) . '</span>' : ''))) ?></td>
        <td class="small muted"><?= e(substr((string)($r['sent_at'] ?: $r['created_at']), 5, 11)) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</div>
<?php page_footer();
