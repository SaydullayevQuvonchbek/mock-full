<?php
defined('APP_ROOT') || exit;
unset($_SESSION['student']);
redirect('home');
