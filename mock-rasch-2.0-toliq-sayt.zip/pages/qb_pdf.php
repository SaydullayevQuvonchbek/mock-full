<?php
defined('APP_ROOT') || exit;
/** Admin: bo'lim (ichki bo'limlari bilan) savollarini PDF qilib berish; key=1 — oxirida javoblar kaliti */
$sid = (int)($_GET['s'] ?? 0);
$sec = $sid ? row('SELECT * FROM qb_sections WHERE id=?', [$sid]) : null;
if (!$sec) { flash('Bo\'lim topilmadi', 'err'); redirect('qb'); }
$ids = qb_descendants([$sid]);
// bo'limlar daraxti tartibida, har bo'limda — o'z tartibida
$order = array_flip(array_map(fn($t) => (int)$t['id'], qb_tree()));
$in = implode(',', array_fill(0, count($ids), '?'));
$qs = rows("SELECT id, section_id, img, kind, nopt, answer, label, sort FROM qb_questions WHERE section_id IN ($in)", $ids);
usort($qs, function ($a, $b) use ($order) {
    return [$order[(int)$a['section_id']] ?? 0, (int)$a['sort'], (int)$a['id']] <=> [$order[(int)$b['section_id']] ?? 0, (int)$b['sort'], (int)$b['id']];
});
$withKey = !empty($_GET['key']);
if (!$qs) { flash('Bu bo\'limda savol yo\'q', 'err'); redirect('qb_questions', ['s' => $sid]); }
if (count($qs) > 150) { flash('Bo\'limda ' . count($qs) . ' ta savol — PDF uchun juda ko\'p (150 tagacha). Ichki bo\'limlar bo\'yicha alohida oling.', 'err'); redirect('qb_questions', ['s' => $sid]); }
@ini_set('memory_limit', '256M'); @set_time_limit(120);
$pdf = qb_pdf(qb_section_path($sid), (app_setting('center') ?: 'MOCK') . ' · ' . count($qs) . ' ta savol · ' . date('d.m.Y'), $qs, $withKey);
if ($pdf === null) { flash('PDF yaratish uchun serverda PHP GD kengaytmasi kerak', 'err'); redirect('qb_questions', ['s' => $sid]); }
session_write_close();
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="savollar-' . $sid . ($withKey ? '-kalit' : '') . '.pdf"');
header('Content-Length: ' . strlen($pdf));
header('Cache-Control: private, no-store');
echo $pdf;
exit;
