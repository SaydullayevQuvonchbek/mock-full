<?php
defined('APP_ROOT') || exit;
/**
 * Parol belgilash / almashtirish.
 * - Vaqtinchalik parol bilan kirgan (must_change) o'quvchi: eski parol so'ralmaydi, almashtirmaguncha boshqa sahifaga o'tolmaydi.
 * - Kabinetdan: joriy parol so'raladi.
 */
$me = student();
$s = row('SELECT * FROM students WHERE id=?', [$me['id']]);
$forced = !empty($me['mc']);
$err = '';
if (is_post()) {
    csrf_check();
    $new = (string)($_POST['new'] ?? '');
    $new2 = (string)($_POST['new2'] ?? '');
    $wait = throttle_wait('student', 'chg' . $s['code'], 5, 30, 15);
    if ($wait) $err = "Juda ko'p noto'g'ri urinish. $wait daqiqadan keyin urinib ko'ring.";
    elseif (!$forced && !student_pass_check($s, (string)($_POST['old'] ?? ''))) { throttle_fail('student', 'chg' . $s['code']); $err = 'Joriy parol noto\'g\'ri.'; }
    elseif ($p = pass_problem($new, (string)$s['code'])) $err = $p;
    elseif ($new !== $new2) $err = 'Yangi parollar mos emas.';
    elseif ($forced && $s['pin'] !== '' && hash_equals((string)$s['pin'], $new)) $err = 'Yangi parol vaqtinchalik paroldan farq qilsin.';
    else {
        student_set_pass((int)$s['id'], $new, false);
        $ver = (string)val('SELECT pass_changed_at FROM students WHERE id=?', [$s['id']]);
        $_SESSION['student']['mc'] = 0;
        $_SESSION['student']['ver'] = $ver;
        flash('Parol saqlandi');
        $ap = $_SESSION['after_pass'] ?? null; unset($_SESSION['after_pass']);
        if (is_array($ap) && ($ap['p'] ?? '') === 'moc') redirect('moc', !empty($ap['test']) ? ['test' => (int)$ap['test']] : []);
        redirect('student_home');
    }
}
page_header($forced ? 'Yangi parol belgilang' : 'Parolni o\'zgartirish', ['main' => 'narrow-main']);
?>
<div class="card narrow">
  <h1><?= $forced ? 'Yangi parol belgilang' : 'Parolni o\'zgartirish' ?></h1>
  <?php if ($forced): ?><p class="muted">Siz o'quv markazi bergan vaqtinchalik parol bilan kirdingiz. Davom etish uchun o'zingiz eslab qoladigan parol belgilang (kamida 6 belgi).</p><?php endif; ?>
  <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
  <form method="post" class="form" autocomplete="off">
    <?= csrf_field() ?>
    <?php if (!$forced): ?><label>Joriy parol <input type="password" name="old" required autocomplete="current-password"></label><?php endif; ?>
    <label>Yangi parol <input type="password" name="new" required minlength="6" maxlength="64" autocomplete="new-password" autofocus></label>
    <label>Yangi parol (takror) <input type="password" name="new2" required minlength="6" maxlength="64" autocomplete="new-password"></label>
    <button class="btn primary wide">Saqlash</button>
  </form>
  <?php if ($forced): ?><p class="small muted mt"><a href="<?= e(url('student_logout')) ?>">Chiqish</a></p><?php else: ?><p class="small mt"><a href="<?= e(url('student_home')) ?>">← Orqaga</a></p><?php endif; ?>
</div>
<?php page_footer();
