<?php
defined('APP_ROOT') || exit;
/**
 * Eshik ro'yxatlari (chop etish uchun):
 *  mode=room (standart) — har xona uchun alohida katta shriftli varaq: o'rin → F.I.Sh (xona eshigiga yopishtiriladi);
 *  mode=all — butun MOCK uchun alifbo tartibidagi umumiy ro'yxat: F.I.Sh → xona · o'rin (kirish joyiga osiladi).
 */
$test = get_test_or_404();
$tid = (int)$test['id'];
$mode = ($_GET['mode'] ?? '') === 'all' ? 'all' : 'room';
$rooms = test_rooms($tid);
$only = (int)($_GET['room'] ?? 0);
$all = reg_students($tid, ['order' => 'room']);
$date = $test['test_date'] ? date('d.m.Y', strtotime($test['test_date'])) : '';
page_header('Eshik ro\'yxati', ['bare' => true, 'body' => 'print-page roomlist-page']);
?>
<div class="no-print toolbar">
  <button class="btn primary" onclick="print()"><?= icon('print', 16) ?>Chop etish</button>
  <a class="btn <?= $mode === 'room' ? '' : 'ghost' ?>" href="<?= e(url('room_door', ['id' => $tid])) ?>">Xonalar bo'yicha</a>
  <a class="btn <?= $mode === 'all' ? '' : 'ghost' ?>" href="<?= e(url('room_door', ['id' => $tid, 'mode' => 'all'])) ?>">Umumiy ro'yxat (alifbo)</a>
  <a class="small" href="<?= e(url('registrations', ['id' => $tid])) ?>">← Ro'yxatga qaytish</a>
</div>
<?php if (!$rooms): ?><div class="card narrow empty">Xonalar kiritilmagan.</div>
<?php elseif ($mode === 'all'):
    $placed = array_values(array_filter($all, fn($s) => $s['room_id'] && $s['seat']));
    usort($placed, fn($a, $b) => strcasecmp((string)$a['full_name'], (string)$b['full_name']));
    $chunks = array_chunk($placed, 60);
    if (!$chunks) echo '<div class="card narrow empty">Hali hech kim xonaga joylashtirilmagan.</div>';
    foreach ($chunks as $ci => $chunk): ?>
<section class="door-sheet">
  <header><div><small><?= e(app_setting('center')) ?> · <?= e($test['title']) ?><?= $date ? ' · ' . e($date) : '' ?></small><h1>Xona va o'rinlar</h1></div><div class="room-count"><?= count($chunks) > 1 ? ($ci + 1) . ' / ' . count($chunks) : '' ?></div></header>
  <table class="door-all"><thead><tr><th>F.I.Sh</th><th>Xona</th><th class="num">O'rin</th></tr></thead><tbody>
    <?php foreach ($chunk as $s): ?><tr><td><?= e($s['full_name']) ?></td><td><b><?= e($s['room_name']) ?></b></td><td class="num"><b><?= (int)$s['seat'] ?></b></td></tr><?php endforeach; ?>
  </tbody></table>
</section>
<?php endforeach; ?>
<?php else:
    $by = [];
    foreach ($all as $s) if ($s['room_id'] && $s['seat']) $by[(int)$s['room_id']][] = $s;
    $any = false;
    foreach ($rooms as $r): if ($only && (int)$r['id'] !== $only) continue; $list = $by[(int)$r['id']] ?? []; $any = true; ?>
<section class="door-sheet">
  <header>
    <div><small><?= e(app_setting('center')) ?> · <?= e($test['title']) ?><?= $date ? ' · ' . e($date) : '' ?></small><h1 class="door-title"><?= e($r['name']) ?></h1>
      <?php if ($r['proctor'] !== ''): ?><div class="door-proctor">Nazoratchi: <b><?= e($r['proctor']) ?></b></div><?php endif; ?></div>
    <div class="room-count"><b><?= count($list) ?></b> kishi</div>
  </header>
  <?php if (!$list): ?><p class="empty">Bu xonaga hech kim joylashtirilmagan.</p>
  <?php else: ?>
  <ol class="door-seats <?= count($list) > 22 ? 'two' : '' ?>">
    <?php foreach ($list as $s): ?><li><span class="no"><?= (int)$s['seat'] ?></span><span class="nm"><?= e($s['full_name']) ?></span><span class="id"><?= e($s['code']) ?></span></li><?php endforeach; ?>
  </ol>
  <?php endif; ?>
</section>
<?php endforeach; if (!$any): ?><div class="card narrow empty">Xona topilmadi.</div><?php endif; ?>
<?php endif; ?>
<?php page_footer();
