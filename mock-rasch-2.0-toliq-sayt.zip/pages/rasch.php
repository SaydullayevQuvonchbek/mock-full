<?php
defined('APP_ROOT') || exit;
page_header('Rasch modeli qanday ishlaydi');
?>
<article class="doc">
<div class="eyebrow">Qo'llanma</div>
<h1>Rasch modeli qanday ishlaydi</h1>
<p class="lead">Milliy sertifikat imtihonlari natijalari Rasch modeli asosida hisoblanadi. Bu sahifada model g'oyasi, formulalari va platformada ballar qanday chiqishi oddiy tilda, interaktiv misollar bilan tushuntirilgan.</p>

<nav class="toc">
  <a href="#g1">1. Oddiy hisob va Rasch farqi</a>
  <a href="#g2">2. Asosiy formula</a>
  <a href="#g3">3. Qiyinlik qanday topiladi</a>
  <a href="#g4">4. Interaktiv tajriba</a>
  <a href="#g5">5. Qadam-baqadam misol</a>
  <a href="#g55">6. Ball, daraja va foiz</a>
  <a href="#g6">7. Savollar sifatini tekshirish</a>
  <a href="#g7">8. Amaliy maslahatlar</a>
</nav>

<section id="g1">
<h2>1. Oddiy hisob va Rasch farqi</h2>
<p>Oddiy (klassik) usulda natija — to'g'ri javoblar soni yoki har bir savolga oldindan qo'yilgan ballar yig'indisi. Muammo shundaki, <b>bu natija test qanchalik qiyin bo'lganiga bog'liq</b>: oson variantda 40 ta to'g'ri javob va qiyin variantda 40 ta to'g'ri javob bir xil bilimni anglatmaydi.</p>
<p>Rasch modeli o'quvchining <b>qobiliyati</b> (θ, "teta") va savolning <b>qiyinligi</b> (b) ni bitta umumiy shkalada — <b>logit</b>da o'lchaydi. Savol qiyinligi oldindan belgilanmaydi: u barcha ishtirokchilar javoblaridan hisoblanadi. Kam odam yechgan savol — qiyin, ko'pchilik yechgan savol — oson.</p>
</section>

<section id="g2">
<h2>2. Asosiy formula</h2>
<p>θ qobiliyatli o'quvchining b qiyinlikdagi savolni to'g'ri yechish ehtimoli:</p>
<div class="formula">P(to'g'ri) = e<sup>θ − b</sup> / (1 + e<sup>θ − b</sup>)</div>
<p>Faqat <b>farq</b> (θ − b) muhim:</p>
<div class="table-wrap"><table class="tbl compact-tbl narrow-tbl">
  <thead><tr><th class="num">θ − b</th><th class="num">−3</th><th class="num">−2</th><th class="num">−1</th><th class="num">0</th><th class="num">+1</th><th class="num">+2</th><th class="num">+3</th></tr></thead>
  <tbody><tr><td>Ehtimol</td><td class="num">5%</td><td class="num">12%</td><td class="num">27%</td><td class="num"><b>50%</b></td><td class="num">73%</td><td class="num">88%</td><td class="num">95%</td></tr></tbody>
</table></div>
<p>O'quvchi qobiliyati savol qiyinligiga teng bo'lsa (θ = b), uni yechish ehtimoli aynan 50%.</p>

<div class="card icc-demo">
  <div class="icc-controls">
    <label>O'quvchi qobiliyati θ = <b id="thV">0.0</b><input type="range" id="th" min="-4" max="4" step="0.1" value="0"></label>
    <label>Savol qiyinligi b = <b id="bV">1.0</b><input type="range" id="bb" min="-4" max="4" step="0.1" value="1"></label>
    <div class="icc-p">To'g'ri yechish ehtimoli: <b id="pV">27%</b></div>
  </div>
  <svg viewBox="0 0 520 260" class="chart" id="icc">
    <g id="iccGrid"></g>
    <path id="iccCurve" class="curve-main"/>
    <line id="iccV" class="guide"/><line id="iccH" class="guide"/>
    <circle id="iccDot" r="6" class="dot"/>
  </svg>
  <p class="small muted">Egri chiziq — <b>savolning xarakteristik egri chizig'i</b> (ICC). Qiyinlik b ni o'zgartirsangiz, egri chiziq o'ngga yoki chapga suriladi; shakli esa barcha savollar uchun bir xil — bu Rasch modelining asosiy talabi.</p>
</div>
</section>

<section id="g3">
<h2>3. Qiyinlik va qobiliyat qanday hisoblanadi</h2>
<p>Platforma <b>JMLE</b> (Joint Maximum Likelihood Estimation) usulidan foydalanadi. Soddalashtirib aytganda:</p>
<ol>
  <li><b>Boshlang'ich taxmin.</b> Har bir savol uchun b ≈ ln(xato qilganlar / yechganlar), har bir o'quvchi uchun θ ≈ ln(to'g'ri / xato).</li>
  <li><b>O'quvchilarni tuzatish.</b> Joriy b lar bo'yicha har bir o'quvchi uchun "kutilgan" to'g'ri javoblar soni hisoblanadi (Σ P). Haqiqiy soni ko'proq bo'lsa θ oshiriladi, kamroq bo'lsa kamaytiriladi.</li>
  <li><b>Savollarni tuzatish.</b> Xuddi shunday: savolni kutilganidan kam odam yechgan bo'lsa, u qiyinroq (b oshadi).</li>
  <li>Savollar qiyinligining o'rtachasi 0 ga tenglanadi va 2–3-qadamlar o'zgarish 0.00001 dan kichik bo'lguncha takrorlanadi.</li>
  <li>Hamma yechgan yoki hech kim yechmagan savollar, hamma savolni yechgan yoki birortasini ham yechmagan o'quvchilar alohida (0.3 tuzatish bilan) baholanadi.</li>
</ol>
<div class="callout">
  <b>Muhim xususiyat.</b> Sof Rasch modelida <b>to'g'ri javoblar soni θ uchun yetarli statistika</b>: bir testda bir xil sondagi to'g'ri javob bir xil θ beradi — qaysi savollar yechilganidan qat'i nazar. Qiyin savollarning "qadri" boshqacha namoyon bo'ladi: qiyin testdagi 40 ta to'g'ri javob oson testdagi 40 tadan yuqori θ ga teng. Pastdagi tajribada buni o'zingiz tekshiring.
</div>
</section>

<section id="g4">
<h2>4. Interaktiv tajriba: 10 ta savolli mini-test</h2>
<p>Savollar oson (chapda) dan qiyinga (o'ngda) tartiblangan. Qaysi savollarni "yechganingizni" belgilang — θ darhol qayta hisoblanadi. Masalan, 1–5 savollarni, keyin 6–10 savollarni belgilab ko'ring: to'g'ri javoblar soni bir xil (5), θ ham bir xil, lekin <b>moslik (outfit)</b> keskin o'zgaradi — ikkinchi holat "g'alati" javoblar naqshi (taxmin yoki ko'chirish belgisi).</p>
<div class="card sim">
  <div id="simItems" class="sim-items"></div>
  <div class="sim-out">
    <div>To'g'ri: <b id="simR">0</b> / 10</div>
    <div>θ = <b id="simT">—</b> logit</div>
    <div>Moslik (outfit): <b id="simF">—</b></div>
  </div>
  <p class="small muted" id="simNote"></p>
</div>
</section>

<?php
// ---- Qadam-baqadam misol: platformaning o'z Rasch dvigateli bilan hisoblanadi ----
$exNames = ['Aziz', 'Malika', 'Jasur', 'Nodira', 'Sardor', 'Madina', 'Bekzod', 'Zarina'];
$exX = [
    [1, 1, 1, 1, 1, 0], [1, 1, 1, 1, 0, 1], [1, 1, 1, 1, 0, 0], [1, 1, 0, 1, 0, 1],
    [1, 1, 1, 0, 0, 0], [1, 0, 1, 0, 0, 0], [1, 1, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0],
];
$exR = rasch_estimate($exX);
$exMean = stats_mean($exR['theta']); $exSd = stats_sd($exR['theta']);
$exBall = fn($t) => 50 + 10 * ($t - $exMean) / $exSd;
$nS = count($exX); $nQ = count($exX[0]);
?>
<section id="g5">
<h2>5. Qadam-baqadam misol: 8 o'quvchi, 6 savol</h2>
<p>Quyidagi hisoblarni platformaning o'zi — natijalaringizni hisoblaydigan xuddi shu dastur — hozir bajardi. Milliy imtihonda o'quvchilar o'n minglab va savollar 55 ta, lekin qadamlar aynan shunday.</p>

<h3>1-qadam. Javoblar jadvali</h3>
<div class="table-wrap"><table class="tbl compact-tbl narrow-tbl ex-tbl">
  <thead><tr><th>O'quvchi</th><?php for ($i = 1; $i <= $nQ; $i++): ?><th class="num"><?= $i ?>-savol</th><?php endfor; ?><th class="num">To'g'ri</th></tr></thead>
  <tbody>
  <?php foreach ($exX as $n => $row): ?>
    <tr><td><b><?= e($exNames[$n]) ?></b></td><?php foreach ($row as $x): ?><td class="num"><?= $x ? '<span class="ok-mark">✓</span>' : '<span class="no-mark">✗</span>' ?></td><?php endforeach; ?><td class="num"><b><?= array_sum($row) ?></b> / <?= $nQ ?></td></tr>
  <?php endforeach; ?>
  <tr class="ex-sum"><td>Yechganlar</td><?php for ($i = 0; $i < $nQ; $i++): $c = array_sum(array_column($exX, $i)); ?><td class="num"><?= $c ?> / <?= $nS ?></td><?php endfor; ?><td></td></tr>
  </tbody>
</table></div>

<h3>2-qadam. Har bir savolning qiyinligi (b)</h3>
<p>Kam odam yechgan savol — qiyin. Rasch buni logitda ifodalaydi: 0 — o'rtacha, manfiy — oson, musbat — qiyin.</p>
<div class="table-wrap"><table class="tbl compact-tbl narrow-tbl">
  <thead><tr><th>Savol</th><?php for ($i = 1; $i <= $nQ; $i++): ?><th class="num"><?= $i ?></th><?php endfor; ?></tr></thead>
  <tbody>
    <tr><td>Yechganlar ulushi</td><?php for ($i = 0; $i < $nQ; $i++): ?><td class="num"><?= round(array_sum(array_column($exX, $i)) / $nS * 100) ?>%</td><?php endfor; ?></tr>
    <tr><td>Qiyinlik b</td><?php foreach ($exR['b'] as $b): [$dl, $dc] = difficulty_label((float)$b); ?><td class="num"><span class="dtag <?= $dc ?>"><?= fmt($b, 2) ?></span></td><?php endforeach; ?></tr>
  </tbody>
</table></div>

<h3>3-qadam. Har bir o'quvchining qobiliyati (θ)</h3>
<p>θ shunday tanlanadiki, o'quvchining barcha savollar bo'yicha kutilgan to'g'ri javoblari yig'indisi uning haqiqiy natijasiga teng bo'lsin: <span class="formula-inline">Σ P(θ, b<sub>i</sub>) = to'g'ri javoblar soni</span>.</p>

<h3>4-qadam. θ dan ballga</h3>
<p>Guruh bo'yicha: o'rtacha θ̄ = <b><?= fmt($exMean, 2) ?></b>, standart chetlanish σ = <b><?= fmt($exSd, 2) ?></b>. Har bir o'quvchi uchun <span class="formula-inline">Z = (θ − θ̄) / σ</span>, <span class="formula-inline">Ball = 50 + 10·Z</span>.</p>
<div class="table-wrap"><table class="tbl compact-tbl narrow-tbl">
  <thead><tr><th>O'quvchi</th><th class="num">To'g'ri</th><th class="num">θ</th><th class="num">Z</th><th class="num">Ball</th><th>Daraja</th><th class="num">Foiz (÷65)</th></tr></thead>
  <tbody>
  <?php foreach ($exX as $n => $row): $t = $exR['theta'][$n]; $bl = $exBall($t); ?>
    <tr><td><b><?= e($exNames[$n]) ?></b></td><td class="num"><?= array_sum($row) ?> / <?= $nQ ?></td><td class="num"><?= fmt($t, 2) ?></td><td class="num"><?= fmt(($t - $exMean) / $exSd, 2) ?></td>
      <td class="num"><b><?= fmt($bl) ?></b></td><td><?= grade_badge(grade_for(round($bl, 1))) ?></td><td class="num"><?= fmt(min(100, $bl / 65 * 100), 0) ?>%</td></tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<div class="callout">
  <b>Nimaga e'tibor bering:</b>
  <ul style="margin:.4rem 0 0">
    <li><b>Jasur va Nodira</b> — ikkalasi 4/6, lekin turli savollarni yechgan. θ va ball bir xil: Rasch'da to'g'ri javoblar <i>soni</i> hal qiladi.</li>
    <li><b>50 ball — o'rtacha natija</b>, minimal emas. O'rtachadan yuqori o'quvchi 50 dan ko'p, pastrog'i kam oladi. Sertifikat uchun minimal — <b>46 ball (C)</b>.</li>
    <li>Kichik guruhda (8 kishi) ballar keskin tarqaladi. Milliy imtihonda o'n minglab ishtirokchi bo'lgani uchun o'rtacha va σ barqaror.</li>
  </ul>
</div>
</section>

<section id="g55">
<h2>6. Ball, daraja va foiz — sertifikatda nima yoziladi</h2>
<p>Rasmiy sertifikatda uchta ko'rsatkich bor: <b>umumiy to'plagan ball</b>, <b>daraja</b> va <b>umumiy ballga nisbatan foiz ko'rsatkichi</b>.</p>
<div class="table-wrap"><table class="tbl compact-tbl narrow-tbl">
  <thead><tr><th>Daraja</th><th>Ball</th><th>Foiz ko'rsatkichi</th></tr></thead>
  <tbody>
    <tr><td><?= grade_badge('A+') ?></td><td>70 va undan yuqori (chegara yo'q)</td><td>100%</td></tr>
    <tr><td><?= grade_badge('A') ?></td><td>65 – 69.9</td><td>100%</td></tr>
    <tr><td><?= grade_badge('B+') ?></td><td>60 – 64.9</td><td>92 – 99.8%</td></tr>
    <tr><td><?= grade_badge('B') ?></td><td>55 – 59.9</td><td>85 – 92%</td></tr>
    <tr><td><?= grade_badge('C+') ?></td><td>50 – 54.9</td><td>77 – 84%</td></tr>
    <tr><td><?= grade_badge('C') ?></td><td>46 – 49.9</td><td>71 – 77%</td></tr>
    <tr><td><?= grade_badge('NB') ?></td><td>46 dan past</td><td>sertifikat berilmaydi</td></tr>
  </tbody>
</table></div>
<p><b>Foiz ko'rsatkichi</b> = ball ÷ 65 × 100, lekin 100% dan oshmaydi. Chunki 65 ball (A) OTMga kirishda fandan maksimal ball beradi. Masalan, 64.9 ball → 99.85% → 93 ballik fanda 92.85 ball. 65.48 yoki 87.1 ball → 100%.</p>
<h3>Nega ball 75 dan oshadi (masalan 87.1)?</h3>
<p>2024-yilda "maksimal natija 75 ball" deb e'lon qilingan, ammo haqiqiy sertifikatlarda 75 dan yuqori ballar uchraydi — 87.1 kabi. <span class="formula-inline">50 + 10·Z</span> formulasining yuqori chegarasi yo'q:</p>
<div class="table-wrap"><table class="tbl compact-tbl narrow-tbl">
  <thead><tr><th class="num">Z</th><th class="num">Ball</th><th class="num">Shundan yuqori natija (normal taqsimot)</th></tr></thead>
  <tbody>
    <tr><td class="num">1.5</td><td class="num">65</td><td class="num">≈ 6.7% — har 15 kishidan biri</td></tr>
    <tr><td class="num">2.0</td><td class="num">70</td><td class="num">≈ 2.3%</td></tr>
    <tr><td class="num">2.5</td><td class="num">75</td><td class="num">≈ 0.6%</td></tr>
    <tr><td class="num">3.0</td><td class="num">80</td><td class="num">≈ 0.13%</td></tr>
    <tr><td class="num">3.7</td><td class="num">87</td><td class="num">≈ 0.01% — 10 000 kishidan bittasi</td></tr>
  </tbody>
</table></div>
<p>Ya'ni 87.1 — o'rtachadan 3,7 standart chetlanish yuqori, eng kuchli ishtirokchilar qatoridagi natija. Foiz ko'rsatkichi baribir 100%.</p>
<p>Bilim va malakalarni baholash agentligi θ ni ballga o'tkazish formulasini to'liq e'lon qilmagan — yuqoridagi 50 + 10·Z eng ko'p ishlatiladigan standart usul va rasmiy natijalar bilan mos keladi, lekin rasmiy hisob bilan 100% bir xil deb kafolatlab bo'lmaydi. Platformada yana ikki usul bor:</p>
<dl class="gloss">
  <dt>Chiziqli θ shkala</dt>
  <dd><span class="formula-inline">Ball = 75 · (θ − θ<sub>min</sub>) / (θ<sub>max</sub> − θ<sub>min</sub>)</span> — guruhga emas, faqat savollar qiyinligiga bog'liq. Kichik guruhlar uchun barqarorroq.</dd>
  <dt>Qiyinlikka qarab vaznli ball</dt>
  <dd>Har bir savol vazni <span class="formula-inline">w = 1 + (b − b<sub>min</sub>)</span>, ball = 75 · Σw(yechilgan) / Σw(hammasi). Qiyin savol ko'proq ball beradi; bir xil sondagi to'g'ri javobda turli ball chiqishi mumkin.</dd>
</dl>
<p>"Ballni 75 bilan cheklash" sozlamasi ixtiyoriy va standart holatda o'chiq — rasmiy sertifikatlardagi kabi ball 75 dan oshishi mumkin.</p>
</section>

<section id="g6">
<h2>7. Savollar sifatini tekshirish</h2>
<p>Rasch tahlili faqat ball hisoblamaydi — u savollarni ham "tekshiradi". "Rasch tahlili" sahifasida:</p>
<ul>
  <li><b>Wright xaritasi</b> — o'quvchilar va savollar bitta shkalada. Yaxshi testda savollar o'quvchilar joylashgan oraliqni to'liq qoplaydi; hamma savol pastda bo'lsa — test juda oson.</li>
  <li><b>Infit / Outfit (MNSQ)</b> — javoblar modelga mosligi. 0.7–1.3 — yaxshi. 1.3 dan katta — savol noaniq, ikki xil tushunilishi mumkin yoki "tuzoq" bor.</li>
  <li><b>Nuqtali-biserial korrelyatsiya (r<sub>pb</sub>)</b> — savol kuchli va kuchsiz o'quvchilarni ajrata oladimi. Manfiy qiymat ko'pincha <b>kalit xatosi</b> belgisi.</li>
  <li><b>Distraktorlar tahlili</b> — noto'g'ri variantlardan biri to'g'ri javobdan ko'p tanlangan bo'lsa, kalitni tekshiring.</li>
  <li><b>O'quvchi mosligi</b> — natijalar jadvalidagi outfit 2 dan katta bo'lsa, o'quvchi oson savollarda xato qilib, qiyinlarini yechgan: taxmin qilish, ko'chirish yoki e'tiborsizlik ehtimoli.</li>
</ul>
</section>

<section id="g7">
<h2>8. Amaliy maslahatlar</h2>
<ul>
  <li><b>Ishtirokchilar soni:</b> kamida 30, yaxshisi 100+. Kam ishtirokchida savollar qiyinligi xatosi (SE) katta bo'ladi.</li>
  <li><b>Savollar qiyinligi xilma-xil bo'lsin:</b> taxminan −3 … +3 logit oralig'ida, shunda har bir darajadagi o'quvchi aniq o'lchanadi.</li>
  <li><b>Kalitni tekshiring:</b> natijalarni e'lon qilishdan oldin "Rasch tahlili"dagi qizil belgili savollarni ko'rib chiqing, kalitni tuzating — hammasi avtomatik qayta hisoblanadi.</li>
  <li><b>Ochiq javoblar:</b> onlayn va Excel orqali kelgan matnli javoblarni "Ochiq javoblar" sahifasida guruhlab ko'ring va to'g'ri shakllarni qabul qiling.</li>
  <li>Bu MOCK — mashq imtihoni. Platforma natijasi rasmiy milliy sertifikat balli emas, balki unga yaqin baho va o'quvchi uchun tahlil.</li>
</ul>
</section>
</article>
<script>
(function(){
  // ICC grafigi
  const W=520,H=260,pl=40,pr=10,pt=10,pb=30, X=v=>pl+(v+4)/8*(W-pl-pr), Y=p=>pt+(1-p)*(H-pt-pb);
  const P=(t,b)=>1/(1+Math.exp(-(t-b)));
  let g='';
  for(let v=-4;v<=4;v++){g+=`<line class="grid" x1="${X(v)}" x2="${X(v)}" y1="${pt}" y2="${H-pb}"/><text class="tick" x="${X(v)}" y="${H-pb+16}" text-anchor="middle">${v}</text>`;}
  [0,0.25,0.5,0.75,1].forEach(p=>{g+=`<line class="grid" x1="${pl}" x2="${W-pr}" y1="${Y(p)}" y2="${Y(p)}"/><text class="tick" x="${pl-6}" y="${Y(p)+4}" text-anchor="end">${p*100}%</text>`;});
  g+=`<text class="axis-title" x="${W-pr}" y="${H-2}" text-anchor="end">θ (logit)</text>`;
  document.getElementById('iccGrid').innerHTML=g;
  const th=document.getElementById('th'), bb=document.getElementById('bb');
  function draw(){
    const t=+th.value,b=+bb.value; let d='';
    for(let v=-4;v<=4.001;v+=0.05) d+=(d?'L':'M')+X(v).toFixed(1)+','+Y(P(v,b)).toFixed(1);
    document.getElementById('iccCurve').setAttribute('d',d);
    const p=P(t,b), dot=document.getElementById('iccDot');
    dot.setAttribute('cx',X(t)); dot.setAttribute('cy',Y(p));
    const v=document.getElementById('iccV'); v.setAttribute('x1',X(t)); v.setAttribute('x2',X(t)); v.setAttribute('y1',Y(p)); v.setAttribute('y2',H-pb);
    const h=document.getElementById('iccH'); h.setAttribute('x1',pl); h.setAttribute('x2',X(t)); h.setAttribute('y1',Y(p)); h.setAttribute('y2',Y(p));
    document.getElementById('thV').textContent=t.toFixed(1); document.getElementById('bV').textContent=b.toFixed(1);
    document.getElementById('pV').textContent=Math.round(p*100)+'%';
  }
  th.oninput=bb.oninput=draw; draw();

  // Mini-test simulyatori
  const bs=[-2.5,-2,-1.4,-0.8,-0.3,0.3,0.8,1.4,2,2.5];
  const st=bs.map(()=>false);
  const box=document.getElementById('simItems');
  box.innerHTML=bs.map((b,i)=>`<button type="button" class="sim-item" data-i="${i}"><b>${i+1}</b><small>b=${b}</small><span class="pp"></span></button>`).join('');
  function thetaFor(r){
    const L=bs.length; if(r<=0) r=0.3; if(r>=L) r=L-0.3;
    let t=Math.log(r/(L-r));
    for(let k=0;k<60;k++){let E=0,V=0;bs.forEach(b=>{const p=P(t,b);E+=p;V+=p*(1-p);});const s=Math.max(-1,Math.min(1,(r-E)/V));t+=s;if(Math.abs(s)<1e-7)break;}
    return t;
  }
  function upd(){
    const r=st.filter(Boolean).length, t=thetaFor(r);
    let z2=0; bs.forEach((b,i)=>{const p=P(t,b),x=st[i]?1:0;z2+=(x-p)**2/(p*(1-p));});
    const of=z2/bs.length;
    document.getElementById('simR').textContent=r;
    document.getElementById('simT').textContent=t.toFixed(2);
    const f=document.getElementById('simF'); f.textContent=of.toFixed(2); f.className=of>2?'warn':(of>1.3?'amber-t':'');
    box.querySelectorAll('.sim-item').forEach((el,i)=>{el.classList.toggle('on',st[i]); el.querySelector('.pp').textContent=Math.round(P(t,bs[i])*100)+'%';});
    document.getElementById('simNote').textContent = (r===0||r===10) ? 'Ekstremal natija (0 yoki hammasi to\'g\'ri): θ 0.3 tuzatish bilan baholanadi.' :
      (of>2 ? 'Javoblar naqshi modeldan juda uzoq: oson savollar xato, qiyinlari to\'g\'ri. Real testda bunday o\'quvchi "shubhali" deb belgilanadi.' :
      'Har bir savol ostidagi foiz — shu θ dagi o\'quvchining uni yechish ehtimoli.');
  }
  box.addEventListener('click',e=>{const b=e.target.closest('.sim-item'); if(!b) return; st[+b.dataset.i]=!st[+b.dataset.i]; upd();});
  upd();
})();
</script>
<?php page_footer();
