<?php
defined('APP_ROOT') || exit;
require_once APP_ROOT . '/inc/sheet_layout.php';
$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    $tests = rows('SELECT id, title, test_date FROM tests ORDER BY id DESC');
    page_header('Skaner');
    ?>
    <h1>Varaqalarni skanerlash</h1>
    <p class="muted">Qaysi test varaqalarini skanerlaysiz?</p>
    <div class="grid3">
    <?php foreach ($tests as $t): ?>
      <a class="card link-card" href="<?= e(url('scan', ['id' => $t['id']])) ?>"><h3><?= e($t['title']) ?></h3><p class="muted"><?= e($t['test_date']) ?></p></a>
    <?php endforeach; ?>
    <?php if (!$tests): ?><div class="card empty">Avval test yarating.</div><?php endif; ?>
    </div>
    <?php
    page_footer();
    return;
}
$test = get_test_or_404();
$L = sheet_layout($test);
$items = test_items($test);
$mcLabels = array_values(array_map(fn($i) => $i['label'], array_filter($items, fn($i) => $i['type'] === 'mc')));
$openLabels = array_values(array_map(fn($i) => $i['label'], array_filter($items, fn($i) => $i['type'] === 'open')));
page_header('Skaner — ' . $test['title']);
test_tabs($test, 'scan');
?>
<div class="scan-intro card soft">
  <div>
    <b>Qanday ishlaydi:</b> platformadan chop etilgan <a href="<?= e(url('sheet', ['id' => $test['id']])) ?>" target="_blank">javoblar varaqasi</a>ni skaner qiling (JPG/PNG yoki ko'p sahifali PDF) yoki telefonda suratga oling. Tizim 4 ta burchak markerini topadi, ID va javoblarni o'qiydi. Har bir varaqni tekshirib, saqlang.
    <div class="small muted mt">Maslahat: varaq tekis va to'liq kadrda bo'lsin, soya tushmasin. Skaner uchun 150–200 dpi yetarli. Ochiq topshiriqlarni oldin tekshiruvchi ✓ yoki ✗ doirachani to'liq bo'yab belgilab chiqadi.</div>
  </div>
  <div class="row gap wrap">
    <label class="btn primary">📁 Fayllarni tanlash<input type="file" id="files" accept="image/*,application/pdf" multiple hidden></label>
    <label class="btn ghost">📷 Kamera<input type="file" id="camera" accept="image/*" capture="environment" hidden></label>
    <?php if ($cl = centers_list()): ?><select id="scanCenter" title="Yangi o'quvchilar qaysi markazga biriktirilsin"><option value="0">O'z markazimiz</option><?php foreach ($cl as $cid => $cn): ?><option value="<?= $cid ?>"><?= e($cn) ?></option><?php endforeach; ?></select><?php endif; ?>
    <button class="btn success" id="saveAll" disabled>Barcha "tayyor"larni saqlash</button>
  </div>
</div>
<details class="card scan-help">
  <summary>Skaner qanday ishlaydi — qadam-baqadam</summary>
  <div class="scan-steps">
    <div class="scan-step"><svg viewBox="0 0 120 76"><rect x="30" y="4" width="60" height="68" rx="2" fill="none" stroke="currentColor" stroke-opacity=".35"/><rect x="33" y="7" width="7" height="7" fill="currentColor"/><rect x="80" y="7" width="7" height="7" fill="currentColor"/><rect x="33" y="62" width="7" height="7" fill="currentColor"/><rect x="80" y="62" width="7" height="7" fill="currentColor"/><rect x="43" y="9" width="9" height="2.5" fill="currentColor"/></svg><b>1. Burchak markerlari</b>Rasm kulrangga o'tkaziladi. Har bir chorakda eng katta qora kvadrat qidiriladi — bu 4 ta marker. Chap-yuqoridagi qisqa chiziq varaq to'g'ri yoki teskari turganini bildiradi.</div>
    <div class="scan-step"><svg viewBox="0 0 120 76"><path d="M8 14 L50 6 L54 66 L4 60 Z" fill="none" stroke="currentColor" stroke-opacity=".45"/><path d="M60 38 h14 m-4 -4 l4 4 l-4 4" stroke="var(--accent)" fill="none" stroke-width="1.6"/><rect x="80" y="8" width="34" height="58" fill="none" stroke="currentColor"/></svg><b>2. Perspektivani tuzatish</b>4 marker orqali gomografiya hisoblanadi: varaqdagi har bir nuqta (mm) rasmdagi pikselga aniq mos keladi. Qiya surat, burilish va masshtab shu bilan to'g'rilanadi.</div>
    <div class="scan-step"><svg viewBox="0 0 120 76"><circle cx="30" cy="38" r="18" fill="none" stroke="currentColor" stroke-opacity=".5"/><circle cx="30" cy="38" r="11" fill="var(--accent)" fill-opacity=".25" stroke="var(--accent)" stroke-dasharray="2 2"/><circle cx="85" cy="38" r="18" fill="currentColor" fill-opacity=".85"/><text x="30" y="70" font-size="8" text-anchor="middle" fill="currentColor">0.05</text><text x="85" y="70" font-size="8" text-anchor="middle" fill="currentColor">0.78</text></svg><b>3. Qoralikni o'lchash</b>Har bir doirachaning ichki qismi (60% radius — chekka chiziq va harf ta'sir qilmasligi uchun) o'rtacha yorqinligi atrofdagi qog'oz oqligi bilan solishtiriladi: 0 — oq, 1 — to'liq qora.</div>
    <div class="scan-step"><svg viewBox="0 0 120 76"><line x1="6" y1="38" x2="114" y2="38" stroke="currentColor" stroke-opacity=".3"/><line x1="44" y1="14" x2="44" y2="62" stroke="var(--accent)" stroke-dasharray="3 2"/><text x="46" y="12" font-size="7" fill="var(--accent)">T</text><circle cx="16" cy="38" r="4" fill="currentColor" fill-opacity=".3"/><circle cx="24" cy="38" r="4" fill="currentColor" fill-opacity=".3"/><circle cx="30" cy="38" r="4" fill="currentColor" fill-opacity=".3"/><circle cx="86" cy="38" r="4" fill="currentColor"/><circle cx="98" cy="38" r="4" fill="currentColor"/></svg><b>4. Chegara (T)</b>Barcha doirachalar qoraligining medianasi — bo'sh qog'oz foni. Chegara = fon + 0.17 (kamida 0.24). Shuning uchun qalam, ko'k yoki qora ruchka, yorug' yoki qorong'i surat — hammasi o'z fonidan o'lchanadi.</div>
    <div class="scan-step"><svg viewBox="0 0 120 76"><g fill="none" stroke="currentColor" stroke-opacity=".5"><circle cx="20" cy="20" r="6"/><circle cx="36" cy="20" r="6"/><circle cx="68" cy="20" r="6"/><circle cx="20" cy="54" r="6"/><circle cx="52" cy="54" r="6"/><circle cx="68" cy="54" r="6"/></g><circle cx="52" cy="20" r="6" fill="currentColor"/><circle cx="36" cy="54" r="6" fill="var(--critical)"/><circle cx="52" cy="54" r="6" fill="var(--critical)"/><text x="84" y="23" font-size="8" fill="currentColor">C</text><text x="84" y="57" font-size="8" fill="var(--critical)">ko'p</text></svg><b>5. Javob qarori</b>Savolda eng qora variant T dan oshsa — javob shu. Ikkinchi variant ham T dan oshib, birinchisining 62% idan ko'p bo'lsa — "bir nechta belgilangan" (hisoblanmaydi). Chegaraga yaqin qiymat — sariq "noaniq" belgisi.</div>
    <div class="scan-step"><svg viewBox="0 0 120 76"><g fill="none" stroke="currentColor" stroke-opacity=".45"><circle cx="20" cy="10" r="4"/><circle cx="20" cy="30" r="4"/><circle cx="20" cy="40" r="4"/><circle cx="20" cy="50" r="4"/><circle cx="36" cy="10" r="4"/><circle cx="36" cy="20" r="4"/><circle cx="36" cy="30" r="4"/><circle cx="36" cy="50" r="4"/><circle cx="52" cy="20" r="4"/><circle cx="52" cy="30" r="4"/><circle cx="52" cy="40" r="4"/><circle cx="52" cy="50" r="4"/></g><circle cx="20" cy="20" r="4" fill="currentColor"/><circle cx="36" cy="40" r="4" fill="currentColor"/><circle cx="52" cy="10" r="4" fill="currentColor"/><text x="68" y="42" font-size="11" font-family="monospace" fill="currentColor">1 3 0 …</text></svg><b>6. ID raqam</b>6 ta ustun, har birida 0–9. Har ustunda eng qora raqam olinadi. Bo'sh yoki ikkita bo'yalgan ustun "?" bo'ladi. Topilgan ID bazadan qidiriladi — ism ko'rinadi, topilmasa ogohlantiriladi.</div>
    <div class="scan-step"><svg viewBox="0 0 120 76"><rect x="6" y="26" width="46" height="22" rx="2" fill="none" stroke="currentColor" stroke-opacity=".5"/><text x="29" y="41" font-size="10" text-anchor="middle" fill="currentColor">12,5</text><circle cx="68" cy="37" r="8" fill="var(--ok)"/><text x="68" y="41" font-size="9" text-anchor="middle" fill="#fff">✓</text><circle cx="90" cy="37" r="8" fill="none" stroke="currentColor" stroke-opacity=".5"/><text x="90" y="41" font-size="9" text-anchor="middle" fill="currentColor" fill-opacity=".5">✗</text></svg><b>7. Ochiq topshiriqlar</b>O'quvchi javobni katakchaga yozadi, tekshiruvchi uni kalit bilan solishtirib ✓ (to'g'ri) yoki ✗ (noto'g'ri) doirachani <b>to'liq bo'yaydi</b> (ptichka yoki X chizish ishonchsiz: sinovda to'liq bo'yash 0.80, ptichka atigi 0.30 qoralik berdi). Skaner shu belgini o'qiydi; ikkalasi bo'yalgan yoki belgisiz qolsa — ogohlantiradi.</div>
    <div class="scan-step"><svg viewBox="0 0 120 76"><rect x="10" y="8" width="100" height="60" rx="6" fill="none" stroke="currentColor" stroke-opacity=".35"/><path d="M30 40 l10 10 l22 -24" stroke="var(--ok)" stroke-width="4" fill="none" stroke-linecap="round"/><text x="72" y="44" font-size="9" fill="currentColor">Saqlash</text></svg><b>8. Operator tasdiqlaydi</b>Rasmdagi rangli doirachalar — tizim nimani o'qiganini ko'rsatadi. "Diagnostika" bo'limida har bir doiracha qiymati bor. Xato bo'lsa bir bosishda tuzatib, saqlaysiz.</div>
  </div>
</details>
<div id="drop" class="dropzone">Fayllarni shu yerga tashlang</div>
<div class="scan-layout">
  <div class="scan-queue card"><h3>Navbat <span id="qcount" class="muted"></span></h3><ol id="queue" class="queue"></ol></div>
  <div class="scan-review card" id="review"><div class="empty">Varaq tanlanmagan</div></div>
</div>
<script>
window.SCAN = {
  testId: <?= (int)$test['id'] ?>,
  layout: <?= json_encode($L, JSON_UNESCAPED_UNICODE) ?>,
  mc: <?= json_encode($mcLabels) ?>,
  open: <?= json_encode($openLabels) ?>,
  opts: <?= json_encode(array_column(array_filter($items, fn($i) => $i['type'] === 'mc'), 'opts', 'label')) ?>,
};
</script>
<?php page_footer(['assets/omr.js', 'assets/scan.js']);
