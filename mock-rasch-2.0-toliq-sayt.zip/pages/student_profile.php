<?php
defined('APP_ROOT') || exit;
/**
 * O'quvchi profili: shaxsiy ma'lumotlar, telefonni tasdiqlash/almashtirish (kod bilan), Telegram ulash, ota-ona ma'lumotlari.
 */
$me = student();
$sid = (int)$me['id'];
$s = row('SELECT * FROM students WHERE id=?', [$sid]);
$PV = $_SESSION['pv'] ?? null;   // telefon tasdiqlash holati: ['phone','new','ch','sent']
$err = '';

if (is_post()) {
    csrf_check();
    $act = (string)($_POST['action'] ?? '');

    if ($act === 'info') {
        $pp = trim((string)($_POST['parent_phone'] ?? '')); $pp2 = trim((string)($_POST['parent_phone2'] ?? ''));
        $n1 = $pp === '' ? '' : norm_phone($pp); $n2 = $pp2 === '' ? '' : norm_phone($pp2);
        if ($pp !== '' && $n1 === '') $err = 'Ota-ona telefoni noto\'g\'ri (+998 XX XXX XX XX).';
        elseif ($pp2 !== '' && $n2 === '') $err = 'Ota-onaning 2-telefoni noto\'g\'ri.';
        elseif ($n1 !== '' && $n1 === $s['phone']) $err = 'Ota-ona telefoni o\'zingizning raqamingiz bilan bir xil bo\'lmasin.';
        if ($err === '') {
            q('UPDATE students SET school=?, grade_level=?, parent_name=?, parent_phone=?, parent_phone2=?, parent_optout=? WHERE id=?',
                [mb_substr(trim((string)($_POST['school'] ?? '')), 0, 160), mb_substr(trim((string)($_POST['grade_level'] ?? '')), 0, 20),
                 mb_substr(trim((string)($_POST['parent_name'] ?? '')), 0, 120), $n1, $n2, isset($_POST['parent_optout']) ? 1 : 0, $sid]);
            flash('Ma\'lumotlar saqlandi');
            redirect('student_profile');
        }
    }

    if ($act === 'tg_link') {
        $u = tg_link_url($sid, 'stu');
        if ($u === null) flash('Telegram bot hozircha ulanmagan yoki juda ko\'p havola yaratilgan. Birozdan keyin urinib ko\'ring.', 'err');
        else $_SESSION['tg_link_url'] = $u;
        redirect('student_profile');
    }
    if ($act === 'par_link') {
        $u = tg_link_url($sid, 'par');
        if ($u === null) flash('Telegram bot hozircha ulanmagan yoki juda ko\'p havola yaratilgan. Birozdan keyin urinib ko\'ring.', 'err');
        else $_SESSION['par_link_url'] = $u;
        redirect('student_profile');
    }
    if ($act === 'par_unlink') {
        q('UPDATE students SET parent_tg_chat=NULL, parent_tg_at=NULL WHERE id=?', [$sid]);
        flash('Ota-ona Telegrami uzildi', 'warn');
        redirect('student_profile');
    }
    if ($act === 'tg_unlink') {
        q('UPDATE students SET tg_chat_id=NULL, tg_username="", tg_linked_at=NULL WHERE id=?', [$sid]);
        flash('Telegram ulanishi uzildi', 'warn');
        redirect('student_profile');
    }

    // --- telefon: tasdiqlash yoki almashtirish
    if ($act === 'pv_start' || $act === 'pv_change' || $act === 'pv_resend') {
        $ipWait = throttle_wait('phonev', client_ip(), 12, 12, 60);
        $new = false;
        if ($act === 'pv_resend' && $PV) { $phone = $PV['phone']; $new = !empty($PV['new']); }
        elseif ($act === 'pv_change') {
            $phone = norm_phone((string)($_POST['phone'] ?? '')); $new = true;
            if ($phone === '') $err = 'Telefon raqamni +998 XX XXX XX XX ko\'rinishida kiriting.';
            elseif ($phone === $s['phone'] && $s['phone_verified_at']) $err = 'Bu raqam allaqachon tasdiqlangan.';
            elseif ($phone !== $s['phone'] && val('SELECT 1 FROM students WHERE phone=? AND id<>?', [$phone, $sid])) $err = 'Bu telefon raqam boshqa hisobda bor.';
        } else { $phone = (string)$s['phone']; if ($phone === '') $err = 'Avval telefon raqamingizni kiriting.'; }
        if ($err === '') {
            if ($ipWait) $err = "Juda ko'p urinish. $ipWait daqiqadan keyin qayta urinib ko'ring.";
            elseif ($act === 'pv_resend' && $PV && time() - (int)$PV['sent'] < 45) $err = 'Kodni qayta yuborish uchun 45 soniya kuting.';
            elseif (!($chs = phone_proof_channels($phone))) $err = 'Hozircha telefonni tasdiqlash imkoni yo\'q (SMS/Telegram Gateway ulanmagan). O\'quv markaziga murojaat qiling.';
            elseif (!otp_allowed('phone', phone_otp_target($sid, $phone))) $err = 'Bugun juda ko\'p kod so\'raldi. Ertaga urinib ko\'ring.';
            else {
                throttle_fail('phonev', client_ip());
                $code = otp_create('phone', phone_otp_target($sid, $phone), $sid, '');
                $via = otp_deliver(['phone' => $phone, 'tg_chat_id' => null], $code, $chs);
                if ($via === '') $err = 'Kodni yuborib bo\'lmadi. Birozdan keyin qayta urinib ko\'ring.';
                else { $_SESSION['pv'] = $PV = ['phone' => $phone, 'new' => $new, 'ch' => $via, 'sent' => time()]; flash('Tasdiqlash kodi ' . mask_phone($phone) . ' raqamiga ' . ($via === 'sms' ? 'SMS' : 'Telegram') . ' orqali yuborildi'); redirect('student_profile'); }
            }
        }
    }
    if ($act === 'pv_code' && $PV) {
        $ipWait = throttle_wait('phonev', client_ip(), 12, 12, 60);
        if ($ipWait) $err = "Juda ko'p urinish. $ipWait daqiqadan keyin urinib ko'ring.";
        elseif (otp_verify('phone', phone_otp_target($sid, $PV['phone']), (string)($_POST['code'] ?? ''))) {
            if (val('SELECT 1 FROM students WHERE phone=? AND id<>?', [$PV['phone'], $sid])) { $err = 'Bu telefon raqam boshqa hisobda bor.'; }
            else {
                q('UPDATE students SET phone=?, phone_verified_at=NOW() WHERE id=?', [$PV['phone'], $sid]);
                unset($_SESSION['pv']);
                flash('Telefon raqamingiz tasdiqlandi: ' . fmt_phone($PV['phone']));
                redirect('student_profile');
            }
        } else { throttle_fail('phonev', client_ip()); $err = 'Kod noto\'g\'ri yoki muddati o\'tgan. 3 marta xato kiritilsa, yangi kod so\'rash kerak.'; }
    }
    if ($act === 'pv_cancel') { unset($_SESSION['pv']); redirect('student_profile'); }
    $s = row('SELECT * FROM students WHERE id=?', [$sid]);
}

$tgUrl = $_SESSION['tg_link_url'] ?? null; unset($_SESSION['tg_link_url']);
$parUrl = $_SESSION['par_link_url'] ?? null; unset($_SESSION['par_link_url']);
$botName = tg_meta('bot');
$canProve = $s['phone'] !== '' ? (bool)phone_proof_channels($s['phone']) : (bool)phone_proof_channels('+998900000000');
page_header('Profil');
?>
<div class="page-head"><div><h1>Profil</h1><p class="muted" style="margin:0"><?= e($s['full_name']) ?> · ID <span class="mono"><?= e($s['code']) ?></span><?= $s['group_name'] ? ' · ' . e($s['group_name']) : '' ?></p></div>
  <div class="row gap"><a class="btn ghost" href="<?= e(url('student_home')) ?>">← Mening sahifam</a><a class="btn ghost" href="<?= e(url('student_setpass')) ?>">Parolni o'zgartirish</a></div></div>
<?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>

<div class="grid2">
  <div class="card">
    <h2>Telefon raqam</h2>
    <p>
      <?php if ($s['phone'] !== ''): ?><b class="mono"><?= e(fmt_phone($s['phone'])) ?></b>
        <?= $s['phone_verified_at'] ? '<span class="tag green">tasdiqlangan</span>' : '<span class="tag">tasdiqlanmagan</span>' ?>
      <?php else: ?><span class="muted">kiritilmagan</span><?php endif; ?>
    </p>
    <?php if ($PV): ?>
      <div class="alert info small">Kod <b><?= e(mask_phone($PV['phone'])) ?></b> raqamiga <?= $PV['ch'] === 'sms' ? 'SMS' : 'Telegram' ?> orqali yuborildi<?= !empty($PV['new']) ? ' (yangi raqam)' : '' ?>. 5 daqiqa amal qiladi.</div>
      <form method="post" class="form">
        <?= csrf_field() ?><input type="hidden" name="action" value="pv_code">
        <label>6 xonali kod <input name="code" required class="big-input" inputmode="numeric" maxlength="6" pattern="\d{6}" autocomplete="one-time-code" autofocus placeholder="••••••"></label>
        <button class="btn primary">Tasdiqlash</button>
      </form>
      <div class="row gap mt small">
        <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="pv_resend"><button class="btn sm ghost">Kodni qayta yuborish</button></form>
        <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="pv_cancel"><button class="btn sm ghost">Bekor qilish</button></form>
      </div>
    <?php elseif (!$canProve): ?>
      <p class="small muted">Telefonni kod bilan tasdiqlash hozircha yoqilmagan. Raqamni o'zgartirish uchun o'quv markaziga murojaat qiling.</p>
    <?php else: ?>
      <?php if ($s['phone'] !== '' && !$s['phone_verified_at']): ?>
        <form method="post" class="mb"><?= csrf_field() ?><input type="hidden" name="action" value="pv_start"><button class="btn primary">Raqamni tasdiqlash (kod yuborish)</button></form>
      <?php endif; ?>
      <details class="small" <?= $s['phone'] === '' ? 'open' : '' ?>>
        <summary><?= $s['phone'] === '' ? 'Telefon raqam qo\'shish' : 'Raqamni almashtirish' ?></summary>
        <form method="post" class="form mt">
          <?= csrf_field() ?><input type="hidden" name="action" value="pv_change">
          <label>Yangi raqam <input name="phone" inputmode="tel" placeholder="+998 90 123 45 67" required></label>
          <button class="btn">Kod yuborish</button>
        </form>
      </details>
    <?php endif; ?>
    <p class="small muted mt">Tasdiqlangan raqam bilan parolni tiklash va xabarlar olish ishonchli bo'ladi. Kirishda ID o'rniga telefon raqamingizni ham yozishingiz mumkin.</p>
  </div>

  <div class="card">
    <h2>Telegram</h2>
    <?php if ($s['tg_chat_id'] !== null): ?>
      <p><span class="tag green">ulangan</span> <?= $s['tg_username'] ? '@' . e($s['tg_username']) : '' ?> <span class="muted small"><?= e(substr((string)$s['tg_linked_at'], 0, 16)) ?></span></p>
      <p class="small muted">MOCK eslatmalari, savollar kitobi, xona/o'rin va natija shu yerga keladi. Parolni tiklash kodi ham avval Telegramga yuboriladi.</p>
      <form method="post" onsubmit="return confirm('Telegram ulanishi uzilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="tg_unlink"><button class="btn sm danger-ghost">Ulanishni uzish</button></form>
    <?php elseif ($botName === '' || !tg_ready()): ?>
      <p class="small muted">Telegram bot hozircha ulanmagan.</p>
    <?php elseif ($tgUrl): ?>
      <p class="small">Quyidagi tugmani bosing — Telegram ochiladi, so'ng <b>«Start»</b> (Boshlash) ni bosing. Havola 30 daqiqa amal qiladi va bir marta ishlaydi.</p>
      <p><a class="btn primary" target="_blank" rel="noopener" href="<?= e($tgUrl) ?>">Telegramda ochish</a></p>
      <p class="small muted">Ulangach bu sahifani yangilang.</p>
    <?php else: ?>
      <p class="small muted">Telegramni ulasangiz, savollar kitobi va natijalar o'zingizga botda keladi, javoblarni ham botda kiritishingiz mumkin.</p>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="tg_link"><button class="btn primary">Telegramni ulash</button></form>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <h2>Ma'lumotlarim</h2>
  <form method="post" class="form">
    <?= csrf_field() ?><input type="hidden" name="action" value="info">
    <p class="small muted" style="margin:0">F.I.Sh: <b><?= e($s['full_name']) ?></b> — ism xato bo'lsa, o'quv markaziga murojaat qiling (sertifikatda shu ism chiqadi).</p>
    <div class="grid2">
      <label>Maktab <input name="school" value="<?= e($s['school']) ?>" maxlength="160"></label>
      <label>Sinf <input name="grade_level" value="<?= e($s['grade_level']) ?>" maxlength="20" placeholder="11-sinf"></label>
    </div>
    <fieldset class="parent-fs"><legend>Ota-ona (natijalar SMS orqali yuboriladi)</legend>
      <div class="grid3">
        <label>Ism <input name="parent_name" value="<?= e($s['parent_name']) ?>" maxlength="120"></label>
        <label>Telefon <input name="parent_phone" value="<?= e($s['parent_phone'] !== '' ? fmt_phone($s['parent_phone']) : '') ?>" inputmode="tel" placeholder="+998 90 123 45 67"></label>
        <label>2-telefon <input name="parent_phone2" value="<?= e($s['parent_phone2'] !== '' ? fmt_phone($s['parent_phone2']) : '') ?>" inputmode="tel" placeholder="ixtiyoriy"></label>
      </div>
      <label class="check"><input type="checkbox" name="parent_optout" <?= $s['parent_optout'] ? 'checked' : '' ?>> Natijalar ota-onamga yuborilmasin</label>
    </fieldset>
    <button class="btn primary">Saqlash</button>
  </form>
  <?php if (tg_ready() && tg_meta('bot') !== ''): ?>
  <div class="mt" style="border-top:1px solid var(--line);padding-top:.8rem">
    <h3 style="margin-top:0">Ota-ona Telegrami</h3>
    <?php if ($s['parent_tg_chat'] !== null): ?>
      <p><span class="tag green">ulangan</span> <span class="small muted">natijalar ota-onangizning Telegramiga ham keladi (bepul)</span></p>
      <form method="post" onsubmit="return confirm('Ota-ona Telegrami uzilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="par_unlink"><button class="btn sm danger-ghost">Uzish</button></form>
    <?php elseif ($parUrl): ?>
      <p class="small">Bu havolani ota-onangizga yuboring — ular ochib, <b>«Start»</b> ni bossa, natijalar ularning Telegramiga keladi. Havola 30 daqiqa amal qiladi va bir marta ishlaydi.</p>
      <input class="mono" style="width:100%" readonly onclick="this.select()" value="<?= e($parUrl) ?>">
    <?php else: ?>
      <p class="small muted">Ota-onangiz Telegramda bo'lsa, natijalar SMS o'rniga botga keladi.</p>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="par_link"><button class="btn sm">Ota-ona uchun havola olish</button></form>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</div>
<?php page_footer();
