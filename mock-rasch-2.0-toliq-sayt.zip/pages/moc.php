<?php
defined('APP_ROOT') || exit;
/**
 * Oldin ro'yxatdan o'tgan (ID + parol bilan kirgan) o'quvchi uchun MOCK tanlash.
 * Yangi foydalanuvchi p=register da MOCK ni tanlab, ma'lumotlarini kiritadi.
 */
$me = student();
if ($me) { student_session_guard(); $me = student(); }   // parol almashtirilgan / majburiy almashtirish
$tid = (int)($_GET['test'] ?? $_POST['test'] ?? 0);
if (!$me && !is_post()) redirect('register', $tid ? ['test' => $tid] : []);

if (is_post()) {
    csrf_check();
    if (!$me) redirect('student_login', ['next' => 'moc', 'test' => $tid]);
    $t = row('SELECT id, title, reg_open FROM tests WHERE id=?', [$tid]);
    $act = $_POST['action'] ?? '';
    if ($t && $act === 'enroll') {
        if ($t['reg_open']) {
            q('INSERT IGNORE INTO test_registrations (test_id, student_id) VALUES (?,?)', [$t['id'], $me['id']]);
            flash('Siz "' . $t['title'] . '" ga ro\'yxatdan o\'tdingiz');
        } else flash('Bu MOCK ga ro\'yxat yopilgan', 'err');
    }
    if ($t && $act === 'cancel') {
        $started = val('SELECT 1 FROM responses WHERE test_id=? AND student_id=?', [$t['id'], $me['id']]);
        if ($t['reg_open'] && !$started) {
            q('DELETE FROM test_registrations WHERE test_id=? AND student_id=?', [$t['id'], $me['id']]);
            flash('Ro\'yxatdan chiqdingiz', 'warn');
        } else flash('Endi bekor qilib bo\'lmaydi', 'err');
    }
    redirect('moc', $tid ? ['test' => $tid] : []);
}

$where = $tid ? 't.id=? AND (t.reg_open=1' . ($me ? ' OR r.student_id IS NOT NULL' : '') . ')' : 't.reg_open=1';
$par = $me ? [$me['id']] : [0];
if ($tid) $par[] = $tid;
$tests = rows("SELECT t.id, t.title, t.subject, t.test_date, t.reg_open, t.online, r.created_at reg_at,
                      (SELECT COUNT(*) FROM test_registrations x WHERE x.test_id=t.id) n_reg,
                      (SELECT 1 FROM responses y WHERE y.test_id=t.id AND y.student_id=r.student_id LIMIT 1) started
               FROM tests t LEFT JOIN test_registrations r ON r.test_id=t.id AND r.student_id=?
               WHERE $where ORDER BY t.test_date IS NULL, t.test_date, t.id", $par);
if ($tid && !$tests) { flash('Bu MOCK ga ro\'yxat ochiq emas', 'warn'); redirect('moc'); }

page_header('MOCK ga ro\'yxatdan o\'tish', ['main' => 'narrow-main']);
?>
<div class="card narrow">
  <h1>MOCK ga ro'yxatdan o'tish</h1>
  <p class="muted"><b><?= e($me['name']) ?></b> (ID <span class="mono"><?= e($me['code']) ?></span>) — ma'lumotlaringiz saqlangan. MOCK ni tanlab, "Ro'yxatdan o'tish" ni bosing.</p>

  <?php foreach ($tests as $t): ?>
    <div class="moc-item">
      <div>
        <b><?= e($t['title']) ?></b>
        <div class="small muted"><?= e($t['subject']) ?> · <?= e($t['test_date'] ?: 'sana keyinroq e\'lon qilinadi') ?><?= $t['online'] ? ' · onlayn' : '' ?> · <?= (int)$t['n_reg'] ?> kishi ro'yxatda</div>
      </div>
      <?php if ($me && $t['reg_at']): ?>
        <div class="row gap center-v">
          <span class="tag green">Ro'yxatdasiz</span>
          <?php if ($t['reg_open'] && !$t['started']): ?><form method="post" onsubmit="return confirm('Ro\'yxatdan chiqasizmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="cancel"><input type="hidden" name="test" value="<?= (int)$t['id'] ?>"><button class="btn sm danger-ghost">Bekor qilish</button></form><?php endif; ?>
        </div>
      <?php elseif ($me): ?>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="enroll"><input type="hidden" name="test" value="<?= (int)$t['id'] ?>"><button class="btn primary sm">Ro'yxatdan o'tish</button></form>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
  <?php if (!$tests): ?>
    <p class="empty">Hozir ro'yxati ochiq MOCK yo'q. Yangi MOCK e'lon qilinganda shu yerda paydo bo'ladi.</p>
  <?php endif; ?>
  <p class="small muted mt"><a href="<?= e(url('student_home')) ?>">← Mening sahifam</a></p>
</div>
<?php page_footer();
