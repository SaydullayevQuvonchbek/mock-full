<?php
defined('APP_ROOT') || exit;
$test = get_test_or_404();
$cid = (int)($_GET['center'] ?? 0);
$center = row('SELECT * FROM centers WHERE id=?', [$cid]);
if (!$center) { flash('Markaz topilmadi', 'err'); redirect('centers'); }
if ($test['dirty'] && val('SELECT COUNT(*) FROM responses WHERE test_id=?', [$test['id']]) && $test['key']) { compute_test((int)$test['id']); $test = test_by_id((int)$test['id']); }
$items = test_items($test);
$L = count($items);
$all = rows('SELECT r.*, s.code, s.full_name, s.group_name, s.center_id FROM results r JOIN students s ON s.id=r.student_id WHERE r.test_id=? ORDER BY r.rank_no', [$test['id']]);
$mine = array_values(array_filter($all, fn($r) => (int)$r['center_id'] === $cid));
$N = count($all); $n = count($mine);
$avg = fn($a, $k) => $a ? array_sum(array_map(fn($r) => (float)$r[$k], $a)) / count($a) : 0;
$cert = fn($a) => count(array_filter($a, fn($r) => (float)$r['ball'] >= 46));
$grades = [];
foreach (array_merge(array_map(fn($g) => $g[0], GRADE_SCALE), ['NB']) as $g) $grades[$g === 'NB' ? 'Sert.siz' : $g] = 0;
foreach ($mine as $r) $grades[$r['grade'] === 'NB' ? 'Sert.siz' : $r['grade']]++;
// Savollar bo'yicha: markaz va umumiy to'g'ri javob ulushi
$pAll = array_fill(0, $L, 0); $pMine = array_fill(0, $L, 0);
foreach ($all as $r) { $bits = str_split($r['scored']); foreach ($bits as $i => $b) if ($b === '1') { $pAll[$i]++; if ((int)$r['center_id'] === $cid) $pMine[$i]++; } }
page_header('Markaz hisoboti — ' . $center['name']);
?>
<div class="page-head">
  <div>
    <div class="crumbs no-print"><a href="<?= e(url('centers')) ?>">Hamkor markazlar</a><span>/</span><?= e($center['name']) ?></div>
    <h1><?= e($center['name']) ?></h1>
    <div class="meta-row"><span><?= e($test['title']) ?></span><span><?= e($test['test_date'] ?: '—') ?></span><span><?= $n ?> ishtirokchi (jami <?= $N ?>)</span></div>
  </div>
  <div class="row gap no-print">
    <a class="btn ghost" href="<?= e(url('export', ['what' => 'results', 'id' => $test['id'], 'center' => $cid])) ?>"><?= icon('download', 16) ?>Excel</a>
    <button class="btn primary" onclick="print()"><?= icon('print', 16) ?>Chop etish</button>
  </div>
</div>
<?php if (!$n): ?>
  <div class="card empty">Bu markazdan hali natija yo'q. Test sahifasidagi import yoki skanerda markazni tanlab javoblarni yuklang.</div>
<?php else: ?>
<div class="stats4">
  <div class="stat"><span><?= $n ?></span>Ishtirokchi</div>
  <div class="stat"><span><?= fmt($avg($mine, 'ball')) ?></span>O'rtacha ball<small>umumiy: <?= fmt($avg($all, 'ball')) ?></small></div>
  <div class="stat"><span><?= fmt($avg($mine, 'raw')) ?> <small style="display:inline;font:500 .9rem var(--sans)">/ <?= $L ?></small></span>O'rtacha to'g'ri javob<small>umumiy: <?= fmt($avg($all, 'raw')) ?></small></div>
  <div class="stat accent"><span><?= round($cert($mine) / $n * 100) ?>%</span>Sertifikat (≥ 46)<small><?= $cert($mine) ?> ta · umumiy <?= $N ? round($cert($all) / $N * 100) : 0 ?>%</small></div>
</div>
<div class="grid-side">
  <div class="card">
    <h2>Darajalar</h2>
    <?= svg_bar_chart($grades, ['colors' => ['A+' => 'bar g-ap', 'A' => 'bar g-a', 'B+' => 'bar g-bp', 'B' => 'bar g-b', 'C+' => 'bar g-cp', 'C' => 'bar g-c', 'Sert.siz' => 'bar g-none'], 'title' => 'Darajalar']) ?>
  </div>
  <div class="card">
    <h2>Eng zaif savollar</h2>
    <p class="small muted">Markaz o'quvchilari umumiy natijadan eng ko'p ortda qolgan savollar — dars rejasiga qo'shish uchun.</p>
    <?php
      $diff = [];
      foreach ($items as $i => $it) $diff[$it['label']] = [$pMine[$i] / $n, $N ? $pAll[$i] / $N : 0];
      uasort($diff, fn($a, $b) => ($a[0] - $a[1]) <=> ($b[0] - $b[1]));
    ?>
    <table class="tbl compact-tbl"><thead><tr><th>Savol</th><th class="num">Markaz</th><th class="num">Umumiy</th><th class="num">Farq</th></tr></thead><tbody>
      <?php foreach (array_slice($diff, 0, 8, true) as $lab => [$pm, $pa]): ?>
        <tr><td><b><?= e($lab) ?></b></td><td class="num"><?= round($pm * 100) ?>%</td><td class="num muted"><?= round($pa * 100) ?>%</td><td class="num <?= $pm < $pa ? 'warn' : '' ?>"><?= ($pm >= $pa ? '+' : '') . round(($pm - $pa) * 100) ?></td></tr>
      <?php endforeach; ?>
    </tbody></table>
  </div>
</div>
<div class="section-title"><h2>O'quvchilar natijalari</h2></div>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th class="num">Umumiy o'rin</th><th>O'quvchi</th><th class="num">To'g'ri</th><th class="num">Ball</th><th class="num">Foiz</th><th>Daraja</th><th class="no-print"></th></tr></thead>
  <tbody>
  <?php foreach ($mine as $r): ?>
    <tr>
      <td class="num"><?= (int)$r['rank_no'] ?> / <?= $N ?></td>
      <td><b><?= e($r['full_name']) ?></b><div class="small muted mono"><?= e($r['code']) ?></div></td>
      <td class="num"><?= (int)$r['raw'] ?>/<?= $L ?></td>
      <td class="num"><b><?= fmt($r['ball']) ?></b></td>
      <td class="num muted"><?= fmt(cert_percent((float)$r['ball']), 0) ?>%</td>
      <td><?= grade_badge($r['grade']) ?></td>
      <td class="right no-print"><a class="btn sm ghost" target="_blank" href="<?= e(url('certificate', ['id' => $test['id'], 'sid' => $r['student_id']])) ?>"><?= icon('print', 14) ?></a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<div class="card">
  <h2>Barcha savollar bo'yicha to'g'ri javoblar</h2>
  <div class="item-cmp">
    <?php foreach ($items as $i => $it): $pm = $pMine[$i] / $n; $pa = $N ? $pAll[$i] / $N : 0; ?>
      <div class="ic <?= $pm + 0.1 < $pa ? 'low' : ($pm > $pa + 0.1 ? 'high' : '') ?>" title="<?= e($it['label']) ?>: markaz <?= round($pm * 100) ?>%, umumiy <?= round($pa * 100) ?>%">
        <b><?= e($it['label']) ?></b><span><?= round($pm * 100) ?>%</span><small><?= round($pa * 100) ?>%</small>
      </div>
    <?php endforeach; ?>
  </div>
  <p class="small muted mt">Katta raqam — markaz, kichik — barcha ishtirokchilar. Qizil — markaz 10 foizdan ko'proq ortda, yashil — 10 foizdan ko'proq oldinda.</p>
</div>
<p class="small muted">Rasch baholari barcha markazlar ishtirokchilari birgalikda hisoblangan (<?= $N ?> kishi) — bu savollar qiyinligini aniqroq baholaydi.</p>
<?php endif; ?>
<?php page_footer();
