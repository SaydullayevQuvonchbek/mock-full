<?php
defined('APP_ROOT') || exit;
$test = test_by_id((int)($_GET['id'] ?? 0));
if (!$test) { http_response_code(404); exit('Test topilmadi'); }
$docs = [];
if (admin()) {
    if (!empty($_GET['all'])) {
        issue_certificates($test);   // ma'lumotlarni yangilash (raqamlar o'zgarmaydi)
        foreach (rows('SELECT c.* FROM certificates c JOIN results r ON r.test_id=c.test_id AND r.student_id=c.student_id WHERE c.test_id=? ORDER BY r.rank_no', [$test['id']]) as $c) {
            $c['data'] = json_decode($c['data_json'], true); $docs[] = $c;
        }
    } else {
        $c = issue_certificate($test, (int)($_GET['sid'] ?? 0));
        if ($c) $docs[] = $c;
    }
} elseif (student()) {
    if (!$test['published']) { flash('Natijalar hali e\'lon qilinmagan', 'warn'); redirect('student_home'); }
    $c = row('SELECT * FROM certificates WHERE test_id=? AND student_id=?', [$test['id'], student()['id']]);
    $c = $c ? array_merge($c, ['data' => json_decode($c['data_json'], true)]) : issue_certificate($test, (int)student()['id']);
    if ($c) $docs[] = $c;
} else {
    redirect('student_login');
}
if (!$docs) { flash('Natija topilmadi', 'warn'); redirect(admin() ? 'results' : 'student_home', ['id' => $test['id']]); }

function cert_row(string $k, string $v): string
{
    return '<div class="cr"><span>' . e($k) . '</span><b>' . e($v) . '</b></div>';
}
page_header('Sertifikat', ['bare' => true, 'body' => 'print-page cert-page']);
?>
<div class="no-print toolbar">
  <button class="btn primary" onclick="print()"><?= icon('print', 16) ?>Chop etish / PDF</button>
  <span class="muted small"><?= count($docs) ?> ta hujjat · A4, masshtab 100%, chekkalar — yo'q, "Fon grafikasi" yoqilgan</span>
</div>
<?php foreach ($docs as $c): $d = $c['data']; $isCert = $c['kind'] === 'cert';
    $gcls = ['A+' => 'g-ap', 'A' => 'g-a', 'B+' => 'g-bp', 'B' => 'g-b', 'C+' => 'g-cp', 'C' => 'g-c'][$d['grade']] ?? 'g-none'; ?>
<section class="cert <?= $isCert ? '' : 'is-report' ?>">
  <div class="cert-frame">
    <header class="cert-head">
      <div class="cert-brand"><span class="brand-mark"><?= e(mb_strtoupper(mb_substr(trim($d['issuer']) ?: 'M', 0, 1))) ?></span><div><b><?= e($d['issuer']) ?></b><small>MOCK — milliy sertifikat formatidagi sinov imtihoni</small></div></div>
      <div class="cert-no">№ <?= e($c['number']) ?></div>
    </header>
    <div class="cert-title">
      <h1><?= $isCert ? 'Sertifikat' : 'Natija varaqasi' ?></h1>
      <p><?= e($d['subject']) ?> fanidan sinov imtihoni (MOCK) natijasi</p>
    </div>
    <div class="cert-name">
      <small><?= $isCert ? 'Ushbu sertifikat egasi' : 'Ishtirokchi' ?></small>
      <h2><?= e($d['name']) ?></h2>
      <span><?= e(trim(($d['school'] ?? '') . ($d['grade_level'] ? ' · ' . $d['grade_level'] : ''), ' ·')) ?></span>
    </div>
    <div class="cert-score">
      <div class="cs-main"><small>Umumiy to'plagan ball</small><b><?= fmt($d['ball']) ?></b></div>
      <div><small>Umumiy ballga nisbatan foiz</small><b><?= fmt($d['percent'], 1) ?>%</b></div>
      <div><small>Daraja</small><b class="cert-grade <?= $gcls ?>"><?= $d['grade'] === 'NB' ? '—' : e($d['grade']) ?></b></div>
    </div>
    <?php if (!$isCert): ?><p class="cert-note">46 balldan past — sertifikat darajasiga yetmagan. Keyingi MOCK da muvaffaqiyat tilaymiz!</p><?php endif; ?>
    <div class="cert-grid">
      <div class="cert-rows">
        <?= cert_row('O\'quvchi ID', $d['code']) ?>
        <?= cert_row('Familiyasi', $d['last'] ?: '—') ?>
        <?= cert_row('Ismi', $d['first'] ?: '—') ?>
        <?= cert_row('Otasining ismi', $d['middle'] ?: '—') ?>
        <?= cert_row('Test', $d['test']) ?>
        <?= cert_row('Sana', $d['date'] ?: '—') ?>
        <?= cert_row('To\'g\'ri javoblar', $d['raw'] . ' / ' . $d['items'] . '  (' . $d['tasks_full'] . ' / ' . $d['tasks'] . ' topshiriq)') ?>
        <?php if ($d['n']): ?><?= cert_row('O\'rin', $d['rank'] . ' / ' . $d['n']) ?><?php endif; ?>
        <?php if (!empty($d['center'])): ?><?= cert_row('Markaz', $d['center']) ?><?php endif; ?>
      </div>
      <div class="cert-sections">
        <h3>Test sinovi natijasi</h3>
        <?php foreach ($d['sections'] as $s): ?>
          <div class="cr"><span><?= e($s['name']) ?> <em>(<?= (int)$s['ok'] ?>/<?= (int)$s['total'] ?>)</em></span><b><?= number_format((float)$s['ball'], 3, '.', '') ?></b></div>
        <?php endforeach; ?>
        <div class="cr total"><span>Jami</span><b><?= fmt($d['ball']) ?></b></div>
        <?php if ($d['official'] !== null && abs($d['official'] - $d['ball']) > 0.05): ?>
          <p class="cert-official">Rasmiy shkala bo'yicha taxminiy ball: <b><?= fmt($d['official']) ?></b> — <?= e($d['grade_official'] === 'NB' ? 'sertifikatsiz' : $d['grade_official']) ?></p>
        <?php endif; ?>
      </div>
    </div>
    <footer class="cert-foot">
      <div class="cert-qr"><div class="qr" data-url="<?= e(cert_verify_url($c)) ?>"></div><small>Haqiqiyligini tekshirish<br><?= e($c['number']) ?></small></div>
      <div class="cert-sign"><span>Berilgan sana: <b><?= e(date('d.m.Y', strtotime($c['issued_at']))) ?></b></span><span class="sign-line">Rahbar: ______________________</span></div>
    </footer>
    <p class="cert-disclaimer">Ushbu hujjat <?= e($d['issuer']) ?> tomonidan o'tkazilgan sinov imtihoni natijasini tasdiqlaydi. U Bilim va malakalarni baholash agentligining rasmiy milliy sertifikati hisoblanmaydi.</p>
  </div>
</section>
<?php endforeach; ?>
<script src="assets/qrcode.js"></script>
<script>
document.querySelectorAll('.qr').forEach(function (el) {
  try { var q = qrcode(0, 'M'); q.addData(el.dataset.url); q.make(); el.innerHTML = q.createSvgTag({ cellSize: 3, margin: 0, scalable: true }); }
  catch (e) { el.textContent = el.dataset.url; }
});
</script>
<?php page_footer();
