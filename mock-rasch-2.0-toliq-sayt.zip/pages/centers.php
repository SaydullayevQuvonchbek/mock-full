<?php
defined('APP_ROOT') || exit;
if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    $data = [trim($_POST['name'] ?? ''), trim($_POST['contact'] ?? ''), trim($_POST['phone'] ?? ''), trim($_POST['note'] ?? '')];
    if ($act === 'add' && $data[0] !== '') {
        if (val('SELECT 1 FROM centers WHERE name=?', [$data[0]])) flash('Bunday markaz bor', 'err');
        else { q('INSERT INTO centers (name, contact, phone, note) VALUES (?,?,?,?)', $data); flash('Markaz qo\'shildi'); }
    }
    if ($act === 'edit' && $data[0] !== '') {
        q('UPDATE centers SET name=?, contact=?, phone=?, note=? WHERE id=?', array_merge($data, [(int)$_POST['id']]));
        flash('Saqlandi');
    }
    if ($act === 'delete') {
        q('UPDATE students SET center_id=NULL WHERE center_id=?', [(int)$_POST['id']]);
        q('DELETE FROM centers WHERE id=?', [(int)$_POST['id']]);
        flash('Markaz o\'chirildi (o\'quvchilar o\'z markazimizga o\'tdi)');
    }
    redirect('centers');
}
$list = rows('SELECT c.*, (SELECT COUNT(*) FROM students s WHERE s.center_id=c.id) n,
              (SELECT COUNT(DISTINCT r.test_id) FROM results r JOIN students s ON s.id=r.student_id WHERE s.center_id=c.id) nt
              FROM centers c ORDER BY c.name');
$edit = isset($_GET['edit']) ? row('SELECT * FROM centers WHERE id=?', [(int)$_GET['edit']]) : null;
$tests = rows('SELECT id, title, test_date FROM tests ORDER BY id DESC');
page_header('Hamkor markazlar');
?>
<div class="page-head">
  <div><h1>Hamkor markazlar</h1><p class="muted" style="margin:0">Boshqa o'quv markazlari javoblarini yuklab, Rasch bo'yicha tekshirib, markaz uchun alohida hisobot berasiz.</p></div>
</div>
<div class="card soft small">
  <b>Qanday ishlaydi:</b> 1) markazni shu yerda qo'shing; 2) test sahifasida Excel/CSV import, skaner yoki qo'lda kiritishda "Markaz" ni tanlang — o'quvchilar shu markazga biriktiriladi;
  3) Rasch barcha ishtirokchilar bo'yicha birga hisoblanadi (ko'p ishtirokchi — aniqroq baho); 4) "Hisobot" tugmasi faqat shu markaz natijalarini chiqaradi (chop etish va Excel).
</div>
<div class="grid-side">
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>Markaz</th><th>Mas'ul</th><th class="num">O'quvchilar</th><th class="num">Testlar</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($list as $c): ?>
      <tr>
        <td><b><?= e($c['name']) ?></b><?php if ($c['note']): ?><div class="small muted"><?= e($c['note']) ?></div><?php endif; ?></td>
        <td class="small"><?= e($c['contact']) ?><div class="muted"><?= e($c['phone']) ?></div></td>
        <td class="num"><a href="<?= e(url('students', ['center' => $c['id']])) ?>"><?= (int)$c['n'] ?></a></td>
        <td class="num"><?= (int)$c['nt'] ?></td>
        <td class="right nowrap">
          <form method="get" class="inline">
            <input type="hidden" name="p" value="center_report"><input type="hidden" name="center" value="<?= (int)$c['id'] ?>">
            <select name="id" class="sel-sm"><?php foreach ($tests as $t): ?><option value="<?= (int)$t['id'] ?>"><?= e($t['title']) ?></option><?php endforeach; ?></select>
            <button class="btn sm"><?= icon('chart', 14) ?>Hisobot</button>
          </form>
          <a class="btn sm ghost" href="<?= e(url('centers', ['edit' => $c['id']])) ?>">Tahrirlash</a>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$list): ?><tr><td colspan="5" class="empty">Hali hamkor markaz yo'q</td></tr><?php endif; ?>
    </tbody>
  </table></div>
  <div class="card">
    <h2><?= $edit ? 'Markazni tahrirlash' : 'Yangi markaz' ?></h2>
    <form method="post" class="form">
      <?= csrf_field() ?><input type="hidden" name="action" value="<?= $edit ? 'edit' : 'add' ?>"><?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
      <label>Nomi <input name="name" value="<?= e($edit['name'] ?? '') ?>" required></label>
      <label>Mas'ul shaxs <input name="contact" value="<?= e($edit['contact'] ?? '') ?>"></label>
      <label>Telefon <input name="phone" value="<?= e($edit['phone'] ?? '') ?>"></label>
      <label>Izoh <input name="note" value="<?= e($edit['note'] ?? '') ?>" placeholder="Shahar, shartnoma…"></label>
      <button class="btn primary"><?= $edit ? 'Saqlash' : 'Qo\'shish' ?></button>
    </form>
    <?php if ($edit): ?>
      <form method="post" class="mt" onsubmit="return confirm('Markaz o\'chirilsinmi? O\'quvchilari o\'chmaydi.')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><button class="btn sm danger-ghost">Markazni o'chirish</button></form>
    <?php endif; ?>
  </div>
</div>
<?php page_footer();
