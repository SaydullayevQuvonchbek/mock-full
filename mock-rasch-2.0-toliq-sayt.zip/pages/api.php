<?php
defined('APP_ROOT') || exit;
$a = $_GET['a'] ?? '';

if ($a === 'student') {
    if (!admin()) json_out(['error' => 'auth'], 403);
    $s = row('SELECT id, code, full_name, group_name FROM students WHERE code=?', [preg_replace('/\D/', '', $_GET['code'] ?? '')]);
    $has = $s ? (bool)val('SELECT 1 FROM responses WHERE test_id=? AND student_id=?', [(int)($_GET['test'] ?? 0), $s['id']]) : false;
    json_out(['student' => $s, 'has_response' => $has]);
}

if ($a === 'save_scan') {
    if (!admin()) json_out(['ok' => false, 'error' => 'Admin sifatida kiring'], 403);
    csrf_check();
    $in = json_decode(file_get_contents('php://input'), true) ?: [];
    $test = test_by_id((int)($in['test'] ?? 0));
    if (!$test) json_out(['ok' => false, 'error' => 'Test topilmadi']);
    $st = find_or_create_student((string)($in['code'] ?? ''), trim((string)($in['full_name'] ?? '')), '', (int)($in['center_id'] ?? 0) ?: null);
    if (!$st) json_out(['ok' => false, 'error' => 'ID yoki F.I.Sh kerak']);
    if (!empty($in['full_name']) && $st['full_name'] !== trim($in['full_name'])) {
        [$l, $f, $m] = split_name(trim($in['full_name']));
        q('UPDATE students SET full_name=?, last_name=?, first_name=?, middle_name=? WHERE id=?', [compose_name($l, $f, $m), $l, $f, $m, $st['id']]);
        $st['full_name'] = compose_name($l, $f, $m);
    }
    $ans = [];
    foreach (test_items($test) as $it) {
        $v = (string)($in['answers'][$it['label']] ?? '');
        if ($it['type'] === 'mc') $v = in_array($v, $it['opts'], true) ? $v : '';
        else $v = in_array($v, ['#1', '#0'], true) ? $v : '';
        $ans[$it['label']] = $v;
    }
    save_response((int)$test['id'], (int)$st['id'], $ans, 'omr');
    json_out(['ok' => true, 'student' => ['code' => $st['code'], 'full_name' => $st['full_name'], 'group_name' => $st['group_name']]]);
}

if ($a === 'online_save') {
    $s = student();
    if (!$s) json_out(['ok' => false, 'error' => 'Qayta kiring'], 403);
    csrf_check();
    $in = json_decode(file_get_contents('php://input'), true) ?: [];
    $test = test_by_id((int)($in['test'] ?? 0));
    if (!$test || !$test['online']) json_out(['ok' => false, 'error' => 'Test yopiq']);
    $r = row('SELECT * FROM responses WHERE test_id=? AND student_id=?', [$test['id'], $s['id']]);
    if (!$r) json_out(['ok' => false, 'error' => 'Test boshlanmagan']);
    if ($r['status'] === 'submitted') json_out(['ok' => false, 'error' => 'Siz allaqachon topshirgansiz', 'submitted' => true]);
    $deadline = online_deadline($test, $r);
    $late = time() > $deadline + 60; // 1 daqiqa tarmoq zaxirasi
    $ans = [];
    foreach (test_items($test) as $it) {
        $v = trim((string)($in['answers'][$it['label']] ?? ''));
        if ($it['type'] === 'mc') $v = in_array($v, $it['opts'], true) ? $v : '';
        else $v = mb_substr(str_replace(['#'], '', $v), 0, 40);
        $ans[$it['label']] = $v;
    }
    if ($late) {
        // Vaqt tugagan — oxirgi saqlangan javoblar bilan yakunlanadi
        q('UPDATE responses SET status="submitted", submitted_at=NOW() WHERE id=?', [$r['id']]);
        q('UPDATE tests SET dirty=1 WHERE id=?', [$test['id']]);
        json_out(['ok' => false, 'error' => 'Vaqt tugadi. Oxirgi saqlangan javoblaringiz qabul qilindi.', 'submitted' => true]);
    }
    $final = !empty($in['final']);
    q('UPDATE responses SET answers=?, status=?, submitted_at=IF(?, NOW(), NULL) WHERE id=?',
        [json_encode($ans, JSON_UNESCAPED_UNICODE), $final ? 'submitted' : 'in_progress', $final ? 1 : 0, $r['id']]);
    if ($final) q('UPDATE tests SET dirty=1 WHERE id=?', [$test['id']]);
    json_out(['ok' => true, 'submitted' => $final, 'saved_at' => date('H:i:s')]);
}

json_out(['error' => 'unknown'], 404);
