<?php
defined('APP_ROOT') || exit;
if (admin()) redirect('dashboard');
if (student()) redirect('student_home');
$openTests = rows('SELECT id, title, subject, test_date, online FROM tests WHERE reg_open=1 ORDER BY test_date IS NULL, test_date, id LIMIT 6');
page_header('Bosh sahifa');
?>
<section class="hero">
  <div>
    <div class="eyebrow"><?= e(app_setting('center')) ?></div>
    <h1>Matematika MOCK — milliy sertifikat formatidagi sinov imtihoni</h1>
    <p class="lead">Haqiqiy imtihondagi kabi javoblar varaqasi, vaqt va baholash. Natija 75 ballik shkalada, A+ … C darajalarida va bo'limlar (algebra, geometriya) bo'yicha beriladi.</p>
    <div class="row gap">
      <a class="btn primary" href="<?= e(url('register')) ?>">MOCK ga ro'yxatdan o'tish</a>
      <a class="btn" href="<?= e(url('student_login')) ?>">Natijani bilish</a>
    </div>
  </div>
  <div class="card hero-moc">
    <div class="eyebrow">Ro'yxat ochiq</div>
    <?php if ($openTests): ?>
      <?php foreach ($openTests as $t): ?>
        <a class="moc-link" href="<?= e(url('register', ['test' => $t['id']])) ?>">
          <span><b><?= e($t['title']) ?></b><small><?= e($t['subject']) ?> · <?= $t['test_date'] ? e(date('d.m.Y', strtotime($t['test_date']))) : 'sana keyinroq' ?><?= $t['online'] ? ' · onlayn' : '' ?></small></span>
          <?= icon('arrow', 16) ?>
        </a>
      <?php endforeach; ?>
    <?php else: ?>
      <p class="muted small">Hozir ro'yxati ochiq MOCK yo'q. Ma'lumotlaringizni oldindan qoldirsangiz, keyingi MOCK e'lon qilinganda bir bosishda ro'yxatdan o'tasiz.</p>
      <a class="btn wide" href="<?= e(url('register')) ?>">Oldindan ro'yxatdan o'tish</a>
    <?php endif; ?>
  </div>
</section>
<section class="grid2 home-actions">
  <div class="card">
    <h2>Natijani bilish</h2>
    <p class="muted small">ID (yoki telefon) va parolingizni kiriting.</p>
    <form method="post" action="<?= e(url('student_login')) ?>" class="form row gap wrap home-login">
      <?= csrf_field() ?>
      <label>ID yoki telefon <input name="ident" maxlength="20" required class="big-input" placeholder="123456" autocomplete="username"></label>
      <label>Parol <input name="pass" type="password" required class="big-input" placeholder="••••••" autocomplete="current-password"></label>
      <button class="btn primary">Kirish</button>
    </form>
    <p class="small"><a href="<?= e(url('student_reset')) ?>">Parolni unutdingizmi?</a></p>
  </div>
  <div class="card">
    <h2>Sertifikatni tekshirish</h2>
    <p class="muted small">Sertifikat raqamini kiriting yoki undagi QR kodni telefon kamerasi bilan skanerlang.</p>
    <form method="get" class="form row gap wrap home-login">
      <input type="hidden" name="p" value="verify">
      <label>Raqam <input name="n" required class="big-input" placeholder="M26-000123"></label>
      <button class="btn">Tekshirish</button>
    </form>
  </div>
</section>
<section class="grid3 steps mt">
  <div class="card"><h3>1. Ro'yxatdan o'ting</h3><p>MOCK ni tanlang, ma'lumotlaringizni kiriting va parol belgilang — ID beriladi.</p></div>
  <div class="card"><h3>2. Imtihon kuni</h3><p>Ismingiz yozilgan javoblar varaqasini to'ldirasiz yoki onlayn ishlaysiz.</p></div>
  <div class="card"><h3>3. Natija</h3><p>ID va parol bilan ball, daraja, har bir savol bo'yicha tahlil va sertifikatni olasiz.</p></div>
</section>
<?php page_footer();
