<?php
defined('APP_ROOT') || exit;
/**
 * Ota-ona uchun natija sahifasi. Kirish uchun akkaunt kerak emas — SMS/Telegram dagi havola imzolangan (HMAC):
 * ID + MOCK + token bir-biriga mos bo'lsagina ochiladi, boshqa o'quvchining natijasini taxmin qilib bo'lmaydi.
 */
$code = ''; $tid = 0; $k = '';
if (preg_match('/^(\d{6})\.(\d{1,9})\.([0-9a-f]{16})$/', (string)($_GET['c'] ?? ''), $mm)) { $code = $mm[1]; $tid = (int)$mm[2]; $k = $mm[3]; }
$s = $r = $test = null; $err = '';
if (throttle_wait('parentlink', client_ip(), 60, 60, 15)) {
    $err = 'Juda ko\'p so\'rov. Birozdan keyin urinib ko\'ring.';
} else {
    $s = $code !== '' ? row('SELECT * FROM students WHERE code=?', [$code]) : null;
    if (!$s || $tid <= 0 || !hash_equals(substr(parent_token((int)$s['id'], $tid), 0, 16), $k)) { throttle_fail('parentlink', client_ip()); $s = null; $err = 'Havola noto\'g\'ri yoki eskirgan.'; }
    else {
        $test = test_by_id($tid);
        $r = msg_result_row((int)$s['id'], $tid);
        if (!$test || !$r) $err = 'Natija hali e\'lon qilinmagan.';
    }
}
if ($s && is_post() && ($_POST['action'] ?? '') === 'optout') {
    csrf_check();
    q('UPDATE students SET parent_optout=? WHERE id=?', [!empty($_POST['undo']) ? 0 : 1, $s['id']]);
    flash(!empty($_POST['undo']) ? 'Natijalar yana yuboriladi' : 'Tushunarli — bundan keyin natijalar yuborilmaydi', 'ok');
    redirect('pr', ['c' => $code . '.' . $tid . '.' . $k]);
}
if ($s) $s = row('SELECT * FROM students WHERE id=?', [$s['id']]);
page_header('Natija', ['main' => 'narrow-main']);
?>
<div class="card narrow" style="max-width:560px">
  <?php if ($err): ?>
    <h1>Natija</h1><div class="alert err"><?= e($err) ?></div>
  <?php else: $sec = section_scores($test, (string)val('SELECT scored FROM results WHERE test_id=? AND student_id=?', [$tid, $s['id']]), (float)$r['ball']); ?>
    <div class="eyebrow"><?= e(app_setting('center')) ?></div>
    <h1><?= e($s['full_name']) ?></h1>
    <p class="muted" style="margin-top:0"><?= e($r['title']) ?><?= $test['test_date'] ? ' · ' . e(date('d.m.Y', strtotime($test['test_date']))) : '' ?></p>
    <div class="stats4" style="grid-template-columns:repeat(3,1fr)">
      <div class="stat"><span><?= fmt($r['ball']) ?></span>Ball</div>
      <div class="stat"><span><?= grade_badge($r['grade']) ?></span>Daraja</div>
      <div class="stat"><span><?= (int)$r['rank_no'] ?><small> / <?= (int)$r['total'] ?></small></span>O'rin</div>
    </div>
    <?php if ($sec): ?>
      <h3 class="mt">Bo'limlar bo'yicha</h3>
      <table class="tbl compact-tbl"><thead><tr><th>Bo'lim</th><th class="num">To'g'ri javoblar</th><th class="num">Ball</th></tr></thead><tbody>
        <?php foreach ($sec as $x): ?><tr><td><?= e($x['name']) ?></td><td class="num"><?= (int)$x['ok'] ?> / <?= (int)$x['total'] ?></td><td class="num"><?= fmt($x['ball']) ?></td></tr><?php endforeach; ?>
      </tbody></table>
    <?php endif; ?>
    <p class="small muted mt">Ball Rasch modeli asosida hisoblangan: savollarning qiyinligi hisobga olinadi, shuning uchun to'g'ri javoblar soni bir xil bo'lgan o'quvchilarning balli farq qilishi mumkin. Sertifikat chegarasi — 46 ball.</p>
    <form method="post" class="mt" onsubmit="return confirm('<?= $s['parent_optout'] ? 'Natijalarni yana yuborishni yoqasizmi?' : 'Bundan keyin natijalar yuborilmasin?' ?>')">
      <?= csrf_field() ?><input type="hidden" name="action" value="optout"><?php if ($s['parent_optout']): ?><input type="hidden" name="undo" value="1"><?php endif; ?>
      <button class="btn sm ghost"><?= $s['parent_optout'] ? 'Natijalarni yana yuborish' : 'Natijalarni bundan keyin yubormang' ?></button>
    </form>
  <?php endif; ?>
</div>
<?php page_footer();
