<?php
/**
 * Front controller: index.php?p=<sahifa>
 */
declare(strict_types=1);
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';

$routes = [
    // ommaviy
    'home' => 'public', 'login' => 'public', 'logout' => 'public', 'rasch' => 'admin',
    'student_login' => 'public', 'student_logout' => 'public', 'register' => 'public', 'verify' => 'public', 'moc' => 'public', 'tg_login' => 'public', 'student_reset' => 'public',
    'certificate' => 'any', 'pdf' => 'any', 'qb_img' => 'any',
    // o'quvchi
    'student_home' => 'student', 'student_test' => 'student', 'student_result' => 'student', 'student_setpass' => 'student', 'student_profile' => 'student', 'student_practice' => 'student', 'student_practice_do' => 'student', 'student_practice_pdf' => 'student',
    // admin
    'dashboard' => 'admin', 'tests' => 'admin', 'test_edit' => 'admin', 'students' => 'admin',
    'entry' => 'admin', 'import' => 'admin', 'scan' => 'admin', 'sheet' => 'admin',
    'results' => 'admin', 'analysis' => 'admin', 'open_review' => 'admin', 'export' => 'admin',
    'result_card' => 'admin', 'responses' => 'admin', 'cards' => 'admin',
    'groups' => 'admin', 'centers' => 'admin', 'center_report' => 'admin', 'registrations' => 'admin', 'room_list' => 'admin', 'room_door' => 'admin', 'parent_send' => 'admin', 'parent_result' => 'public', 'pr' => 'public', 'results_list' => 'admin', 'tg_monitor' => 'admin', 'settings' => 'admin',
    'qb' => 'admin', 'qb_questions' => 'admin', 'qb_import' => 'admin', 'qb_api' => 'admin', 'qb_pdf' => 'admin',
    // ajax
    'api' => 'api',
];

$p = $_GET['p'] ?? (admin() ? 'dashboard' : 'home');
if (!isset($routes[$p])) {
    http_response_code(404);
    $p = 'home';
}
$access = $routes[$p];
if ($access === 'admin') require_admin();
if ($access === 'student') require_student();

try {
    require __DIR__ . '/pages/' . $p . '.php';
} catch (Throwable $ex) {
    // Tafsilotlar faqat server jurnaliga yoziladi — foydalanuvchiga ichki ma'lumot ko'rsatilmaydi
    error_log('[MOCK Rasch] ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
    if (!headers_sent()) http_response_code(500);
    if (($routes[$p] ?? '') === 'api') json_out(['ok' => false, 'error' => 'Server xatosi'], 500);
    page_header('Xatolik');
    echo '<div class="card narrow"><h1>Xatolik yuz berdi</h1><p class="muted">So\'rovni bajarib bo\'lmadi. Sahifani yangilab qayta urinib ko\'ring.' . (admin() ? ' Tafsilot: <code>' . e($ex->getMessage()) . '</code>' : '') . '</p></div>';
    page_footer();
}
