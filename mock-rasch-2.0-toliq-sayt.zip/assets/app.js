/* Umumiy skriptlar: jadvalni saralash */
document.querySelectorAll('table.sortable').forEach(tbl => {
  tbl.querySelectorAll('thead th').forEach((th, ci) => {
    th.classList.add('sort-h');
    th.addEventListener('click', () => {
      const body = tbl.tBodies[0];
      const asc = th.dataset.dir !== 'asc';
      tbl.querySelectorAll('thead th').forEach(x => delete x.dataset.dir);
      th.dataset.dir = asc ? 'asc' : 'desc';
      const val = td => {
        if (!td) return '';
        if (td.dataset.v !== undefined) return parseFloat(td.dataset.v);
        const t = td.textContent.trim().replace(/\s/g, '');
        const n = parseFloat(t.replace(',', '.'));
        return isNaN(n) ? t.toLowerCase() : n;
      };
      [...body.rows].sort((a, b) => {
        const x = val(a.cells[ci]), y = val(b.cells[ci]);
        const r = (typeof x === 'number' && typeof y === 'number') ? x - y : String(x).localeCompare(String(y));
        return asc ? r : -r;
      }).forEach(r => body.appendChild(r));
    });
  });
});

/* Kunduzgi / tungi rejim */
(function () {
  const root = document.documentElement;
  const isDark = () => root.getAttribute('data-theme') === 'dark' ||
    (!root.getAttribute('data-theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
  const paint = () => document.querySelectorAll('.theme-toggle').forEach(b => {
    const span = b.querySelector('span');
    if (span) span.textContent = isDark() ? 'Kunduzgi rejim' : 'Tungi rejim';
    b.setAttribute('aria-pressed', isDark() ? 'true' : 'false');
  });
  document.querySelectorAll('.theme-toggle').forEach(b => b.addEventListener('click', () => {
    const next = isDark() ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('moc-theme', next); } catch (e) { /* saqlab bo'lmadi */ }
    paint();
  }));
  paint();
})();
