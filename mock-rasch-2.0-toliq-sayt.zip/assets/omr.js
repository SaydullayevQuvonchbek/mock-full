/*
 * MOCK Rasch — brauzerda ishlaydigan OMR (javoblar varaqasini o'qish).
 * Tashqi kutubxonasiz: 4 ta burchak markeri → gomografiya → pufakchalar qorayishini o'lchash.
 * Koordinatalar sheet_layout.php dan (mm) keladi.
 */
(function (global) {
  'use strict';

  const MAX_SIDE = 1700;

  function toCanvas(src) {
    const w0 = src.naturalWidth || src.videoWidth || src.width;
    const h0 = src.naturalHeight || src.videoHeight || src.height;
    const k = Math.min(1, MAX_SIDE / Math.max(w0, h0));
    const c = document.createElement('canvas');
    c.width = Math.round(w0 * k); c.height = Math.round(h0 * k);
    const ctx = c.getContext('2d', { willReadFrequently: true });
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(src, 0, 0, c.width, c.height);
    return c;
  }

  function grayOf(canvas) {
    const { width: W, height: H } = canvas;
    const d = canvas.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, W, H).data;
    const g = new Uint8ClampedArray(W * H);
    for (let i = 0, j = 0; i < g.length; i++, j += 4) g[i] = (d[j] * 299 + d[j + 1] * 587 + d[j + 2] * 114) / 1000;
    return { g, W, H };
  }

  function integral(g, W, H) {
    const I = new Float64Array((W + 1) * (H + 1));
    for (let y = 1; y <= H; y++) {
      let row = 0;
      for (let x = 1; x <= W; x++) {
        row += g[(y - 1) * W + (x - 1)];
        I[y * (W + 1) + x] = I[(y - 1) * (W + 1) + x] + row;
      }
    }
    return I;
  }

  function boxMean(I, W, H, x, y, r) {
    const x0 = Math.max(0, x - r), y0 = Math.max(0, y - r);
    const x1 = Math.min(W, x + r + 1), y1 = Math.min(H, y + r + 1);
    const s = I[y1 * (W + 1) + x1] - I[y0 * (W + 1) + x1] - I[y1 * (W + 1) + x0] + I[y0 * (W + 1) + x0];
    return s / ((x1 - x0) * (y1 - y0));
  }

  /** Qora komponentlarni topish (markerlar uchun) */
  function findBlobs(gray, I) {
    const { g, W, H } = gray;
    const win = Math.round(Math.max(W, H) / 10);
    const bin = new Uint8Array(W * H);
    const step = 2; // tezlik uchun lokal o'rtachani har 2 pikselda hisoblaymiz
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const m = boxMean(I, W, H, x - (x % step), y - (y % step), win);
        bin[y * W + x] = g[y * W + x] < Math.min(m * 0.62, 150) ? 1 : 0;
      }
    }
    const lab = new Int32Array(W * H);
    const blobs = [];
    const stack = new Int32Array(W * H);
    let id = 0;
    for (let p = 0; p < W * H; p++) {
      if (!bin[p] || lab[p]) continue;
      id++;
      let sp = 0; stack[sp++] = p; lab[p] = id;
      let area = 0, sx = 0, sy = 0, minx = W, maxx = 0, miny = H, maxy = 0;
      while (sp) {
        const q = stack[--sp];
        const x = q % W, y = (q / W) | 0;
        area++; sx += x; sy += y;
        if (x < minx) minx = x; if (x > maxx) maxx = x; if (y < miny) miny = y; if (y > maxy) maxy = y;
        if (x > 0 && bin[q - 1] && !lab[q - 1]) { lab[q - 1] = id; stack[sp++] = q - 1; }
        if (x < W - 1 && bin[q + 1] && !lab[q + 1]) { lab[q + 1] = id; stack[sp++] = q + 1; }
        if (y > 0 && bin[q - W] && !lab[q - W]) { lab[q - W] = id; stack[sp++] = q - W; }
        if (y < H - 1 && bin[q + W] && !lab[q + W]) { lab[q + W] = id; stack[sp++] = q + W; }
      }
      const bw = maxx - minx + 1, bh = maxy - miny + 1;
      if (area < 30) continue;
      blobs.push({ id, area, cx: sx / area, cy: sy / area, bw, bh, minx, miny, fill: area / (bw * bh),
        bcx: minx + (bw - 1) / 2, bcy: miny + (bh - 1) / 2,
        touches: minx === 0 || miny === 0 || maxx === W - 1 || maxy === H - 1 });
    }
    // Ichi bo'sh (CamScanner kabi filtrlar kvadrat ichini oqartirib yuboradi) markerlar uchun:
    // blob piksellarining qancha qismi ramka chetidagi 28% li kamarda yotganini hisoblaymiz
    for (const b of blobs) {
      if (b.fill > 0.55 || b.area > 40000) { b.edge = 1; continue; }
      const band = Math.max(2, Math.round(Math.min(b.bw, b.bh) * 0.28));
      let onEdge = 0;
      for (let y = b.miny; y < b.miny + b.bh; y++) {
        const yin = y - b.miny >= band && b.miny + b.bh - 1 - y >= band;
        for (let x = b.minx; x < b.minx + b.bw; x++) {
          if (lab[y * W + x] !== b.id) continue;
          if (!yin || x - b.minx < band || b.minx + b.bw - 1 - x < band) onEdge++;
        }
      }
      b.edge = onEdge / b.area;
    }
    return blobs;
  }

  function pickMarkers(blobs, W, H) {
    const minS = Math.min(W, H);
    // To'liq qora kvadrat (fill > 0.55) yoki ichi bo'sh ramka/burchak chizig'i (piksellari chetda, edge > 0.85)
    const cand = blobs.filter(b => !b.touches && b.bw / b.bh > 0.6 && b.bw / b.bh < 1.67
      && Math.max(b.bw, b.bh) > minS * 0.012 && Math.max(b.bw, b.bh) < minS * 0.09
      && (b.fill > 0.55 || (b.fill > 0.1 && b.edge > 0.85)));
    const quads = [
      b => b.cx < W / 2 && b.cy < H / 2, b => b.cx >= W / 2 && b.cy < H / 2,
      b => b.cx >= W / 2 && b.cy >= H / 2, b => b.cx < W / 2 && b.cy >= H / 2,
    ];
    const corners = [[0, 0], [W, 0], [W, H], [0, H]];
    // Har chorakda burchakka eng yaqin 4 tagacha nomzod (+ "yo'q" varianti)
    const lists = quads.map((q, k) => {
      const inQ = cand.filter(q);
      inQ.sort((a, b) => Math.hypot(a.bcx - corners[k][0], a.bcy - corners[k][1]) - Math.hypot(b.bcx - corners[k][0], b.bcy - corners[k][1]));
      return inQ.slice(0, 4).concat([null]);
    });
    // Barcha kombinatsiyalar: 4 yoki 3 marker; geometriya bo'yicha eng yaxshisi
    const size = b => Math.max(b.bw, b.bh);
    let best = null;
    const evalCombo = (pts, missing) => {
      const P = pts.slice();
      if (missing >= 0) { const o = (missing + 2) % 4, a1 = (missing + 1) % 4, b1 = (missing + 3) % 4; P[missing] = [P[a1][0] + P[b1][0] - P[o][0], P[a1][1] + P[b1][1] - P[o][1]]; }
      const d = (i, j) => Math.hypot(P[i][0] - P[j][0], P[i][1] - P[j][1]);
      const top = d(0, 1), bot = d(3, 2), left = d(0, 3), right = d(1, 2);
      if (Math.min(top, bot, left, right) < minS * 0.2) return null;
      const aspect = (top + bot) / (left + right);           // 0.68 (portret) yoki 1.47 (albom)
      const asp = Math.min(Math.abs(Math.log(aspect / 0.681)), Math.abs(Math.log(aspect / 1.468)));
      if (asp > 0.35) return null;                                          // ±40% dan ortiq — bu varaq emas
      const par = (Math.abs(top - bot) / Math.max(top, bot) + Math.abs(left - right) / Math.max(left, right)) / 2; // perspektivada 0.3 gacha
      // Qavariqlik: to'rtburchak o'z-o'zini kesmasin
      const cross = (i, j, k) => (P[j][0] - P[i][0]) * (P[k][1] - P[j][1]) - (P[j][1] - P[i][1]) * (P[k][0] - P[j][0]);
      const signs = [cross(0, 1, 2), cross(1, 2, 3), cross(2, 3, 0), cross(3, 0, 1)];
      if (!(signs.every(v => v > 0) || signs.every(v => v < 0))) return null;
      // Burchaklar 90° ga yaqin bo'lsin (perspektivada ±15°); yolg'on nomzod (harf, doiracha) buni buzadi
      let ang = 0;
      for (let i = 0; i < 4; i++) {
        const p = P[(i + 3) % 4], c = P[i], n = P[(i + 1) % 4];
        const v1 = [p[0] - c[0], p[1] - c[1]], v2 = [n[0] - c[0], n[1] - c[1]];
        const cos = (v1[0] * v2[0] + v1[1] * v2[1]) / (Math.hypot(v1[0], v1[1]) * Math.hypot(v2[0], v2[1]) || 1);
        ang += Math.abs(Math.acos(Math.max(-1, Math.min(1, cos))) - Math.PI / 2) / (Math.PI / 2);   // 0 = to'g'ri burchak
      }
      if (ang / 4 > 0.25) return null;                                     // o'rtacha 22° dan ortiq og'ish — varaq emas
      if (missing >= 0 && (P[missing][0] < -minS * 0.05 || P[missing][1] < -minS * 0.05 || P[missing][0] > W + minS * 0.05 || P[missing][1] > H + minS * 0.05)) return null;
      return asp * 3 + par * 2 + ang * 2 + (missing >= 0 ? 0.5 : 0);
    };
    for (const a of lists[0]) for (const b of lists[1]) for (const c of lists[2]) for (const d of lists[3]) {
      const mk = [a, b, c, d];
      const miss = mk.map((m, i) => m ? -1 : i).filter(i => i >= 0);
      if (miss.length > 1) continue;
      const found = mk.filter(Boolean);
      const sz = found.map(size).sort((x, y) => x - y);
      if (sz[sz.length - 1] / sz[0] > 1.8) continue;
      const score = evalCombo(mk.map(m => m ? [m.bcx, m.bcy] : null), miss.length ? miss[0] : -1);
      if (score === null) continue;
      // Markerlar bir xil o'lchamda bo'lsin (harf yoki doiracha aralashsa — jarima); kattaroq afzal
      const spread = (sz[sz.length - 1] / sz[0] - 1) * 0.8;
      const sizeBonus = -Math.log(sz[0] / (minS * 0.03)) * 0.15;
      const total = score + spread + Math.max(-0.3, Math.min(0.3, sizeBonus));
      if (!best || total < best.total) best = { total, mk, miss: miss.length ? miss[0] : -1 };
    }
    if (!best) return null;
    const res = best.mk.map(m => m ? { bcx: m.bcx, bcy: m.bcy, bw: m.bw, bh: m.bh } : null);
    res.cand = cand;
    if (best.miss >= 0) {
      const m = best.miss, o = (m + 2) % 4, a1 = (m + 1) % 4, b1 = (m + 3) % 4;
      res[m] = { bcx: res[a1].bcx + res[b1].bcx - res[o].bcx, bcy: res[a1].bcy + res[b1].bcy - res[o].bcy, estimated: true };
    }
    return res;
  }

  /** 4 nuqtadan gomografiya: (x,y) mm → (u,v) px */
  function homography(src, dst) {
    const A = [], B = [];
    for (let i = 0; i < 4; i++) {
      const [x, y] = src[i], [u, v] = dst[i];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); B.push(u);
      A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); B.push(v);
    }
    const h = solve(A, B);
    h.push(1);
    return h;
  }

  function solve(A, b) {
    const n = b.length;
    const M = A.map((r, i) => r.concat([b[i]]));
    for (let c = 0; c < n; c++) {
      let p = c;
      for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
      [M[c], M[p]] = [M[p], M[c]];
      const d = M[c][c] || 1e-12;
      for (let r = 0; r < n; r++) {
        if (r === c) continue;
        const f = M[r][c] / d;
        for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
      }
    }
    return M.map((r, i) => r[n] / (r[i] || 1e-12));
  }

  function project(h, x, y) {
    const w = h[6] * x + h[7] * y + h[8];
    return [(h[0] * x + h[1] * y + h[2]) / w, (h[3] * x + h[4] * y + h[5]) / w];
  }

  function makeSampler(gray, I, h) {
    const { g, W, H } = gray;
    const win = Math.round(Math.max(W, H) / 40);
    return function darkness(xmm, ymm, rmm, inner = 0.6) {
      const [u, v] = project(h, xmm, ymm);
      const [u2, v2] = project(h, xmm + rmm, ymm);
      const rp = Math.max(2, Math.hypot(u2 - u, v2 - v) * inner);
      let s = 0, n = 0;
      const r2 = rp * rp;
      for (let y = Math.floor(v - rp); y <= Math.ceil(v + rp); y++) {
        if (y < 0 || y >= H) continue;
        for (let x = Math.floor(u - rp); x <= Math.ceil(u + rp); x++) {
          if (x < 0 || x >= W) continue;
          if ((x - u) * (x - u) + (y - v) * (y - v) > r2) continue;
          s += g[y * W + x]; n++;
        }
      }
      if (!n) return 0;
      const inside = s / n;
      // Qog'oz oqligi: kattaroq atrofdagi yorqin qiymat
      const white = Math.max(boxMean(I, W, H, Math.round(u), Math.round(v), win), inside, 60);
      const ref = Math.max(white, localWhite(g, W, H, u, v, rp * 3.2));
      return Math.max(0, Math.min(1, 1 - inside / ref));
    };
  }

  // Atrofdagi 85-persentil yorqinlik (qog'oz rangi)
  function localWhite(g, W, H, u, v, R) {
    const vals = [];
    const st = Math.max(1, Math.round(R / 8));
    for (let y = Math.floor(v - R); y <= v + R; y += st) {
      if (y < 0 || y >= H) continue;
      for (let x = Math.floor(u - R); x <= u + R; x += st) {
        if (x < 0 || x >= W) continue;
        vals.push(g[y * W + x]);
      }
    }
    if (!vals.length) return 200;
    vals.sort((a, b) => a - b);
    return vals[Math.floor(vals.length * 0.85)];
  }

  /**
   * Mahalliy moslash: bir guruh doirachalar (bitta qator) uchun (dx, dy) mm siljishni topadi.
   * Har nomzod siljishda "doira ko'rinishi" balli: bosilgan halqa qorayishi (bo'sh doiracha) yoki
   * ichi qorayishi (bo'yalgan doiracha). Guruh bo'yicha yig'indi eng katta bo'lgan siljish olinadi;
   * u kutilgan joydan sezilarli yaxshi bo'lsagina qo'llanadi.
   */
  function makeRefiner(gray, P, rmm) {
    const { g, W, H } = gray;
    const [u0, v0] = P(100, 150), [u1, v1] = P(100 + rmm, 150);
    const rp = Math.hypot(u1 - u0, v1 - v0);           // doiracha radiusi (px)
    // Halqa: 5 xil radiusda 24 nuqta; radiuslar ichida eng qorasini olamiz — bosilgan doira radiusi ±20% farq qilsa ham topiladi
    const rings = [0.8, 0.9, 1.0, 1.1, 1.2].map(rr => { const pts = []; for (let a = 0; a < 24; a++) pts.push([Math.cos(a * Math.PI / 12) * rp * rr, Math.sin(a * Math.PI / 12) * rp * rr]); return pts; });
    const inPts = [];
    const st = Math.max(1, rp / 4);
    for (let y = -rp * 0.55; y <= rp * 0.55; y += st) for (let x = -rp * 0.55; x <= rp * 0.55; x += st) if (x * x + y * y <= rp * rp * 0.3) inPts.push([x, y]);
    const at = (u, v) => { const x = Math.round(u), y = Math.round(v); return (x < 0 || y < 0 || x >= W || y >= H) ? 255 : g[y * W + x]; };
    const circleScore = (u, v, white, ringOnly) => {
      let ringDark = 0;
      for (const pts of rings) { let ring = 0; for (const [dx, dy] of pts) ring += at(u + dx, v + dy); ringDark = Math.max(ringDark, 1 - ring / pts.length / white); }
      if (ringOnly) return ringDark;   // dag'al bosqich: faqat doira konturi (savol raqamlari "bo'yalgan" bo'lib ko'rinmasin)
      let inn = 0; for (const [dx, dy] of inPts) inn += at(u + dx, v + dy);
      const innDark = 1 - inn / inPts.length / white;
      return Math.max(ringDark - innDark * 0.5, innDark);
    };
    return function refine(bs, center, R, step, lam) {
      center = center || [0, 0]; R = R || 1.5; step = step || 0.375;   // mm
      const coarse = lam !== undefined;                                   // dag'al bosqich (butun ustun): faqat halqa bali
      lam = coarse ? lam : 0.02;                                           // siljish jarimasi (ball / mm)
      const centers = bs.map(b => { const [u, v] = P(b.x, b.y); return { u, v, white: Math.max(60, localWhite(g, W, H, u, v, rp * 3.2)) }; });
      // mm → px yo'nalishi (mahalliy): 1 mm x va y bo'yicha vektor
      const c0 = centers[0]; const [ux, vx] = P(bs[0].x + 1, bs[0].y), [uy, vy] = P(bs[0].x, bs[0].y + 1);
      const ex = [ux - c0.u, vx - c0.v], ey = [uy - c0.u, vy - c0.v];
      // Dag'al bosqichda o'rtacha bilan birga eng past 10% ham hisobga olinadi: bir qator/ustunga "sakrab" o'tsa
      // (aliasing) bir qator doirachalar bo'sh qog'ozga tushadi va bu ko'rsatkich nolga tushadi — to'g'ri joyda esa
      // barcha bosma halqalar ko'rinadi.
      const scoreAt = (dx, dy) => {
        const v = centers.map(c => circleScore(c.u + ex[0] * dx + ey[0] * dy, c.v + ex[1] * dx + ey[1] * dy, c.white, coarse));
        const mean = v.reduce((a, b) => a + b, 0) / v.length;
        if (!coarse || v.length < 4) return mean;
        v.sort((a, b) => a - b);
        return 0.7 * mean + 0.3 * v[Math.floor(v.length * 0.1)];
      };
      let best = center.slice(), bestS = -1;
      const base = scoreAt(center[0], center[1]);
      for (let dy = center[1] - R; dy <= center[1] + R + 1e-9; dy += step) for (let dx = center[0] - R; dx <= center[0] + R + 1e-9; dx += step) {
        const dist = Math.hypot(dx - center[0], dy - center[1]);
        // Siljish uchun jarima: 1 mm uzoqlashish kamida 0.03 ball yaxshilanishni talab qiladi (tekis varaqda "sudralib" ketmasin)
        const sc = scoreAt(dx, dy) - lam * dist - lam * 0.5 * Math.hypot(dx, dy);
        // teng ballda markazga yaqin nomzod afzal
        if (sc > bestS + 1e-6 || (Math.abs(sc - bestS) <= 1e-6 && dist < Math.hypot(best[0] - center[0], best[1] - center[1]))) { bestS = sc; best = [dx, dy]; }
      }
      return bestS > base + 0.03 ? best : center.slice();
    };
  }

  function decide(values, T) {
    // values: [{v, d}] → {val, flag}
    const s = values.slice().sort((a, b) => b.d - a.d);
    const d1 = s[0].d, d2 = s[1] ? s[1].d : 0;
    if (d1 < T) return { val: '', flag: d1 > T * 0.75 ? 'uncertain' : '' };
    if (d2 >= T && d2 > d1 * 0.62) return { val: '*', flag: 'multi' };
    return { val: s[0].v, flag: (d1 < T * 1.3 || d2 > T * 0.8) ? 'uncertain' : '' };
  }

  /**
   * Asosiy funksiya. src — Image/Canvas/ImageBitmap. L — layout.
   */
  function process(src, L) {
    const canvas = toCanvas(src);
    const gray = grayOf(canvas);
    const I = integral(gray.g, gray.W, gray.H);
    const blobs = findBlobs(gray, I);
    const mk = pickMarkers(blobs, gray.W, gray.H);
    if (!mk) return { ok: false, error: 'Burchakdagi 4 ta qora marker topilmadi. Varaq to\'liq va tekis tushgan bo\'lsin.', canvas };
    const dst0 = mk.map(b => [b.bcx, b.bcy]);
    const markersUsed = mk.filter(b => !b.estimated).length;
    // Rasm 0°, 90°, 180° yoki 270° burilgan bo'lishi mumkin: 4 ta moslikni sinab,
    // sahifa nisbati (186 × 273 mm) to'g'ri va yo'nalish chizig'i eng qora bo'lganini olamiz
    const o = L.orient;
    const ox = o.x + o.w / 2, oy = o.y + o.h / 2;
    let best = null;
    for (let k = 0; k < 4; k++) {
      const dst = [dst0[k], dst0[(k + 1) % 4], dst0[(k + 2) % 4], dst0[(k + 3) % 4]];
      const top = Math.hypot(dst[1][0] - dst[0][0], dst[1][1] - dst[0][1]);
      const left = Math.hypot(dst[3][0] - dst[0][0], dst[3][1] - dst[0][1]);
      const aspect = top / Math.max(1, left);           // to'g'ri moslikda ≈ 0.68, noto'g'risida ≈ 1.47
      if (aspect > 1.05) continue;
      const hk = homography(L.markers, dst);
      const sk = makeSampler(gray, I, hk);
      const dk = sk(ox, oy, o.h * 0.45, 1);
      const score = dk - sk(L.page.w - ox, L.page.h - oy, o.h * 0.45, 1);
      if (!best || score > best.score) best = { k, h: hk, sample: sk, dst, score, orientDark: dk };
    }
    if (!best) return { ok: false, error: 'Markerlar joylashuvi varaq nisbatiga mos kelmadi. Butun varaq rasmga tushsin.', canvas };
    if (best.orientDark < 0.25) return { ok: false, error: 'Varaq topilmadi: burchak markerlari yoki yo\'nalish chizig\'i ko\'rinmayapti. Butun varaq tekis va yorug\' tushsin.', canvas };
    let { h, sample, dst } = best;
    const rotated = best.k ? best.k * 90 : 0;

    // Yon markerlar (1.5+ varaqlar): chap/o'ng chetda qo'shimcha kvadratlar. Topilgan juftlar varaqni gorizontal
    // bo'laklarga (bandlarga) ajratadi; har band o'z 4 markeri bilan alohida tekislanadi — buklangan varaq uchun.
    const mkSize = mk.filter(b => !b.estimated).reduce((a, b) => a + Math.max(b.bw, b.bh), 0) / markersUsed;
    const [pa, pb] = [project(h, 100, 150), project(h, 101, 150)];
    const pxPerMm = Math.hypot(pa[0] - pb[0], pa[1] - pb[1]);
    const sideFound = [];
    const rows = [{ y: L.markers[0][1], L: dst[0], R: dst[1] }];
    (L.sides || []).forEach(pair => {
      const got = pair.map(([mx, my]) => {
        const [eu, ev] = project(h, mx, my);
        let bestB = null, bd = 1e9;
        for (const c of mk.cand) {
          const dd = Math.hypot(c.bcx - eu, c.bcy - ev);
          const sz = Math.max(c.bw, c.bh);
          if (dd < pxPerMm * 9 && dd < bd && sz > mkSize * 0.55 && sz < mkSize * 1.6) { bd = dd; bestB = c; }
        }
        return bestB;
      });
      if (got[0] && got[1]) { rows.push({ y: pair[0][1], L: [got[0].bcx, got[0].bcy], R: [got[1].bcx, got[1].bcy] }); sideFound.push(...got); }
    });
    rows.push({ y: L.markers[3][1], L: dst[3], R: dst[2] });
    rows.sort((a, b) => a.y - b.y);
    // Har band uchun gomografiya: [chap-yuqori, o'ng-yuqori, o'ng-past, chap-past]
    const bands = [];
    for (let i = 0; i + 1 < rows.length; i++) {
      const a = rows[i], b = rows[i + 1];
      const hb = rows.length === 2 ? h : homography([[L.markers[0][0], a.y], [L.markers[1][0], a.y], [L.markers[1][0], b.y], [L.markers[0][0], b.y]], [a.L, a.R, b.R, b.L]);
      bands.push({ y0: a.y, y1: b.y, h: hb, sample: rows.length === 2 ? sample : makeSampler(gray, I, hb) });
    }
    const bandFor = y => bands.find(bd => y < bd.y1) || bands[bands.length - 1];
    const Hfor = y => bandFor(y).h;
    const P = (x, y) => project(Hfor(y), x, y);
    const sampleAt = (x, y, rr, inner) => bandFor(y).sample(x, y, rr, inner);

    // Mahalliy moslash: buklangan/egilgan varaqda doirachalar gomografiya bergan joydan siljiydi —
    // har bir qatorni ±1.5 mm atrofda bosilgan doiralar bo'yicha qayta topamiz
    const r = L.r;
    const refine = makeRefiner(gray, P, r);
    const all = [];
    const meas = (b, off) => { const d = sampleAt(b.x + off[0], b.y + off[1], r); all.push(d); return d; };
    // Buklanish silliq o'zgaradi: har ustunda yuqoridan pastga, har qator oldingi qator siljishi atrofida qidiriladi
    const idVals = L.id.cols.map(col => col.map(b => ({ v: b.v, x: b.x, y: b.y })));
    // Qatorlar ketma-ket, oldingi qator siljishi atrofida (±1.5 mm) — buklanish silliq o'zgaradi.
    // ID: qator bo'yicha (6 ta doiracha birgalikda — bittalab qidirsa qo'shni bo'yalgan doiracha "tortib" oladi)
    // Avval butun blok bo'yicha dag'al qidiruv (faqat halqa balli, qadam yarim mm, ±4 mm), keyin qatorma-qator aniq qidiruv.
    { let prev = refine(idVals.flat(), [0, 0], 4.0, 0.5, 0.01);
      for (let row = 0; row < 10; row++) {
        const bs = idVals.map(col => col[row]).filter(Boolean);
        const off = refine(bs, prev, 1.5);
        bs.forEach(b => { b.d = meas(b, off); b.off = off; }); prev = off;
      } }
    const mcVals = L.mc.map(q => ({ label: q.label, nx: q.nx, opts: q.opts.map(b => ({ v: b.v, x: b.x, y: b.y })) }));
    const byCol = new Map();
    mcVals.forEach(q => { if (!byCol.has(q.nx)) byCol.set(q.nx, []); byCol.get(q.nx).push(q); });
    byCol.forEach(qs => {
      // Ustun bo'yicha dag'al qidiruv ±6 mm (36 ta halqa birgalikda), keyin qatorma-qator
      let prev = refine(qs.flatMap(q => q.opts), [0, 0], 6.0, 0.5, 0.01);
      qs.forEach(q => { const off = refine(q.opts, prev, 1.5); q.opts.forEach(b => { b.d = meas(b, off); b.off = off; }); prev = off; });
    });
    // Ochiq qismlar: ikki doiracha — ✓ (x) va ✗ (xw); ustunlar bo'yicha ketma-ket
    const openVals = L.open.map(b => ({ label: b.label, x: b.x, xw: b.xw, y: b.y }));
    const openCols = new Map();
    openVals.forEach(b => { const key = b.x < L.page.w / 2 ? 0 : 1; if (!openCols.has(key)) openCols.set(key, []); openCols.get(key).push(b); });
    openCols.forEach(bs => {
      const allPts = bs.flatMap(b => b.xw !== undefined ? [{ x: b.x, y: b.y }, { x: b.xw, y: b.y }] : [{ x: b.x, y: b.y }]);
      // Ochiq bo'lim yuqori band chegarasidan (yon markerlar) pastda — buklanish chizig'i shu oraliqqa tushsa butun bo'lim
      // siljiydi. Shuning uchun avval butun ustun (10 doiracha) bo'yicha ±4.5 mm dag'al qidiruv (faqat halqa), keyin qatorma-qator.
      let prev = allPts.length >= 4 ? refine(allPts, [0, 0], 4.5, 0.5, 0.01) : [0, 0];
      bs.forEach(b => {
        const pair = [{ x: b.x, y: b.y }]; if (b.xw !== undefined) pair.push({ x: b.xw, y: b.y });
        const off = refine(pair, prev, 1.5);
        b.dOk = meas(pair[0], off); b.dNo = pair[1] ? meas(pair[1], off) : 0; b.off = off; prev = off;
      });
    });
    const offs = [...idVals.flat(), ...mcVals.flatMap(q => q.opts), ...openVals].map(b => b.off || [0, 0]);
    const med = i => { const v = offs.map(o => o[i]).sort((a, b) => a - b); return v[Math.floor(v.length / 2)]; };
    const mx = med(0), my = med(1);
    let maxShift = 0;
    offs.forEach(o => { maxShift = Math.max(maxShift, Math.hypot(o[0] - mx, o[1] - my)); });
    const sorted = all.slice().sort((a, b) => a - b);
    const base = sorted[Math.floor(sorted.length * 0.5)] || 0;
    const T = Math.max(0.24, base + 0.17);

    const flags = [];
    let code = '';
    idVals.forEach((col, i) => {
      const dcs = decide(col, T);
      if (dcs.val === '' || dcs.val === '*') { code += '?'; flags.push('ID ' + (i + 1) + '-raqam ' + (dcs.val === '*' ? 'bir nechta' : 'bo\'sh')); }
      else code += dcs.val;
      col.forEach(b => { b.sel = b.v === dcs.val; b.multi = dcs.val === '*' && b.d >= T; });
    });
    const answers = {};
    const qflags = {};
    mcVals.forEach(q => {
      const dcs = decide(q.opts, T);
      answers[q.label] = dcs.val === '*' ? '' : dcs.val;
      if (dcs.flag) qflags[q.label] = dcs.flag;
      q.opts.forEach(b => { b.sel = b.v === dcs.val; b.multi = dcs.val === '*' && b.d >= T; });
    });
    const unchecked = [], both = [];
    openVals.forEach(b => {
      const two = b.xw !== undefined;
      b.ok = b.dOk >= T; b.no = two && b.dNo >= T;
      if (b.ok && b.no) {
        // ikkalasi bo'yalgan: aniq ustunlik bo'lsa kuchlisini olamiz, aks holda tekshiruvchiga qoldiramiz
        if (b.dOk > b.dNo * 1.6) { b.no = false; qflags[b.label] = 'uncertain'; }
        else if (b.dNo > b.dOk * 1.6) { b.ok = false; qflags[b.label] = 'uncertain'; }
        else { qflags[b.label] = 'multi'; both.push(b.label); }
      }
      if (b.ok && !b.no) answers[b.label] = '#1';
      else if (b.no && !b.ok) answers[b.label] = '#0';
      else { answers[b.label] = ''; if (!b.ok && !b.no && two) unchecked.push(b.label); }
      if (!qflags[b.label] && (Math.abs(b.dOk - T) < 0.06 || (two && Math.abs(b.dNo - T) < 0.06))) qflags[b.label] = 'uncertain';
    });
    if (markersUsed === 3) flags.push('Bitta burchak markeri topilmadi — o\'rni taxminan hisoblandi, javoblarni rasm bilan solishtiring');
    if (maxShift > 2.0) flags.push('Varaq egilgan yoki buklangan (doirachalar ' + maxShift.toFixed(1) + ' mm gacha siljigan) — mahalliy moslash qo\'llandi');
    if (both.length) flags.push('Ochiq: ✓ va ✗ ikkalasi bo\'yalgan: ' + both.join(', '));
    if (unchecked.length === openVals.length && openVals.length) flags.push('Ochiq topshiriqlar tekshiruvchi tomonidan belgilanmagan');
    else if (unchecked.length) flags.push('Ochiq, belgilanmagan: ' + unchecked.join(', '));
    const multi = Object.keys(qflags).filter(k => qflags[k] === 'multi');
    const unc = Object.keys(qflags).filter(k => qflags[k] === 'uncertain');
    if (multi.length) flags.push('Bir nechta belgilangan: ' + multi.join(', '));
    if (unc.length) flags.push('Noaniq: ' + unc.join(', '));

    // Vizual tekshiruv uchun chizish
    const ctx = canvas.getContext('2d');
    ctx.lineWidth = Math.max(1.5, canvas.width / 600);
    const drawB = (b, color, fill) => {
      const off = b.off || [0, 0];
      const [u, v] = P(b.x + off[0], b.y + off[1]);
      const [u2, v2] = P(b.x + off[0] + r, b.y + off[1]);
      const rp = Math.hypot(u2 - u, v2 - v) * 1.15;
      ctx.beginPath(); ctx.arc(u, v, rp, 0, Math.PI * 2);
      if (fill) { ctx.fillStyle = fill; ctx.fill(); }
      ctx.strokeStyle = color; ctx.stroke();
    };
    idVals.flat().forEach(b => b.multi ? drawB(b, '#e11d48', 'rgba(225,29,72,.25)') : b.sel ? drawB(b, '#16a34a', 'rgba(22,163,74,.25)') : null);
    mcVals.forEach(q => q.opts.forEach(b => {
      if (b.multi) drawB(b, '#e11d48', 'rgba(225,29,72,.25)');
      else if (b.sel) drawB(b, '#16a34a', 'rgba(22,163,74,.25)');
      else if (qflags[q.label] === 'uncertain' && b.d > T * 0.6) drawB(b, '#f59e0b');
    }));
    openVals.forEach(b => {
      drawB({ x: b.x, y: b.y, off: b.off }, b.ok ? '#16a34a' : 'rgba(100,116,139,.55)', b.ok ? 'rgba(22,163,74,.25)' : null);
      if (b.xw !== undefined) drawB({ x: b.xw, y: b.y, off: b.off }, b.no ? '#e11d48' : 'rgba(100,116,139,.55)', b.no ? 'rgba(225,29,72,.22)' : null);
    });
    dst0.forEach(([u, v], i) => { ctx.strokeStyle = mk[i].estimated ? '#f59e0b' : '#7c3aed'; ctx.beginPath(); ctx.arc(u, v, canvas.width / 70, 0, Math.PI * 2); ctx.stroke(); });
    ctx.strokeStyle = '#0ea5e9';
    sideFound.forEach(c => { ctx.beginPath(); ctx.arc(c.bcx, c.bcy, canvas.width / 80, 0, Math.PI * 2); ctx.stroke(); });

    return { ok: true, code, answers, flags, qflags, rotated, markersUsed, sideMarkers: sideFound.length, bands: bands.length, maxShift: +maxShift.toFixed(2), threshold: T, base, canvas, h,
      debug: {
        mc: mcVals.map(q => ({ label: q.label, opts: q.opts.map(o => ({ v: o.v, d: +o.d.toFixed(2) })), val: answers[q.label], flag: qflags[q.label] || '' })),
        id: idVals.map(c => c.map(b => ({ v: b.v, d: +b.d.toFixed(2) }))),
        open: openVals.map(b => ({ label: b.label, ok: +b.dOk.toFixed(2), no: +b.dNo.toFixed(2), val: answers[b.label], flag: qflags[b.label] || '' })),
        markers: dst.map(([u, v]) => [Math.round(u), Math.round(v)]), size: [gray.W, gray.H], shifts: mcVals.map(q => q.opts[0].off.map(v => +v.toFixed(1))),
      } };
  }

  global.MocOMR = { process };
})(window);
