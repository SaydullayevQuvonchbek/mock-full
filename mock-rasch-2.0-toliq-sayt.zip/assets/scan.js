/* Skaner sahifasi: navbat, OMR, tekshirish va saqlash */
(function () {
  'use strict';
  const S = window.SCAN;
  const csrf = document.querySelector('meta[name=csrf]').content;
  const queue = [];
  let current = -1;
  const $q = document.getElementById('queue');
  const $rev = document.getElementById('review');
  const $saveAll = document.getElementById('saveAll');

  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function addFiles(files) {
    [...files].forEach(f => {
      if (f.type === 'application/pdf' || /\.pdf$/i.test(f.name)) addPdf(f);
      else queue.push({ name: f.name, file: f, status: 'pending' });
    });
    renderQueue();
    pump();
  }

  let pdfLoading = null;
  function loadPdfJs() {
    if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
    if (pdfLoading) return pdfLoading;
    pdfLoading = new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = 'assets/pdfjs/pdf.min.js?v=3.11.174';   // platformaning o'zida (internet shart emas)
      s.onload = () => {
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'assets/pdfjs/pdf.worker.min.js?v=3.11.174';
        res(window.pdfjsLib);
      };
      s.onerror = () => rej(new Error('PDF o\'quvchi yuklanmadi (internet kerak). Rasmlarni JPG/PNG ko\'rinishida yuklang.'));
      document.head.appendChild(s);
    });
    return pdfLoading;
  }

  async function addPdf(f) {
    const holder = { name: f.name + ' (PDF yuklanmoqda…)', status: 'pending', placeholder: true };
    queue.push(holder); renderQueue();
    try {
      const lib = await loadPdfJs();
      const pdf = await lib.getDocument({ data: await f.arrayBuffer() }).promise;
      const idx = queue.indexOf(holder);
      queue.splice(idx, 1);
      const pages = [];
      for (let p = 1; p <= pdf.numPages; p++) pages.push({ name: f.name + ' — ' + p + '-bet', pdf, page: p, status: 'pending' });
      queue.splice(idx, 0, ...pages);
    } catch (e) {
      holder.status = 'error'; holder.error = e.message; holder.name = f.name;
    }
    renderQueue(); pump();
  }

  async function sourceOf(item) {
    if (item.pdf) {
      const page = await item.pdf.getPage(item.page);
      const vp0 = page.getViewport({ scale: 1 });
      const scale = 1700 / Math.max(vp0.width, vp0.height);
      const vp = page.getViewport({ scale });
      const c = document.createElement('canvas');
      c.width = vp.width; c.height = vp.height;
      await page.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
      return c;
    }
    const url = URL.createObjectURL(item.file);
    const img = new Image();
    await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error('Rasmni ochib bo\'lmadi')); img.src = url; });
    return img;
  }

  let busy = false;
  async function pump() {
    if (busy) return;
    const item = queue.find(i => i.status === 'pending' && !i.placeholder);
    if (!item) return;
    busy = true;
    item.status = 'working'; renderQueue();
    await new Promise(r => setTimeout(r, 20));
    try {
      const src = await sourceOf(item);
      const res = MocOMR.process(src, S.layout);
      item.result = res;
      if (!res.ok) { item.status = 'error'; item.error = res.error; }
      else {
        item.code = res.code.replace(/\?/g, '');
        item.mc = S.mc.map(l => res.answers[l] || '_').join('');
        item.open = {}; S.open.forEach(l => item.open[l] = res.answers[l] || '');
        item.flags = res.flags;
        item.status = (res.flags.length || res.code.includes('?')) ? 'warn' : 'ready';
        lookup(item);
      }
    } catch (e) {
      item.status = 'error'; item.error = e.message;
    }
    busy = false;
    renderQueue();
    if (current === -1 || queue[current] === item) show(queue.indexOf(item));
    pump();
  }

  async function lookup(item) {
    if (!/^\d{6}$/.test(item.code || '')) { item.student = null; return; }
    try {
      const r = await fetch('index.php?p=api&a=student&code=' + item.code + '&test=' + S.testId).then(r => r.json());
      item.student = r.student; item.hasResponse = r.has_response;
      if (r.student && !item.sname) item.sname = r.student.full_name;
    } catch (e) { /* tarmoq xatosi */ }
    renderQueue();
    if (queue[current] === item) show(current);
  }

  const statusText = { pending: 'navbatda', working: 'o\'qilmoqda…', ready: 'tayyor', warn: 'tekshiring', error: 'xato', saved: 'saqlandi' };
  function renderQueue() {
    $q.innerHTML = queue.map((it, i) => `<li class="q-${it.status} ${i === current ? 'cur' : ''}" data-i="${i}">
      <span class="q-name">${esc(it.name)}</span>
      <span class="q-meta">${it.code ? '<span class="mono">' + esc(it.code) + '</span> ' : ''}${it.student ? esc(it.student.full_name) : ''}</span>
      <span class="q-status">${statusText[it.status] || ''}</span></li>`).join('');
    document.getElementById('qcount').textContent = queue.length ? '(' + queue.filter(i => i.status === 'saved').length + '/' + queue.length + ' saqlandi)' : '';
    $saveAll.disabled = !queue.some(i => i.status === 'ready');
  }
  $q.addEventListener('click', e => { const li = e.target.closest('li'); if (li) show(+li.dataset.i); });

  function show(i) {
    current = i; renderQueue();
    const it = queue[i];
    if (!it) { $rev.innerHTML = '<div class="empty">Varaq tanlanmagan</div>'; return; }
    if (it.status === 'error') { $rev.innerHTML = `<h3>${esc(it.name)}</h3><div class="alert err">${esc(it.error)}</div>` + (it.result && it.result.canvas ? '<div class="scan-img" id="imgHold"></div>' : ''); if (it.result && it.result.canvas) document.getElementById('imgHold').appendChild(it.result.canvas); return; }
    if (!it.result) { $rev.innerHTML = '<div class="empty">O\'qilmoqda…</div>'; return; }
    const res = it.result;
    const mcGrid = S.mc.map((l, k) => {
      const ch = (it.mc || '')[k] || '_';
      const fl = res.qflags[l] ? ' fl-' + res.qflags[l] : '';
      return `<div class="key-row${fl}" data-k="${k}"><span class="qno">${esc(l)}</span>` +
        S.opts[l].map(o => `<button type="button" class="bub-btn ${o === ch ? 'on' : ''}" data-v="${o}">${o}</button>`).join('') + '</div>';
    }).join('');
    const openGrid = S.open.map(l => {
      const v = it.open[l] || '';
      const fl = res.qflags[l] ? ' fl-' + res.qflags[l] : '';
      return `<div class="open-tri${fl}" data-l="${esc(l)}"><span class="qno">${esc(l)}</span>` +
        `<button type="button" class="tri ok ${v === '#1' ? 'on' : ''}" data-v="#1" title="To'g'ri">✓</button>` +
        `<button type="button" class="tri no ${v === '#0' ? 'on' : ''}" data-v="#0" title="Noto'g'ri">✗</button></div>`;
    }).join('');
    $rev.innerHTML = `
      <div class="row between center-v"><h3>${esc(it.name)}</h3>
        <div class="row gap"><button class="btn sm ghost" id="prev">←</button><button class="btn sm ghost" id="next">→</button></div></div>
      ${it.flags && it.flags.length ? '<div class="alert warn small">' + it.flags.map(esc).join('<br>') + '</div>' : ''}
      ${it.status === 'saved' ? '<div class="alert ok small">Saqlangan. O\'zgartirib qayta saqlashingiz mumkin.</div>' : ''}
      <div class="scan-grid">
        <div class="scan-img" id="imgHold"></div>
        <form id="revForm" class="form">
          <div class="grid2">
            <label>ID <input id="rCode" class="mono big-input" maxlength="6" value="${esc(it.code || '')}"></label>
            <label>F.I.Sh <input id="rName" value="${esc(it.name_edit ?? it.sname ?? '')}" placeholder="ID topilmasa yangi o'quvchi"></label>
          </div>
          <div class="small ${it.student ? 'muted' : 'warn'}" id="rInfo">${it.student ? 'Topildi: ' + esc(it.student.full_name) + ' (' + esc(it.student.group_name || '') + ')' + (it.hasResponse ? ' — <b>javob mavjud, yangilanadi</b>' : '') : (it.code && it.code.length === 6 ? 'Bu ID bazada yo\'q — yangi o\'quvchi yaratiladi' : 'ID to\'liq o\'qilmadi — qo\'lda kiriting')}</div>
          <label class="mt">Yopiq javoblar <input id="rMc" class="mono" value="${esc(it.mc)}"></label>
          <div class="key-grid compact" id="rGrid">${mcGrid}</div>
          ${S.open.length ? '<div class="mt small"><b>Ochiq topshiriqlar</b> — tekshiruvchi belgisi (✓ to\'g\'ri, ✗ noto\'g\'ri, belgisiz — tekshirilmagan)</div><div class="open-tri-grid">' + openGrid + '</div>' : ''}
          <div class="row gap mt center-v wrap"><button class="btn primary" id="rSave" type="submit">Saqlash (Enter)</button>
            <span class="small muted">Chegara: ${res.threshold.toFixed(2)}${res.rotated ? ' · rasm ' + res.rotated + '° aylantirilgan' : ''}${res.markersUsed === 3 ? ' · 3 marker (aniqlik pastroq)' : ''}</span></div>
        </form>
      </div>
      <details class="diag-wrap"><summary>Diagnostika: har bir doiracha qanchalik bo'yalgan</summary><div id="diag"></div></details>`;
    document.getElementById('imgHold').appendChild(res.canvas);
    const $mc = document.getElementById('rMc');
    const rows = [...document.querySelectorAll('#rGrid .key-row')];
    const paint = () => { const s = $mc.value.toUpperCase(); rows.forEach((r, k) => r.querySelectorAll('.bub-btn').forEach(b => b.classList.toggle('on', b.dataset.v === s[k]))); };
    $mc.addEventListener('input', () => { $mc.value = $mc.value.toUpperCase().replace(/[^A-F_]/g, ''); it.mc = $mc.value; paint(); });
    rows.forEach((r, k) => r.addEventListener('click', e => {
      const b = e.target.closest('.bub-btn'); if (!b) return;
      const s = $mc.value.padEnd(rows.length, '_').split(''); s[k] = s[k] === b.dataset.v ? '_' : b.dataset.v;
      $mc.value = it.mc = s.join(''); paint();
    }));
    document.querySelectorAll('.open-tri').forEach(row => row.addEventListener('click', e => {
      const b = e.target.closest('.tri'); if (!b) return;
      const l = row.dataset.l; it.open[l] = it.open[l] === b.dataset.v ? '' : b.dataset.v;
      row.querySelectorAll('.tri').forEach(x => x.classList.toggle('on', x.dataset.v === it.open[l]));
    }));
    const dbg = document.getElementById('diag');
    if (dbg) dbg.innerHTML = renderDiag(res);
    const $code = document.getElementById('rCode');
    $code.addEventListener('change', () => { it.code = $code.value.replace(/\D/g, ''); it.student = null; it.sname = ''; lookup(it); });
    document.getElementById('rName').addEventListener('input', e => it.name_edit = e.target.value);
    document.getElementById('prev').onclick = () => show(Math.max(0, current - 1));
    document.getElementById('next').onclick = () => show(Math.min(queue.length - 1, current + 1));
    document.getElementById('revForm').addEventListener('submit', async e => {
      e.preventDefault();
      const ok = await save(it);
      if (ok) {
        const nxt = queue.findIndex((q, k) => k > current && (q.status === 'ready' || q.status === 'warn'));
        show(nxt >= 0 ? nxt : current);
      }
    });
  }

  // Diagnostika jadvali: 0 — oq, 1 — to'liq qora. Chegara (T) dan yuqorisi "bo'yalgan" deb olinadi.
  function renderDiag(res) {
    const D = res.debug, T = res.threshold;
    const cell = (d, v, sel) => `<span class="dc${d >= T ? ' on' : ''}${sel ? ' sel' : ''}" style="--d:${Math.min(1, d)}"><i>${esc(v)}</i><b>${d.toFixed(2)}</b></span>`;
    let h = `<p class="small muted">Qog'oz foni: <b>${res.base.toFixed(2)}</b> · chegara T = <b>${T.toFixed(2)}</b> · markerlar: ${D.markers.map(m => '(' + m.join(', ') + ')').join(' ')} · tasvir ${D.size.join('×')} px${res.rotated ? ' · ' + res.rotated + '° aylantirilgan' : ''}${res.markersUsed === 3 ? ' · 3 marker' : ''}${res.maxShift ? ' · mahalliy siljish ' + res.maxShift + ' mm' : ''}${res.sideMarkers ? ' · yon markerlar: ' + res.sideMarkers + ' (' + res.bands + ' band)' : ''}</p>`;
    h += '<div class="diag-sec"><h4>ID ustunlari</h4><div class="diag-id">' + D.id.map((col, i) => {
      const best = col.reduce((a, b) => b.d > a.d ? b : a);
      return `<div class="diag-col"><div class="small muted">${i + 1}</div>` + col.map(b => cell(b.d, b.v, b === best && b.d >= T)).join('') + '</div>';
    }).join('') + '</div></div>';
    h += '<div class="diag-sec"><h4>Yopiq savollar</h4><div class="diag-mc">' + D.mc.map(q =>
      `<div class="diag-row${q.flag ? ' fl-' + q.flag : ''}"><span class="qno">${esc(q.label)}</span>` + q.opts.map(o => cell(o.d, o.v, o.v === q.val)).join('') + `<span class="diag-val">${esc(q.val || '—')}</span></div>`).join('') + '</div></div>';
    if (D.open.length) h += '<div class="diag-sec"><h4>Ochiq (✓ / ✗)</h4><div class="diag-mc">' + D.open.map(o =>
      `<div class="diag-row${o.flag ? ' fl-' + o.flag : ''}"><span class="qno">${esc(o.label)}</span>${cell(o.ok, '✓', o.val === '#1')}${cell(o.no, '✗', o.val === '#0')}<span class="diag-val">${o.val === '#1' ? 'to\'g\'ri' : o.val === '#0' ? 'xato' : '—'}</span></div>`).join('') + '</div></div>';
    return h;
  }

  async function save(it) {
    const answers = {};
    S.mc.forEach((l, k) => { const c = (it.mc || '')[k]; answers[l] = c && c !== '_' ? c : ''; });
    S.open.forEach(l => answers[l] = it.open[l] || '');
    const cSel = document.getElementById('scanCenter');
    const body = { test: S.testId, code: it.code || '', full_name: it.name_edit ?? it.sname ?? '', answers, center_id: cSel ? +cSel.value : 0 };
    if (!body.code && !body.full_name) { alert('ID yoki F.I.Sh kiriting'); return false; }
    try {
      const r = await fetch('index.php?p=api&a=save_scan', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF': csrf }, body: JSON.stringify(body) }).then(r => r.json());
      if (!r.ok) throw new Error(r.error || 'Saqlanmadi');
      it.status = 'saved'; it.code = r.student.code; it.student = r.student;
      renderQueue();
      return true;
    } catch (e) { alert(e.message); return false; }
  }

  $saveAll.addEventListener('click', async () => {
    $saveAll.disabled = true;
    for (const it of queue.filter(i => i.status === 'ready')) await save(it);
    renderQueue();
    if (current >= 0) show(current);
  });

  document.getElementById('files').addEventListener('change', e => { addFiles(e.target.files); e.target.value = ''; });
  document.getElementById('camera').addEventListener('change', e => { addFiles(e.target.files); e.target.value = ''; });
  const drop = document.getElementById('drop');
  ['dragenter', 'dragover'].forEach(ev => document.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('on'); }));
  ['dragleave', 'drop'].forEach(ev => document.addEventListener(ev, e => { e.preventDefault(); if (ev === 'drop' || e.target === drop) drop.classList.remove('on'); }));
  document.addEventListener('drop', e => { if (e.dataTransfer && e.dataTransfer.files.length) addFiles(e.dataTransfer.files); });
})();
