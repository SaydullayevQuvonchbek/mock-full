<?php
defined('APP_ROOT') || exit;
/**
 * Rasch (1PL) dixotomik modeli — JMLE (Joint Maximum Likelihood Estimation).
 *
 *   P(x=1 | θ, b) = exp(θ − b) / (1 + exp(θ − b))
 *
 * θ — o'quvchi qobiliyati (logit), b — topshiriq qiyinligi (logit).
 * Topshiriqlar qiyinligining o'rtachasi 0 ga tenglanadi (shkala markazi).
 *
 * Kirish: $X — N×L matritsa (0/1). Chiqish: item va person parametrlari, SE,
 * infit/outfit, reliability, xom ball → θ jadvali.
 */

function rasch_p(float $theta, float $b): float
{
    $z = $theta - $b;
    if ($z > 35) return 1.0 - 1e-15;
    if ($z < -35) return 1e-15;
    return 1.0 / (1.0 + exp(-$z));
}

/**
 * Berilgan item qiyinliklari bo'yicha xom ball r ga mos θ ni topadi (Nyuton usuli).
 * Ekstremal ballar (0 va L) uchun 0.3 tuzatish qo'llanadi (Winsteps EXTRSC=0.3 kabi).
 */
function rasch_theta_for_score(float $r, array $b, float $extreme = 0.3): array
{
    $L = count($b);
    if ($L === 0) return [0.0, 0.0];
    if ($r <= 0) $r = $extreme;
    if ($r >= $L) $r = $L - $extreme;
    $theta = log($r / ($L - $r)) + array_sum($b) / $L;
    for ($it = 0; $it < 100; $it++) {
        $E = 0.0; $V = 0.0;
        foreach ($b as $bi) {
            $p = rasch_p($theta, $bi);
            $E += $p; $V += $p * (1 - $p);
        }
        $step = ($r - $E) / max($V, 1e-9);
        $step = max(-1.0, min(1.0, $step));
        $theta += $step;
        if (abs($step) < 1e-7) break;
    }
    $V = 0.0;
    foreach ($b as $bi) { $p = rasch_p($theta, $bi); $V += $p * (1 - $p); }
    return [$theta, 1.0 / sqrt(max($V, 1e-9))];
}

/**
 * Item qiyinligini berilgan θ lar bo'yicha topadi (ekstremal itemlar uchun).
 */
function rasch_b_for_count(float $s, array $thetas, float $extreme = 0.3): array
{
    $N = count($thetas);
    if ($s <= 0) $s = $extreme;
    if ($s >= $N) $s = $N - $extreme;
    $b = -log($s / ($N - $s)) + array_sum($thetas) / max(1, $N);
    for ($it = 0; $it < 100; $it++) {
        $E = 0.0; $V = 0.0;
        foreach ($thetas as $t) { $p = rasch_p($t, $b); $E += $p; $V += $p * (1 - $p); }
        $step = ($s - $E) / max($V, 1e-9);
        $step = max(-1.0, min(1.0, $step));
        $b -= $step;
        if (abs($step) < 1e-7) break;
    }
    $V = 0.0;
    foreach ($thetas as $t) { $p = rasch_p($t, $b); $V += $p * (1 - $p); }
    return [$b, 1.0 / sqrt(max($V, 1e-9))];
}

/**
 * Asosiy baholash.
 * @param array $X  N×L (0/1)
 * @return array
 */
function rasch_estimate(array $X, int $maxIter = 500, float $conv = 1e-5): array
{
    $N = count($X);
    $L = $N ? count($X[0]) : 0;
    $res = [
        'N' => $N, 'L' => $L, 'b' => array_fill(0, $L, 0.0), 'b_se' => array_fill(0, $L, null),
        'item_infit' => array_fill(0, $L, null), 'item_outfit' => array_fill(0, $L, null),
        'item_extreme' => array_fill(0, $L, false),
        'theta' => array_fill(0, $N, 0.0), 'theta_se' => array_fill(0, $N, null),
        'person_infit' => array_fill(0, $N, null), 'person_outfit' => array_fill(0, $N, null),
        'person_extreme' => array_fill(0, $N, false),
        'raw' => array_fill(0, $N, 0), 'score_table' => [], 'iterations' => 0,
        'converged' => false, 'reliability' => null, 'item_reliability' => null, 'alpha' => null,
    ];
    if ($N === 0 || $L === 0) return $res;

    $r = array_fill(0, $N, 0);
    $s = array_fill(0, $L, 0);
    for ($n = 0; $n < $N; $n++) {
        for ($i = 0; $i < $L; $i++) {
            $x = $X[$n][$i] ? 1 : 0;
            $X[$n][$i] = $x;
            $r[$n] += $x; $s[$i] += $x;
        }
    }
    $res['raw'] = $r;

    // 1) Ekstremal person/itemlarni navbatma-navbat ajratish
    $activeP = array_fill(0, $N, true);
    $activeI = array_fill(0, $L, true);
    do {
        $changed = false;
        $nI = count(array_filter($activeI));
        for ($n = 0; $n < $N; $n++) {
            if (!$activeP[$n]) continue;
            $rn = 0; foreach ($activeI as $i => $a) if ($a) $rn += $X[$n][$i];
            if ($rn === 0 || $rn === $nI) { $activeP[$n] = false; $changed = true; }
        }
        $nP = count(array_filter($activeP));
        for ($i = 0; $i < $L; $i++) {
            if (!$activeI[$i]) continue;
            $si = 0; foreach ($activeP as $n => $a) if ($a) $si += $X[$n][$i];
            if ($si === 0 || $si === $nP) { $activeI[$i] = false; $changed = true; }
        }
    } while ($changed && count(array_filter($activeP)) > 0 && count(array_filter($activeI)) > 0);

    $P_idx = array_keys(array_filter($activeP));
    $I_idx = array_keys(array_filter($activeI));
    $nP = count($P_idx); $nI = count($I_idx);

    $b = array_fill(0, $L, 0.0);
    $theta = array_fill(0, $N, 0.0);

    if ($nP >= 2 && $nI >= 2) {
        // Faol to'plamdagi ballar
        $rA = []; $sA = [];
        foreach ($P_idx as $n) { $t = 0; foreach ($I_idx as $i) $t += $X[$n][$i]; $rA[$n] = $t; }
        foreach ($I_idx as $i) { $t = 0; foreach ($P_idx as $n) $t += $X[$n][$i]; $sA[$i] = $t; }
        // PROX boshlang'ich qiymatlar
        foreach ($P_idx as $n) $theta[$n] = log($rA[$n] / ($nI - $rA[$n]));
        foreach ($I_idx as $i) $b[$i] = log(($nP - $sA[$i]) / $sA[$i]);
        $mean = 0; foreach ($I_idx as $i) $mean += $b[$i]; $mean /= $nI;
        foreach ($I_idx as $i) $b[$i] -= $mean;

        for ($it = 1; $it <= $maxIter; $it++) {
            $maxChange = 0.0;
            // Person yangilash
            foreach ($P_idx as $n) {
                $E = 0.0; $V = 0.0;
                foreach ($I_idx as $i) { $p = rasch_p($theta[$n], $b[$i]); $E += $p; $V += $p * (1 - $p); }
                $step = ($rA[$n] - $E) / max($V, 1e-9);
                $step = max(-1.0, min(1.0, $step));
                $theta[$n] += $step;
                $maxChange = max($maxChange, abs($step));
            }
            // Item yangilash
            foreach ($I_idx as $i) {
                $E = 0.0; $V = 0.0;
                foreach ($P_idx as $n) { $p = rasch_p($theta[$n], $b[$i]); $E += $p; $V += $p * (1 - $p); }
                $step = ($sA[$i] - $E) / max($V, 1e-9);
                $step = max(-1.0, min(1.0, $step));
                $b[$i] -= $step;
                $maxChange = max($maxChange, abs($step));
            }
            $mean = 0; foreach ($I_idx as $i) $mean += $b[$i]; $mean /= $nI;
            foreach ($I_idx as $i) $b[$i] -= $mean;
            $res['iterations'] = $it;
            if ($maxChange < $conv) { $res['converged'] = true; break; }
        }
        // JMLE statistik siljishini tuzatish (Wright): (L-1)/L
        $corr = ($nI - 1) / $nI;
        foreach ($I_idx as $i) $b[$i] *= $corr;
    } elseif ($nI >= 1) {
        // Juda kam ma'lumot: faqat p-qiymatdan taxmin
        foreach ($I_idx as $i) {
            $si = 0; foreach ($P_idx as $n) $si += $X[$n][$i];
            $b[$i] = log((max(1, $nP) - $si + 0.5) / ($si + 0.5));
        }
    }

    // 2) Ekstremal itemlar: barcha person θ (faol) bo'yicha baholash
    $activeThetas = [];
    foreach ($P_idx as $n) $activeThetas[] = $theta[$n];
    if (!$activeThetas) {
        // hamma person ekstremal — xom balldan taxmin
        foreach ($r as $rn) { $rr = min(max($rn, 0.3), $L - 0.3); $activeThetas[] = log($rr / ($L - $rr)); }
    }
    for ($i = 0; $i < $L; $i++) {
        if ($activeI[$i]) continue;
        $res['item_extreme'][$i] = true;
        $sAct = 0; foreach ($P_idx as $n) $sAct += $X[$n][$i];
        $cnt = count($P_idx) ?: $N;
        if (!$P_idx) { $sAct = $s[$i]; }
        [$bb, $se] = rasch_b_for_count((float)$sAct, $activeThetas);
        if ($sAct <= 0) $bb = max($bb, max($b) + 0.5);
        if ($sAct >= $cnt) $bb = min($bb, min($b) - 0.5);
        $b[$i] = $bb; $res['b_se'][$i] = $se;
    }

    // 3) Xom ball → θ jadvali (barcha L item bo'yicha). Rasch: xom ball yetarli statistika.
    $table = [];
    for ($k = 0; $k <= $L; $k++) {
        [$t, $se] = rasch_theta_for_score((float)$k, $b);
        $table[$k] = ['theta' => $t, 'se' => $se];
    }
    $res['score_table'] = $table;

    for ($n = 0; $n < $N; $n++) {
        $res['theta'][$n] = $table[$r[$n]]['theta'];
        $res['theta_se'][$n] = $table[$r[$n]]['se'];
        $res['person_extreme'][$n] = ($r[$n] === 0 || $r[$n] === $L);
    }
    $res['b'] = $b;

    // 4) Item SE va fit (faqat ekstremal bo'lmaganlar)
    $thetaF = $res['theta'];
    foreach ($I_idx as $i) {
        $W = 0.0; $sumZ2 = 0.0; $sumY2 = 0.0; $cnt = 0;
        foreach ($P_idx as $n) {
            $p = rasch_p($thetaF[$n], $b[$i]);
            $w = $p * (1 - $p);
            $y = $X[$n][$i] - $p;
            $W += $w; $sumY2 += $y * $y; $sumZ2 += ($y * $y) / max($w, 1e-9); $cnt++;
        }
        $res['b_se'][$i] = 1.0 / sqrt(max($W, 1e-9));
        $res['item_outfit'][$i] = $cnt ? $sumZ2 / $cnt : null;
        $res['item_infit'][$i] = $W > 0 ? $sumY2 / $W : null;
    }
    foreach ($P_idx as $n) {
        $W = 0.0; $sumZ2 = 0.0; $sumY2 = 0.0; $cnt = 0;
        foreach ($I_idx as $i) {
            $p = rasch_p($thetaF[$n], $b[$i]);
            $w = $p * (1 - $p);
            $y = $X[$n][$i] - $p;
            $W += $w; $sumY2 += $y * $y; $sumZ2 += ($y * $y) / max($w, 1e-9); $cnt++;
        }
        $res['person_outfit'][$n] = $cnt ? $sumZ2 / $cnt : null;
        $res['person_infit'][$n] = $W > 0 ? $sumY2 / $W : null;
    }

    // 5) Ishonchlilik (person separation reliability) va Cronbach alfa
    if ($nP >= 2) {
        $vals = []; $errs = [];
        foreach ($P_idx as $n) { $vals[] = $thetaF[$n]; $errs[] = $res['theta_se'][$n] ** 2; }
        $var = stats_var($vals);
        $mse = array_sum($errs) / count($errs);
        $res['reliability'] = $var > 0 ? max(0.0, ($var - $mse) / $var) : 0.0;
    }
    if ($nI >= 2) {
        $vals = []; $errs = [];
        foreach ($I_idx as $i) { $vals[] = $b[$i]; $errs[] = $res['b_se'][$i] ** 2; }
        $var = stats_var($vals);
        $mse = array_sum($errs) / count($errs);
        $res['item_reliability'] = $var > 0 ? max(0.0, ($var - $mse) / $var) : 0.0;
    }
    if ($N >= 2 && $L >= 2) {
        $itemVar = 0.0;
        for ($i = 0; $i < $L; $i++) { $pp = $s[$i] / $N; $itemVar += $pp * (1 - $pp); }
        $totVar = stats_var($r);
        $res['alpha'] = $totVar > 0 ? ($L / ($L - 1)) * (1 - $itemVar / $totVar) : null;
    }
    return $res;
}

function stats_mean(array $a): float
{
    return $a ? array_sum($a) / count($a) : 0.0;
}

/** Tanlanma dispersiyasi (n−1) */
function stats_var(array $a): float
{
    $n = count($a);
    if ($n < 2) return 0.0;
    $m = array_sum($a) / $n;
    $s = 0.0; foreach ($a as $v) $s += ($v - $m) ** 2;
    return $s / ($n - 1);
}

function stats_sd(array $a): float
{
    return sqrt(stats_var($a));
}

/** Pirson korrelyatsiyasi */
function stats_corr(array $x, array $y): ?float
{
    $n = count($x);
    if ($n < 3) return null;
    $mx = array_sum($x) / $n; $my = array_sum($y) / $n;
    $sxy = 0; $sxx = 0; $syy = 0;
    for ($k = 0; $k < $n; $k++) {
        $dx = $x[$k] - $mx; $dy = $y[$k] - $my;
        $sxy += $dx * $dy; $sxx += $dx * $dx; $syy += $dy * $dy;
    }
    if ($sxx <= 0 || $syy <= 0) return null;
    return $sxy / sqrt($sxx * $syy);
}
