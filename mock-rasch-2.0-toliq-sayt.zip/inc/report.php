<?php
defined('APP_ROOT') || exit;
/** O'quvchi natija kartasi (admin va o'quvchi uchun umumiy) */

function difficulty_label(float $b): array
{
    if ($b < -1.0) return ['Oson', 'd-easy'];
    if ($b <= 1.0) return ['O\'rta', 'd-mid'];
    return ['Qiyin', 'd-hard'];
}

function render_scale_bar(float $ball): string
{
    $pct = max(0, min(100, $ball / MAX_BALL * 100)); $over = $ball > MAX_BALL;
    $s = '<div class="scale-bar"><div class="scale-track">';
    $bands = [[0, 46, 'g-none', ''], [46, 50, 'g-c', 'C'], [50, 55, 'g-cp', 'C+'], [55, 60, 'g-b', 'B'], [60, 65, 'g-bp', 'B+'], [65, 70, 'g-a', 'A'], [70, 75, 'g-ap', 'A+']];
    foreach ($bands as [$a, $b, $cls, $lab]) {
        $s .= '<div class="band ' . $cls . '" style="left:' . ($a / 75 * 100) . '%;width:' . (($b - $a) / 75 * 100) . '%"><span>' . $lab . '</span></div>';
    }
    $s .= '<div class="marker' . ($over ? ' over' : '') . '" style="left:' . $pct . '%"><b>' . fmt($ball) . ($over ? ' →' : '') . '</b></div>';
    $s .= '</div><div class="scale-ticks"><span>0</span><span style="left:' . (46 / 75 * 100) . '%">46</span><span style="left:' . (60 / 75 * 100) . '%">60</span><span style="left:' . (70 / 75 * 100) . '%">70</span><span style="left:100%">75</span></div></div>';
    return $s;
}

function render_result_card(array $test, int $sid, bool $forStudent = false): void
{
    $st = row('SELECT * FROM students WHERE id=?', [$sid]);
    $res = row('SELECT * FROM results WHERE test_id=? AND student_id=?', [$test['id'], $sid]);
    $resp = row('SELECT * FROM responses WHERE test_id=? AND student_id=?', [$test['id'], $sid]);
    if (!$st || !$res || !$resp) {
        echo '<div class="card empty">Natija hali hisoblanmagan.</div>';
        return;
    }
    $N = (int)($test['stats']['N'] ?? 0);
    $items = test_items($test);
    $ans = json_decode($resp['answers'] ?: '{}', true) ?: [];
    $stats = [];
    foreach (rows('SELECT * FROM item_stats WHERE test_id=?', [$test['id']]) as $r) $stats[$r['label']] = $r;
    $theta = (float)$res['theta'];
    $scored = str_split($res['scored']);
    $unexpectedWrong = []; $unexpectedRight = [];
    foreach ($items as $i => $it) {
        $okx = ($scored[$i] ?? '0') === '1';
        $px = rasch_p($theta, isset($stats[$it['label']]) ? (float)$stats[$it['label']]['b'] : 0.0);
        if (!$okx && $px >= 0.75) $unexpectedWrong[] = $it['label'];
        if ($okx && $px <= 0.25) $unexpectedRight[] = $it['label'];
    }
    ?>
    <div class="result-card">
      <div class="rc-head">
        <div>
          <div class="eyebrow"><?= e($test['title']) ?> · <?= e($test['test_date']) ?></div>
          <h2><?= e($st['full_name'] ?: 'O\'quvchi') ?></h2>
          <div class="muted">ID <span class="mono"><?= e($st['code']) ?></span><?= $st['group_name'] ? ' · ' . e($st['group_name']) : '' ?></div>
        </div>
        <div class="rc-score">
          <div class="rc-ball"><?= fmt($res['ball']) ?><small>/ 75</small></div>
          <?php if ($res['ball_raw'] !== null && (float)$res['ball_raw'] > (float)$res['ball'] + 0.05): ?><div class="small muted" title="Cheklovsiz qiymat (test sozlamasida 75 bilan cheklash yoqilgan)">cheklovsiz: <?= fmt($res['ball_raw']) ?></div><?php endif; ?>
          <?= grade_badge($res['grade']) ?>
          <div class="small muted rc-pct">Foiz ko'rsatkichi: <b><?= fmt(cert_percent((float)$res['ball']), 1) ?>%</b></div>
        </div>
      </div>
      <?= render_scale_bar((float)$res['ball']) ?>
      <div class="stats4 small-stats">
        <div class="stat"><span><?= (int)$res['raw'] ?> / <?= count($items) ?></span>To'g'ri javoblar</div>
        <div class="stat"><span><?= (int)$res['rank_no'] ?> / <?= $N ?></span>O'rin</div>
        <?php $sc = section_counts($test, $res['scored']); ?>
        <?php if ($forStudent): ?>
        <div class="stat"><span><?= $sc['tasks_full'] ?> / <?= $sc['tasks_total'] ?></span>To'liq yechilgan topshiriq</div>
        <div class="stat"><span><?= fmt(cert_percent((float)$res['ball']), 1) ?>%</span>Foiz ko'rsatkichi</div>
        <?php else: ?>
        <div class="stat"><span><?= fmt($theta, 2) ?></span>Qobiliyat θ (logit)</div>
        <div class="stat"><span>± <?= fmt($res['se'], 2) ?></span>O'lchov xatosi</div>
        <?php endif; ?>
      </div>
      <div class="card soft">
        <div class="card-head"><h3>To'g'ri javoblar</h3><span class="small muted">bo'limlar bo'yicha</span></div>
        <div class="sec-bars">
          <?php foreach ($sc['sections'] as [$lab, $ok, $tot]): ?>
            <div class="sec-bar"><span><?= e($lab) ?></span><span class="track"><i style="width:<?= round($ok / max(1, $tot) * 100) ?>%"></i></span><span class="v"><?= $ok ?> / <?= $tot ?></span></div>
          <?php endforeach; ?>
        </div>
        <div class="sec-total">
          <div><b><?= $sc['items_ok'] ?> / <?= $sc['items_total'] ?></b>baholanadigan element</div>
          <div><b><?= $sc['tasks_full'] ?> / <?= $sc['tasks_total'] ?></b>to'liq yechilgan topshiriq</div>
          <?php if ($sc['tasks_partial']): ?><div><b><?= $sc['tasks_partial'] ?></b>qisman yechilgan (a yoki b)</div><?php endif; ?>
        </div>
        <?php $ss = section_scores($test, $res['scored'], (float)$res['ball']); if (count($ss) > 1): ?>
        <div class="sec-total">
          <?php foreach ($ss as $sx): ?><div><b><?= number_format((float)$sx['ball'], 3, '.', '') ?></b><?= e($sx['name']) ?> (<?= $sx['ok'] ?>/<?= $sx['total'] ?>)</div><?php endforeach; ?>
        </div>
        <?php endif; ?>
        <?php if ($res['ball_official'] !== null && abs((float)$res['ball_official'] - (float)$res['ball']) > 0.05): ?>
          <?php if ($forStudent): ?>
          <p class="small muted" style="margin:.8rem 0 0">Rasmiy shkala bo'yicha taxminiy ball: <b><?= fmt($res['ball_official']) ?></b> — <?= grade_badge($res['grade_official']) ?>.</p>
          <?php else: ?>
          <p class="small muted" style="margin:.8rem 0 0">Rasmiy shkala bo'yicha prognoz (50 + 10·Z): <b><?= fmt($res['ball_official']) ?></b> — <?= grade_badge($res['grade_official']) ?>. Markaz balli M = <?= fmt($test['t_mean'] ?? 50) ?> bilan hisoblangan.</p>
          <?php endif; ?>
        <?php endif; ?>
      </div>
      <div class="grid2">
        <div class="card soft">
          <h3>Birinchi navbatda takrorlang</h3>
          <?php if ($unexpectedWrong): ?>
            <p class="small">Sizning darajangizda odatda yechiladigan, lekin xato qilingan savollar: <b><?= e(implode(', ', $unexpectedWrong)) ?></b>. Bu mavzular ballingizni eng tez oshiradi.</p>
          <?php else: ?><p class="small muted">Darajangizga mos savollarda kutilmagan xato yo'q.</p><?php endif; ?>
        </div>
        <div class="card soft">
          <h3>Kuchli tomonlar</h3>
          <?php if ($unexpectedRight): ?>
            <p class="small">Darajangizdan qiyinroq bo'lsa ham yechilgan savollar: <b><?= e(implode(', ', $unexpectedRight)) ?></b>.</p>
          <?php else: ?><p class="small muted">Keyingi bosqich — "Qiyin" belgili savollar ustida ishlash.</p><?php endif; ?>
        </div>
      </div>
      <h3 class="mt">Har bir savol bo'yicha</h3>
      <div class="table-wrap"><table class="tbl compact-tbl">
        <thead><tr><th>Savol</th><th>Javobingiz</th><?php if (!$forStudent || $test['published']): ?><th>To'g'ri javob</th><?php endif; ?><th>Natija</th><th>Qiyinlik</th><?php if (!$forStudent): ?><th class="num" title="Shu θ darajadagi o'quvchi bu savolni to'g'ri yechish ehtimoli">Kutilgan ehtimol</th><?php endif; ?></tr></thead>
        <tbody>
        <?php foreach ($items as $i => $it):
            $lab = $it['label'];
            $a = (string)($ans[$lab] ?? '');
            $shown = $a === '#1' ? '✓ (tekshiruvchi)' : ($a === '#0' ? '✗ (tekshiruvchi)' : ($a === '' ? '—' : $a));
            $ok = ($scored[$i] ?? '0') === '1';
            $b = isset($stats[$lab]) ? (float)$stats[$lab]['b'] : 0.0;
            $p = rasch_p($theta, $b);
            [$dl, $dc] = difficulty_label($b);
            $flag = '';
            if (!$ok && $p >= 0.75) $flag = 'unexp-wrong';
            if ($ok && $p <= 0.25) $flag = 'unexp-right';
        ?>
          <tr class="<?= $flag ?>">
            <td><b><?= e($lab) ?></b></td>
            <td class="mono"><?= e($shown) ?></td>
            <?php if (!$forStudent || $test['published']): ?><td class="mono"><?= e(str_replace('|', ' yoki ', (string)($test['key'][$lab] ?? '—'))) ?></td><?php endif; ?>
            <td><?= $ok ? '<span class="ok-mark">✓</span>' : '<span class="no-mark">✗</span>' ?></td>
            <td><span class="dtag <?= $dc ?>"><?= $dl ?></span><?php if (!$forStudent): ?> <span class="muted small"><?= fmt($b, 2) ?></span><?php endif; ?></td>
            <?php if (!$forStudent): ?><td class="num"><div class="pbar"><i style="width:<?= round($p * 100) ?>%"></i></div><?= round($p * 100) ?>%</td><?php endif; ?>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
      <?php if (!$forStudent): ?><p class="small muted mt">Ball Rasch modeli bo'yicha hisoblangan: bir xil sondagi to'g'ri javob bir xil θ beradi, θ esa savollar qiyinligiga bog'liq. Batafsil: <a href="<?= e(url('rasch')) ?>">Rasch modeli qanday ishlaydi</a>.</p><?php endif; ?>
    </div>
    <?php
}
