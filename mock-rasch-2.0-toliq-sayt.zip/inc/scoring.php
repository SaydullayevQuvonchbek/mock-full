<?php
defined('APP_ROOT') || exit;
/**
 * Javoblarni tekshirish (0/1), Rasch hisoblash va 75 ballik shkalaga o'tkazish.
 */

/** Ochiq javobni normallashtirish */
function norm_answer(string $s): string
{
    $s = mb_strtolower(trim($s));
    $s = str_replace(
        ['−', '–', '—', ',', ' ', "\t", '·', '*', '×', 'sqrt', 'pi', 'π', '÷'],
        ['-', '-', '-', '.', '', '', '', '', '', '√', 'π', 'π', '/'],
        $s
    );
    $s = rtrim($s, '.');
    $s = str_replace(['∞', 'infinity', 'inf', ':'], ['∞', '∞', '∞', '/'], $s);
    // "x=5" → "5", "x1=2;x2=3" → "2;3"
    $s = preg_replace('/(^|;)[a-z][0-9₀-₉]*=/u', '$1', $s);
    return $s;
}

/** Sonli qiymat: butun, o'nli, oddiy kasr (a/b) */
function parse_num(string $s): ?float
{
    if (preg_match('/^[+-]?\d+(\.\d+)?$/', $s)) return (float)$s;
    if (preg_match('/^([+-]?\d+(?:\.\d+)?)\/([+-]?\d+(?:\.\d+)?)$/', $s, $m) && (float)$m[2] != 0.0) {
        return (float)$m[1] / (float)$m[2];
    }
    return null;
}

/**
 * Oddiy matematik ifodani xavfsiz hisoblash (eval ishlatilmaydi):
 * sonlar, + − × ÷ ^, qavslar, √ (√2, √(x), 2√3), π, yashirin ko'paytirish (2π, 3(4)).
 * Hisoblab bo'lmasa null.
 */
function eval_expr(string $s): ?float
{
    if ($s === '' || mb_strlen($s) > 40) return null;
    if (!preg_match_all('/\d+(?:\.\d+)?|π|√|[-+*\/^()]/u', $s, $m)) return null;
    if (implode('', $m[0]) !== $s) return null;          // tanilmagan belgi bor
    $t = $m[0]; $i = 0; $n = count($t); $depth = 0;
    $isPrimaryStart = fn($k) => $k < $n && (is_numeric($t[$k]) || in_array($t[$k], ['π', '√', '('], true));
    $expr = null; $term = null; $factor = null; $unary = null; $primary = null;
    $primary = function () use (&$t, &$i, $n, &$expr, &$unary, &$depth): ?float {
        if ($i >= $n || ++$depth > 60) return null;
        $tok = $t[$i];
        if (is_numeric($tok)) { $i++; return (float)$tok; }
        if ($tok === 'π') { $i++; return M_PI; }
        if ($tok === '√') { $i++; $v = $unary(); return ($v === null || $v < 0) ? null : sqrt($v); }
        if ($tok === '(') { $i++; $v = $expr(); if ($i >= $n || $t[$i] !== ')') return null; $i++; return $v; }
        return null;
    };
    $factor = function () use (&$t, &$i, $n, &$primary, &$unary): ?float {
        $v = $primary();
        if ($v === null) return null;
        if ($i < $n && $t[$i] === '^') { $i++; $e = $unary(); if ($e === null) return null; $v = $v ** $e; }
        return is_finite($v) ? $v : null;
    };
    $unary = function () use (&$t, &$i, $n, &$factor, &$unary): ?float {
        if ($i < $n && ($t[$i] === '-' || $t[$i] === '+')) { $neg = $t[$i] === '-'; $i++; $v = $unary(); return $v === null ? null : ($neg ? -$v : $v); }
        return $factor();
    };
    $term = function () use (&$t, &$i, $n, &$unary, $isPrimaryStart): ?float {
        $v = $unary();
        while ($v !== null && $i < $n) {
            if ($t[$i] === '*' || $t[$i] === '/') {
                $op = $t[$i]; $i++; $r = $unary();
                if ($r === null || ($op === '/' && abs($r) < 1e-300)) return null;
                $v = $op === '*' ? $v * $r : $v / $r;
            } elseif ($isPrimaryStart($i)) {          // yashirin ko'paytirish: 2√3, 2π, 3(4)
                $r = $unary(); if ($r === null) return null; $v *= $r;
            } else break;
        }
        return $v;
    };
    $expr = function () use (&$t, &$i, $n, &$term): ?float {
        $v = $term();
        while ($v !== null && $i < $n && ($t[$i] === '+' || $t[$i] === '-')) {
            $op = $t[$i]; $i++; $r = $term(); if ($r === null) return null;
            $v = $op === '+' ? $v + $r : $v - $r;
        }
        return $v;
    };
    $v = $expr();
    return ($v !== null && $i === $n && is_finite($v)) ? $v : null;
}

function nums_equal(float $a, float $b): bool
{
    return abs($a - $b) <= 1e-9 * max(1.0, abs($b));   // yaxlitlangan o'nli kasr aniq qiymat hisoblanmaydi
}

/**
 * Kalitda bir nechta to'g'ri shakl "|" bilan: "0.5|1/2".
 * Bir nechta qiymatli javob (masalan ildizlar) ";" bilan: "2;3" — tartibi ahamiyatsiz.
 * Sonli ifodalar qiymati bo'yicha solishtiriladi: 1/2 = 0.5, √12 = 2√3, 8/3 = 2.6666667.
 */
function answer_matches(string $given, string $key): bool
{
    $g = norm_answer($given);
    if ($g === '') return false;
    foreach (explode('|', $key) as $alt) {
        $k = norm_answer($alt);
        if ($k === '') continue;
        if ($g === $k) return true;
        if (str_contains($k, ';') || str_contains($g, ';')) {
            $gp = array_values(array_filter(array_map('norm_answer', explode(';', $g)), 'strlen'));
            $kp = array_values(array_filter(array_map('norm_answer', explode(';', $k)), 'strlen'));
            if (count($gp) !== count($kp) || !$gp) continue;
            $gv = array_map('eval_expr', $gp); $kv = array_map('eval_expr', $kp);
            if (in_array(null, $gv, true) || in_array(null, $kv, true)) {
                sort($gp); sort($kp);
                if ($gp === $kp) return true;
                continue;
            }
            sort($gv); sort($kv);
            $ok = true;
            foreach ($gv as $j => $x) if (!nums_equal($x, $kv[$j])) { $ok = false; break; }
            if ($ok) return true;
            continue;
        }
        $gn = eval_expr($g); $kn = eval_expr($k);
        if ($gn !== null && $kn !== null && nums_equal($gn, $kn)) return true;
    }
    return false;
}

/**
 * Bitta item bahosi. Ochiq itemlar uchun: "#1" — tekshiruvchi to'g'ri deb belgilagan,
 * "#0" — noto'g'ri, boshqa matn — kalit bilan solishtiriladi.
 */
function score_item(array $item, $value, array $key): int
{
    $value = trim((string)($value ?? ''));
    if ($value === '') return 0;
    $k = (string)($key[$item['label']] ?? '');
    if ($item['type'] === 'mc') {
        return ($k !== '' && strtoupper($value) === strtoupper($k)) ? 1 : 0;
    }
    if ($value === '#1') return 1;
    if ($value === '#0') return 0;
    return ($k !== '' && answer_matches($value, $k)) ? 1 : 0;
}

function score_response(array $test, array $answers, array $overrides = []): array
{
    $out = [];
    foreach (test_items($test) as $it) {
        $lab = $it['label'];
        $out[$lab] = isset($overrides[$lab]) ? ((int)$overrides[$lab] ? 1 : 0) : score_item($it, $answers[$lab] ?? '', $test['key']);
    }
    return $out;
}

/**
 * Testni to'liq hisoblash: Rasch + natijalar + item statistikasi. DB ga yozadi.
 */
function compute_test(int $testId): array
{
    $test = test_by_id($testId);
    if (!$test) throw new RuntimeException('Test topilmadi');
    $items = test_items($test);
    $L = count($items);
    $resp = rows('SELECT r.*, s.code, s.full_name FROM responses r JOIN students s ON s.id=r.student_id
                  WHERE r.test_id=? AND r.status="submitted" ORDER BY r.id', [$testId]);
    $X = []; $answersAll = []; $sids = [];
    foreach ($resp as $r) {
        $ans = json_decode($r['answers'] ?: '{}', true) ?: [];
        $sc = score_response($test, $ans, json_decode((string)($r['overrides'] ?? ''), true) ?: []);
        $X[] = array_values($sc);
        $answersAll[] = $ans;
        $sids[] = (int)$r['student_id'];
    }
    $N = count($X);

    db()->beginTransaction();
    q('DELETE FROM results WHERE test_id=?', [$testId]);
    q('DELETE FROM item_stats WHERE test_id=?', [$testId]);

    if ($N === 0) {
        q('UPDATE tests SET stats_json=?, dirty=0, computed_at=NOW() WHERE id=?', [json_encode(['N' => 0]), $testId]);
        db()->commit();
        return ['N' => 0];
    }

    $R = rasch_estimate($X);
    $method = $test['method'] ?: 'tscore';
    $cap = (int)($test['cap75'] ?? 1) === 1;
    $M = (float)($test['t_mean'] ?? 50); $S = (float)($test['t_sd'] ?? 10);
    if ($S <= 0) $S = 10;
    $ballsRaw = convert_to_ball($R, $X, $method, $M, $S);   // markaz balli, cheklanmagan
    $balls = array_map(fn($v) => apply_cap($v, $cap), $ballsRaw);
    // Rasmiy prognoz: har doim 50 + 10·Z (milliy sertifikat shkalasiga eng yaqin baho)
    $officialRaw = convert_to_ball($R, $X, 'tscore', 50, 10);
    $official = array_map(fn($v) => apply_cap($v, $cap), $officialRaw);

    // Natijalar va reyting
    $order = range(0, $N - 1);
    usort($order, fn($a, $b) => $balls[$b] <=> $balls[$a] ?: $R['raw'][$b] <=> $R['raw'][$a]);
    $rank = []; $prev = null; $pos = 0;
    foreach ($order as $k => $n) {
        $pos++;
        if ($prev === null || abs($balls[$n] - $prev) > 1e-9) $rankNo = $pos;
        $rank[$n] = $rankNo; $prev = $balls[$n];
    }
    $ins = db()->prepare('INSERT INTO results (test_id, student_id, raw, theta, se, infit, outfit, ball, ball_raw, grade, rank_no, scored, ball_official, grade_official)
                          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
    for ($n = 0; $n < $N; $n++) {
        $ins->execute([
            $testId, $sids[$n], $R['raw'][$n], round($R['theta'][$n], 4), round($R['theta_se'][$n], 4),
            $R['person_infit'][$n] !== null ? round($R['person_infit'][$n], 3) : null,
            $R['person_outfit'][$n] !== null ? round($R['person_outfit'][$n], 3) : null,
            $balls[$n], $ballsRaw[$n], grade_for($balls[$n]), $rank[$n], implode('', $X[$n]),
            $official[$n], grade_for($official[$n]),
        ]);
    }

    // Item statistikasi
    $totals = $R['raw'];
    $insI = db()->prepare('INSERT INTO item_stats (test_id, label, ord, b, se, infit, outfit, pvalue, pbis, n_correct, options_json, extreme)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
    foreach ($items as $i => $it) {
        $col = array_column($X, $i);
        $nc = array_sum($col);
        $rest = [];
        for ($n = 0; $n < $N; $n++) $rest[] = $totals[$n] - $col[$n];
        $pb = stats_corr($col, $rest);
        $opts = [];
        if ($it['type'] === 'mc') {
            foreach ($it['opts'] as $o) $opts[$o] = 0;
            $opts['—'] = 0;
            foreach ($answersAll as $a) {
                $v = strtoupper(trim((string)($a[$it['label']] ?? '')));
                if ($v === '' || !isset($opts[$v])) $v = '—';
                $opts[$v]++;
            }
        } else {
            $blank = 0;
            foreach ($answersAll as $a) if (trim((string)($a[$it['label']] ?? '')) === '') $blank++;
            $opts = ['correct' => $nc, 'blank' => $blank];
        }
        $insI->execute([
            $testId, $it['label'], $i, round($R['b'][$i], 4),
            $R['b_se'][$i] !== null ? round($R['b_se'][$i], 4) : null,
            $R['item_infit'][$i] !== null ? round($R['item_infit'][$i], 3) : null,
            $R['item_outfit'][$i] !== null ? round($R['item_outfit'][$i], 3) : null,
            round($nc / $N, 4), $pb !== null ? round($pb, 3) : null, $nc,
            json_encode($opts, JSON_UNESCAPED_UNICODE), $R['item_extreme'][$i] ? 1 : 0,
        ]);
    }

    // Umumiy statistika + xom ball → θ → ball jadvali
    $thetaMean = stats_mean($R['theta']);
    $thetaSd = stats_sd($R['theta']);
    $scoreTable = [];
    foreach ($R['score_table'] as $k => $st) {
        $scoreTable[$k] = [
            'theta' => round($st['theta'], 3), 'se' => round($st['se'], 3),
            'ball' => ($bt = ball_for_theta_row($R, $method, $k, $st['theta'], $thetaMean, $thetaSd, $M, $S)) === null ? null : apply_cap($bt, $cap),
            'official' => apply_cap((float)ball_for_theta_row($R, 'tscore', $k, $st['theta'], $thetaMean, $thetaSd), $cap),
            'ball_raw' => $bt,
        ];
    }
    $gradeDist = [];
    foreach (GRADE_SCALE as [$g]) $gradeDist[$g] = 0;
    $gradeDist['NB'] = 0;
    foreach ($balls as $bl) $gradeDist[grade_for($bl)]++;

    $stats = [
        'N' => $N, 'L' => $L, 'method' => $method,
        'theta_mean' => round($thetaMean, 4), 'theta_sd' => round($thetaSd, 4),
        'raw_mean' => round(stats_mean($R['raw']), 3), 'raw_sd' => round(stats_sd($R['raw']), 3),
        'ball_mean' => round(stats_mean($balls), 2), 'ball_sd' => round(stats_sd($balls), 2),
        'reliability' => $R['reliability'] !== null ? round($R['reliability'], 3) : null,
        'item_reliability' => $R['item_reliability'] !== null ? round($R['item_reliability'], 3) : null,
        'alpha' => $R['alpha'] !== null ? round($R['alpha'], 3) : null,
        'iterations' => $R['iterations'], 'converged' => $R['converged'],
        'score_table' => $scoreTable, 'grades' => $gradeDist,
        'weighted' => $method === 'weighted' ? item_weights($R['b']) : null,
        'cap' => $cap,
        'at_cap' => count(array_filter($ballsRaw, fn($v) => $v >= MAX_BALL - 1e-9)),
        'ball_raw_max' => round(max($ballsRaw), 1),
        'methods' => compare_methods($R, $X, $cap),
        't_mean' => $M, 't_sd' => $S,
        'official_cert' => count(array_filter($official, fn($v) => $v >= 46 - 1e-9)),
        'm_preview' => m_preview($R, $S),
    ];
    q('UPDATE tests SET stats_json=?, dirty=0, computed_at=NOW() WHERE id=?',
        [json_encode($stats, JSON_UNESCAPED_UNICODE), $testId]);
    db()->commit();
    return $stats;
}

/** Vaznli usul: w_i = 1 + (b_i − b_min); qiyinroq topshiriq ko'proq vaznga ega */
function item_weights(array $b): array
{
    if (!$b) return [];
    $min = min($b);
    return array_map(fn($x) => round(1 + ($x - $min), 4), $b);
}

function apply_cap(float $v, bool $cap): float
{
    $v = max(0.0, $v);
    return round($cap ? min(MAX_BALL, $v) : $v, 1);
}

/**
 * θ → ball (cheklanmagan). Standart ball usulida 50 + 10·Z qiymati 75 dan oshishi mumkin —
 * cheklash (cap) apply_cap() da alohida qo'llanadi.
 */
function convert_to_ball(array $R, array $X, string $method, float $M = 50, float $S = 10): array
{
    $N = count($R['theta']);
    $out = [];
    $mean = stats_mean($R['theta']);
    $sd = stats_sd($R['theta']);
    if ($method === 'weighted') {
        $w = item_weights($R['b']);
        $sumW = array_sum($w) ?: 1;
        for ($n = 0; $n < $N; $n++) {
            $s = 0.0;
            foreach ($X[$n] as $i => $x) if ($x) $s += $w[$i];
            $out[$n] = round(MAX_BALL * $s / $sumW, 1);
        }
        return $out;
    }
    for ($n = 0; $n < $N; $n++) {
        $out[$n] = ball_for_theta_row($R, $method, $R['raw'][$n], $R['theta'][$n], $mean, $sd, $M, $S);
    }
    return $out;
}

function ball_for_theta_row(array $R, string $method, int $raw, float $theta, float $mean, float $sd, float $M = 50, float $S = 10): ?float
{
    $L = $R['L'];
    if ($method === 'linear') {
        $t0 = $R['score_table'][0]['theta'];
        $tL = $R['score_table'][$L]['theta'];
        if ($tL - $t0 <= 0) return 0.0;
        return round(MAX_BALL * ($theta - $t0) / ($tL - $t0), 1);
    }
    if ($method === 'weighted') {
        return null; // vaznli usulda ball xom ballga emas, qaysi itemlar yechilganiga bog'liq
    }
    // tscore — cheklanmagan: M + S·Z (rasmiy prognoz uchun M = 50, S = 10)
    if ($sd <= 1e-9) return round($M, 1);
    $z = ($theta - $mean) / $sd;
    return round(max(0.0, $M + $S * $z), 1);
}

/** O'rtacha M ni o'zgartirganda nechta o'quvchi sertifikat (≥ 46) oladi */
function m_preview(array $R, float $S = 10): array
{
    $mean = stats_mean($R['theta']); $sd = stats_sd($R['theta']);
    $out = [];
    foreach ([50, 52, 54, 55, 56, 58, 60] as $M) {
        $c = 0;
        foreach ($R['theta'] as $t) if ($sd > 0 && $M + $S * ($t - $mean) / $sd >= 46 - 1e-9) $c++;
        $out[$M] = $c;
    }
    return $out;
}

/** Uchala usulni bir xil Rasch hisobida solishtirish (natijalar sahifasi uchun) */
function compare_methods(array $R, array $X, bool $cap): array
{
    $out = [];
    foreach (array_keys(method_names()) as $m) {
        $raw = convert_to_ball($R, $X, $m);
        $b = array_map(fn($v) => apply_cap($v, $cap), $raw);
        $g = [];
        foreach ($b as $v) { $gr = grade_for($v); $g[$gr] = ($g[$gr] ?? 0) + 1; }
        $out[$m] = [
            'mean' => round(stats_mean($b), 1), 'max' => round(max($raw), 1), 'min' => round(min($b), 1),
            'at_cap' => count(array_filter($raw, fn($v) => $v >= MAX_BALL - 1e-9)),
            'over' => count(array_filter($raw, fn($v) => $v > MAX_BALL + 1e-9)),
            'cert' => count(array_filter($b, fn($v) => $v >= 46 - 1e-9)),
            'a' => ($g['A+'] ?? 0) + ($g['A'] ?? 0),
            'aplus' => $g['A+'] ?? 0,
        ];
    }
    return $out;
}

/**
 * Bo'limlar bo'yicha to'g'ri javoblar: yopiq, moslashtirish, ochiq (a/b) va to'liq yechilgan topshiriqlar.
 */
function section_counts(array $test, string $scored): array
{
    $items = test_items($test);
    $bits = str_split($scored);
    $sec = [
        'closed' => ['Yopiq (A–D)', 0, 0], 'match' => ['Moslashtirish (A–F)', 0, 0], 'open' => ['Ochiq (a/b qismlar)', 0, 0],
    ];
    $tasks = []; // topshiriq raqami => [to'g'ri qismlar, jami qismlar]
    foreach ($items as $i => $it) {
        $ok = ($bits[$i] ?? '0') === '1';
        $k = $it['type'] === 'open' ? 'open' : (count($it['opts']) > 4 ? 'match' : 'closed');
        $sec[$k][1] += $ok ? 1 : 0; $sec[$k][2]++;
        $tasks[$it['task']][0] = ($tasks[$it['task']][0] ?? 0) + ($ok ? 1 : 0);
        $tasks[$it['task']][1] = ($tasks[$it['task']][1] ?? 0) + 1;
    }
    $full = 0; $partial = 0;
    foreach ($tasks as [$c, $t]) { if ($c === $t) $full++; elseif ($c > 0) $partial++; }
    $sec = array_filter($sec, fn($x) => $x[2] > 0);
    return [
        'sections' => $sec,
        'items_ok' => array_sum(array_column($sec, 1)), 'items_total' => count($items),
        'tasks_full' => $full, 'tasks_partial' => $partial, 'tasks_total' => count($tasks),
    ];
}

/**
 * Sertifikatdagi kabi bo'lim ballari: umumiy ball bo'limlarga to'g'ri yechilgan savollarning
 * qiyinlik vazni (w = 1 + b − b_min) ulushiga qarab taqsimlanadi. Bo'limlar yig'indisi = umumiy ball.
 * Eslatma: rasmiy taqsimlash formulasi e'lon qilinmagan — bu platformaning shaffof usuli.
 */
function section_scores(array $test, string $scored, float $ball): array
{
    static $cache = [];
    $tid = (int)$test['id'];
    if (!isset($cache[$tid])) {
        $b = [];
        foreach (rows('SELECT label, b FROM item_stats WHERE test_id=?', [$tid]) as $r) $b[$r['label']] = (float)$r['b'];
        $cache[$tid] = $b;
    }
    $bmap = $cache[$tid];
    $bmin = $bmap ? min($bmap) : 0.0;
    $sec = test_sections($test);
    $bits = str_split($scored);
    $out = [];
    foreach (SECTION_NAMES as $k => $name) $out[$k] = ['name' => $name, 'ok' => 0, 'total' => 0, 'w' => 0.0, 'ball' => 0.0];
    $wSum = 0.0;
    foreach (test_items($test) as $i => $it) {
        $k = $sec[$it['task']] ?? 'A';
        $out[$k]['total']++;
        if (($bits[$i] ?? '0') === '1') {
            $w = 1 + (($bmap[$it['label']] ?? 0.0) - $bmin);
            $out[$k]['ok']++; $out[$k]['w'] += $w; $wSum += $w;
        }
    }
    foreach ($out as $k => &$o) $o['ball'] = $wSum > 0 ? round($ball * $o['w'] / $wSum, 3) : 0.0;
    unset($o);
    // yaxlitlash farqini oxirgi bo'limga qo'shamiz, yig'indi aniq teng bo'lsin
    $keys = array_keys(array_filter($out, fn($o) => $o['total'] > 0));
    if ($keys && $wSum > 0) {
        $diff = round($ball - array_sum(array_column($out, 'ball')), 3);
        $out[end($keys)]['ball'] = round($out[end($keys)]['ball'] + $diff, 3);
    }
    return array_filter($out, fn($o) => $o['total'] > 0);
}
