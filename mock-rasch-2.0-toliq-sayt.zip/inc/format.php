<?php
defined('APP_ROOT') || exit;
/**
 * Test formati: milliy sertifikat matematika — 1–32 (A–D), 33–35 moslashtirish (A–F),
 * 36–45 ochiq topshiriqlar (a va b qismlari). Jami 55 ta baholanadigan element (item).
 */

const GRADE_SCALE = [
    ['A+', 70.0], ['A', 65.0], ['B+', 60.0], ['B', 55.0], ['C+', 50.0], ['C', 46.0],
];
const MAX_BALL = 75.0;        // e'lon qilingan "maksimal" (ixtiyoriy cheklov uchun)
const FULL_PERCENT_BALL = 65.0; // shu balldan boshlab foiz ko'rsatkichi 100% (OTMda fandan maksimal ball)

/** Sertifikatdagi "umumiy ballga nisbatan foiz ko'rsatkichi": ball / 65 × 100, 100% dan oshmaydi */
function cert_percent(float $ball): float
{
    return round(min(100.0, max(0.0, $ball / FULL_PERCENT_BALL * 100)), 2);
}

/**
 * Test uchun barcha itemlar ro'yxati.
 * Har bir item: ['label'=>'1', 'type'=>'mc', 'opts'=>['A','B','C','D'], 'task'=>1, 'part'=>'']
 */
function test_items(array $test): array
{
    $nClosed = (int)($test['n_closed'] ?? 32);
    $nMatch  = (int)($test['n_match'] ?? 3);
    $nOpen   = (int)($test['n_open'] ?? 10);
    $items = [];
    $no = 1;
    for ($i = 0; $i < $nClosed; $i++, $no++) {
        $items[] = ['label' => (string)$no, 'type' => 'mc', 'opts' => ['A', 'B', 'C', 'D'], 'task' => $no, 'part' => ''];
    }
    for ($i = 0; $i < $nMatch; $i++, $no++) {
        $items[] = ['label' => (string)$no, 'type' => 'mc', 'opts' => ['A', 'B', 'C', 'D', 'E', 'F'], 'task' => $no, 'part' => ''];
    }
    for ($i = 0; $i < $nOpen; $i++, $no++) {
        foreach (['a', 'b'] as $p) {
            $items[] = ['label' => $no . $p, 'type' => 'open', 'opts' => [], 'task' => $no, 'part' => $p];
        }
    }
    return $items;
}

function closed_count(array $test): int
{
    return (int)$test['n_closed'] + (int)$test['n_match'];
}

function grade_for(float $ball): string
{
    foreach (GRADE_SCALE as [$g, $min]) {
        if ($ball >= $min - 1e-9) return $g;
    }
    return 'NB'; // sertifikat berilmaydi
}

function method_names(): array
{
    return [
        'tscore'   => 'Rasch θ → standart ball (50 + 10·Z)',
        'linear'   => 'Rasch θ → chiziqli shkala (0 … 75)',
        'weighted' => 'Qiyinlikka qarab vaznli ball (0 … 75)',
    ];
}

const SECTION_NAMES = ['A' => 'Algebra va matematik analiz asoslari', 'G' => 'Geometriya'];

/** Topshiriq raqami → bo'lim ('A' yoki 'G'). Belgilanmaganlari algebra hisoblanadi. */
function test_sections(array $test): array
{
    $raw = json_decode((string)($test['sections_json'] ?? ''), true) ?: [];
    $out = [];
    $nTasks = (int)$test['n_closed'] + (int)$test['n_match'] + (int)$test['n_open'];
    for ($t = 1; $t <= $nTasks; $t++) $out[$t] = (($raw[(string)$t] ?? 'A') === 'G') ? 'G' : 'A';
    return $out;
}
