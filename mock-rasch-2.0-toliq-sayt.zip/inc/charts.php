<?php
defined('APP_ROOT') || exit;
/** Oddiy SVG grafiklar (tashqi kutubxonasiz) */

function svg_bar_chart(array $data, array $opt = []): string
{
    // $data: [label => value]; $opt['colors'] = [label => css class]
    $w = $opt['w'] ?? 560; $h = $opt['h'] ?? 220;
    $padL = 34; $padB = 28; $padT = 16; $padR = 8;
    $max = max(4, (int)ceil(max($data ?: [1]) / 4) * 4);
    $n = max(1, count($data));
    $bw = ($w - $padL - $padR) / $n;
    $s = '<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="' . e($opt['title'] ?? 'grafik') . '">';
    $ticks = 4;
    for ($t = 0; $t <= $ticks; $t++) {
        $v = $max * $t / $ticks;
        $y = $h - $padB - ($h - $padB - $padT) * $t / $ticks;
        $s .= '<line class="grid" x1="' . $padL . '" x2="' . ($w - $padR) . '" y1="' . $y . '" y2="' . $y . '"/>';
        $s .= '<text class="tick" x="' . ($padL - 6) . '" y="' . ($y + 4) . '" text-anchor="end">' . round($v) . '</text>';
    }
    $i = 0;
    foreach ($data as $label => $v) {
        $bh = ($h - $padB - $padT) * $v / $max;
        $x = $padL + $i * $bw + $bw * 0.15;
        $y = $h - $padB - $bh;
        $cls = $opt['colors'][$label] ?? 'bar';
        $s .= '<rect class="' . e($cls) . '" x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . round($bw * 0.7, 1) . '" height="' . round(max(0, $bh), 1) . '" rx="3"><title>' . e($label) . ': ' . $v . '</title></rect>';
        if ($v > 0) $s .= '<text class="val" x="' . round($x + $bw * 0.35, 1) . '" y="' . round($y - 4, 1) . '" text-anchor="middle">' . $v . '</text>';
        $s .= '<text class="tick" x="' . round($x + $bw * 0.35, 1) . '" y="' . ($h - $padB + 16) . '" text-anchor="middle">' . e($label) . '</text>';
        $i++;
    }
    $s .= '</svg>';
    return $s;
}

/**
 * Wright xaritasi: chapda o'quvchilar θ gistogrammasi, o'ngda itemlar qiyinligi.
 */
function svg_wright_map(array $thetas, array $items /* [label=>b] */, array $opt = []): string
{
    $all = array_merge($thetas, array_values($items));
    if (!$all) return '';
    $lo = floor(min($all)) - 0.5; $hi = ceil(max($all)) + 0.5;
    $lo = max($lo, -7); $hi = min($hi, 7);
    $w = 640; $h = 520; $padT = 20; $padB = 24; $mid = 250;
    $Y = fn($v) => $padT + ($hi - max($lo, min($hi, $v))) / ($hi - $lo) * ($h - $padT - $padB);
    $s = '<svg class="chart wright" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="Wright xaritasi">';
    // o'q
    for ($v = ceil($lo); $v <= floor($hi); $v++) {
        $y = $Y($v);
        $s .= '<line class="grid" x1="40" x2="' . ($w - 10) . '" y1="' . $y . '" y2="' . $y . '"/>';
        $s .= '<text class="tick" x="' . ($mid) . '" y="' . ($y - 3) . '" text-anchor="middle">' . ($v > 0 ? '+' : '') . $v . '</text>';
    }
    $s .= '<line class="axis" x1="' . $mid . '" x2="' . $mid . '" y1="' . $padT . '" y2="' . ($h - $padB) . '"/>';
    $s .= '<text class="axis-title" x="' . ($mid - 20) . '" y="14" text-anchor="end">O\'quvchilar (θ)</text>';
    $s .= '<text class="axis-title" x="' . ($mid + 20) . '" y="14">Topshiriqlar (b)</text>';
    $s .= '<text class="tick" x="8" y="' . ($padT + 10) . '">yuqori qobiliyat / qiyin</text>';
    $s .= '<text class="tick" x="8" y="' . ($h - 6) . '">past qobiliyat / oson</text>';
    // o'quvchilar gistogrammasi (0.25 logit qadam)
    $bin = 0.25; $bins = [];
    foreach ($thetas as $t) { $k = (int)floor(($t - $lo) / $bin); $bins[$k] = ($bins[$k] ?? 0) + 1; }
    $maxB = max(1, max($bins ?: [1]));
    foreach ($bins as $k => $c) {
        $v0 = $lo + $k * $bin; $y1 = $Y($v0 + $bin); $y0 = $Y($v0);
        $len = ($mid - 50) * $c / $maxB;
        $s .= '<rect class="bar-person" x="' . round($mid - 6 - $len, 1) . '" y="' . round($y1 + 0.5, 1) . '" width="' . round($len, 1) . '" height="' . round(max(1, $y0 - $y1 - 1), 1) . '"><title>' . $c . ' o\'quvchi: θ ≈ ' . round($v0 + $bin / 2, 2) . '</title></rect>';
    }
    // itemlar — ustma-ust tushmasligi uchun qatorlab joylash
    asort($items);
    $slots = [];
    foreach ($items as $label => $b) {
        $row = (int)round($Y($b) / 14);
        $y = $row * 14;                      // bir qatorga tekislash — yozuvlar ustma-ust tushmaydi
        $col = $slots[$row] = ($slots[$row] ?? -1) + 1;
        $x = $mid + 12 + $col * 38;
        if ($x > $w - 30) continue;
        $cls = $opt['flag'][$label] ?? '';
        $s .= '<g class="item-dot ' . e($cls) . '"><circle cx="' . ($x + 3) . '" cy="' . round($y, 1) . '" r="3"/><text x="' . ($x + 9) . '" y="' . round($y + 4, 1) . '">' . e($label) . '</text><title>' . e($label) . ': b = ' . round($b, 2) . '</title></g>';
    }
    $s .= '</svg>';
    return $s;
}

/**
 * Ball taqsimoti gistogrammasi (cheklanmagan qiymatlar bo'yicha), daraja chegaralari va 75 chizig'i bilan.
 */
function svg_ball_histogram(array $vals, array $opt = []): string
{
    if (!$vals) return '';
    $step = 2.5;
    $maxV = max($vals);
    $hiEdge = max(80.0, ceil(($maxV + 0.01) / 5) * 5);
    $nb = (int)ceil($hiEdge / $step);
    $bins = array_fill(0, $nb, 0);
    foreach ($vals as $v) { $k = min($nb - 1, max(0, (int)floor($v / $step))); $bins[$k]++; }
    $w = 640; $h = 250; $pl = 34; $pr = 12; $pt = 26; $pb = 30;
    $X = fn($v) => $pl + $v / $hiEdge * ($w - $pl - $pr);
    $stepC = max(1, (int)ceil(max($bins) / 4));
    $maxC = $stepC * 4;
    $Y = fn($c) => $h - $pb - $c / $maxC * ($h - $pt - $pb);
    $s = '<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="Ballar taqsimoti">';
    for ($t = 0; $t <= 4; $t++) {
        $c = $maxC * $t / 4; $y = $Y($c);
        $s .= '<line class="grid" x1="' . $pl . '" x2="' . ($w - $pr) . '" y1="' . round($y, 1) . '" y2="' . round($y, 1) . '"/>';
        $s .= '<text class="tick" x="' . ($pl - 6) . '" y="' . round($y + 4, 1) . '" text-anchor="end">' . round($c) . '</text>';
    }
    foreach ($bins as $k => $c) {
        if (!$c) continue;
        $a = $k * $step; $b = $a + $step;
        $g = grade_for($a + 0.01);
        $cls = ['A+' => 'g-ap', 'A' => 'g-a', 'B+' => 'g-bp', 'B' => 'g-b', 'C+' => 'g-cp', 'C' => 'g-c'][$g] ?? 'g-none';
        $x = $X($a) + 1; $bw = $X($b) - $X($a) - 2; $y = $Y($c);
        $s .= '<rect class="hbar ' . $cls . '" x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . round($bw, 1) . '" height="' . round($h - $pb - $y, 1) . '" rx="3"><title>' . fmt($a) . '–' . fmt($b) . ' ball: ' . $c . ' o\'quvchi</title></rect>';
    }
    foreach ([46 => 'C', 50 => 'C+', 55 => 'B', 60 => 'B+', 65 => 'A', 70 => 'A+'] as $v => $lab) {
        $x = round($X($v), 1);
        $s .= '<line class="thr" x1="' . $x . '" x2="' . $x . '" y1="' . ($pt - 6) . '" y2="' . ($h - $pb) . '"/><text class="thr-lbl" x="' . ($x + 3) . '" y="' . ($pt - 10) . '">' . $lab . '</text>';
    }
    $x75 = round($X(75), 1);
    $s .= '<line class="cap-line" x1="' . $x75 . '" x2="' . $x75 . '" y1="' . ($pt - 6) . '" y2="' . ($h - $pb) . '"/><text class="cap-lbl" x="' . ($x75 + 4) . '" y="' . ($pt + 6) . '">75</text>';
    for ($v = 0; $v <= $hiEdge; $v += 10) {
        $s .= '<text class="tick" x="' . round($X($v), 1) . '" y="' . ($h - $pb + 16) . '" text-anchor="middle">' . $v . '</text>';
    }
    $s .= '<line class="axis" x1="' . $pl . '" x2="' . ($w - $pr) . '" y1="' . ($h - $pb) . '" y2="' . ($h - $pb) . '"/>';
    $s .= '</svg>';
    return $s;
}

/** Har bir savolga to'g'ri javob berganlar ulushi (ustunli diagramma) */
function svg_item_bars(array $items, int $N, array $flag = []): string
{
    if (!$items || !$N) return '';
    $n = count($items);
    $w = max(640, $n * 15 + 50); $h = 230; $pl = 36; $pr = 8; $pt = 12; $pb = 34;
    $bw = ($w - $pl - $pr) / $n;
    $Y = fn($p) => $pt + (1 - $p) * ($h - $pt - $pb);
    $s = '<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="Savollar bo\'yicha to\'g\'ri javoblar ulushi">';
    foreach ([0, .25, .5, .75, 1] as $p) {
        $y = round($Y($p), 1);
        $s .= '<line class="grid" x1="' . $pl . '" x2="' . ($w - $pr) . '" y1="' . $y . '" y2="' . $y . '"/><text class="tick" x="' . ($pl - 5) . '" y="' . ($y + 4) . '" text-anchor="end">' . ($p * 100) . '%</text>';
    }
    foreach (array_values($items) as $i => $it) {
        $p = (float)$it['pvalue'];
        $x = $pl + $i * $bw + 1.5; $y = $Y($p);
        $cls = isset($flag[$it['label']]) && $flag[$it['label']] === 'flag-red' ? 'bar-crit' : 'bar';
        $s .= '<rect class="' . $cls . '" x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . round(max(2, $bw - 3), 1) . '" height="' . round($h - $pb - $y, 1) . '" rx="2"><title>' . e($it['label']) . '-savol: ' . (int)$it['n_correct'] . ' / ' . $N . ' (' . round($p * 100) . '%)</title></rect>';
        $s .= '<text class="tick" x="' . round($x + ($bw - 3) / 2, 1) . '" y="' . ($h - $pb + 12 + ($i % 2) * 11) . '" text-anchor="middle" style="font-size:9.5px">' . e($it['label']) . '</text>';
    }
    $s .= '<line class="axis" x1="' . $pl . '" x2="' . ($w - $pr) . '" y1="' . ($h - $pb) . '" y2="' . ($h - $pb) . '"/></svg>';
    return $s;
}

/**
 * Savollar bo'yicha ustunli diagramma: ustunlar nol chizig'idan yuqoriga (musbat) yoki pastga (manfiy) o'sadi.
 * $rows: [['label' => '12', 'v' => -0.53 (yoki null — hisoblanmagan), 'cls' => 'b-neg', 'tip' => 'sichqoncha ustiga kelganda matn'], ...]
 * $opt:  lo, hi — o'q chegaralari; step — eng kichik bo'linma qadami; dec — qiymat kasr xonalari; plus — musbatga "+" qo'yish;
 *        sym — o'qni nolga nisbatan simmetrik qilish; vals — ustun uchida qiymat yozish;
 *        clip — |qiymat| shundan katta bo'lsa ustun kesiladi (uzilish belgisi, yozuvda haqiqiy qiymat);
 *        tlim — [min, max] o'q raqamlari shu oraliqdan chiqmasin; thr — [[qiymat, yozuv], ...] punktir chegaralar;
 *        band — [pastki, yuqori, yozuv] soyalangan yo'lak; sections — [[boshi, oxiri (indeks), nomi, izoh], ...];
 *        ytitle — o'q birligi; title — aria-label.
 * Ranglar CSS'dan olinadi; SVG'dagi atributlar — CSS yuklanmay qolgan (eski kesh) holat uchun zaxira.
 */
function svg_item_columns(array $rows, array $opt = []): string
{
    $rows = array_values($rows);
    $n = count($rows);
    if (!$n) return '';
    $lo = (float)$opt['lo']; $hi = (float)$opt['hi']; $step = (float)($opt['step'] ?? 1);
    $dec = (int)($opt['dec'] ?? 2); $vals = $opt['vals'] ?? true; $plus = !empty($opt['plus']);
    $clip = isset($opt['clip']) ? (float)$opt['clip'] : null;
    $slot = 20; $bw = 12; $pl = 44; $pt = !empty($opt['sections']) ? 48 : 20; $ph = (int)($opt['h'] ?? 300);
    $pr = (!empty($opt['thr']) || !empty($opt['band'])) ? 62 : 10;          // o'ng chet — chegara yozuvlari uchun (ustunlar ostida qolmasin)
    $parts = (bool)array_filter($rows, fn($r) => preg_match('/^\d+[a-z]$/', (string)$r['label']));
    $pb = $parts ? 40 : 26;                                                // "36a" → pastda "a", ostida "36" (yozuvlar tiqilmasin)
    $w = $pl + $n * $slot + $pr; $h = $pt + $ph + $pb;
    $shown = fn($v) => $clip === null ? (float)$v : max(-$clip, min($clip, (float)$v));   // chizmada ko'rinadigan qiymat
    // Ustun uchidagi yozuv sig'ishi uchun o'qni kerakli qadar kengaytirish
    $vs = array_map($shown, array_values(array_filter(array_column($rows, 'v'), fn($v) => $v !== null)));
    if ($vs && $vals) {
        $need = 38 / $ph;
        for ($g = 0; $g < 60 && max($vs) > $hi - $need * ($hi - $lo); $g++) $hi += $step;
        for ($g = 0; $g < 60 && min($vs) < $lo + $need * ($hi - $lo); $g++) $lo -= $step;
    }
    if (!empty($opt['sym'])) { $m = max(-$lo, $hi); $lo = -$m; $hi = $m; }
    // O'q bo'linmalari: 10 tadan oshmasin (o'q keng bo'lsa qadam 2, 5 ... bo'ladi)
    $tstep = $step;
    foreach ([0.05, 0.1, 0.2, 0.25, 0.5, 1, 2, 2.5, 5, 10, 20] as $st) if ($st >= $step - 1e-9 && ($hi - $lo) / $st <= 10) { $tstep = $st; break; }
    $tickDec = $tstep < 1 ? ($tstep == 0.25 || $tstep == 0.05 ? 2 : 1) : ($tstep == 2.5 ? 1 : 0);
    [$tMin, $tMax] = $opt['tlim'] ?? [-INF, INF];
    $Y = fn($v) => $pt + ($hi - max($lo, min($hi, (float)$v))) / ($hi - $lo) * $ph;
    $num = function (float $v, int $d) use ($plus): string {
        $v = round($v, $d); if ($v == 0) $v = 0.0;   // "−0.00" emas, "0.00"
        return ($v < 0 ? '−' : ($plus && $v > 0 ? '+' : '')) . number_format(abs($v), $d, '.', '');
    };
    $fill = ['b-neg' => '#2a78d6', 'b-pos' => '#eb6834', 'b-norm' => '#3987e5', 'b-crit' => '#d03b3b'];

    $s = '<svg class="chart item-cols" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="' . e($opt['title'] ?? '') . '" font-family="Inter, Arial, sans-serif">';
    if (!empty($opt['ytitle'])) $s .= '<text class="axis-title" x="4" y="' . ($pt - 10) . '" font-size="11.5" fill="#817e74">' . e($opt['ytitle']) . '</text>';
    if (!empty($opt['band'])) {
        [$a, $b, $lbl] = $opt['band'];
        $ya = round($Y($b), 1); $yb = round($Y($a), 1);
        $s .= '<rect class="band" x="' . $pl . '" y="' . $ya . '" width="' . ($w - $pl - $pr) . '" height="' . max(0, $yb - $ya) . '" fill="#fbf1dd"/>';
        $s .= '<text class="band-lbl" x="' . ($w - $pr + 6) . '" y="' . round(($ya + $yb) / 2 + 3.5, 1) . '" font-size="10" fill="#817e74">' . e($lbl) . '</text>';
    }
    for ($k = (int)ceil($lo / $tstep - 1e-9); $k * $tstep <= $hi + 1e-9; $k++) {
        $v = $k * $tstep; if ($v < $tMin - 1e-9 || $v > $tMax + 1e-9) continue;
        $y = round($Y($v), 1);
        if (abs($v) > 1e-9) $s .= '<line class="grid" x1="' . $pl . '" x2="' . ($w - $pr) . '" y1="' . $y . '" y2="' . $y . '" stroke="#e5e1d5"/>';
        $s .= '<text class="tick" x="' . ($pl - 6) . '" y="' . ($y + 4) . '" text-anchor="end" font-size="11" fill="#817e74">' . $num($v, $tickDec) . '</text>';
    }
    foreach ($opt['thr'] ?? [] as $t) {
        [$v, $lbl] = $t;
        $y = round($Y($v), 1);
        $s .= '<line class="thr" x1="' . $pl . '" x2="' . ($w - $pr + 3) . '" y1="' . $y . '" y2="' . $y . '" stroke="#d4cfc0" stroke-dasharray="3 3"/>';
        $s .= '<text class="thr-lbl" x="' . ($w - $pr + 6) . '" y="' . ($y + 3.5) . '" font-size="10.5" fill="#817e74">' . e($lbl) . '</text>';
    }
    foreach ($opt['sections'] ?? [] as [$from, $to, $name, $note]) {
        $x0 = $pl + $from * $slot; $x1 = $pl + ($to + 1) * $slot; $wide = $x1 - $x0 >= 130;
        if ($from > 0) $s .= '<line class="sec-sep" x1="' . $x0 . '" x2="' . $x0 . '" y1="' . ($pt - 8) . '" y2="' . ($pt + $ph) . '" stroke="#d4cfc0"/>';
        $tx = $wide ? ($x0 + $x1) / 2 : $x0 + 5; $anc = $wide ? 'middle' : 'start';
        $s .= '<text class="sec-name" x="' . $tx . '" y="14" text-anchor="' . $anc . '" font-size="11.5" font-weight="700">' . e($name) . '</text>';
        if ($note !== '') $s .= '<text class="sec-note" x="' . $tx . '" y="28" text-anchor="' . $anc . '" font-size="10.5" fill="#817e74">' . e($note) . '</text>';
    }
    $y0 = round($Y(0), 1); $grp = [];
    foreach ($rows as $i => $r) {
        $x = $pl + $i * $slot; $cx = $x + $slot / 2;
        $s .= '<g class="col">';
        if ($r['v'] !== null) {
            $v = (float)$r['v']; $cut = $clip !== null && abs($v) > $clip; $y1 = $Y($shown($v));
            if (abs($y1 - $y0) < 1.5) $y1 = $v < 0 ? $y0 + 1.5 : $y0 - 1.5;   // nolga juda yaqin qiymat ham ko'rinsin
            $up = $y1 < $y0; $rr = min(4, abs($y1 - $y0), $bw / 2); $bx = $cx - $bw / 2; $sg = $up ? 1 : -1;
            // 4px yumaloq uch, asos (nol) tomoni to'g'ri burchak
            $d = 'M' . round($bx, 1) . ',' . $y0 . 'V' . round($y1 + $sg * $rr, 1) . 'Q' . round($bx, 1) . ',' . round($y1, 1) . ' ' . round($bx + $rr, 1) . ',' . round($y1, 1)
               . 'H' . round($bx + $bw - $rr, 1) . 'Q' . round($bx + $bw, 1) . ',' . round($y1, 1) . ' ' . round($bx + $bw, 1) . ',' . round($y1 + $sg * $rr, 1) . 'V' . $y0 . 'Z';
            $cls = (string)($r['cls'] ?? '');
            $s .= '<path class="b ' . e($cls) . '" d="' . $d . '" fill="' . ($fill[$cls] ?? '#3987e5') . '"/>';
            if ($cut) {   // kesilgan ustun: uchiga yaqin ikki qiya uzilish
                $yb = round($y1 + $sg * 9, 1);
                $s .= '<path class="brk" d="M' . round($bx - 2, 1) . ',' . round($yb + 2, 1) . 'L' . round($bx + $bw + 2, 1) . ',' . round($yb - 2, 1)
                    . 'M' . round($bx - 2, 1) . ',' . round($yb + 6 * $sg + 2, 1) . 'L' . round($bx + $bw + 2, 1) . ',' . round($yb + 6 * $sg - 2, 1) . '" stroke="#fff" stroke-width="2.5" fill="none"/>';
            }
            if ($vals) {
                $tx = round($cx + 3.6, 1); $ty = round($up ? $y1 - 4 : $y1 + 4, 1);
                $s .= '<text class="bval" x="' . $tx . '" y="' . $ty . '" transform="rotate(-90 ' . $tx . ' ' . $ty . ')" text-anchor="' . ($up ? 'start' : 'end') . '" font-size="9.5" font-weight="600" fill="#4d4b45">' . $num($v, $dec) . '</text>';
            }
        }
        $xl = (string)$r['label'];
        if (preg_match('/^(\d+)([a-z])$/', $xl, $mm)) { $xl = $mm[2]; $grp[$mm[1]][] = $cx; }   // "36a" → "a" (raqam pastda bir marta)
        $s .= '<text class="tick xl' . ($r['v'] === null ? ' na' : '') . '" x="' . $cx . '" y="' . ($pt + $ph + 16) . '" text-anchor="middle" font-size="10.5" font-weight="600" fill="#4d4b45">' . e($xl) . '</text>';
        // Sichqoncha uchun butun ustun kengligidagi ko'rinmas maydon (kichik ustunni ham oson topish uchun)
        $s .= '<rect class="hit" x="' . $x . '" y="' . $pt . '" width="' . $slot . '" height="' . ($ph + $pb - 4) . '" fill="transparent"><title>' . e($r['tip'] ?? '') . '</title></rect>';
        $s .= '</g>';
    }
    foreach ($grp as $no => $xs) {   // topshiriq raqami a/b juftligi ostida
        $a = min($xs) - 6; $b = max($xs) + 6; $yy = $pt + $ph + 21;
        $s .= '<path class="grp-br" d="M' . $a . ',' . $yy . 'v2.5H' . $b . 'v-2.5" fill="none" stroke="#d4cfc0"/>';
        $s .= '<text class="tick xl" x="' . round(($a + $b) / 2, 1) . '" y="' . ($yy + 13) . '" text-anchor="middle" font-size="10.5" font-weight="600" fill="#4d4b45">' . e($no) . '</text>';
    }
    $s .= '<line class="zero" x1="' . $pl . '" x2="' . ($w - $pr) . '" y1="' . $y0 . '" y2="' . $y0 . '" stroke="#4d4b45" stroke-width="1.2"/>';
    return $s . '</svg>';
}
