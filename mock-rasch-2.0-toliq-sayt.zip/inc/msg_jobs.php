<?php
defined('APP_ROOT') || exit;
/**
 * Navbat vazifalari: xona/o'rin xabari (room) va ota-onalarga natija (p1, p2 — SMS; ptg — ota-ona Telegrami).
 * Navbat umumiy: tg_queue (channel = 'tg' | 'sms'); yuborishni tg_drain() boshqaradi.
 */

/** Ota-ona havolasi tokeni: o'quvchi + test uchun, saqlanmaydi (HMAC) — havolani faqat shu yerdan yasash mumkin */
function parent_token(int $sid, int $tid): string
{
    return substr(hash_hmac('sha256', 'pr|' . $sid . '|' . $tid, otp_key()), 0, 24);
}

function parent_result_url(array $s, int $tid): string
{
    $base = tg_site_url();
    // qisqa havola (SMS uzunligi): ID.MOCK.token
    return ($base !== '' ? $base . '/' : '') . 'index.php?p=pr&c=' . $s['code'] . '.' . $tid . '.' . substr(parent_token((int)$s['id'], $tid), 0, 16);
}

/** Natija satri (e'lon qilingan bo'lsa), aks holda null */
function msg_result_row(int $sid, int $tid): ?array
{
    return row('SELECT t.id, t.title, t.published, res.ball, res.grade, res.rank_no,
                       (SELECT COUNT(*) FROM results r2 WHERE r2.test_id=res.test_id) total
                FROM results res JOIN tests t ON t.id=res.test_id WHERE res.test_id=? AND res.student_id=? AND t.published=1', [$tid, $sid]);
}

/** Navbat vazifasini kanali bo'yicha yuboradi. Qaytaradi: tg_call formatidagi natija */
function msg_deliver(array $j, string $html, string $sms, ?array $kb = null): array
{
    if (($j['channel'] ?? 'tg') === 'sms') {
        if (!sms_ready()) return ['ok' => false, 'code' => 400, 'desc' => 'Eskiz ulanmagan', 'retry' => 0];
        $r = sms_send((string)$j['phone'], $sms);
        if ($r['ok']) return ['ok' => true];
        $code = (int)($r['code'] ?? 0);
        $final = $r['desc'] === 'Telefon raqam noto\'g\'ri' || ($code >= 400 && $code < 500 && $code !== 401 && $code !== 429);
        return ['ok' => false, 'code' => $final ? 400 : ($code === 429 ? 429 : 0), 'desc' => $r['desc'] ?: 'SMS yuborilmadi', 'retry' => 1];
    }
    return tg_send((int)$j['chat_id'], $html, $kb);
}

function msg_run_job(array $j): array
{
    $sid = (int)$j['student_id'];
    $tid = (int)$j['test_id'];
    $s = row('SELECT * FROM students WHERE id=?', [$sid]);
    if ($j['kind'] === 'temp') {   // vaqtinchalik parolni yuborish (faqat hali almashtirilmagan bo'lsa)
        if (!$s || (int)$s['must_change'] !== 1 || (string)$s['pin'] === '') return ['ok' => true, 'skip' => 'parol allaqachon almashtirilgan'];
        $site = tg_site_url();
        $html = "🔑 <b>MOCK Rasch</b>\nID: <b>" . tg_h($s['code']) . "</b>\nVaqtinchalik parol: <b>" . tg_h($s['pin']) . "</b>\n\nKirgach parolni o‘zingiz belgilaysiz." . ($site !== '' ? "\n" . tg_h($site) : '');
        return msg_deliver($j, $html, sms_render('temp', ['id' => $s['code'], 'pass' => $s['pin']]));
    }
    $test = $tid ? test_by_id($tid) : null;
    if (!$s || !$test) return ['ok' => true, 'skip' => 'topilmadi'];

    if ($j['kind'] === 'room') {
        $g = row('SELECT g.seat, r.name FROM test_registrations g JOIN test_rooms r ON r.id=g.room_id WHERE g.test_id=? AND g.student_id=?', [$tid, $sid]);
        if (!$g || $g['seat'] === null) return ['ok' => true, 'skip' => 'xona belgilanmagan'];
        $when = !empty($test['test_date']) ? date('d.m.Y', strtotime((string)$test['test_date'])) : (!empty($test['online_start']) ? tg_dt($test['online_start']) : '');
        $whenSms = $when !== '' ? $when : 'sana belgilanmagan';
        $html = "🏫 <b>" . tg_h($test['title']) . "</b>" . ($when !== '' ? "\n📅 " . tg_h($when) : '')
            . "\n📍 Xona: <b>" . tg_h($g['name']) . "</b>\n💺 O‘rin: <b>" . (int)$g['seat'] . "</b>\n\n15 daqiqa oldin keling; ID raqamingiz va qalam olib keling.";
        $sms = sms_render('room', ['test' => mb_substr((string)$test['title'], 0, 40), 'date' => $whenSms, 'room' => $g['name'], 'seat' => (int)$g['seat']]);
        $r = msg_deliver($j, $html, $sms);
        if (!empty($r['ok']) && !isset($r['skip'])) q('UPDATE test_registrations SET notified_at=NOW() WHERE test_id=? AND student_id=?', [$tid, $sid]);
        return $r;
    }

    // Ota-onaga natija
    if (!empty($s['parent_optout'])) return ['ok' => true, 'skip' => 'ota-ona rad etgan'];
    $res = msg_result_row($sid, $tid);
    if (!$res) return ['ok' => true, 'skip' => 'natija e’lon qilinmagan'];
    $url = parent_result_url($s, $tid);
    $name = (string)($s['full_name'] ?: 'O‘quvchi');
    $grade = tg_grade_label((string)$res['grade']);
    $html = "📊 <b>" . tg_h($name) . "</b> — <b>" . tg_h($res['title']) . "</b> natijasi\n\nBall: <b>" . fmt($res['ball']) . "</b>\nDaraja: <b>" . tg_h($grade) . "</b>\nO‘rin: <b>" . (int)$res['rank_no'] . "</b> / " . (int)$res['total']
        . "\n\nBatafsil: " . tg_h($url);
    $sms = sms_render('result', ['name' => mb_substr($name, 0, 24), 'test' => mb_substr((string)$res['title'], 0, 18), 'ball' => fmt($res['ball']), 'grade' => $grade, 'rank' => (int)$res['rank_no'], 'url' => $url]);
    return msg_deliver($j, $html, $sms);
}

/**
 * Vaqtinchalik parolni navbatga qo'yadi (bot bo'lsa bot, bo'lmasa SMS). Qaytaradi: 'bot' | 'sms' | ''.
 * Telegram Gateway faqat kod yuboradi, shuning uchun bu yerda ishlatilmaydi.
 */
function msg_queue_temp(array $s): string
{
    if ((int)$s['must_change'] !== 1 || (string)$s['pin'] === '') return '';
    $ph = (string)$s['phone'];
    $ch = ''; $chat = 0; $phone = '';
    if (!empty($s['tg_chat_id']) && tg_ready()) { $ch = 'tg'; $chat = (int)$s['tg_chat_id']; }
    elseif ($ph !== '' && sms_ready()) { $ch = 'sms'; $phone = $ph; }
    if ($ch === '') return '';
    q('DELETE FROM tg_queue WHERE kind="temp" AND student_id=? AND sent_at IS NOT NULL', [$s['id']]);
    tg_enqueue('temp', 0, (int)$s['id'], $chat, null, null, $ch, $phone);
    return $ch === 'tg' ? 'bot' : 'sms';
}

/**
 * Xona va o'rin haqida xabar rejasi. Kanal: bot (ulangan bo'lsa), aks holda SMS (telefon va Eskiz bo'lsa), aks holda yetkazib bo'lmaydi.
 * $resend=false — avval xabar olganlar o'tkaziladi.
 * Qaytaradi: ['bot'=>[[sid,chat]…], 'sms'=>[[sid,phone]…], 'none'=>[sid…], 'done'=>soni (avval yuborilgan)]
 */
function room_notify_plan(int $tid, bool $resend = false): array
{
    $plan = ['bot' => [], 'sms' => [], 'none' => [], 'done' => 0];
    foreach (rows('SELECT s.id, s.phone, s.tg_chat_id, g.notified_at FROM test_registrations g JOIN students s ON s.id=g.student_id
                   WHERE g.test_id=? AND g.room_id IS NOT NULL AND g.seat IS NOT NULL ORDER BY s.full_name', [$tid]) as $r) {
        if (!$resend && $r['notified_at']) { $plan['done']++; continue; }
        if (!empty($r['tg_chat_id']) && tg_ready()) $plan['bot'][] = [(int)$r['id'], (int)$r['tg_chat_id']];
        elseif ($r['phone'] !== '' && sms_ready()) $plan['sms'][] = [(int)$r['id'], (string)$r['phone']];
        else $plan['none'][] = (int)$r['id'];
    }
    return $plan;
}

/** Rejani navbatga qo'yadi. Qaytaradi: ['bot'=>n,'sms'=>n,'none'=>n] */
function room_notify_queue(int $tid, bool $resend = false): array
{
    $plan = room_notify_plan($tid, $resend);
    foreach ($plan['bot'] as [$sid, $chat]) {
        q('DELETE FROM tg_queue WHERE kind="room" AND test_id=? AND student_id=?', [$tid, $sid]);
        tg_enqueue('room', $tid, $sid, $chat);
    }
    foreach ($plan['sms'] as [$sid, $phone]) {
        q('DELETE FROM tg_queue WHERE kind="room" AND test_id=? AND student_id=?', [$tid, $sid]);
        tg_enqueue('room', $tid, $sid, 0, null, null, 'sms', $phone);
    }
    return ['bot' => count($plan['bot']), 'sms' => count($plan['sms']), 'none' => count($plan['none'])];
}

/* ---------------- Ota-onalarga natija ---------------- */

/**
 * Ota-onalarga natija yuborish rejasi (faqat natijasi bor o'quvchilar).
 * $mode: 'auto' — ota-ona Telegrami ulangan bo'lsa Telegram, bo'lmasa SMS; 'sms' — faqat SMS; 'tg' — faqat Telegram.
 * $both: SMS ikkala raqamga ham. $resend: avval yuborilganlarga ham.
 * Qaytaradi: ['jobs'=>[[kind,sid,name,chat,phone]…], 'none'=>[[sid,name,sabab]…], 'done'=>soni, 'total'=>soni]
 */
function parent_plan(array $test, string $mode = 'auto', bool $both = false, bool $resend = false): array
{
    $plan = ['jobs' => [], 'none' => [], 'done' => 0, 'total' => 0];
    $tid = (int)$test['id'];
    $sent = [];
    foreach (rows('SELECT student_id, kind FROM tg_queue WHERE test_id=? AND kind IN ("p1","p2","ptg") AND sent_at IS NOT NULL AND error=""', [$tid]) as $r) $sent[(int)$r['student_id']][$r['kind']] = true;
    $list = rows('SELECT s.id, s.full_name, s.parent_phone, s.parent_phone2, s.parent_tg_chat, s.parent_optout
                  FROM results r JOIN students s ON s.id=r.student_id WHERE r.test_id=? ORDER BY s.full_name', [$tid]);
    foreach ($list as $s) {
        $sid = (int)$s['id'];
        $plan['total']++;
        if ($s['parent_optout']) { $plan['none'][] = [$sid, $s['full_name'], 'ota-ona rad etgan']; continue; }
        $tgOk = $mode !== 'sms' && $s['parent_tg_chat'] !== null && tg_ready();
        $phones = array_values(array_unique(array_filter([$s['parent_phone'], $s['parent_phone2']])));
        if (!$both) $phones = array_slice($phones, 0, 1);
        $smsOk = $mode !== 'tg' && sms_ready() && $phones;
        $cand = [];
        if ($tgOk) $cand[] = ['ptg', (int)$s['parent_tg_chat'], ''];
        if ($smsOk && !($mode === 'auto' && $tgOk)) foreach ($phones as $i => $ph) $cand[] = [$i === 0 ? 'p1' : 'p2', 0, $ph];
        if (!$cand) {
            $why = $s['parent_phone'] === '' && $s['parent_phone2'] === '' && $s['parent_tg_chat'] === null ? 'ota-ona raqami yo‘q' : (!sms_ready() && $mode !== 'tg' ? 'SMS ulanmagan' : 'tanlangan kanalda yetkazib bo‘lmaydi');
            $plan['none'][] = [$sid, $s['full_name'], $why];
            continue;
        }
        $already = true;
        foreach ($cand as $c) if (empty($sent[$sid][$c[0]])) $already = false;
        if ($already && !$resend) { $plan['done']++; continue; }
        foreach ($cand as $c) {
            if (!$resend && !empty($sent[$sid][$c[0]])) continue;
            $plan['jobs'][] = [$c[0], $sid, $s['full_name'], $c[1], $c[2]];
        }
    }
    return $plan;
}

/** Rejani navbatga qo'yadi. Qaytaradi: ['tg'=>n,'sms'=>n] */
function parent_queue(array $test, string $mode, bool $both, bool $resend): array
{
    $plan = parent_plan($test, $mode, $both, $resend);
    $n = ['tg' => 0, 'sms' => 0];
    foreach ($plan['jobs'] as [$kind, $sid, , $chat, $phone]) {
        q('DELETE FROM tg_queue WHERE kind=? AND test_id=? AND student_id=?', [$kind, (int)$test['id'], $sid]);
        tg_enqueue($kind, (int)$test['id'], $sid, $chat, null, null, $kind === 'ptg' ? 'tg' : 'sms', $phone);
        $n[$kind === 'ptg' ? 'tg' : 'sms']++;
    }
    return $n;
}

/** Yetkazish hisoboti: har bir vazifa uchun holat */
function parent_report(int $tid): array
{
    return rows('SELECT q.id, q.kind, q.channel, q.phone, q.chat_id, q.sent_at, q.error, q.attempts, q.created_at, s.full_name, s.code
                 FROM tg_queue q JOIN students s ON s.id=q.student_id
                 WHERE q.test_id=? AND q.kind IN ("p1","p2","ptg") ORDER BY s.full_name, q.kind', [$tid]);
}
