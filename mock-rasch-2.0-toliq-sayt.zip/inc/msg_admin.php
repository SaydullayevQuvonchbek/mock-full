<?php
defined('APP_ROOT') || exit;
/**
 * Sozlamalar → «Xabarlar» kartasi: Eskiz.uz SMS, Telegram Gateway, kodlarni yuborish tartibi.
 */

/** Sozlamalar sahifasidagi amallar. Bajarilgan bo'lsa true */
function msg_settings_post(string $act): bool
{
    if (strncmp($act, 'msg_', 4) !== 0) return false;

    if ($act === 'msg_eskiz') {
        $email = trim((string)($_POST['sms_email'] ?? ''));
        $pass = (string)($_POST['sms_pass'] ?? '');
        $from = trim((string)($_POST['sms_from'] ?? ''));
        if ($email === '' && $pass === '') {
            foreach (['sms_email', 'sms_pass', 'sms_token', 'sms_token_at', 'sms_bal', 'sms_bal_at'] as $k) q('DELETE FROM meta WHERE k=?', ['set_' . $k]);
            flash('Eskiz ulanishi o‘chirildi');
            return true;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { flash('Eskiz email manzilini to‘g‘ri kiriting', 'err'); return true; }
        if ($pass === '' && sms_meta('sms_pass') === '') { flash('Eskiz parolini (API paroli) kiriting', 'err'); return true; }
        if ($from !== '' && !preg_match('/^[A-Za-z0-9 ._-]{1,11}$/', $from)) { flash('Jo‘natuvchi nomi: 1–11 ta lotin harf/raqam (Eskiz bergan, masalan 4546)', 'err'); return true; }
        $changed = $email !== sms_meta('sms_email') || ($pass !== '' && $pass !== sms_meta('sms_pass'));
        sms_meta_set('sms_email', $email);
        if ($pass !== '') sms_meta_set('sms_pass', $pass);
        sms_meta_set('sms_from', $from !== '' ? $from : '4546');
        if ($changed) { q('DELETE FROM meta WHERE k IN ("set_sms_token","set_sms_token_at","set_sms_bal","set_sms_bal_at")'); }
        $tok = sms_token(true);
        if ($tok === null) { flash('Saqlandi, lekin Eskiz ga kirib bo‘lmadi — email yoki parolni tekshiring (jurnalga qarang)', 'err'); return true; }
        $b = sms_balance(true);
        flash('Eskiz ulandi' . ($b !== null ? '. Balans: ' . number_format($b, 0, '.', ' ') . ' so‘m' : ''));
        return true;
    }
    if ($act === 'msg_eskiz_test') {
        $ph = norm_phone((string)($_POST['phone'] ?? ''));
        if ($ph === '') { flash('Telefon raqamni to‘g‘ri kiriting (+998 90 123 45 67)', 'err'); return true; }
        if (!sms_ready()) { flash('Avval Eskiz ma’lumotlarini kiriting', 'err'); return true; }
        // Sinov uchun eng oddiy tasdiqlangan shablon — kod matni
        $r = sms_send($ph, sms_render('code', ['code' => str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT)]));
        flash($r['ok'] ? 'Sinov SMS yuborildi (' . mask_phone($ph) . '). Telefonga kelishini kuting.' : 'SMS yuborilmadi: ' . ($r['desc'] ?: 'noma’lum xato'), $r['ok'] ? 'ok' : 'err');
        return true;
    }
    if ($act === 'msg_gw') {
        $tok = trim((string)($_POST['gw_token'] ?? ''));
        if ($tok === '') {
            if (isset($_POST['gw_clear'])) { q('DELETE FROM meta WHERE k="set_gw_token"'); flash('Telegram Gateway o‘chirildi'); }
            else flash('Tokenni kiriting', 'err');
            return true;
        }
        if (strlen($tok) < 20 || preg_match('/\s/', $tok)) { flash('Token ko‘rinishi noto‘g‘ri', 'err'); return true; }
        sms_meta_set('gw_token', $tok);
        flash('Gateway tokeni saqlandi. «Sinash» orqali o‘z raqamingizga kod yuborib tekshiring.');
        return true;
    }
    if ($act === 'msg_gw_test') {
        $ph = norm_phone((string)($_POST['phone'] ?? ''));
        if ($ph === '') { flash('Telefon raqamni to‘g‘ri kiriting', 'err'); return true; }
        if (!gw_ready()) { flash('Avval Gateway tokenini kiriting', 'err'); return true; }
        $r = gw_send_code($ph, str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT));
        flash($r['ok'] ? 'Telegram orqali kod yuborildi (' . mask_phone($ph) . ')' : 'Yuborilmadi: ' . ($r['desc'] ?: 'raqamda Telegram yo‘q'), $r['ok'] ? 'ok' : 'err');
        return true;
    }
    if ($act === 'msg_order') {
        $o = (string)($_POST['otp_order'] ?? '');
        if (!in_array($o, ['bot,gw,sms', 'bot,sms,gw', 'gw,sms', 'sms'], true)) $o = 'bot,gw,sms';
        sms_meta_set('otp_order', $o);
        flash('Kodlarni yuborish tartibi saqlandi');
        return true;
    }
    return false;
}

/** Sozlamalar → Xabarlar kartasi */
function msg_settings_card(): void
{
    $smsOn = sms_ready();
    $gwOn = gw_ready();
    $bal = $smsOn ? sms_balance() : null;
    $order = implode(',', notify_order());
    $log = rows("SELECT dir, kind, ok, info, created_at FROM tg_log WHERE kind IN ('sms','gw','otp') ORDER BY id DESC LIMIT 12");
    $since = date('Y-m-d H:i:s', time() - 86400);
    $day = row("SELECT SUM(kind='sms' AND ok=1) s, SUM(kind='gw' AND ok=1) g, SUM(kind IN ('sms','gw') AND ok=0) f FROM tg_log WHERE created_at>?", [$since]);
    ?>
  <div class="card" id="xabarlar" style="grid-column:1/-1">
    <h2>Xabarlar: SMS va tasdiqlash kodlari</h2>
    <p class="small muted">Parolni tiklash, telefon tasdiqlash, xona haqida xabar va ota-onalarga natija yuborish shu yerdagi kanallar orqali ketadi. Kod avval o‘quvchining <b>Telegram boti</b>ga, bo‘lmasa <b>Telegram Gateway</b> (raqamning Telegramiga), u ham bo‘lmasa <b>SMS</b> ga yuboriladi.</p>
    <div class="row gap" style="flex-wrap:wrap">
      <span class="tag <?= $smsOn ? 'green' : '' ?>">Eskiz SMS: <b><?= $smsOn ? 'ulangan' : 'ulanmagan' ?></b></span>
      <?php if ($bal !== null): ?><span class="tag <?= $bal < 20000 ? 'red' : '' ?>">Balans: <b><?= e(number_format($bal, 0, '.', ' ')) ?> so‘m</b></span><?php endif; ?>
      <span class="tag <?= $gwOn ? 'green' : '' ?>">Telegram Gateway: <b><?= $gwOn ? 'ulangan' : 'ulanmagan' ?></b></span>
      <span class="tag">24 soatda: SMS <b><?= (int)($day['s'] ?? 0) ?></b> · Gateway <b><?= (int)($day['g'] ?? 0) ?></b> · xato <b><?= (int)($day['f'] ?? 0) ?></b></span>
    </div>

    <div class="grid2 mt">
      <div>
        <h3>1. Eskiz.uz (SMS)</h3>
        <form method="post" class="form" autocomplete="off">
          <?= csrf_field() ?><input type="hidden" name="action" value="msg_eskiz">
          <label>Eskiz email <input type="email" name="sms_email" value="<?= e(sms_meta('sms_email')) ?>" autocomplete="off" placeholder="my.eskiz.uz dagi email"></label>
          <label>Eskiz parol (API paroli) <input type="password" name="sms_pass" autocomplete="new-password" placeholder="<?= $smsOn ? '•••••• (o‘zgartirish uchun yangisini kiriting)' : 'parol' ?>"></label>
          <label>Jo‘natuvchi nomi (from) <input name="sms_from" value="<?= e(sms_meta('sms_from', '4546')) ?>" maxlength="11" placeholder="4546"></label>
          <p class="small muted" style="margin-top:-.4rem">Standart <b>4546</b>. Markazning o‘z nomi (masalan «MOCK») Eskizda alohida tasdiqlanadi. Email va parolni ikkala maydonni bo‘sh qoldirib saqlasangiz — ulanish o‘chadi.</p>
          <div class="row gap"><button class="btn primary"><?= $smsOn ? 'Saqlash va tekshirish' : 'Ulash va tekshirish' ?></button></div>
        </form>
        <?php if ($smsOn): ?>
        <form method="post" class="row gap mt" autocomplete="off">
          <?= csrf_field() ?><input type="hidden" name="action" value="msg_eskiz_test">
          <input name="phone" placeholder="+998 90 123 45 67" inputmode="tel" style="max-width:12rem" required>
          <button class="btn">Sinov SMS yuborish</button>
        </form>
        <?php endif; ?>
      </div>
      <div>
        <h3>2. Telegram Gateway</h3>
        <form method="post" class="form" autocomplete="off">
          <?= csrf_field() ?><input type="hidden" name="action" value="msg_gw">
          <label>Gateway API tokeni <input type="password" name="gw_token" autocomplete="new-password" spellcheck="false" placeholder="<?= $gwOn ? '•••• …' . e(substr(gw_token(), -4)) . ' (almashtirish uchun yangisini kiriting)' : 'gatewayapi.telegram.org dan olingan token' ?>"></label>
          <p class="small muted" style="margin-top:-.4rem">Token <b>gateway.telegram.org</b> da hisob ochib olinadi. Raqam Telegramda ro‘yxatdan o‘tgan bo‘lsa, kod Telegramning «Verification Codes» chatiga keladi (SMS dan arzon). Raqamda Telegram bo‘lmasa avtomatik SMS ga o‘tadi.</p>
          <div class="row gap"><button class="btn primary">Saqlash</button><?php if ($gwOn): ?><button class="btn danger-ghost" name="gw_clear" value="1" formnovalidate>Uzish</button><?php endif; ?></div>
        </form>
        <?php if ($gwOn): ?>
        <form method="post" class="row gap mt" autocomplete="off">
          <?= csrf_field() ?><input type="hidden" name="action" value="msg_gw_test">
          <input name="phone" placeholder="+998 90 123 45 67" inputmode="tel" style="max-width:12rem" required>
          <button class="btn">Sinash (kod yuborish)</button>
        </form>
        <?php endif; ?>

        <h3 class="mt">3. Kod yuborish tartibi</h3>
        <form method="post" class="form">
          <?= csrf_field() ?><input type="hidden" name="action" value="msg_order">
          <label>Tartib
            <select name="otp_order">
              <option value="bot,gw,sms" <?= $order === 'bot,gw,sms' ? 'selected' : '' ?>>Bot → Gateway → SMS (tavsiya)</option>
              <option value="bot,sms,gw" <?= $order === 'bot,sms,gw' ? 'selected' : '' ?>>Bot → SMS → Gateway</option>
              <option value="gw,sms" <?= $order === 'gw,sms' ? 'selected' : '' ?>>Gateway → SMS (botsiz)</option>
              <option value="sms" <?= $order === 'sms' ? 'selected' : '' ?>>Faqat SMS</option>
            </select></label>
          <div class="row gap"><button class="btn">Saqlash</button></div>
        </form>
      </div>
    </div>

    <h3 class="mt">Eskizda tasdiqlatiladigan SMS shablonlari</h3>
    <p class="small muted">Eskiz har bir SMS matnini oldindan tekshiradi — tasdiqlanmagan matn yetib bormaydi. Platforma faqat quyidagi qat’iy matnlarni yuboradi: <b>my.eskiz.uz → SMS → Shablonlar</b> bo‘limiga aynan shularni kiriting (<code>{…}</code> o‘rniga Eskiz o‘z o‘zgaruvchisini qo‘yadi) va tasdiqlanishini kuting.</p>
    <table class="tbl compact-tbl"><thead><tr><th>Maqsad</th><th>Matn</th></tr></thead><tbody>
      <?php foreach (sms_templates() as $tp): ?><tr><td class="small"><?= e($tp[0]) ?></td><td class="mono small"><?= e($tp[1]) ?></td></tr><?php endforeach; ?>
    </tbody></table>

    <h3 class="mt">So‘nggi yuborishlar</h3>
    <?php if (!$log): ?><p class="small muted">Hali yo‘q.</p><?php else: ?>
    <table class="tbl compact-tbl"><thead><tr><th>Vaqt</th><th>Kanal</th><th>Natija</th><th>Izoh</th></tr></thead><tbody>
      <?php foreach ($log as $l): ?><tr><td class="small muted"><?= e(substr($l['created_at'], 5, 11)) ?></td><td class="small"><?= e(['sms' => 'SMS', 'gw' => 'Gateway', 'otp' => 'Bot (kod)'][$l['kind']] ?? $l['kind']) ?></td><td><?= $l['ok'] ? '<span class="tag green">ok</span>' : '<span class="tag red">xato</span>' ?></td><td class="small"><?= e($l['info']) ?></td></tr><?php endforeach; ?>
    </tbody></table>
    <?php endif; ?>
  </div>
    <?php
}
