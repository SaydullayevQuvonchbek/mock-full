<?php
defined('APP_ROOT') || exit;
/**
 * O'quvchi kabineti: natijalar tarixi (bo'limlar bo'yicha), o'sish grafigi, Telegram ulash havolasi, telefon tasdiqlash.
 */

/**
 * O'quvchining e'lon qilingan natijalari (eskisi → yangisi), har biri bo'limlar bo'yicha:
 * ['test_id','title','date','ball','grade','rank','n','sec'=>['A'=>['ok','total','ball','name'],'G'=>…]]
 */
function student_history(int $sid): array
{
    $list = rows('SELECT res.test_id, res.ball, res.grade, res.rank_no, res.scored, t.title, t.test_date
                  FROM results res JOIN tests t ON t.id=res.test_id
                  WHERE res.student_id=? AND t.published=1 ORDER BY t.test_date IS NULL, t.test_date, t.id', [$sid]);
    $out = [];
    foreach ($list as $r) {
        $t = test_by_id((int)$r['test_id']);
        if (!$t) continue;
        $out[] = [
            'test_id' => (int)$r['test_id'], 'title' => $r['title'], 'date' => $r['test_date'],
            'ball' => (float)$r['ball'], 'grade' => $r['grade'], 'rank' => (int)$r['rank_no'],
            'n' => (int)($t['stats']['N'] ?? 0),
            'sec' => section_scores($t, (string)$r['scored'], (float)$r['ball']),
        ];
    }
    return $out;
}

/** Bo'limlar bo'yicha o'rtacha to'g'ri javoblar ulushi (%): ['A'=>[ok,total,pct], 'G'=>…] */
function student_section_avg(array $hist): array
{
    $acc = [];
    foreach ($hist as $h) foreach ($h['sec'] as $k => $s) {
        $acc[$k] = $acc[$k] ?? ['name' => $s['name'], 'ok' => 0, 'total' => 0];
        $acc[$k]['ok'] += $s['ok']; $acc[$k]['total'] += $s['total'];
    }
    foreach ($acc as &$a) $a['pct'] = $a['total'] > 0 ? round(100 * $a['ok'] / $a['total']) : 0;
    unset($a);
    return $acc;
}

/** Chiziqli grafik (SVG). $series: [['cls'=>'ln-ball','name'=>'Ball','pts'=>[v|null,…]], …]; $labels: x yorliqlari */
function svg_line_chart(array $labels, array $series, float $max, array $opt = []): string
{
    $w = (int)($opt['w'] ?? 640); $h = (int)($opt['h'] ?? 240);
    $pl = 40; $pr = 16; $pt = 18; $pb = 44;
    $n = max(1, count($labels));
    $x = fn(int $i) => $n === 1 ? ($pl + ($w - $pl - $pr) / 2) : $pl + ($w - $pl - $pr) * $i / ($n - 1);
    $y = fn(float $v) => $h - $pb - ($h - $pb - $pt) * max(0, min($max, $v)) / $max;
    $s = '<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="' . e($opt['title'] ?? 'o\'sish grafigi') . '">';
    $ticks = (int)($opt['ticks'] ?? 3);
    for ($t = 0; $t <= $ticks; $t++) {
        $v = $max * $t / $ticks; $yy = round($y($v), 1);
        $s .= '<line class="grid" x1="' . $pl . '" x2="' . ($w - $pr) . '" y1="' . $yy . '" y2="' . $yy . '"/><text class="tick" x="' . ($pl - 6) . '" y="' . ($yy + 4) . '" text-anchor="end">' . round($v) . '</text>';
    }
    if (isset($opt['threshold'])) {
        $yy = round($y((float)$opt['threshold'][0]), 1);
        $s .= '<line class="thr" x1="' . $pl . '" x2="' . ($w - $pr) . '" y1="' . $yy . '" y2="' . $yy . '"/><text class="tick thr-t" x="' . ($w - $pr) . '" y="' . ($yy - 4) . '" text-anchor="end">' . e($opt['threshold'][1]) . '</text>';
    }
    foreach ($labels as $i => $lb) {
        $s .= '<text class="tick" x="' . round($x($i), 1) . '" y="' . ($h - $pb + 16) . '" text-anchor="middle">' . e(mb_strimwidth((string)$lb, 0, 12, '…')) . '</text>';
    }
    foreach ($series as $se) {
        $d = ''; $dots = ''; $pen = false;
        foreach ($se['pts'] as $i => $v) {
            if ($v === null) { $pen = false; continue; }
            $px = round($x($i), 1); $py = round($y((float)$v), 1);
            $d .= ($pen ? 'L' : 'M') . $px . ' ' . $py . ' '; $pen = true;
            $dots .= '<circle class="pt ' . e($se['cls']) . '" cx="' . $px . '" cy="' . $py . '" r="4"><title>' . e($se['name'] . ': ' . $v . ' — ' . ($labels[$i] ?? '')) . '</title></circle>';
            if (!empty($opt['values'])) $dots .= '<text class="val" x="' . $px . '" y="' . ($py - 9) . '" text-anchor="middle">' . e((string)$v) . '</text>';
        }
        if ($d !== '') $s .= '<path class="ln ' . e($se['cls']) . '" d="' . trim($d) . '"/>' . $dots;
    }
    // izoh (legend)
    if (count($series) > 1) {
        $lx = $pl;
        foreach ($series as $se) {
            $s .= '<circle class="pt ' . e($se['cls']) . '" cx="' . $lx . '" cy="' . ($h - 8) . '" r="4"/><text class="tick" x="' . ($lx + 9) . '" y="' . ($h - 4) . '">' . e($se['name']) . '</text>';
            $lx += 20 + 7 * mb_strlen($se['name']);
        }
    }
    return $s . '</svg>';
}

/* ---------------- Telegram ulash havolasi ---------------- */

/**
 * Bir martalik ulash havolasi: https://t.me/<bot>?start=<token> (30 daqiqa). $who: 'stu' — o'quvchi, 'par' — ota-ona.
 * Bot ulanmagan bo'lsa yoki limitga yetilgan bo'lsa null.
 */
function tg_link_url(int $sid, string $who = 'stu'): ?string
{
    $bot = tg_meta('bot');
    if (!tg_ready() || $bot === '') return null;
    if ((int)val('SELECT COUNT(*) FROM tg_links WHERE student_id=? AND who=? AND used_at IS NULL AND expires_at>NOW()', [$sid, $who]) >= 5) return null;
    $tok = bin2hex(random_bytes(14));
    q('INSERT INTO tg_links (token_hash, student_id, who, expires_at) VALUES (?,?,?,DATE_ADD(NOW(), INTERVAL 30 MINUTE))', [hash('sha256', $tok), $sid, $who === 'par' ? 'par' : 'stu']);
    if (random_int(1, 30) === 1) q('DELETE FROM tg_links WHERE expires_at < DATE_SUB(NOW(), INTERVAL 1 DAY)');
    return 'https://t.me/' . rawurlencode($bot) . '?start=' . $tok;
}

/* ---------------- Telefon tasdiqlash ---------------- */

/** Telefon egaligini isbotlay oladigan kanallar (bot emas — faqat Gateway va SMS) */
function phone_proof_channels(string $phone): array
{
    return array_values(array_intersect(notify_channels(['phone' => $phone, 'tg_chat_id' => null]), ['gw', 'sms']));
}

function phone_otp_target(int $sid, string $phone): string
{
    return 'p' . $sid . ':' . preg_replace('/\D/', '', $phone);
}
