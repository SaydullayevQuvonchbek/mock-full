<?php
defined('APP_ROOT') || exit;
/**
 * PHP 7.4 bilan moslik: PHP 8 da qo'shilgan funksiyalarning o'rnini bosuvchilar.
 * OSPanel 5 va ko'p hostinglarda hali PHP 7.4 turadi. PHP 8+ da bu funksiyalar
 * allaqachon mavjud bo'lgani uchun quyidagilar e'lon qilinmaydi.
 * Talab: PHP 7.4 yoki undan yangi.
 */

if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool
    {
        return $needle === '' || strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}

if (!function_exists('str_ends_with')) {
    function str_ends_with(string $haystack, string $needle): bool
    {
        return $needle === '' || ($haystack !== '' && substr_compare($haystack, $needle, -strlen($needle)) === 0);
    }
}

if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool
    {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}
