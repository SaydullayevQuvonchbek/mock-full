<?php
defined('APP_ROOT') || exit;
/**
 * Namuna ma'lumotlar: Rasch modeli bo'yicha simulyatsiya qilingan 120 o'quvchi javoblari.
 * 12-savol kaliti ataylab noto'g'ri kiritilgan — tahlil sahifasi buni qanday aniqlashini ko'rish uchun.
 */
function demo_randn(): float
{
    $u = max(1e-12, mt_rand() / mt_getrandmax());
    $v = mt_rand() / mt_getrandmax();
    return sqrt(-2 * log($u)) * cos(2 * M_PI * $v);
}

function demo_seed(PDO $pdo): void
{
    mt_srand(20260923);
    $letters = ['A', 'B', 'C', 'D'];
    $key = []; $truth = []; $bTrue = [];
    for ($i = 1; $i <= 32; $i++) {
        $k = $letters[mt_rand(0, 3)];
        $key[(string)$i] = $k; $truth[(string)$i] = $k;
        $bTrue[(string)$i] = -2.2 + 3.4 * ($i - 1) / 31 + 0.35 * demo_randn();
    }
    foreach ([33 => 'E', 34 => 'B', 35 => 'D'] as $i => $k) {
        $key[(string)$i] = $k; $truth[(string)$i] = $k; $bTrue[(string)$i] = 0.3 + 0.3 * demo_randn();
    }
    $openKeys = [
        '36a' => '2', '36b' => '4', '37a' => 'π/2|pi/2', '37b' => '5', '38a' => '21', '38b' => '-11',
        '39a' => '4', '39b' => '-20', '40a' => '6', '40b' => '8/3', '41a' => '64', '41b' => '10',
        '42a' => '10', '42b' => '56', '43a' => '√2|sqrt2', '43b' => '2√2-2', '44a' => '512', '44b' => '48',
        '45a' => '15', '45b' => '450',
    ];
    $j = 0;
    foreach ($openKeys as $lab => $k) {
        $key[$lab] = $k; $truth[$lab] = explode('|', $k)[0];
        $bTrue[$lab] = 0.4 + 2.4 * ($j / 19) + 0.3 * demo_randn() + (substr($lab, -1) === 'b' ? 0.5 : 0);
        $j++;
    }
    // 12-savol: o'quvchilar to'g'ri javob sifatida C ni tanlaydi, lekin kalitda D yozilgan (xato kalit)
    $truth['12'] = 'C'; $key['12'] = 'D';

    // Bo'limlar: G — geometriya, qolganlari algebra va analiz
    $sections = [];
    for ($t = 1; $t <= 45; $t++) $sections[(string)$t] = (($t >= 25 && $t <= 30) || ($t >= 33 && $t <= 35) || ($t >= 41 && $t <= 44)) ? 'G' : 'A';
    $pdo->prepare('INSERT INTO tests (title, subject, test_date, n_closed, n_match, n_open, key_json, method, dirty, sections_json, reg_open)
                   VALUES (?,?,?,?,?,?,?,?,1,?,0)')
        ->execute(['MOCK EXAM-12 (namuna)', 'Matematika', date('Y-m-d'), 32, 3, 10,
            json_encode($key, JSON_UNESCAPED_UNICODE), 'tscore', json_encode($sections)]);
    $testId = (int)$pdo->lastInsertId();

    $first = ['Aziz', 'Dilnoza', 'Jasur', 'Malika', 'Sardor', 'Nodira', 'Bekzod', 'Madina', 'Ulug\'bek', 'Shahzoda',
        'Javohir', 'Sevara', 'Otabek', 'Zarina', 'Sherzod', 'Gulnoza', 'Diyor', 'Kamola', 'Islom', 'Mohinur'];
    $last = ['Karimov', 'Rahimova', 'Toshmatov', 'Yusupova', 'Aliyev', 'Nazarova', 'Ergashev', 'Qodirova',
        'Saidov', 'Mirzayeva', 'Xolmatov', 'Abdullayeva', 'Rustamov', 'Hasanova', 'Umarov'];
    $groups = ['11-A', '11-B', '10-A', 'Kechki guruh'];
    $insS = $pdo->prepare('INSERT INTO students (code, full_name, last_name, first_name, group_name, pin) VALUES (?,?,?,?,?,?)');
    foreach ($groups as $g) $pdo->prepare('INSERT IGNORE INTO study_groups (name) VALUES (?)')->execute([$g]);
    $insR = $pdo->prepare('INSERT INTO responses (test_id, student_id, answers, source, status, started_at, submitted_at)
                           VALUES (?,?,?,?,"submitted",NOW(),NOW())');
    $used = [];
    for ($n = 0; $n < 120; $n++) {
        do { $code = (string)mt_rand(100000, 999999); } while (isset($used[$code]));
        $used[$code] = 1;
        $fn = $first[mt_rand(0, count($first) - 1)];
        $ln = $last[mt_rand(0, count($last) - 1)];
        $female = in_array($fn, ['Dilnoza', 'Malika', 'Nodira', 'Madina', 'Shahzoda', 'Sevara', 'Zarina', 'Gulnoza', 'Kamola', 'Mohinur'], true);
        if ($female && substr($ln, -1) !== 'a') $ln .= 'a';
        if (!$female && substr($ln, -2) === 'va') $ln = substr($ln, 0, -1);
        $insS->execute([$code, "$ln $fn", $ln, $fn, $groups[mt_rand(0, 3)], str_pad((string)mt_rand(0, 9999), 4, '0', STR_PAD_LEFT)]);
        $sid = (int)$pdo->lastInsertId();
        $theta = 0.2 + 1.25 * demo_randn();
        $ans = [];
        foreach ($bTrue as $lab => $b) {
            $p = 1 / (1 + exp(-($theta - $b)));
            $ok = (mt_rand() / mt_getrandmax()) < $p;
            if (ctype_digit((string)$lab)) {
                $opts = ((int)$lab >= 33) ? ['A', 'B', 'C', 'D', 'E', 'F'] : $letters;
                if ($ok) $ans[$lab] = $truth[$lab];
                elseif (mt_rand(0, 9) === 0) $ans[$lab] = '';
                else { do { $w = $opts[mt_rand(0, count($opts) - 1)]; } while ($w === $truth[$lab]); $ans[$lab] = $w; }
            } else {
                if ($ok) $ans[$lab] = $truth[$lab];
                elseif (mt_rand(0, 2) === 0) $ans[$lab] = '';
                else $ans[$lab] = (string)mt_rand(-20, 60);
            }
        }
        $insR->execute([$testId, $sid, json_encode($ans, JSON_UNESCAPED_UNICODE), 'demo']);
    }
}
