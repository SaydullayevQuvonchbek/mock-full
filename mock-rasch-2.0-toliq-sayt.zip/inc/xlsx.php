<?php
defined('APP_ROOT') || exit;
/**
 * Minimal XLSX o'quvchi (tashqi kutubxonasiz): birinchi varaqni 2 o'lchamli massiv sifatida qaytaradi.
 */
function xlsx_read(string $file): array
{
    if (!class_exists('ZipArchive')) throw new RuntimeException('PHP zip kengaytmasi yoqilmagan. CSV formatdan foydalaning.');
    $zip = new ZipArchive();
    if ($zip->open($file) !== true) throw new RuntimeException('XLSX faylni ochib bo\'lmadi');

    $shared = [];
    $ss = $zip->getFromName('xl/sharedStrings.xml');
    if ($ss !== false) {
        $x = simplexml_load_string($ss, 'SimpleXMLElement', LIBXML_NONET | LIBXML_NOCDATA);
        foreach ($x->si as $si) {
            if (isset($si->t)) { $shared[] = (string)$si->t; continue; }
            $t = '';
            foreach ($si->r as $r) $t .= (string)$r->t;
            $shared[] = $t;
        }
    }
    // Birinchi varaq yo'lini aniqlash
    $sheetPath = 'xl/worksheets/sheet1.xml';
    $wb = $zip->getFromName('xl/workbook.xml');
    $rels = $zip->getFromName('xl/_rels/workbook.xml.rels');
    if ($wb !== false && $rels !== false) {
        $wbx = simplexml_load_string($wb, 'SimpleXMLElement', LIBXML_NONET);
        $wbx->registerXPathNamespace('m', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main');
        $sheets = $wbx->xpath('//m:sheets/m:sheet');
        if ($sheets) {
            $rid = (string)$sheets[0]->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships')['id'];
            $rx = simplexml_load_string($rels, 'SimpleXMLElement', LIBXML_NONET);
            foreach ($rx->Relationship as $rel) {
                if ((string)$rel['Id'] === $rid) {
                    $target = ltrim((string)$rel['Target'], '/');
                    $sheetPath = str_starts_with($target, 'xl/') ? $target : 'xl/' . $target;
                }
            }
        }
    }
    $xml = $zip->getFromName($sheetPath);
    $zip->close();
    if ($xml === false) throw new RuntimeException('XLSX ichida varaq topilmadi');
    $sx = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NONET);
    $out = [];
    foreach ($sx->sheetData->row as $row) {
        $r = [];
        foreach ($row->c as $c) {
            $ref = (string)$c['r'];
            $col = xlsx_col_index(preg_replace('/\d/', '', $ref));
            $t = (string)$c['t'];
            if ($t === 's') $v = $shared[(int)$c->v] ?? '';
            elseif ($t === 'inlineStr') $v = (string)$c->is->t;
            elseif ($t === 'b') $v = ((string)$c->v) === '1' ? 'TRUE' : 'FALSE';
            else $v = (string)$c->v;
            if ($t === '' && is_numeric($v) && str_contains($v, 'E')) $v = (string)(float)$v;
            $r[$col] = $v;
        }
        if ($r) {
            $max = max(array_keys($r));
            $line = [];
            for ($i = 0; $i <= $max; $i++) $line[] = $r[$i] ?? '';
            $out[] = $line;
        } else {
            $out[] = [];
        }
    }
    return $out;
}

function xlsx_col_index(string $letters): int
{
    $n = 0;
    foreach (str_split(strtoupper($letters)) as $ch) $n = $n * 26 + (ord($ch) - 64);
    return $n - 1;
}

function csv_read(string $file): array
{
    $raw = file_get_contents($file);
    if (str_starts_with($raw, "\xEF\xBB\xBF")) $raw = substr($raw, 3);
    if (!mb_check_encoding($raw, 'UTF-8')) $raw = mb_convert_encoding($raw, 'UTF-8', 'Windows-1251');
    $first = strtok($raw, "\n");
    // Ajratgich: eng ko'p uchraganini olamiz; teng bo'lsa ustuvorlik ; → , → TAB (PHP versiyasiga bog'liq bo'lmasin)
    $d = ';'; $best = -1;
    foreach ([';', ',', "\t"] as $cand) { $c = substr_count((string)$first, $cand); if ($c > $best) { $best = $c; $d = $cand; } }
    $out = [];
    $fh = fopen('php://memory', 'r+');
    fwrite($fh, $raw); rewind($fh);
    while (($r = fgetcsv($fh, 0, $d, '"', '\\')) !== false) $out[] = $r;
    fclose($fh);
    return $out;
}
