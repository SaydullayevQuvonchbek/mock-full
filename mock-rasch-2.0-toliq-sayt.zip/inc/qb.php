<?php
defined('APP_ROOT') || exit;
/**
 * Savollar banki: bo'limlar daraxti, PDF dan qirqilgan savol rasmlari, javob kaliti, o'quvchi mashq testlari, PDF chiqarish.
 * Mashq natijasi faqat nechta to'g'ri topilgani (umumiy va bo'limlar bo'yicha) — qaysi savol xato ekani va to'g'ri javoblar ko'rsatilmaydi.
 */

function qb_dir(): string
{
    $d = APP_ROOT . '/uploads/qb';
    if (!is_dir($d)) @mkdir($d, 0755, true);
    if (is_dir($d) && !is_file($d . '/.htaccess')) @file_put_contents($d . '/.htaccess', "Require all denied\n");   // rasmlar faqat index.php?p=qb_img orqali
    return $d;
}

/* ---------------- Bo'limlar ---------------- */

/**
 * Bo'limlar daraxti (tekis ro'yxat, tartib bilan): ['id','parent_id','name','depth','own','ready','total','ready_total']
 *  own/ready — shu bo'limning o'z savollari (kaliti borlari), total/ready_total — ichki bo'limlar bilan.
 */
function qb_tree(): array
{
    $secs = rows('SELECT id, parent_id, name, sort FROM qb_sections ORDER BY sort, name, id');
    $cnt = [];
    foreach (rows("SELECT section_id, COUNT(*) n, SUM(answer<>'') r FROM qb_questions GROUP BY section_id") as $r) $cnt[(int)$r['section_id']] = [(int)$r['n'], (int)$r['r']];
    $by = [];
    foreach ($secs as $s) $by[(int)($s['parent_id'] ?? 0)][] = $s;
    $out = [];
    $walk = function (int $pid, int $depth) use (&$walk, &$by, &$out, $cnt) {
        $tot = [0, 0];
        foreach ($by[$pid] ?? [] as $s) {
            $id = (int)$s['id'];
            $idx = count($out);
            $out[] = ['id' => $id, 'parent_id' => $s['parent_id'] !== null ? (int)$s['parent_id'] : 0, 'name' => $s['name'], 'depth' => $depth,
                      'own' => $cnt[$id][0] ?? 0, 'ready' => $cnt[$id][1] ?? 0, 'total' => 0, 'ready_total' => 0];
            $sub = $walk($id, $depth + 1);
            $out[$idx]['total'] = ($cnt[$id][0] ?? 0) + $sub[0];
            $out[$idx]['ready_total'] = ($cnt[$id][1] ?? 0) + $sub[1];
            $tot[0] += $out[$idx]['total']; $tot[1] += $out[$idx]['ready_total'];
        }
        return $tot;
    };
    $walk(0, 0);
    return $out;
}

/** Bo'lim va uning barcha ichki bo'limlari ID lari */
function qb_descendants(array $ids): array
{
    $ids = array_values(array_unique(array_map('intval', $ids)));
    $all = $ids;
    $frontier = $ids;
    for ($guard = 0; $frontier && $guard < 12; $guard++) {
        $in = implode(',', array_fill(0, count($frontier), '?'));
        $next = array_map('intval', array_column(rows("SELECT id FROM qb_sections WHERE parent_id IN ($in)", $frontier), 'id'));
        $next = array_values(array_diff($next, $all));
        $all = array_merge($all, $next);
        $frontier = $next;
    }
    return $all;
}

function qb_section_path(int $id): string
{
    $parts = [];
    for ($i = 0; $id && $i < 12; $i++) {
        $r = row('SELECT name, parent_id FROM qb_sections WHERE id=?', [$id]);
        if (!$r) break;
        array_unshift($parts, $r['name']);
        $id = (int)($r['parent_id'] ?? 0);
    }
    return implode(' › ', $parts);
}

/* ---------------- Javobni tekshirish ---------------- */

/** Ochiq javobni solishtirish uchun normallashtirish: bo'sh joy olinadi, vergul → nuqta, a/b kasr → son */
function qb_norm_open(string $s): string
{
    $s = mb_strtolower(trim($s));
    $s = str_replace([' ', "\u{00A0}", ','], ['', '', '.'], $s);
    $s = str_replace(['−', '–'], '-', $s);
    if (preg_match('#^(-?\d+(?:\.\d+)?)/(\d+(?:\.\d+)?)$#', $s, $m) && (float)$m[2] != 0.0) return rtrim(rtrim(sprintf('%.9F', (float)$m[1] / (float)$m[2]), '0'), '.');
    if (is_numeric($s)) return rtrim(rtrim(sprintf('%.9F', (float)$s), '0'), '.');
    return $s;
}

/** Javob to'g'rimi? Ochiq savolda kalitda bir nechta variant ";" bilan berilishi mumkin (masalan 0.5;1/2) */
function qb_check(array $q, string $given): bool
{
    $given = trim($given);
    if ($given === '' || (string)$q['answer'] === '') return false;
    if ($q['kind'] !== 'open') return strtoupper($given) === strtoupper(trim((string)$q['answer']));
    $g = qb_norm_open($given);
    foreach (explode(';', (string)$q['answer']) as $a) if ($g === qb_norm_open($a) && $g !== '') return true;
    return false;
}

/** Kalit qiymatini tozalash: test savoli uchun A..D (A..F), ochiq uchun matn. Noto'g'ri bo'lsa null */
function qb_clean_answer(string $kind, int $nopt, string $v): ?string
{
    $v = trim($v);
    if ($v === '') return '';
    if ($kind === 'open') return mb_substr($v, 0, 80);
    $v = strtoupper($v);
    $max = chr(64 + max(2, min(6, $nopt)));
    return (strlen($v) === 1 && $v >= 'A' && $v <= $max) ? $v : null;
}

/**
 * Tezkor kalit matnini [tartib raqami => javob] ga aylantiradi. Qabul qilinadigan ko'rinishlar:
 *  "ACDBB…" (har harf — bitta savol), "1A 2C 3D", "1:A 2:C 3:12 4:0.5;1/2" (bo'sh joy bilan ajratilgan).
 */
function qb_parse_key(string $s): array
{
    $s = trim($s);
    if ($s === '') return [];
    $compact = preg_replace('/[\s,]+/u', '', $s);
    if (preg_match('/^[A-Fa-f]+$/', $compact)) {
        $out = [];
        foreach (str_split(strtoupper($compact)) as $i => $c) $out[$i + 1] = $c;
        return $out;
    }
    if (preg_match('/^(?:\d{1,3}[A-Fa-f])+$/', $compact) && preg_match_all('/(\d{1,3})([A-Fa-f])/', $compact, $m, PREG_SET_ORDER)) {
        $out = [];
        foreach ($m as $x) $out[(int)$x[1]] = strtoupper($x[2]);
        return $out;
    }
    $out = []; $pos = 0;
    foreach (preg_split('/\s+/u', $s, -1, PREG_SPLIT_NO_EMPTY) as $tok) {
        if (preg_match('/^(\d{1,3})[:=)](.+)$/u', $tok, $mm)) { $pos = (int)$mm[1]; $v = $mm[2]; }
        else { $pos++; $v = $tok; }
        $out[$pos] = $v;
    }
    return $out;
}

/* ---------------- Rasm saqlash ---------------- */

/** Yuklangan PNG ni tekshirib saqlaydi va savol yaratadi. Qaytaradi: [id|null, xato] */
function qb_add_image(int $sectionId, string $tmp, string $label, string $src = '', string $kind = 'mc', int $nopt = 4): array
{
    if (!row('SELECT 1 FROM qb_sections WHERE id=?', [$sectionId])) return [null, 'Bo\'lim topilmadi'];
    if (!is_uploaded_file($tmp) && !is_file($tmp)) return [null, 'Fayl topilmadi'];
    $size = filesize($tmp);
    if ($size < 200 || $size > 4 * 1024 * 1024) return [null, 'Rasm hajmi noto\'g\'ri (4 MB gacha)'];
    $head = file_get_contents($tmp, false, null, 0, 8);
    if ($head !== "\x89PNG\r\n\x1a\n") return [null, 'Faqat PNG qabul qilinadi'];
    $info = @getimagesize($tmp);
    if (!$info || $info[2] !== IMAGETYPE_PNG || $info[0] < 20 || $info[1] < 20 || $info[0] > 4000 || $info[1] > 6000) return [null, 'Rasm o\'lchami noto\'g\'ri'];
    $name = 'q' . bin2hex(random_bytes(8)) . '.png';
    $dest = qb_dir() . '/' . $name;
    if (!@move_uploaded_file($tmp, $dest) && !@copy($tmp, $dest)) return [null, 'Rasmni saqlab bo\'lmadi'];
    $sort = (int)val('SELECT COALESCE(MAX(sort),0) FROM qb_questions WHERE section_id=?', [$sectionId]) + 1;
    $kind = $kind === 'open' ? 'open' : 'mc';
    q('INSERT INTO qb_questions (section_id, label, img, w, h, kind, nopt, src, sort) VALUES (?,?,?,?,?,?,?,?,?)',
        [$sectionId, mb_substr($label, 0, 40), $name, $info[0], $info[1], $kind, $nopt === 6 ? 6 : 4, mb_substr($src, 0, 160), $sort]);
    return [(int)db()->lastInsertId(), ''];
}

function qb_delete_question(int $id): void
{
    $r = row('SELECT img FROM qb_questions WHERE id=?', [$id]);
    if (!$r) return;
    $f = qb_dir() . '/' . basename((string)$r['img']);
    if (preg_match('/^q[0-9a-f]{16}\.png$/', basename($f)) && is_file($f)) @unlink($f);
    q('DELETE FROM qb_questions WHERE id=?', [$id]);
}

/** Bo'limni (ichki bo'limlari va savollari bilan) o'chirish */
function qb_delete_section(int $id): int
{
    $ids = qb_descendants([$id]);
    $in = implode(',', array_fill(0, count($ids), '?'));
    foreach (rows("SELECT id FROM qb_questions WHERE section_id IN ($in)", $ids) as $r) qb_delete_question((int)$r['id']);
    q("DELETE FROM qb_sections WHERE id IN ($in)", array_reverse($ids));
    return count($ids);
}

/* ---------------- Mashq testi ---------------- */

/** Tanlangan bo'limlarda (ichki bo'limlari bilan; bo'sh = hammasi) mashqqa yaroqli (kalitli) savollar soni */
function qb_pool_size(array $sectionIds): int
{
    $sectionIds = array_values(array_filter(array_map('intval', $sectionIds)));
    $all = $sectionIds ? qb_descendants($sectionIds) : array_map('intval', array_column(rows('SELECT id FROM qb_sections'), 'id'));
    if (!$all) return 0;
    $in = implode(',', array_fill(0, count($all), '?'));
    return (int)val("SELECT COUNT(*) FROM qb_questions WHERE answer<>'' AND section_id IN ($in)", $all);
}

/** Tanlangan bo'limlardan tasodifiy mashq testi tuzadi. Qaytaradi: [test_id|null, xato] */
function qb_build_test(int $sid, array $sectionIds, int $n, string $via = 'web'): array
{
    $n = max(1, min(60, $n));
    $sectionIds = array_values(array_filter(array_map('intval', $sectionIds)));
    $all = $sectionIds ? qb_descendants($sectionIds) : array_map('intval', array_column(rows('SELECT id FROM qb_sections'), 'id'));
    if (!$all) return [null, 'Savollar banki bo\'sh'];
    $in = implode(',', array_fill(0, count($all), '?'));
    $pool = rows("SELECT q.id, q.section_id, s.name FROM qb_questions q JOIN qb_sections s ON s.id=q.section_id WHERE q.answer<>'' AND q.section_id IN ($in)", $all);
    if (!$pool) return [null, 'Tanlangan bo\'limlarda tayyor savol yo\'q'];
    // oxirgi 3 ta mashqda uchragan savollarni imkon qadar takrorlamaymiz
    $seen = array_flip(array_map('intval', array_column(rows('SELECT i.question_id FROM qb_items i JOIN qb_tests t ON t.id=i.test_id WHERE t.student_id=? AND t.id IN (SELECT id FROM (SELECT id FROM qb_tests WHERE student_id=? ORDER BY id DESC LIMIT 3) x)', [$sid, $sid]), 'question_id')));
    $fresh = array_values(array_filter($pool, fn($r) => !isset($seen[(int)$r['id']])));
    $stale = array_values(array_filter($pool, fn($r) => isset($seen[(int)$r['id']])));
    shuffle($fresh); shuffle($stale);
    $n = max($n, min(5, count($pool)));   // 1 savollik test «to'g'rimi?» degan so'rovga aylanib qolmasin: kamida 5 ta (bank kichik bo'lsa — borcha)
    $pick = array_slice(array_merge($fresh, $stale), 0, $n);
    shuffle($pick);
    $names = [];
    foreach ($sectionIds as $x) { $nm = (string)val('SELECT name FROM qb_sections WHERE id=?', [$x]); if ($nm !== '') $names[] = $nm; }
    $title = 'Mashq: ' . ($names ? mb_strimwidth(implode(', ', $names), 0, 120, '…') : 'barcha bo\'limlar');
    q('INSERT INTO qb_tests (student_id, title, n, via) VALUES (?,?,?,?)', [$sid, $title, count($pick), $via === 'bot' ? 'bot' : 'web']);
    $tid = (int)db()->lastInsertId();
    $ins = db()->prepare('INSERT INTO qb_items (test_id, pos, question_id, section_id, section_name) VALUES (?,?,?,?,?)');
    foreach ($pick as $i => $r) $ins->execute([$tid, $i + 1, $r['id'], $r['section_id'], $r['name']]);
    return [$tid, ''];
}

/** Mashq testini yakunlaydi: javoblar [pos => given]. Qaytaradi: to'g'rilar soni */
function qb_finish(int $testId, array $answers): int
{
    $t = row('SELECT * FROM qb_tests WHERE id=?', [$testId]);
    if (!$t || $t['status'] === 'done') return (int)($t['correct'] ?? 0);
    $ok = 0; $graded = 0;
    foreach (rows('SELECT i.pos, i.question_id, i.given, q.kind, q.answer FROM qb_items i LEFT JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=?', [$testId]) as $it) {
        $given = array_key_exists((int)$it['pos'], $answers) ? mb_substr(trim((string)$answers[(int)$it['pos']]), 0, 80) : (string)$it['given'];
        if ($given === '-') $given = '';   // botda «o'tkazib yuborish»
        if ($it['kind'] === null || (string)$it['answer'] === '') {
            // savol bankdan olib tashlangan yoki kaliti o'chirilgan — o'quvchiga zarar bo'lmasin: hisobga olinmaydi
            q('UPDATE qb_items SET given=?, ok=NULL WHERE test_id=? AND pos=?', [$given, $testId, $it['pos']]);
            continue;
        }
        $graded++;
        $good = qb_check(['kind' => $it['kind'], 'answer' => $it['answer']], $given);
        q('UPDATE qb_items SET given=?, ok=? WHERE test_id=? AND pos=?', [$given, $good ? 1 : 0, $testId, $it['pos']]);
        if ($good) $ok++;
    }
    q('UPDATE qb_tests SET status="done", correct=?, n=?, finished_at=NOW() WHERE id=? AND status<>"done"', [$ok, $graded, $testId]);
    return $ok;
}

/** Natija: umumiy va bo'limlar bo'yicha (faqat sonlar) */
function qb_result(int $testId): array
{
    $t = row('SELECT * FROM qb_tests WHERE id=?', [$testId]);
    $sec = [];
    foreach (rows('SELECT section_name, SUM(ok IS NOT NULL) n, SUM(ok=1) k FROM qb_items WHERE test_id=? GROUP BY section_id, section_name ORDER BY section_name', [$testId]) as $r)
        if ((int)$r['n'] > 0) $sec[] = ['name' => $r['section_name'], 'total' => (int)$r['n'], 'ok' => (int)$r['k']];
    return ['test' => $t, 'total' => (int)($t['n'] ?? 0), 'ok' => (int)($t['correct'] ?? 0), 'sections' => $sec];
}

/** Savol rasmi shu o'quvchining mashq testlarida bormi (rasmni ko'rish huquqi) */
function qb_student_can_see(int $sid, int $questionId): bool
{
    return (bool)val('SELECT 1 FROM qb_items i JOIN qb_tests t ON t.id=i.test_id WHERE t.student_id=? AND i.question_id=? LIMIT 1', [$sid, $questionId]);
}

/* ---------------- PDF chiqarish ---------------- */

/**
 * Juda sodda PDF yozuvchi: A4 sahifalar, matn (Helvetica) va JPEG rasmlar. Tashqi kutubxonasiz.
 * Koordinatalar punktda, y yuqoridan hisoblanadi.
 */
final class MiniPdf
{
    const W = 595.28; const H = 841.89;
    private $objs = [];      // raqam => matn yoki ['stream'=>..., 'dict'=>...]
    private $pages = [];     // sahifa obyekt raqamlari
    private $content = '';
    private $xobjs = [];     // joriy sahifadagi rasmlar [nom => obyekt raqami]
    private $open = false;
    private $imgN = 0;

    private function add($body): int { $this->objs[] = $body; return count($this->objs) + 2; }   // 1 — Catalog, 2 — Pages

    public function newPage(): void
    {
        $this->closePage();
        $this->content = ''; $this->xobjs = []; $this->open = true;
    }

    private function closePage(): void
    {
        if (!$this->open) return;
        $c = $this->add(['stream' => $this->content, 'dict' => '']);
        $xo = '';
        foreach ($this->xobjs as $n => $ref) $xo .= "/$n $ref 0 R ";
        $pg = $this->add('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Contents ' . $c . ' 0 R /Resources << /Font << /F1 __F1__ 0 R /F2 __F2__ 0 R >> /XObject << ' . $xo . '>> >> >>');
        $this->pages[] = $pg;
        $this->open = false;
    }

    private static function enc(string $s): string
    {
        $s = str_replace(['ʻ', 'ʼ', '‘', '’', '`', '“', '”', '—', '–', '›', '→', '…'], ["'", "'", "'", "'", "'", '"', '"', '-', '-', '>', '->', '...'], $s);
        $t = function_exists('iconv') ? @iconv('UTF-8', 'CP1252//TRANSLIT//IGNORE', $s) : false;
        if ($t === false) $t = preg_replace('/[^\x20-\x7E]/', '?', $s);
        return str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\\(', '\\)', '', ' '], $t);
    }

    public function text(float $x, float $y, float $size, string $s, bool $bold = false): void
    {
        $this->content .= sprintf("BT /%s %.2F Tf %.2F %.2F Td (%s) Tj ET\n", $bold ? 'F2' : 'F1', $size, $x, self::H - $y, self::enc($s));
    }

    public function line(float $x1, float $y1, float $x2, float $y2, float $w = 0.5): void
    {
        $this->content .= sprintf("%.2F w %.2F %.2F m %.2F %.2F l S\n", $w, $x1, self::H - $y1, $x2, self::H - $y2);
    }

    public function rect(float $x, float $y, float $w, float $h, float $lw = 0.5): void
    {
        $this->content .= sprintf("%.2F w %.2F %.2F %.2F %.2F re S\n", $lw, $x, self::H - $y - $h, $w, $h);
    }

    /** JPEG rasm: (x, y) — chap-yuqori burchak, $w × $h punkt */
    public function image(string $jpeg, int $pw, int $ph, float $x, float $y, float $w, float $h): void
    {
        $ref = $this->add(['stream' => $jpeg, 'dict' => '/Type /XObject /Subtype /Image /Width ' . $pw . ' /Height ' . $ph . ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode']);
        $name = 'Im' . (++$this->imgN);
        $this->xobjs[$name] = $ref;
        $this->content .= sprintf("q %.2F 0 0 %.2F %.2F %.2F cm /%s Do Q\n", $w, $h, $x, self::H - $y - $h, $name);
    }

    public function output(): string
    {
        $this->closePage();
        $f1 = $this->add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
        $f2 = $this->add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
        $kids = implode(' ', array_map(fn($n) => $n . ' 0 R', $this->pages));
        $all = [1 => '<< /Type /Catalog /Pages 2 0 R >>', 2 => '<< /Type /Pages /Kids [' . $kids . '] /Count ' . count($this->pages) . ' >>'];
        foreach ($this->objs as $i => $o) $all[$i + 3] = $o;
        $out = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $off = [];
        foreach ($all as $n => $o) {
            $off[$n] = strlen($out);
            if (is_array($o)) {
                $out .= "$n 0 obj\n<< " . $o['dict'] . ' /Length ' . strlen($o['stream']) . " >>\nstream\n" . $o['stream'] . "\nendstream\nendobj\n";
            } else {
                $o = str_replace(['__F1__', '__F2__'], [(string)$f1, (string)$f2], $o);
                $out .= "$n 0 obj\n$o\nendobj\n";
            }
        }
        $xref = strlen($out);
        $out .= "xref\n0 " . (count($all) + 1) . "\n0000000000 65535 f \n";
        foreach ($all as $n => $_) $out .= sprintf("%010d 00000 n \n", $off[$n]);
        $out .= "trailer\n<< /Size " . (count($all) + 1) . " /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n";
        return $out;
    }
}

/** PNG faylni oq fonli JPEG ga aylantiradi: [jpeg bayt, w, h] yoki null (GD yo'q/xato) */
function qb_png_to_jpeg(string $path): ?array
{
    if (!function_exists('imagecreatefrompng') || !is_file($path)) return null;
    $im = @imagecreatefrompng($path);
    if (!$im) return null;
    $w = imagesx($im); $h = imagesy($im);
    $bg = imagecreatetruecolor($w, $h);
    imagefill($bg, 0, 0, imagecolorallocate($bg, 255, 255, 255));
    imagecopy($bg, $im, 0, 0, 0, 0, $w, $h);
    ob_start(); imagejpeg($bg, null, 88); $jpg = (string)ob_get_clean();
    if (PHP_VERSION_ID < 80000) { imagedestroy($im); imagedestroy($bg); }   // PHP 8.5 da eskirgan
    return [$jpg, $w, $h];
}

/**
 * Savollar to'plami PDF: $title, $subtitle, $qs — [['id','img','kind','nopt','answer','label'], …] (tartib bilan).
 * $withKey: oxirida javoblar kaliti sahifasi; aks holda javob belgilash jadvali.
 */
function qb_pdf(string $title, string $subtitle, array $qs, bool $withKey = false): ?string
{
    if (!function_exists('imagecreatefrompng')) return null;
    $pdf = new MiniPdf();
    $L = 42.0; $R = MiniPdf::W - 42.0; $maxW = $R - $L - 22; $top = 70.0; $bottom = MiniPdf::H - 48.0;
    $pageNo = 0;
    $head = function () use ($pdf, $title, $subtitle, $L, $R, &$pageNo) {
        $pdf->newPage(); $pageNo++;
        $pdf->text($L, 34, 12, mb_strimwidth($title, 0, 72, '…'), true);
        $pdf->text($L, 48, 8.5, mb_strimwidth($subtitle, 0, 120, '…'));
        $pdf->line($L, 54, $R, 54, 0.8);
        $pdf->text($R - 40, MiniPdf::H - 24, 8, 'Sahifa ' . $pageNo);
    };
    $head(); $y = $top;
    foreach ($qs as $i => $q) {
        $j = qb_png_to_jpeg(qb_dir() . '/' . basename((string)$q['img']));
        if (!$j) continue;
        [$jpg, $pw, $ph] = $j;
        $scale = min(1.0, $maxW / ($pw * 0.5), 1.0);   // 200% da qirqilgan deb hisoblab: 1 px = 0.5 pt
        $dw = $pw * 0.5 * $scale; $dh = $ph * 0.5 * $scale;
        $maxH = $bottom - $top;
        if ($dh > $maxH) { $k = $maxH / $dh; $dw *= $k; $dh *= $k; }
        if ($y + $dh > $bottom) { $head(); $y = $top; }
        $pdf->text($L, $y + 11, 11, ($i + 1) . '.', true);
        $pdf->image($jpg, $pw, $ph, $L + 22, $y, $dw, $dh);
        $y += $dh + 14;
    }
    // javoblar sahifasi
    $head(); $y = $top;
    $pdf->text($L, $y + 6, 12, $withKey ? 'Javoblar kaliti' : 'Javoblar varaqasi', true); $y += 26;
    $colW = ($R - $L) / 2;
    foreach ($qs as $i => $q) {
        $col = $i % 2; $row = intdiv($i, 2);
        if ($col === 0 && $row > 0 && $y + 22 > $bottom) { $head(); $y = $top; }
        $x = $L + $col * $colW; $yy = $y;
        if ($col === 1) { /* ikkinchi ustun — o'sha qator */ }
        $pdf->text($x, $yy + 10, 10, str_pad((string)($i + 1), 2, ' ', STR_PAD_LEFT) . '.', true);
        if ($withKey) $pdf->text($x + 24, $yy + 10, 10, (string)$q['answer']);
        elseif ($q['kind'] === 'open') $pdf->rect($x + 24, $yy - 1, 110, 15);
        else {
            $n = (int)$q['nopt'] === 6 ? 6 : 4;
            for ($k = 0; $k < $n; $k++) { $pdf->rect($x + 26 + $k * 28, $yy - 1, 15, 15); $pdf->text($x + 30 + $k * 28, $yy + 10, 9, chr(65 + $k)); }
        }
        if ($col === 1) $y += 22;
    }
    return $pdf->output();
}
