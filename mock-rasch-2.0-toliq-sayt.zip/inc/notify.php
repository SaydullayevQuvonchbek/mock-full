<?php
defined('APP_ROOT') || exit;
/**
 * Xabar yuborish: kanal tanlash (bot → Telegram Gateway → SMS) va bir martalik kodlar (OTP).
 */

/** Kodlarni xeshlash kaliti (birinchi ishlatilganda yaratiladi) */
function otp_key(): string
{
    $k = sms_meta('otp_key');
    if ($k === '') { $k = bin2hex(random_bytes(16)); sms_meta_set('otp_key', $k); }
    return $k;
}

/** Kanal tartibi: sozlama 'otp_order' */
function notify_order(): array
{
    $o = sms_meta('otp_order', 'bot,gw,sms');
    return in_array($o, ['bot,gw,sms', 'bot,sms,gw', 'gw,sms', 'sms'], true) ? explode(',', $o) : ['bot', 'gw', 'sms'];
}

/** Bu o'quvchiga qaysi kanallar mavjud (tartib bilan): ['bot','gw','sms'] */
function notify_channels(array $s): array
{
    $has = [];
    $hasPhone = !empty($s['phone']);
    foreach (notify_order() as $c) {
        if ($c === 'bot' && !empty($s['tg_chat_id']) && tg_ready()) $has[] = 'bot';
        elseif ($c === 'gw' && $hasPhone && gw_ready()) $has[] = 'gw';
        elseif ($c === 'sms' && $hasPhone && sms_ready()) $has[] = 'sms';
    }
    return $has;
}

/** OTP limiti: bitta nishonga kuniga 5 ta, bitta IP ga 20 ta. true = yuborish mumkin */
function otp_allowed(string $kind, string $target): bool
{
    $since = date('Y-m-d H:i:s', time() - 86400);
    if ((int)val('SELECT COUNT(*) FROM otp_codes WHERE kind=? AND target=? AND created_at>?', [$kind, $target, $since]) >= 5) return false;
    if ((int)val('SELECT COUNT(*) FROM otp_codes WHERE ip=? AND created_at>?', [client_ip(), $since]) >= 20) return false;
    return true;
}

/** Yangi kod yaratadi (oldingi ishlatilmaganlari bekor qilinadi). Qaytaradi: oddiy matndagi 6 xonali kod */
function otp_create(string $kind, string $target, ?int $sid, string $channel): string
{
    q('UPDATE otp_codes SET used_at=NOW() WHERE kind=? AND target=? AND used_at IS NULL', [$kind, $target]);
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    q('INSERT INTO otp_codes (kind, target, code_hash, channel, student_id, expires_at, ip) VALUES (?,?,?,?,?,DATE_ADD(NOW(), INTERVAL 5 MINUTE),?)',
        [$kind, $target, hash_hmac('sha256', $code, otp_key()), $channel, $sid, client_ip()]);
    if (random_int(1, 40) === 1) q('DELETE FROM otp_codes WHERE created_at < DATE_SUB(NOW(), INTERVAL 3 DAY)');
    return $code;
}

/** Kodni tekshiradi (3 urinish, 5 daqiqa). true = to'g'ri (kod ishlatilgan deb belgilanadi) */
function otp_verify(string $kind, string $target, string $code): bool
{
    $r = row('SELECT * FROM otp_codes WHERE kind=? AND target=? AND used_at IS NULL AND expires_at>NOW() ORDER BY id DESC LIMIT 1', [$kind, $target]);
    if (!$r || (int)$r['attempts'] >= 3) return false;
    q('UPDATE otp_codes SET attempts=attempts+1 WHERE id=?', [$r['id']]);
    if (!hash_equals((string)$r['code_hash'], hash_hmac('sha256', preg_replace('/\D/', '', $code), otp_key()))) return false;
    q('UPDATE otp_codes SET used_at=NOW() WHERE id=?', [$r['id']]);
    return true;
}

/**
 * Kodni yetkazadi: berilgan kanallar ketma-ketligidan birinchi muvaffaqiyatlisi.
 * $channels — notify_channels() natijasi. Qaytaradi: ishlatilgan kanal ('bot'|'gw'|'sms') yoki ''.
 */
function otp_deliver(array $s, string $code, array $channels): string
{
    foreach ($channels as $c) {
        if ($c === 'bot') {
            $r = tg_send((int)$s['tg_chat_id'], "🔐 Tasdiqlash kodi: <b>" . tg_h($code) . "</b>\n5 daqiqa amal qiladi. Hech kimga bermang.");
            tg_log('out', (int)$s['tg_chat_id'], 'otp', $r['ok'], $r['ok'] ? '' : $r['desc']);
            if ($r['ok']) return 'bot';
        } elseif ($c === 'gw') {
            if (gw_send_code((string)$s['phone'], $code)['ok']) return 'gw';
        } elseif ($c === 'sms') {
            if (sms_send((string)$s['phone'], sms_render('code', ['code' => $code]))['ok']) return 'sms';
        }
    }
    return '';
}

/** Kanal nomi (o'quvchiga ko'rsatiladigan) */
function notify_channel_label(string $c): string
{
    return ['bot' => 'Telegram bot', 'gw' => 'Telegram', 'sms' => 'SMS'][$c] ?? '';
}

/** Telefonni yashiradi: +998 90 *** ** 67 */
function mask_phone(string $p): string
{
    $d = preg_replace('/\D/', '', $p);
    return strlen($d) === 12 ? '+998 ' . substr($d, 3, 2) . ' *** ** ' . substr($d, 10, 2) : '***';
}
