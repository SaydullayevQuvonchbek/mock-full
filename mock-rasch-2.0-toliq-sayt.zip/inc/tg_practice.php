<?php
defined('APP_ROOT') || exit;
/**
 * Telegram bot: /mashq — savollar bankidan tasodifiy mashq testi (rasmli savollar, tugmali javoblar).
 * Yakunda faqat nechta to'g'ri topilgani (umumiy va bo'limlar bo'yicha) yuboriladi. PHP 7.4 bilan mos.
 * Holat: tg_state(step='qb', data='<test>:<pos>') — ochiq savolga matn bilan javob uchun.
 */

function tg_qb_state(int $chat, string $data): void
{
    q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'qb', $data]);
}

/** /mashq — bo'lim tanlash menyusi */
function tg_qb_menu(int $chat, array $st): void
{
    $tree = array_values(array_filter(qb_tree(), function ($s) { return $s['ready_total'] > 0; }));
    if (!$tree) { tg_send($chat, 'Hozircha mashq savollari qo‘shilmagan.'); return; }
    $kb = [];
    $open = row('SELECT id, n FROM qb_tests WHERE student_id=? AND status="open" AND via="bot" ORDER BY id DESC LIMIT 1', [$st['id']]);
    if ($open) $kb[] = [['text' => '▶️ Davom ettirish (' . (int)$open['n'] . ' ta savol)', 'callback_data' => 'qbr:' . (int)$open['id']]];
    $kb[] = [['text' => '🎲 Barcha bo‘limlar', 'callback_data' => 'qbs:0']];
    foreach (array_slice($tree, 0, 24) as $s) {
        $kb[] = [['text' => str_repeat('· ', (int)$s['depth']) . mb_strimwidth((string)$s['name'], 0, 40, '…') . ' (' . (int)$s['ready_total'] . ')', 'callback_data' => 'qbs:' . (int)$s['id']]];
    }
    tg_send($chat, "📚 <b>Mashq testi</b>\nBo‘limni tanlang — tasodifiy savollar beriladi. Yakunda nechta to‘g‘ri topganingiz ko‘rsatiladi.", ['inline_keyboard' => $kb]);
}

function tg_qb_own_test(int $tid, int $sid): ?array
{
    return row('SELECT * FROM qb_tests WHERE id=? AND student_id=? AND status="open"', [$tid, $sid]);
}

/** Savol xabaridagi tugmalarni olib tashlaydi (javob berilgach) */
function tg_qb_clear_kb(int $chat, int $msgId): void
{
    if ($msgId) tg_call('editMessageReplyMarkup', ['chat_id' => $chat, 'message_id' => $msgId, 'reply_markup' => ['inline_keyboard' => []]]);
}

/** «qb…» tugmalari */
function tg_qb_cb(int $chat, array $st, string $data, callable $cb, int $msgId = 0): void
{
    $sid = (int)$st['id'];
    if (!preg_match('/^qb([a-zA-Z]):(\d+)(?::(\d+))?(?::([A-F]))?$/', $data, $m)) { $cb(); return; }
    $act = $m[1]; $a = (int)$m[2]; $b = isset($m[3]) ? (int)$m[3] : 0; $L = $m[4] ?? '';

    if ($act === 's') {                                   // bo'lim tanlandi → savollar soni
        $pool = qb_pool_size($a ? [$a] : []);
        if ($pool < 1) { $cb('Bu bo‘limda tayyor savol yo‘q', true); return; }
        $cb();
        $row = [];
        foreach ([5, 10, 20, 30, 45] as $n) if ($n <= $pool) $row[] = ['text' => (string)$n, 'callback_data' => 'qbn:' . $a . ':' . $n];
        if (!$row || ($pool <= 60 && !in_array($pool, [5, 10, 20, 30, 45], true))) $row[] = ['text' => 'Hammasi (' . min(60, $pool) . ')', 'callback_data' => 'qbn:' . $a . ':' . min(60, $pool)];
        tg_send($chat, 'Nechta savol bo‘lsin? (bankda ' . $pool . ' ta tayyor savol bor)', ['inline_keyboard' => array_chunk($row, 3)]);
        return;
    }
    if ($act === 'n') {                                   // test tuzish
        $open = (int)val('SELECT COUNT(*) FROM qb_tests WHERE student_id=? AND status="open"', [$sid]);
        $today = (int)val('SELECT COUNT(*) FROM qb_tests WHERE student_id=? AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [$sid]);
        if ($open >= 8) { $cb('Yakunlanmagan mashqlaringiz ko‘p. Avval ularni yakunlang (saytdagi «Mashq testlari»).', true); return; }
        if ($today >= 40) { $cb('Bugungi mashq limiti tugadi. Ertaga davom eting.', true); return; }
        [$tid, $err] = qb_build_test($sid, $a ? [$a] : [], max(1, $b), 'bot');
        if (!$tid) { $cb($err, true); return; }
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_send($chat, '🎯 Mashq tayyor: <b>' . (int)val('SELECT n FROM qb_tests WHERE id=?', [$tid]) . ' ta savol</b>. Har bir savol rasm bilan keladi — tugma bosing' . "\n" . '(ochiq savolda javobni matn bilan yuboring).');
        tg_qb_next($chat, $st, (int)$tid, 0);
        return;
    }
    $t = tg_qb_own_test($a, $sid);
    if (!$t) { $cb('Bu mashq topilmadi yoki yakunlangan', true); return; }
    $tid = (int)$t['id'];

    if ($act === 'a') {                                   // javob (tugma)
        $it = row('SELECT i.given, q.kind, q.nopt FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND i.pos=?', [$tid, $b]);
        if (!$it || $it['kind'] === 'open' || $L === '' || ord($L) - 64 > ((int)$it['nopt'] === 6 ? 6 : 4)) { $cb('Bu savolga matn bilan javob bering', true); return; }
        if ((string)$it['given'] !== '' && (string)$it['given'] !== '-') { $cb('Bu savolga javob berilgan'); return; }
        q('UPDATE qb_items SET given=? WHERE test_id=? AND pos=?', [$L, $tid, $b]);
        $cb($b . '-savol → ' . $L);
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, $b);
        return;
    }
    if ($act === 'k') {                                   // o'tkazish
        $up = q('UPDATE qb_items SET given="-" WHERE test_id=? AND pos=? AND given=""', [$tid, $b]);
        if (!$up->rowCount()) { $cb('Bu savol allaqachon o‘tkazilgan yoki javob berilgan'); tg_qb_clear_kb($chat, $msgId); return; }   // qayta bosish keyingi savolni ikki marta yubormasin
        $cb('O‘tkazildi');
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, $b);
        return;
    }
    if ($act === 'f') {                                   // yakunlashni so'rash
        $cb();
        $n = (int)$t['n'];
        $done = (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given NOT IN ("","-")', [$tid]);
        tg_send($chat, "Mashqni yakunlaysizmi?\nJavob berilgan: <b>$done / $n</b>." . ($done < $n ? "\n⚠️ Javobsiz savollar noto‘g‘ri hisoblanadi." : ''), ['inline_keyboard' => [
            [['text' => '✅ Ha, yakunlash', 'callback_data' => 'qbF:' . $tid]],
            [['text' => '↩️ Davom etaman', 'callback_data' => 'qbr:' . $tid]],
        ]]);
        return;
    }
    if ($act === 'F') {                                   // yakunlash
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_finish($chat, $tid);
        return;
    }
    if ($act === 'q') {                                   // o'tkazilganlarni qayta yechish
        q('UPDATE qb_items SET given="" WHERE test_id=? AND given="-"', [$tid]);
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, 0);
        return;
    }
    if ($act === 'r') {                                   // davom ettirish
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, 0);
        return;
    }
    $cb();
}

/** Keyingi javobsiz savolni yuboradi (bo'lmasa — yakunlash taklifi) */
function tg_qb_next(int $chat, array $st, int $tid, int $afterPos): void
{
    $t = tg_qb_own_test($tid, (int)$st['id']);
    if (!$t) { tg_send($chat, 'Bu mashq topilmadi yoki yakunlangan. /mashq'); return; }
    $left = array_map('intval', array_column(rows('SELECT pos FROM qb_items WHERE test_id=? AND given="" ORDER BY pos', [$tid]), 'pos'));
    $pos = null;
    foreach ($left as $p) if ($p > $afterPos) { $pos = $p; break; }
    if ($pos === null && $left) $pos = $left[0];
    if ($pos === null) {
        $n = (int)$t['n'];
        $done = (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given NOT IN ("","-")', [$tid]);
        $skipped = (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given="-"', [$tid]);
        $kb = [[['text' => '✅ Yakunlash', 'callback_data' => 'qbF:' . $tid]]];
        if ($skipped) $kb[] = [['text' => '↩️ O‘tkazilganlarni yechish (' . $skipped . ')', 'callback_data' => 'qbq:' . $tid]];
        q('DELETE FROM tg_state WHERE chat_id=? AND step="qb"', [$chat]);
        tg_send($chat, "Barcha savollarga o‘tdingiz.\nJavob berilgan: <b>$done / $n</b>." . ($skipped ? "\nO‘tkazilgan: <b>$skipped</b>." : ''), ['inline_keyboard' => $kb]);
        return;
    }
    tg_qb_send_question($chat, $st, $t, $pos);
}

function tg_qb_send_question(int $chat, array $st, array $t, int $pos): void
{
    $tid = (int)$t['id'];
    $it = row('SELECT i.pos, i.section_name, q.id, q.img, q.kind, q.nopt FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND i.pos=?', [$tid, $pos]);
    $path = $it ? qb_dir() . '/' . basename((string)$it['img']) : '';
    if (!$it || !is_file($path)) {                         // savol bankdan olib tashlangan — o'tkazib yuboramiz
        q('UPDATE qb_items SET given="-" WHERE test_id=? AND pos=?', [$tid, $pos]);
        tg_qb_next($chat, $st, $tid, $pos);
        return;
    }
    $cap = '<b>Savol ' . $pos . ' / ' . (int)$t['n'] . '</b> · ' . tg_h($it['section_name']);
    $kb = [];
    if ($it['kind'] === 'open') {
        $cap .= "\n\n✍️ Javobni matn bilan yuboring (kasr: <code>1/2</code>, o‘nlik: <code>0.5</code>).";
    } else {
        $row = [];
        for ($k = 0; $k < ((int)$it['nopt'] === 6 ? 6 : 4); $k++) { $L = chr(65 + $k); $row[] = ['text' => $L, 'callback_data' => 'qba:' . $tid . ':' . $pos . ':' . $L]; }
        $kb[] = $row;
    }
    $kb[] = [['text' => '⏭ O‘tkazish', 'callback_data' => 'qbk:' . $tid . ':' . $pos], ['text' => '🏁 Yakunlash', 'callback_data' => 'qbf:' . $tid]];
    tg_qb_state($chat, $tid . ':' . $pos);
    $base = ['chat_id' => $chat, 'caption' => $cap, 'parse_mode' => 'HTML', 'reply_markup' => ['inline_keyboard' => $kb]];
    $r = tg_call('sendPhoto', $base + ['photo' => new CURLFile($path, 'image/png', 'savol.png')], null, 60);
    if (!$r['ok'] && $r['code'] === 400) {                 // juda cho'zinchoq rasm kabi hollarda — fayl sifatida
        $r = tg_call('sendDocument', $base + ['document' => new CURLFile($path, 'image/png', 'savol-' . $pos . '.png')], null, 60);
    }
    if (!$r['ok']) tg_send($chat, 'Savolni yuborib bo‘lmadi. Birozdan keyin /mashq orqali davom eting.');
}

/** Ochiq savolga (yoki harf bilan) matnli javob. true — qabul qilindi */
function tg_qb_text(int $chat, array $st, array $state, string $text): bool
{
    if (!preg_match('/^(\d+):(\d+)$/', (string)$state['data'], $m)) return false;
    $tid = (int)$m[1]; $pos = (int)$m[2];
    $t = tg_qb_own_test($tid, (int)$st['id']);
    if (!$t) { q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); return false; }
    $it = row('SELECT i.given, q.kind, q.nopt FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND i.pos=?', [$tid, $pos]);
    if (!$it) return false;
    $val = trim($text);
    if ($it['kind'] === 'open') {
        if (mb_strlen($val) > 40) { tg_send($chat, 'Javob juda uzun (40 belgigacha). Eng sodda ko‘rinishda yozing.'); return true; }
    } else {
        $val = strtoupper($val);
        $max = (int)$it['nopt'] === 6 ? 'F' : 'D';
        if (!preg_match('/^[A-F]$/', $val) || $val > $max) { tg_send($chat, 'Bu savolga tugmalar bilan javob bering (A–' . $max . ').'); return true; }
    }
    q('UPDATE qb_items SET given=? WHERE test_id=? AND pos=?', [$val, $tid, $pos]);
    tg_send($chat, '✔️ ' . $pos . '-savol: <code>' . tg_h($val) . '</code>');
    tg_qb_next($chat, $st, $tid, $pos);
    return true;
}

/** Mashqni yakunlaydi va faqat sonlarni yuboradi */
function tg_qb_finish(int $chat, int $tid): void
{
    qb_finish($tid, []);
    q('DELETE FROM tg_state WHERE chat_id=? AND step="qb"', [$chat]);
    $r = qb_result($tid);
    $pct = $r['total'] > 0 ? round(100 * $r['ok'] / $r['total']) : 0;
    $s = "🏁 <b>Mashq yakunlandi</b>\n\nTo‘g‘ri javoblar: <b>" . $r['ok'] . ' / ' . $r['total'] . "</b> ($pct%)";
    if (count($r['sections']) > 1) {
        $s .= "\n\n<b>Bo‘limlar bo‘yicha:</b>";
        foreach ($r['sections'] as $x) $s .= "\n• " . tg_h($x['name']) . ': ' . $x['ok'] . ' / ' . $x['total'];
    }
    tg_send($chat, $s . "\n\nYana mashq qilish: /mashq", null);
}
