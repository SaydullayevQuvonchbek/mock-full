<?php
defined('APP_ROOT') || exit;
/**
 * Telegram Gateway (https://core.telegram.org/gateway/api): telefon raqamga tasdiqlash kodini Telegramning o'zi orqali yuborish.
 * Bot yoki ulanish shart emas — raqam Telegramda ro'yxatdan o'tgan bo'lsa yetadi; aks holda SMS ga o'tiladi.
 * Oqim: checkSendAbility (yuborish mumkinmi + request_id) → sendVerificationMessage (o'z kodimiz, ttl=300).
 * Kodni o'zimiz yaratamiz va o'zimiz tekshiramiz (otp_codes), shuning uchun checkVerificationStatus kerak emas.
 * config.php da 'gw_api' berilsa (sinov) shu manzil ishlatiladi.
 */

function gw_token(): string { return sms_meta('gw_token'); }
function gw_ready(): bool { return gw_token() !== ''; }

function gw_api_base(): string
{
    global $CONFIG;
    return rtrim((string)($CONFIG['gw_api'] ?? 'https://gatewayapi.telegram.org'), '/');
}

/** Qaytaradi: ['ok'=>bool,'result'=>mixed,'desc'=>string] */
function gw_call(string $method, array $params, ?string $token = null): array
{
    $token = $token ?? gw_token();
    if ($token === '') return ['ok' => false, 'result' => null, 'desc' => 'Gateway tokeni kiritilmagan'];
    if (!function_exists('curl_init')) return ['ok' => false, 'result' => null, 'desc' => 'PHP curl kengaytmasi yoqilmagan'];
    $ch = curl_init(gw_api_base() . '/' . $method);
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($params, JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $token],
        CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 15,
    ]);
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    if (PHP_VERSION_ID < 80000) curl_close($ch);   // PHP 8+ da keraksiz, 8.5 da eskirgan
    if ($raw === false) return ['ok' => false, 'result' => null, 'desc' => 'Tarmoq xatosi: ' . $err];
    $j = json_decode((string)$raw, true);
    if (!is_array($j)) return ['ok' => false, 'result' => null, 'desc' => 'Gateway javobi tushunarsiz'];
    return ['ok' => !empty($j['ok']), 'result' => $j['result'] ?? null, 'desc' => (string)($j['error'] ?? '')];
}

/** Raqamga Telegram orqali kod yuborish. Qaytaradi: ['ok'=>bool,'desc'=>string] (ok=false → boshqa kanalga o'ting) */
function gw_send_code(string $phone, string $code): array
{
    $ph = '+' . preg_replace('/\D/', '', $phone);
    $a = gw_call('checkSendAbility', ['phone_number' => $ph]);
    if (!$a['ok'] || empty($a['result']['request_id'])) {
        tg_log('out', null, 'gw', false, 'checkSendAbility: ' . mb_substr($a['desc'], 0, 120));
        return ['ok' => false, 'desc' => $a['desc'] ?: 'Raqamda Telegram yo\'q'];
    }
    $s = gw_call('sendVerificationMessage', ['phone_number' => $ph, 'request_id' => $a['result']['request_id'], 'code' => $code, 'ttl' => 300]);
    tg_log('out', null, 'gw', $s['ok'], $s['ok'] ? ('+' . substr($ph, -4)) : mb_substr($s['desc'], 0, 120));
    return ['ok' => $s['ok'], 'desc' => $s['desc']];
}
