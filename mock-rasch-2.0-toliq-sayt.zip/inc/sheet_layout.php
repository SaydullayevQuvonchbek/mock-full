<?php
defined('APP_ROOT') || exit;
/**
 * Javoblar varaqasi geometriyasi (millimetrda, A4 = 210×297).
 * Bitta manba: chop etiladigan varaqa (sheet.php) ham, skaner (omr.js) ham shu koordinatalardan foydalanadi.
 */
function sheet_layout(array $test): array
{
    $items = test_items($test);
    $mc = array_values(array_filter($items, fn($i) => $i['type'] === 'mc'));
    $open = array_values(array_filter($items, fn($i) => $i['type'] === 'open'));

    $L = [
        'page' => ['w' => 210, 'h' => 297],
        'marker' => 7.0,
        // markerlar markazi: chap-yuqori, o'ng-yuqori, o'ng-past, chap-past
        'markers' => [[12, 12], [198, 12], [198, 285], [12, 285]],
        // Yon markerlar (1.5+): chap va o'ng chetda ikki balandlikda — varaq buklanganda har bo'lak alohida tekislanadi.
        // Har juft [chap, o'ng]; gomografiya bandlari: 12–100, 100–188, 188–285 mm.
        'sides' => [[[12, 100], [198, 100]], [[12, 188], [198, 188]]],
        // yo'nalish belgisi (faqat chap-yuqorida): 180° ag'darilgan rasmni aniqlash uchun
        'orient' => ['x' => 22, 'y' => 10.5, 'w' => 12, 'h' => 3],
        'r' => 2.15,
        'id' => ['digits' => 6, 'x0' => 23, 'dx' => 7.0, 'y0' => 60, 'dy' => 5.3, 'cols' => []],
        'mc' => [],
        'open' => [],
    ];
    // ID pufakchalari
    for ($d = 0; $d < 6; $d++) {
        $col = [];
        for ($v = 0; $v <= 9; $v++) $col[] = ['v' => (string)$v, 'x' => 23 + $d * 7.0, 'y' => 60 + $v * 5.3];
        $L['id']['cols'][] = $col;
    }
    // Yopiq savollar: 4 ustun, ustun bo'yicha to'ldiriladi
    $n = count($mc);
    $perCol = max(1, (int)ceil($n / 4));
    $perCol = max($perCol, min(9, $n));
    $cols = (int)ceil($n / $perCol);
    $maxOptsPerCol = [];
    foreach ($mc as $k => $it) {
        $c = intdiv($k, $perCol);
        $maxOptsPerCol[$c] = max($maxOptsPerCol[$c] ?? 0, count($it['opts']));
    }
    $step = 6.2;
    $totalW = 0;
    foreach ($maxOptsPerCol as $m) $totalW += 11 + ($m - 1) * $step + 6;
    if ($totalW > 178) $step = max(5.0, $step * 178 / $totalW);
    $extra = max(0, (178 - $totalW) / max(1, $cols));
    $colX = []; $x = 16;
    for ($c = 0; $c < $cols; $c++) {
        $colX[$c] = $x;
        $x += 11 + (($maxOptsPerCol[$c] ?? 4) - 1) * $step + 6 + $extra;
    }
    $rowDy = min(7.0, 60 / max(1, $perCol));
    foreach ($mc as $k => $it) {
        $c = intdiv($k, $perCol); $r = $k % $perCol;
        $y = 126 + $r * $rowDy;
        $opts = [];
        foreach ($it['opts'] as $j => $o) $opts[] = ['v' => $o, 'x' => round($colX[$c] + 11 + $j * $step, 2), 'y' => $y];
        $L['mc'][] = ['label' => $it['label'], 'nx' => $colX[$c], 'y' => $y, 'opts' => $opts];
    }
    // Ochiq topshiriqlar: 2 ustun × 5 qator. Har bir qism (a/b) uchun: javob katakchasi +
    // tekshiruvchi uchun ikkita doiracha: ✓ (to'g'ri) va ✗ (noto'g'ri).
    $tasks = [];
    foreach ($open as $it) $tasks[$it['task']][$it['part']] = $it;
    $t = 0;
    foreach ($tasks as $no => $parts) {
        $c = intdiv($t, 5); $r = $t % 5;
        $x0 = 13 + $c * 92; $y = 204 + $r * 12.5;
        $px = $x0 + 8.5;
        foreach (['a', 'b'] as $p) {
            if (!isset($parts[$p])) continue;
            $bx = $px + 4;                        // katakcha chap cheti
            $ok = $bx + 21 + 4.2;                 // ✓ doiracha markazi
            $L['open'][] = ['label' => $parts[$p]['label'], 'task' => $no, 'part' => $p,
                'box' => ['x' => $bx, 'y' => $y - 4.5, 'w' => 21, 'h' => 9],
                'x' => round($ok, 2), 'xw' => round($ok + 5.8, 2), 'y' => $y];
            $px += 40.5;
        }
        $L['open_rows'][] = ['no' => $no, 'x' => $x0, 'y' => $y];
        $t++;
    }
    return $L;
}
