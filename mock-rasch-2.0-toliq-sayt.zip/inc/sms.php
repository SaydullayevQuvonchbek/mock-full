<?php
defined('APP_ROOT') || exit;
/**
 * Eskiz.uz SMS (https://documenter.getpostman.com/view/663428/RzfmES4z — Eskiz API v1).
 *  - Kirish:  POST /api/auth/login (email, password) → token (30 kun amal qiladi, meta da saqlanadi)
 *  - Yuborish: POST /api/message/sms/send (mobile_phone=998XXXXXXXXX, message, from, callback_url)
 *  - Balans:  GET  /api/user/get-limit
 * MUHIM: Eskiz har bir xabar matnini oldindan tasdiqlaydi (moderatsiya). Tasdiqlanmagan matn yetkazilmaydi,
 * shuning uchun platforma faqat sms_templates() dagi qat'iy matnlarni yuboradi — ularni Eskiz kabinetida shablon sifatida tasdiqlating.
 * config.php da 'sms_api' berilsa (sinov) shu manzil ishlatiladi.
 */

function sms_meta(string $k, string $default = ''): string
{
    $v = val('SELECT v FROM meta WHERE k=?', ['set_' . $k]);
    return $v === null ? $default : (string)$v;
}
function sms_meta_set(string $k, string $v): void
{
    q('REPLACE INTO meta (k, v) VALUES (?, ?)', ['set_' . $k, mb_substr($v, 0, 255)]);
}

function sms_api_base(): string
{
    global $CONFIG;
    return rtrim((string)($CONFIG['sms_api'] ?? 'https://notify.eskiz.uz'), '/');
}

function sms_ready(): bool { return sms_meta('sms_email') !== '' && sms_meta('sms_pass') !== ''; }
function sms_sender(): string { return sms_meta('sms_from', '4546') ?: '4546'; }

/** Qat'iy SMS shablonlari (Eskizda tasdiqlatiladi). {…} — o'zgaruvchilar */
function sms_templates(): array
{
    return [
        'code' => ['Parol tiklash / telefon tasdiqlash kodi', 'MOCK Rasch: tasdiqlash kodi {code}. 5 daqiqa amal qiladi. Hech kimga bermang.'],
        'temp' => ['Vaqtinchalik parol', 'MOCK Rasch: ID {id}, vaqtinchalik parol {pass}. Kirgach parolni almashtiring.'],
        'room' => ['Xona va o\'rin', 'MOCK Rasch: {test}, {date}. Siz {room}, {seat}-o\'rin. 15 daqiqa oldin keling.'],
        'result' => ['Natija (ota-onaga)', 'MOCK Rasch: {name}, {test}: {ball} ball ({grade}), {rank}-o\'rin. {url}'],
    ];
}

function sms_render(string $key, array $vars): string
{
    $t = sms_templates()[$key][1] ?? '';
    foreach ($vars as $k => $v) $t = str_replace('{' . $k . '}', (string)$v, $t);
    return $t;
}

/** Past darajali HTTP (multipart/form-data — Eskiz shuni kutadi) */
function sms_http(string $method, string $path, array $params = [], string $token = '', int $timeout = 20): array
{
    if (!function_exists('curl_init')) return ['ok' => false, 'code' => 0, 'data' => null, 'desc' => 'PHP curl kengaytmasi yoqilmagan'];
    $ch = curl_init(sms_api_base() . $path);
    $opt = [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => $timeout,
        CURLOPT_HTTPHEADER => $token !== '' ? ['Authorization: Bearer ' . $token] : []];
    if ($method === 'POST') { $opt[CURLOPT_POST] = true; $opt[CURLOPT_POSTFIELDS] = $params; }
    elseif ($params) curl_setopt($ch, CURLOPT_URL, sms_api_base() . $path . '?' . http_build_query($params));
    curl_setopt_array($ch, $opt);
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if (PHP_VERSION_ID < 80000) curl_close($ch);   // PHP 8+ da keraksiz, 8.5 da eskirgan
    if ($raw === false) return ['ok' => false, 'code' => 0, 'data' => null, 'desc' => 'Tarmoq xatosi: ' . $err];
    $j = json_decode((string)$raw, true);
    $okHttp = $http >= 200 && $http < 300;
    $desc = is_array($j) ? (string)($j['message'] ?? ($j['status'] ?? '')) : 'Javob tushunarsiz (HTTP ' . $http . ')';
    return ['ok' => $okHttp && is_array($j), 'code' => $http, 'data' => $j, 'desc' => $desc];
}

/** Token: meta da (25 kungacha); eskirgan yoki $force bo'lsa qayta kirish */
function sms_token(bool $force = false): ?string
{
    if (!sms_ready()) return null;
    $tok = sms_meta('sms_token');
    $at = (int)sms_meta('sms_token_at', '0');
    if (!$force && $tok !== '' && time() - $at < 25 * 86400) return $tok;
    $r = sms_http('POST', '/api/auth/login', ['email' => sms_meta('sms_email'), 'password' => sms_meta('sms_pass')]);
    $t = $r['ok'] ? (string)($r['data']['data']['token'] ?? '') : '';
    if ($t === '') { tg_log('out', null, 'sms', false, 'Eskiz kirish xatosi: ' . $r['desc']); return null; }
    sms_meta_set('sms_token', $t);
    sms_meta_set('sms_token_at', (string)time());
    return $t;
}

/** Bitta SMS. Qaytaradi: ['ok'=>bool,'id'=>string,'desc'=>string] */
function sms_send(string $phone, string $text): array
{
    $d = preg_replace('/\D/', '', $phone);
    if (!preg_match('/^998\d{9}$/', $d)) return ['ok' => false, 'id' => '', 'desc' => 'Telefon raqam noto\'g\'ri'];
    $tok = sms_token();
    if ($tok === null) return ['ok' => false, 'id' => '', 'desc' => 'Eskiz ga kirib bo\'lmadi (email/parolni tekshiring)'];
    $params = ['mobile_phone' => $d, 'message' => $text, 'from' => sms_sender()];
    $r = sms_http('POST', '/api/message/sms/send', $params, $tok);
    if ($r['code'] === 401) {   // token eskirgan
        $tok = sms_token(true);
        if ($tok !== null) $r = sms_http('POST', '/api/message/sms/send', $params, $tok);
    }
    $ok = $r['ok'] && (isset($r['data']['id']) || ($r['data']['status'] ?? '') === 'waiting' || ($r['data']['status'] ?? '') === 'success');
    $id = (string)($r['data']['id'] ?? '');
    tg_log('out', null, 'sms', $ok, $ok ? ('+' . substr($d, -4) . ' ' . $id) : mb_substr($r['desc'], 0, 150));
    return ['ok' => $ok, 'id' => $id, 'desc' => $r['desc'], 'code' => $r['code']];
}

/** Balans (so'm). 10 daqiqa keshlanadi. null = bilib bo'lmadi */
function sms_balance(bool $fresh = false): ?float
{
    if (!sms_ready()) return null;
    if (!$fresh && time() - (int)sms_meta('sms_bal_at', '0') < 600 && sms_meta('sms_bal') !== '') return (float)sms_meta('sms_bal');
    $tok = sms_token();
    if ($tok === null) return null;
    $r = sms_http('GET', '/api/user/get-limit', [], $tok, 10);
    if ($r['code'] === 401) { $tok = sms_token(true); if ($tok) $r = sms_http('GET', '/api/user/get-limit', [], $tok, 10); }
    if (!$r['ok'] || !isset($r['data']['data']['balance'])) return null;
    $b = (float)$r['data']['data']['balance'];
    sms_meta_set('sms_bal', (string)$b);
    sms_meta_set('sms_bal_at', (string)time());
    return $b;
}
