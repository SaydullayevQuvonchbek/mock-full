<?php
defined('APP_ROOT') || exit;
/** Markaz sertifikati / natija varaqasi: yaratish, raqamlash, tekshirish havolasi */

function app_base_url(): string
{
    global $CONFIG;
    $u = trim(app_setting('public_url'));
    if ($u !== '') return rtrim($u, '/') . '/';
    $scheme = is_https() ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return $scheme . '://' . $host . $dir . '/';
}

function cert_verify_url(array $c): string
{
    return app_base_url() . 'index.php?' . http_build_query(['p' => 'verify', 'n' => $c['number'], 't' => $c['token']]);
}

/** Bitta o'quvchi uchun hujjat ma'lumotlarini yig'ish va saqlash (raqam o'zgarmaydi) */
function issue_certificate(array $test, int $sid): ?array
{
    global $CONFIG;
    $r = row('SELECT r.*, s.code, s.full_name, s.last_name, s.first_name, s.middle_name, s.school, s.grade_level, s.center_id
              FROM results r JOIN students s ON s.id=r.student_id WHERE r.test_id=? AND r.student_id=?', [$test['id'], $sid]);
    if (!$r) return null;
    $ball = (float)$r['ball'];
    $sc = section_counts($test, $r['scored']);
    $data = [
        'name' => $r['full_name'], 'last' => $r['last_name'], 'first' => $r['first_name'], 'middle' => $r['middle_name'],
        'code' => $r['code'], 'school' => $r['school'], 'grade_level' => $r['grade_level'],
        'center' => $r['center_id'] ? (string)val('SELECT name FROM centers WHERE id=?', [$r['center_id']]) : '',
        'issuer' => app_setting('center'), 'test' => $test['title'], 'subject' => $test['subject'], 'date' => $test['test_date'],
        'ball' => $ball, 'percent' => cert_percent($ball), 'grade' => $r['grade'],
        'official' => $r['ball_official'] !== null ? (float)$r['ball_official'] : null, 'grade_official' => $r['grade_official'],
        'raw' => (int)$r['raw'], 'items' => $sc['items_total'], 'tasks_full' => $sc['tasks_full'], 'tasks' => $sc['tasks_total'],
        'sections' => array_values(array_map(fn($s) => ['name' => $s['name'], 'ball' => $s['ball'], 'ok' => $s['ok'], 'total' => $s['total']], section_scores($test, $r['scored'], $ball))),
        'rank' => (int)$r['rank_no'], 'n' => (int)($test['stats']['N'] ?? 0),
    ];
    $kind = $ball >= 46 - 1e-9 ? 'cert' : 'report';
    $json = json_encode($data, JSON_UNESCAPED_UNICODE);
    $ex = row('SELECT * FROM certificates WHERE test_id=? AND student_id=?', [$test['id'], $sid]);
    if ($ex) {
        q('UPDATE certificates SET data_json=?, kind=? WHERE id=?', [$json, $kind, $ex['id']]);
        $id = (int)$ex['id'];
    } else {
        q('INSERT INTO certificates (number, token, test_id, student_id, kind, data_json) VALUES (?,?,?,?,?,?)',
            ['TMP' . bin2hex(random_bytes(6)), bin2hex(random_bytes(8)), $test['id'], $sid, $kind, $json]);
        $id = (int)db()->lastInsertId();
        q('UPDATE certificates SET number=? WHERE id=?', ['M' . date('y') . '-' . str_pad((string)$id, 6, '0', STR_PAD_LEFT), $id]);
    }
    $c = row('SELECT * FROM certificates WHERE id=?', [$id]);
    $c['data'] = json_decode($c['data_json'], true);
    return $c;
}

function issue_certificates(array $test): int
{
    $n = 0;
    foreach (rows('SELECT student_id FROM results WHERE test_id=?', [$test['id']]) as $r) {
        if (issue_certificate($test, (int)$r['student_id'])) $n++;
    }
    return $n;
}
