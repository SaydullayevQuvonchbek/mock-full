<?php
defined('APP_ROOT') || exit;
/**
 * Xavfsizlik: HTTP sarlavhalar, sessiya sozlamalari, kirish urinishlarini cheklash.
 */

/**
 * Sayt teskari proksi (Cloudflare, nginx) orqasida bo'lsa config.php ga 'trusted_proxy' => true qo'shing —
 * shunda haqiqiy IP va HTTPS holati X-Forwarded-* sarlavhalaridan olinadi. Aks holda bu sarlavhalarga ishonilmaydi.
 */
function behind_trusted_proxy(): bool
{
    global $CONFIG;
    return !empty($CONFIG['trusted_proxy']);
}

function client_ip(): string
{
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    if (behind_trusted_proxy()) {
        $xf = (string)($_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '');
        $first = trim(explode(',', $xf)[0]);
        if ($first !== '' && filter_var($first, FILTER_VALIDATE_IP)) $ip = $first;
    }
    return substr($ip, 0, 45);
}

function is_https(): bool
{
    if ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') == 443)) return true;
    return behind_trusted_proxy() && strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
}

function security_headers(): void
{
    if (headers_sent()) return;
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: same-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=(self)');
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; "
        . "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; "
        . "img-src 'self' data: blob:; worker-src 'self' blob:; connect-src 'self'; "
        . "frame-src 'self'; object-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
    if (is_https()) header('Strict-Transport-Security: max-age=15552000');
}

function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_maxlifetime', '43200');   // muddatni quyidagi o'z tekshiruvimiz boshqaradi
    session_name('mocrasch');
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => is_https(),
    ]);
    session_start();
    // Admin sessiyasi 4 soat harakatsizlikdan keyin tugaydi, o'quvchi — 12 soat
    $now = time();
    if (!empty($_SESSION['admin']) && $now - ($_SESSION['admin_seen'] ?? $now) > 4 * 3600) unset($_SESSION['admin']);
    if (!empty($_SESSION['student']) && $now - ($_SESSION['student_seen'] ?? $now) > 12 * 3600) unset($_SESSION['student']);
    if (!empty($_SESSION['admin'])) $_SESSION['admin_seen'] = $now;
    if (!empty($_SESSION['student'])) $_SESSION['student_seen'] = $now;
}

/**
 * Brute-force himoyasi (15 daqiqa oynasida):
 *  - bitta login/ID + bitta IP juftligi uchun 5 ta xato urinish (oddiy holat);
 *  - bitta login/ID uchun barcha IP lardan jami 4×5 = 20 ta (tarqoq hujum) —
 *    shu bilan birga begona odam 5 ta xato urinish bilan sizni o'z hisobingizdan chetlata olmaydi;
 *  - bitta IP uchun 30 ta.
 * Qaytaradi: qolgan kutish vaqti (daqiqa) yoki 0.
 */
function throttle_wait(string $kind, string $ident, int $perIdent = 5, int $perIp = 30, int $minutes = 15): int
{
    $since = date('Y-m-d H:i:s', time() - $minutes * 60);
    $ip = client_ip();
    $pair = (int)val('SELECT COUNT(*) FROM login_attempts WHERE kind=? AND ident=? AND ip=? AND created_at>?', [$kind, $ident, $ip, $since]);
    $a = (int)val('SELECT COUNT(*) FROM login_attempts WHERE kind=? AND ident=? AND created_at>?', [$kind, $ident, $since]);
    $b = (int)val('SELECT COUNT(*) FROM login_attempts WHERE kind=? AND ip=? AND created_at>?', [$kind, $ip, $since]);
    if ($pair < $perIdent && $a < $perIdent * 4 && $b < $perIp) return 0;
    $last = val('SELECT MAX(created_at) FROM login_attempts WHERE kind=? AND (ident=? OR ip=?)', [$kind, $ident, $ip]);
    return max(1, (int)ceil(($minutes * 60 - (time() - strtotime((string)$last))) / 60));
}

function throttle_fail(string $kind, string $ident): void
{
    q('INSERT INTO login_attempts (kind, ident, ip) VALUES (?,?,?)', [$kind, substr($ident, 0, 64), client_ip()]);
    if (random_int(1, 50) === 1) q('DELETE FROM login_attempts WHERE created_at < ?', [date('Y-m-d H:i:s', time() - 86400)]);
}

function throttle_clear(string $kind, string $ident): void
{
    q('DELETE FROM login_attempts WHERE kind=? AND ident=?', [$kind, $ident]);
}

/** Excel'da formula sifatida ishlab ketmasligi uchun (CSV injection) */
function csv_safe($v): string
{
    $v = (string)$v;
    if ($v === '' || strpbrk($v[0], "=+-@\t\r") === false) return $v;
    return preg_match('/^[+-]?\d+([.,]\d+)?%?$/', $v) ? $v : "'" . $v;
}
