<?php
/**
 * Bazani joriy versiyaga moslash. Idempotent: har bir o'zgarish mavjudligi tekshiriladi.
 * install.php (yangi o'rnatish) va bootstrap.php (yangilanish) ikkalasi ham chaqiradi.
 */
defined('APP_ROOT') || exit;

const DB_SCHEMA_VERSION = 11;

function migrate(PDO $pdo): void
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS meta (k VARCHAR(40) PRIMARY KEY, v VARCHAR(255) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $ver = (int)($pdo->query("SELECT v FROM meta WHERE k='schema'")->fetchColumn() ?: 1);
    if ($ver >= DB_SCHEMA_VERSION) return;

    $has = fn(string $t, string $c) => (bool)$pdo->query("SHOW COLUMNS FROM `$t` LIKE " . $pdo->quote($c))->fetch();
    $add = function (string $t, string $c, string $def) use ($pdo, $has) {
        if (!$has($t, $c)) $pdo->exec("ALTER TABLE `$t` ADD `$c` $def");
    };

    // 1.1–1.2
    $add('tests', 'cap75', "TINYINT NOT NULL DEFAULT 0 AFTER method");
    $add('results', 'ball_raw', "DOUBLE NULL AFTER ball");
    if ($ver < 3) {
        $pdo->exec("ALTER TABLE tests ALTER cap75 SET DEFAULT 0");
        $pdo->exec("UPDATE tests SET cap75=0, dirty=1");
    }

    // 1.3: ro'yxatdan o'tish, guruhlar, markazlar, M/S, bo'limlar, sertifikatlar, xavfsizlik
    $add('tests', 'reg_open', "TINYINT NOT NULL DEFAULT 0");
    $add('tests', 't_mean', "DOUBLE NOT NULL DEFAULT 50");
    $add('tests', 't_sd', "DOUBLE NOT NULL DEFAULT 10");
    $add('tests', 'sections_json', "TEXT NULL");
    $add('results', 'ball_official', "DOUBLE NULL");
    $add('results', 'grade_official', "VARCHAR(4) NULL");
    $add('responses', 'overrides', "TEXT NULL");
    $add('students', 'last_name', "VARCHAR(80) NOT NULL DEFAULT ''");
    $add('students', 'first_name', "VARCHAR(80) NOT NULL DEFAULT ''");
    $add('students', 'middle_name', "VARCHAR(80) NOT NULL DEFAULT ''");
    $add('students', 'school', "VARCHAR(160) NOT NULL DEFAULT ''");
    $add('students', 'grade_level', "VARCHAR(20) NOT NULL DEFAULT ''");
    $add('students', 'center_id', "INT NULL");
    $add('students', 'source', "VARCHAR(16) NOT NULL DEFAULT 'admin'");
    $add('students', 'created_ip', "VARCHAR(45) NOT NULL DEFAULT ''");
    $add('users', 'role', "VARCHAR(16) NOT NULL DEFAULT 'admin'");
    $add('users', 'last_login', "DATETIME NULL");

    $pdo->exec("CREATE TABLE IF NOT EXISTS study_groups (
        id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(80) NOT NULL UNIQUE, note VARCHAR(255) NOT NULL DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS centers (
        id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(160) NOT NULL UNIQUE, contact VARCHAR(120) NOT NULL DEFAULT '',
        phone VARCHAR(32) NOT NULL DEFAULT '', note VARCHAR(255) NOT NULL DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS test_registrations (
        test_id INT NOT NULL, student_id INT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (test_id, student_id),
        CONSTRAINT fk_reg_test FOREIGN KEY (test_id) REFERENCES tests(id) ON DELETE CASCADE,
        CONSTRAINT fk_reg_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS certificates (
        id INT AUTO_INCREMENT PRIMARY KEY, number VARCHAR(24) NOT NULL UNIQUE, token CHAR(16) NOT NULL,
        test_id INT NOT NULL, student_id INT NOT NULL, kind VARCHAR(8) NOT NULL DEFAULT 'cert',
        data_json TEXT NOT NULL, issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_cert (test_id, student_id),
        CONSTRAINT fk_cert_test FOREIGN KEY (test_id) REFERENCES tests(id) ON DELETE CASCADE,
        CONSTRAINT fk_cert_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts (
        id INT AUTO_INCREMENT PRIMARY KEY, kind VARCHAR(16) NOT NULL, ident VARCHAR(64) NOT NULL, ip VARCHAR(45) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP, KEY idx_ident (kind, ident, created_at), KEY idx_ip (kind, ip, created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // 1.4: MOCK xonalari, o'rin va chop etish nazorati
    $pdo->exec("CREATE TABLE IF NOT EXISTS test_rooms (
        id INT AUTO_INCREMENT PRIMARY KEY, test_id INT NOT NULL, name VARCHAR(60) NOT NULL, capacity INT NOT NULL DEFAULT 30,
        sort INT NOT NULL DEFAULT 0, KEY idx_room_test (test_id),
        CONSTRAINT fk_room_test FOREIGN KEY (test_id) REFERENCES tests(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $add('test_registrations', 'room_id', "INT NULL");
    $add('test_registrations', 'seat', "INT NULL");
    $add('test_registrations', 'printed_at', "DATETIME NULL");

    $idx = fn(string $t, string $k) => (bool)$pdo->query("SHOW INDEX FROM `$t` WHERE Key_name=" . $pdo->quote($k))->fetch();
    if (!$idx('students', 'idx_phone')) $pdo->exec("ALTER TABLE students ADD INDEX idx_phone (phone)");
    if (!$idx('students', 'idx_center')) $pdo->exec("ALTER TABLE students ADD INDEX idx_center (center_id)");


    // 1.6: Telegram bot orqali onlayn MOCK
    $add('students', 'tg_chat_id', "BIGINT NULL");
    $add('students', 'tg_username', "VARCHAR(64) NOT NULL DEFAULT ''");
    $add('students', 'tg_linked_at', "DATETIME NULL");
    if (!$idx('students', 'uq_tg_chat')) $pdo->exec("ALTER TABLE students ADD UNIQUE KEY uq_tg_chat (tg_chat_id)");
    $add('tests', 'tg_enabled', "TINYINT NOT NULL DEFAULT 0");
    $add('tests', 'tg_audience', "VARCHAR(8) NOT NULL DEFAULT 'reg'");
    $add('tests', 'tg_group', "VARCHAR(80) NOT NULL DEFAULT ''");
    $add('tests', 'tg_file_id', "VARCHAR(255) NOT NULL DEFAULT ''");
    $add('tests', 'tg_file_for', "VARCHAR(80) NOT NULL DEFAULT ''");
    $add('tests', 'tg_result_at', "DATETIME NULL");
    $pdo->exec("CREATE TABLE IF NOT EXISTS tg_queue (
        id INT AUTO_INCREMENT PRIMARY KEY, kind VARCHAR(16) NOT NULL, test_id INT NOT NULL DEFAULT 0, student_id INT NOT NULL DEFAULT 0,
        chat_id BIGINT NOT NULL, payload TEXT NULL, send_at DATETIME NOT NULL, sent_at DATETIME NULL,
        error VARCHAR(255) NOT NULL DEFAULT '', attempts TINYINT NOT NULL DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_job (kind, test_id, student_id), KEY idx_due (sent_at, send_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS tg_tokens (
        token_hash CHAR(64) PRIMARY KEY, student_id INT NOT NULL, test_id INT NOT NULL DEFAULT 0, go VARCHAR(8) NOT NULL DEFAULT 'test',
        expires_at DATETIME NOT NULL, used_at DATETIME NULL, KEY idx_exp (expires_at),
        CONSTRAINT fk_tgtok_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS tg_state (
        chat_id BIGINT PRIMARY KEY, step VARCHAR(16) NOT NULL DEFAULT '', data VARCHAR(40) NOT NULL DEFAULT '',
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $add('tg_state', 'msg_id', "INT NOT NULL DEFAULT 0");
    $pdo->exec("CREATE TABLE IF NOT EXISTS tg_log (
        id INT AUTO_INCREMENT PRIMARY KEY, dir VARCHAR(4) NOT NULL, chat_id BIGINT NULL, kind VARCHAR(16) NOT NULL DEFAULT '',
        ok TINYINT NOT NULL DEFAULT 1, info VARCHAR(255) NOT NULL DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        KEY idx_log_time (created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // 2.0 (I): parol (PIN o'rniga), bir martalik kodlar, SMS/Telegram umumiy navbati
    $add('students', 'pass_hash', "VARCHAR(255) NULL");
    $add('students', 'must_change', "TINYINT NOT NULL DEFAULT 1");
    $add('students', 'phone_verified_at', "DATETIME NULL");
    $add('students', 'last_login', "DATETIME NULL");
    $add('students', 'pass_changed_at', "DATETIME NULL");
    // `pin` ustuni endi VAQTINCHALIK PAROL (admin bergan); o'quvchi o'z parolini belgilagach bo'shatiladi
    $pdo->exec("ALTER TABLE students MODIFY pin VARCHAR(12) NOT NULL DEFAULT ''");
    $pdo->exec("CREATE TABLE IF NOT EXISTS otp_codes (
        id INT AUTO_INCREMENT PRIMARY KEY, kind VARCHAR(10) NOT NULL, target VARCHAR(32) NOT NULL, code_hash CHAR(64) NOT NULL,
        channel VARCHAR(8) NOT NULL DEFAULT '', student_id INT NULL, expires_at DATETIME NOT NULL, attempts TINYINT NOT NULL DEFAULT 0,
        used_at DATETIME NULL, ip VARCHAR(45) NOT NULL DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        KEY idx_otp_target (kind, target, created_at), KEY idx_otp_ip (ip, created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $add('tg_queue', 'channel', "VARCHAR(4) NOT NULL DEFAULT 'tg'");
    $add('tg_queue', 'phone', "VARCHAR(16) NOT NULL DEFAULT ''");
    // 2.0 (II–IV): ota-ona ma'lumotlari, Telegram ulash tokenlari, xona nazoratchisi
    $add('students', 'parent_name', "VARCHAR(120) NOT NULL DEFAULT ''");
    $add('students', 'parent_phone', "VARCHAR(16) NOT NULL DEFAULT ''");
    $add('students', 'parent_phone2', "VARCHAR(16) NOT NULL DEFAULT ''");
    $add('students', 'parent_tg_chat', "BIGINT NULL");
    $add('students', 'parent_tg_at', "DATETIME NULL");
    $add('students', 'parent_optout', "TINYINT NOT NULL DEFAULT 0");
    $pdo->exec("CREATE TABLE IF NOT EXISTS tg_links (
        token_hash CHAR(64) PRIMARY KEY, student_id INT NOT NULL, who VARCHAR(3) NOT NULL DEFAULT 'stu',
        expires_at DATETIME NOT NULL, used_at DATETIME NULL, KEY idx_lnk_exp (expires_at),
        CONSTRAINT fk_tglnk_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $add('test_rooms', 'proctor', "VARCHAR(120) NOT NULL DEFAULT ''");
    $add('test_registrations', 'notified_at', "DATETIME NULL");

    // 2.0 (V): savollar bazasi (PDF dan qirqilgan savol rasmlari) va o'quvchi mashq testlari
    $pdo->exec("CREATE TABLE IF NOT EXISTS qb_sections (
        id INT AUTO_INCREMENT PRIMARY KEY, parent_id INT NULL, name VARCHAR(120) NOT NULL, sort INT NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP, KEY idx_qbs_parent (parent_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS qb_questions (
        id INT AUTO_INCREMENT PRIMARY KEY, section_id INT NOT NULL, label VARCHAR(40) NOT NULL DEFAULT '', img VARCHAR(80) NOT NULL,
        w INT NOT NULL DEFAULT 0, h INT NOT NULL DEFAULT 0, kind VARCHAR(5) NOT NULL DEFAULT 'mc', nopt TINYINT NOT NULL DEFAULT 4,
        answer VARCHAR(80) NOT NULL DEFAULT '', src VARCHAR(160) NOT NULL DEFAULT '', sort INT NOT NULL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP, KEY idx_qbq_sec (section_id, sort),
        CONSTRAINT fk_qbq_sec FOREIGN KEY (section_id) REFERENCES qb_sections(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS qb_tests (
        id INT AUTO_INCREMENT PRIMARY KEY, student_id INT NOT NULL, title VARCHAR(160) NOT NULL DEFAULT '', n INT NOT NULL DEFAULT 0,
        correct INT NULL, status VARCHAR(10) NOT NULL DEFAULT 'open', via VARCHAR(4) NOT NULL DEFAULT 'web',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP, finished_at DATETIME NULL, KEY idx_qbt_stu (student_id, created_at),
        CONSTRAINT fk_qbt_stu FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS qb_items (
        test_id INT NOT NULL, pos INT NOT NULL, question_id INT NOT NULL, section_id INT NOT NULL DEFAULT 0, section_name VARCHAR(120) NOT NULL DEFAULT '',
        given VARCHAR(80) NOT NULL DEFAULT '', ok TINYINT NULL, PRIMARY KEY (test_id, pos), KEY idx_qbi_q (question_id),
        CONSTRAINT fk_qbi_test FOREIGN KEY (test_id) REFERENCES qb_tests(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // 2.1: topshiriqlar (admin savollar bazasidan test tuzib, o'quvchilarga muddat bilan yuboradi)
    $pdo->exec("CREATE TABLE IF NOT EXISTS qb_assign (
        id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(160) NOT NULL DEFAULT '', sections VARCHAR(255) NOT NULL DEFAULT '', n INT NOT NULL DEFAULT 0,
        deadline DATETIME NOT NULL, review TINYINT NOT NULL DEFAULT 1, aud VARCHAR(1000) NOT NULL DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        closed_at DATETIME NULL, KEY idx_qba_due (closed_at, deadline)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS qb_assign_items (
        assign_id INT NOT NULL, pos INT NOT NULL, question_id INT NOT NULL, section_id INT NOT NULL DEFAULT 0, section_name VARCHAR(120) NOT NULL DEFAULT '',
        PRIMARY KEY (assign_id, pos), CONSTRAINT fk_qbai_a FOREIGN KEY (assign_id) REFERENCES qb_assign(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $add('qb_tests', 'assign_id', "INT NULL");
    if (!$pdo->query("SHOW INDEX FROM qb_tests WHERE Key_name='idx_qbt_asg'")->fetch()) $pdo->exec("ALTER TABLE qb_tests ADD KEY idx_qbt_asg (assign_id)");

    // 2.2: o'quvchilarni arxivlash; topshiriqni umuman boshlamaganlar «topshirmadi» (missed)
    $add('students', 'archived_at', "DATETIME NULL");
    $pdo->exec("CREATE TABLE IF NOT EXISTS center_rooms (
        id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(60) NOT NULL, capacity INT NOT NULL DEFAULT 30, proctor VARCHAR(120) NOT NULL DEFAULT '',
        sort INT NOT NULL DEFAULT 0) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if ($ver < 11) {
        $pdo->exec("UPDATE qb_tests t JOIN qb_assign a ON a.id=t.assign_id SET t.status='missed'
                    WHERE t.status='done' AND a.closed_at IS NOT NULL AND NOT EXISTS (SELECT 1 FROM qb_items i WHERE i.test_id=t.id AND i.given NOT IN ('','-'))");
    }

    if ($ver < 4) {
        // Mavjud F.I.Sh ni familiya / ism / otasining ismiga ajratish
        $st = $pdo->query("SELECT id, full_name FROM students WHERE last_name='' AND first_name=''");
        $up = $pdo->prepare("UPDATE students SET last_name=?, first_name=?, middle_name=? WHERE id=?");
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $s) {
            $p = preg_split('/\s+/u', trim((string)$s['full_name']), 3);
            $up->execute([$p[0] ?? '', $p[1] ?? '', $p[2] ?? '', $s['id']]);
        }
        $pdo->exec("INSERT IGNORE INTO study_groups (name) SELECT DISTINCT group_name FROM students WHERE group_name<>''");
        $pdo->exec("UPDATE tests SET dirty=1");
    }
    $pdo->prepare("REPLACE INTO meta (k, v) VALUES ('schema', ?)")->execute([(string)DB_SCHEMA_VERSION]);
}
