<?php
defined('APP_ROOT') || exit;
/**
 * O'quvchi autentifikatsiyasi: parol (PIN o'rniga), vaqtinchalik parol, kirish identifikatori (ID yoki telefon).
 *
 * Eslatma: `students.pin` ustuni endi VAQTINCHALIK PAROL saqlaydi (admin bergan; kartochkada chiqadi).
 * O'quvchi o'z parolini belgilagach ustun bo'shatiladi va `pass_hash` ishlatiladi.
 * Eski PIN lar migratsiyada o'zgarmaydi — birinchi muvaffaqiyatli kirishda xeshlanadi va parolni almashtirish talab qilinadi.
 */

/** Vaqtinchalik parol: 6 belgi, adashtiriladigan belgilarsiz (0/o, 1/l/i yo'q) */
function gen_temp_pass(): string
{
    $al = 'abcdefghjkmnpqrstuvwxyz23456789';
    $out = '';
    for ($i = 0; $i < 6; $i++) $out .= $al[random_int(0, strlen($al) - 1)];
    return $out;
}

/** Yangi parol talablari. Xato matnini yoki null qaytaradi */
function pass_problem(string $p, string $code = ''): ?string
{
    if (mb_strlen($p) < 6) return 'Parol kamida 6 belgidan iborat bo\'lsin.';
    if (mb_strlen($p) > 64) return 'Parol 64 belgidan oshmasin.';
    if (preg_match('/^(.)\1*$/us', $p)) return 'Parol bir xil belgilardan iborat bo\'lmasin.';
    if ($code !== '' && $p === $code) return 'Parol ID raqamingiz bilan bir xil bo\'lmasin.';
    if (preg_match('/^\d{6,}$/', $p) && (strpos('01234567890123456789', $p) !== false || strpos('98765432109876543210', $p) !== false)) return 'Juda oson parol (ketma-ket raqamlar).';
    return null;
}

/** Kirish identifikatori bo'yicha o'quvchi: 6 xonali ID yoki telefon (telefon bitta o'quvchiga tegishli bo'lsa) */
function student_find_by_ident(string $ident): ?array
{
    $ident = trim($ident);
    $d = preg_replace('/\D/', '', $ident);
    if (strlen($d) === 6) return row('SELECT * FROM students WHERE code=?', [$d]);
    $ph = norm_phone($ident);
    if ($ph !== '') {
        $r = rows('SELECT * FROM students WHERE phone=? AND archived_at IS NULL LIMIT 2', [$ph]);
        return count($r) === 1 ? $r[0] : null;
    }
    return null;
}

/** Throttle kaliti: topilgan o'quvchining ID si, topilmasa kiritilgan matn */
function student_ident_key(string $ident, ?array $s): string
{
    return $s ? (string)$s['code'] : substr(preg_replace('/\s+/', '', mb_strtolower($ident)), 0, 40);
}

/** Parolni tekshiradi. Eski (xeshlanmagan) PIN bo'lsa birinchi muvaffaqiyatda xeshlaydi */
function student_pass_check(array $s, string $pass): bool
{
    if ($pass === '') return false;
    if (!empty($s['pass_hash'])) {
        $ok = password_verify($pass, (string)$s['pass_hash']);
        if ($ok && password_needs_rehash((string)$s['pass_hash'], PASSWORD_DEFAULT)) {
            q('UPDATE students SET pass_hash=? WHERE id=?', [password_hash($pass, PASSWORD_DEFAULT), $s['id']]);
        }
        return $ok;
    }
    $tmp = (string)($s['pin'] ?? '');
    if ($tmp === '' || !hash_equals($tmp, $pass)) return false;
    q('UPDATE students SET pass_hash=? WHERE id=?', [password_hash($pass, PASSWORD_DEFAULT), $s['id']]);
    return true;
}

/**
 * Parolni o'rnatadi.
 * $temp = true  — admin bergan vaqtinchalik parol (ochiq saqlanadi, kartochkada chiqadi, kirgach almashtirish majburiy);
 * $temp = false — o'quvchining o'z parol (ochiq nusxa o'chiriladi).
 */
function student_set_pass(int $sid, string $pass, bool $temp = false): void
{
    q('UPDATE students SET pass_hash=?, pin=?, must_change=?, pass_changed_at=NOW() WHERE id=?',
        [password_hash($pass, PASSWORD_DEFAULT), $temp ? $pass : '', $temp ? 1 : 0, $sid]);
}

/** O'quvchi sessiyasini ochadi. $mc = parolni almashtirish majburiy */
function student_session_start(array $s, bool $mc = false): void
{
    session_regenerate_id(true);
    $ver = (string)val('SELECT pass_changed_at FROM students WHERE id=?', [$s['id']]);
    $_SESSION['student'] = ['id' => (int)$s['id'], 'code' => $s['code'], 'name' => $s['full_name'], 'mc' => $mc ? 1 : 0, 'ver' => $ver];
    $_SESSION['student_seen'] = time();
    q('UPDATE students SET last_login=NOW() WHERE id=?', [$s['id']]);
}

/**
 * Har so'rovda (require_student): parol boshqa joyda o'zgartirilgan bo'lsa sessiya yopiladi;
 * parolni almashtirish majburiy bo'lsa — almashtirish sahifasiga yo'naltiriladi.
 */
function student_session_guard(): void
{
    $me = student();
    if (!$me) return;
    $row = row('SELECT pass_changed_at, archived_at FROM students WHERE id=?', [$me['id']]);
    if (!$row) { unset($_SESSION['student']); redirect('student_login'); }
    if ($row['archived_at'] !== null) { unset($_SESSION['student']); flash('Hisobingiz arxivlangan. O\'quv markaziga murojaat qiling.', 'warn'); redirect('student_login'); }
    $cur = $row['pass_changed_at'];
    if ((string)$cur !== (string)($me['ver'] ?? '')) {
        unset($_SESSION['student']);
        flash('Parol o\'zgartirilgan. Qayta kiring.', 'warn');
        redirect('student_login');
    }
    $p = $_GET['p'] ?? '';
    if (!empty($me['mc']) && !in_array($p, ['student_setpass', 'student_logout'], true)) redirect('student_setpass');
}
