<?php
defined('APP_ROOT') || exit;
/**
 * Telegram bot: administrator interfeysi (Sozlamalar kartasi va test sozlamalari bo'limi).
 */

/** Sozlamalar sahifasidagi Telegram amallari. Bajarilgan bo'lsa true */
function tg_settings_post(string $act): bool
{
    if (strncmp($act, 'tg_', 3) !== 0) return false;

    if ($act === 'tg_token') {
        $tok = trim((string)($_POST['token'] ?? ''));
        if ($tok === '') { flash('Bot tokenini kiriting (@BotFather bergan)', 'err'); return true; }
        if (!preg_match('/^\d{5,}:[A-Za-z0-9_-]{30,}$/', $tok)) { flash('Token ko‘rinishi noto‘g‘ri. U «123456789:AAE…» shaklida bo‘ladi', 'err'); return true; }
        $r = tg_call('getMe', [], $tok, 12);
        if (!$r['ok']) { flash('Telegram tokenni qabul qilmadi: ' . $r['desc'], 'err'); return true; }
        tg_meta_set('token', $tok);
        tg_meta_set('bot', (string)($r['result']['username'] ?? ''));
        flash('Bot ulandi: @' . ($r['result']['username'] ?? '?') . '. Endi «Webhook o‘rnatish» tugmasini bosing.');
        return true;
    }
    if ($act === 'tg_remove') {
        if (tg_ready()) tg_call('deleteWebhook', []);
        q('DELETE FROM meta WHERE k IN ("set_tg_token","set_tg_bot")');
        flash('Bot uzildi. O‘quvchilarning Telegram bog‘lanishlari saqlanib qoldi.');
        return true;
    }
    if ($act === 'tg_webhook') {
        $r = tg_set_webhook();
        flash($r['ok'] ? 'Webhook o‘rnatildi. Botga /start yozib sinab ko‘ring.' : 'Webhook o‘rnatilmadi: ' . $r['desc'], $r['ok'] ? 'ok' : 'err');
        return true;
    }
    if ($act === 'tg_unhook') {
        $r = tg_call('deleteWebhook', []);
        flash($r['ok'] ? 'Webhook o‘chirildi — bot xabarlarni qabul qilmaydi.' : 'Xato: ' . $r['desc'], $r['ok'] ? 'ok' : 'err');
        return true;
    }
    if ($act === 'tg_admin') {
        $c = trim((string)($_POST['admin_chat'] ?? ''));
        if ($c !== '' && !preg_match('/^-?\d{4,15}$/', $c)) { flash('Chat ID faqat raqam bo‘lsin', 'err'); return true; }
        tg_meta_set('admin_chat', $c);
        if ($c !== '' && isset($_POST['test_msg'])) {
            $r = tg_send((int)$c, '✅ MOCK Rasch: sinov xabari. Xatolar haqida shu yerga yoziladi.');
            flash($r['ok'] ? 'Sinov xabari yuborildi' : 'Yuborilmadi: ' . $r['desc'] . ' (avval botga /start yozing)', $r['ok'] ? 'ok' : 'err');
        } else flash('Saqlandi');
        return true;
    }
    if ($act === 'tg_cron_key') {
        set_app_setting('cron_key', bin2hex(random_bytes(24)));
        flash('Yangi cron kaliti yaratildi. Hostingdagi cron buyrug‘ini yangilang.');
        return true;
    }
    if ($act === 'tg_run') {
        $r = tg_tick(20);
        if (!empty($r['off'])) flash('Avval bot tokenini kiriting', 'err');
        elseif (!empty($r['busy'])) flash('Navbat hozir boshqa jarayon tomonidan ishlanmoqda — bir oz kutib qayta urining', 'warn');
        else flash('Navbat ishlandi: yuborildi ' . ($r['sent'] ?? 0) . ', xato ' . ($r['failed'] ?? 0) . ', o‘tkazildi ' . ($r['skipped'] ?? 0) . ' · yangi: PDF ' . ($r['queued_start'] ?? 0) . ', yopilgan ' . ($r['closed'] ?? 0) . ', natija ' . ($r['queued_result'] ?? 0));
        return true;
    }
    if ($act === 'tg_retry') {
        $n = q('UPDATE tg_queue SET attempts=0, send_at=NOW(), error="" WHERE sent_at IS NULL AND attempts>=3')->rowCount();
        flash($n . ' ta xabar qayta navbatga qo‘yildi');
        return true;
    }
    if ($act === 'tg_unlink') {
        q('UPDATE students SET tg_chat_id=NULL, tg_username="", tg_linked_at=NULL WHERE id=?', [(int)($_POST['sid'] ?? 0)]);
        flash('O‘quvchining Telegram ulanishi uzildi');
        return true;
    }
    return false;
}

/** Sozlamalar → Telegram kartasi */
function tg_settings_card(): void
{
    $ready = tg_ready();
    $tok = tg_token();
    $site = tg_site_url();
    $st = tg_stats();
    $bot = tg_meta('bot');
    $cron = app_setting('cron_key');
    $lastCron = (int)tg_meta('last_cron', '0');
    $hook = $ready ? tg_call('getWebhookInfo', [], null, 8) : null;
    $hi = ($hook && $hook['ok']) ? $hook['result'] : null;
    $want = $site !== '' ? $site . '/bot.php' : '';
    $hookOk = $hi && ($hi['url'] ?? '') !== '' && ($hi['url'] ?? '') === $want;
    $failed = rows('SELECT q.id, q.kind, q.error, q.created_at, s.full_name, s.code FROM tg_queue q LEFT JOIN students s ON s.id=q.student_id WHERE q.sent_at IS NULL AND q.attempts>=3 ORDER BY q.id DESC LIMIT 10');
    $cmd = $site !== '' && $cron !== '' ? '* * * * * wget -q -O /dev/null "' . $site . '/cron.php?key=' . $cron . '"' : '';
    ?>
  <div class="card" id="telegram" style="grid-column:1/-1">
    <h2>Telegram bot</h2>
    <p class="small muted">Onlayn MOCK ni Telegram orqali o‘tkazish: bot savollar kitobini yuboradi, o‘quvchi javoblarini kiritadi, natija botga qaytadi. Faqat Telegramning bepul Bot API si ishlatiladi.</p>
    <?php if (!function_exists('curl_init')): ?><div class="alert err"><?= icon('alert') ?><span>Serverda PHP <b>curl</b> kengaytmasi yoqilmagan — bot ishlamaydi. Hosting panelida PHP sozlamalaridan curl ni yoqing.</span></div><?php endif; ?>
    <ol class="small" style="margin:.2rem 0 .8rem 1.1rem;line-height:1.7">
      <li class="<?= $site !== '' ? '' : 'warn' ?>">Sayt manzili (yuqoridagi «Markaz» kartasida) <b>https://</b> bilan kiritilgan: <?= $site !== '' ? '<b>' . e($site) . '</b>' : '<b>kiritilmagan</b>' ?></li>
      <li>@BotFather da bot yarating va tokenni quyiga kiriting <?= $ready ? '— ✅ ulangan' . ($bot !== '' ? ': <b>@' . e($bot) . '</b> (token …' . e(substr($tok, -4)) . ')' : '') : '' ?></li>
      <li>«Webhook o‘rnatish» tugmasini bosing <?= $hookOk ? '— ✅ ishlayapti' : '' ?></li>
      <li>Hostingda cron qo‘shing (quyida) <?= $cron !== '' && $lastCron && time() - $lastCron < 300 ? '— ✅ so‘nggi chaqiruv ' . e(date('H:i:s', $lastCron)) : '' ?></li>
    </ol>

    <div class="grid2">
      <div>
        <h3>1. Bot tokeni</h3>
        <form method="post" class="form" autocomplete="off">
          <?= csrf_field() ?><input type="hidden" name="action" value="tg_token">
          <label>Token (@BotFather) <input type="password" name="token" placeholder="<?= $ready ? '•••• …' . e(substr($tok, -4)) . ' (almashtirish uchun yangisini kiriting)' : '123456789:AAE…' ?>" autocomplete="off" spellcheck="false"></label>
          <div class="row gap"><button class="btn primary"><?= $ready ? 'Tokenni almashtirish' : 'Ulash va tekshirish' ?></button></div>
        </form>
        <?php if ($ready): ?>
        <div class="row gap mt">
          <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="tg_webhook"><button class="btn"><?= $hookOk ? 'Webhookni qayta o‘rnatish' : 'Webhook o‘rnatish' ?></button></form>
          <form method="post" onsubmit="return confirm('Botni uzasizmi? O‘quvchilar xabar ololmaydi.')"><?= csrf_field() ?><input type="hidden" name="action" value="tg_remove"><button class="btn danger-ghost">Botni uzish</button></form>
        </div>
        <?php if ($hi): ?>
          <p class="small mt <?= $hookOk ? '' : 'warn' ?>">Webhook: <?= ($hi['url'] ?? '') !== '' ? '<span class="mono">' . e($hi['url']) . '</span>' : '<b>o‘rnatilmagan</b>' ?><?= !$hookOk && ($hi['url'] ?? '') !== '' ? ' — sayt manzilidan farq qiladi' : '' ?>
            · kutayotgan: <?= (int)($hi['pending_update_count'] ?? 0) ?><?= !empty($hi['last_error_message']) ? '<br><span class="warn">So‘nggi xato: ' . e($hi['last_error_message']) . '</span>' : '' ?></p>
        <?php elseif ($hook): ?><p class="small warn mt">Telegram bilan aloqa yo‘q: <?= e($hook['desc']) ?></p><?php endif; ?>
        <?php endif; ?>
      </div>
      <div>
        <h3>2. Xatolar uchun admin chat</h3>
        <form method="post" class="form">
          <?= csrf_field() ?><input type="hidden" name="action" value="tg_admin">
          <label>Admin chat ID (ixtiyoriy) <input name="admin_chat" value="<?= e(tg_meta('admin_chat')) ?>" inputmode="numeric" placeholder="masalan 123456789"></label>
          <p class="small muted" style="margin-top:-.4rem">Yuborilmagan xabarlar haqida shu chatga ogohlantirish keladi. O‘z ID ingizni @userinfobot dan bilib oling, so‘ng botga /start yozing.</p>
          <div class="row gap"><button class="btn">Saqlash</button><button class="btn ghost" name="test_msg" value="1">Saqlash va sinov xabari</button></div>
        </form>
      </div>
    </div>

    <h3 class="mt">3. Cron (har daqiqa)</h3>
    <p class="small muted">Cron PDF ni aniq vaqtida yuboradi, vaqti o‘tgan testlarni yopadi va natijalarni jo‘natadi. Cron bo‘lmasa ham bot ishlaydi, lekin yuborish faqat kimdir botga yozganda yoki «Navbatni hozir ishga tushirish» bosilganda yuradi.</p>
    <?php if ($cron === ''): ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="tg_cron_key"><button class="btn">Cron kalitini yaratish</button></form>
    <?php else: ?>
      <?php if ($cmd !== ''): ?><label class="small" style="display:block">Hosting paneli → Cron → yangi vazifa, har daqiqada:<input class="mono" style="width:100%" readonly onclick="this.select()" value="<?= e($cmd) ?>"></label>
      <?php else: ?><p class="small warn">Cron buyrug‘i uchun avval sayt manzilini kiriting.</p><?php endif; ?>
      <p class="small muted">Yoki PHP orqali: <code>php <?= e(APP_ROOT) ?>/cron.php</code> · So‘nggi chaqiruv: <b class="<?= $lastCron && time() - $lastCron < 300 ? '' : 'warn-txt' ?>"><?= $lastCron ? e(date('d.m H:i:s', $lastCron)) : 'hali bo‘lmagan' ?></b></p>
      <?php if (preg_match('#^/home/([a-z0-9_-]+)/web/#', APP_ROOT, $hm)): ?><p class="small muted">HestiaCP: panel → «CRON» → «Add Cron Job», har daqiqa (<code>* * * * *</code>), buyruq: <code>php <?= e(APP_ROOT) ?>/cron.php &gt;/dev/null 2&gt;&amp;1</code> — yoki server konsolida: <code class="mono">v-add-cron-job <?= e($hm[1]) ?> '*' '*' '*' '*' '*' 'php <?= e(APP_ROOT) ?>/cron.php &gt;/dev/null 2&gt;&amp;1'</code></p><?php endif; ?>
      <form method="post" class="inline" onsubmit="return confirm('Eski kalit ishlamay qoladi. Davom etasizmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="tg_cron_key"><button class="btn sm ghost">Kalitni almashtirish</button></form>
    <?php endif; ?>

    <h3 class="mt">Holat</h3>
    <div class="row gap" style="flex-wrap:wrap">
      <span class="tag">Ulangan o‘quvchilar: <b><?= $st['linked'] ?></b></span>
      <span class="tag">Navbatda: <b><?= $st['pending'] ?></b></span>
      <span class="tag green">Yuborilgan: <b><?= $st['sent'] ?></b></span>
      <span class="tag <?= $st['failed'] ? 'red' : '' ?>">Yuborilmagan: <b><?= $st['failed'] ?></b></span>
      <?php if ($ready): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="tg_run"><button class="btn sm">Navbatni hozir ishga tushirish</button></form><?php endif; ?>
      <?php if ($st['failed']): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="tg_retry"><button class="btn sm ghost">Xatolarni qayta urinish</button></form><?php endif; ?>
    </div>
    <?php if ($failed): ?>
    <table class="tbl compact-tbl mt"><thead><tr><th>O‘quvchi</th><th>Tur</th><th>Xato</th><th>Vaqt</th></tr></thead><tbody>
      <?php foreach ($failed as $f): ?><tr><td><?= e($f['full_name'] ?: '—') ?> <span class="mono small muted"><?= e($f['code']) ?></span></td><td><?= e($f['kind']) ?></td><td class="small"><?= e($f['error']) ?></td><td class="small muted"><?= e(substr($f['created_at'], 5, 11)) ?></td></tr><?php endforeach; ?>
    </tbody></table>
    <p class="small muted">«Forbidden: bot was blocked by the user» — o‘quvchi botni bloklagan; unga botni qayta yoqish kerak.</p>
    <?php endif; ?>
  </div>
    <?php
}

/** Test sozlamalari → «Telegram orqali» bo'limi (test_edit ichidagi forma maydonlari) */
function tg_test_fields(array $t): void
{
    $groups = groups_list();
    $aud = (string)($t['tg_audience'] ?? 'reg');
    ?>
    <fieldset><legend>Telegram orqali o‘tkazish</legend>
      <?php if (!tg_ready()): ?><p class="small warn" style="margin:0">Bot hali ulanmagan. <a href="<?= e(url('settings')) ?>#telegram">Sozlamalar → Telegram</a></p><?php endif; ?>
      <label class="check"><input type="checkbox" name="tg_enabled" <?= !empty($t['tg_enabled']) ? 'checked' : '' ?>> Boshlanish vaqtida savollar kitobini bot orqali yuborish</label>
      <div>
        <label>Kimga yuboriladi
          <select name="tg_audience">
            <option value="reg" <?= $aud === 'reg' ? 'selected' : '' ?>>MOCK ga yozilganlarga</option>
            <option value="group" <?= $aud === 'group' ? 'selected' : '' ?>>Tanlangan guruhga</option>
            <option value="all" <?= $aud === 'all' ? 'selected' : '' ?>>Telegramga ulangan hammaga</option>
          </select></label>
        <label>Guruh (faqat «guruh» uchun)
          <select name="tg_group"><option value="">—</option><?php foreach ($groups as $g): ?><option <?= $t['tg_group'] === $g ? 'selected' : '' ?>><?= e($g) ?></option><?php endforeach; ?></select></label>
      </div>
      <p class="small muted" style="margin:.2rem 0 0">Yuqoridagi «Boshlanish» vaqti kelganda PDF yuboriladi (u bo‘lishi shart). «Tugash» bo‘sh qolsa, boshlanish + davomiylik qo‘yiladi: hamma uchun bir xil yakuniy vaqt. Vaqti o‘tganlar avtomatik yopiladi, natija e’lon qilinganda bot ball va darajani yuboradi.</p>
    </fieldset>
    <?php
}

/** test_edit «settings» amalidan oldin chaqiriladi: Telegram talablarini tekshirib, $_POST ni moslaydi */
function tg_test_prepare_post(): void
{
    if (!isset($_POST['tg_enabled'])) return;
    $start = (string)($_POST['online_start'] ?? '');
    if ($start === '') {
        unset($_POST['tg_enabled']);
        flash('Telegram uchun «Boshlanish» vaqti kerak — Telegram o‘tkazish yoqilmadi', 'err');
        return;
    }
    if (!isset($_POST['online'])) { $_POST['online'] = '1'; flash('Telegram uchun «onlayn test» ham yoqildi', 'warn'); }
    if (trim((string)($_POST['online_end'] ?? '')) === '') {
        $dur = max(10, (int)($_POST['duration_min'] ?? 180));
        $_POST['online_end'] = date('Y-m-d\TH:i', strtotime(str_replace('T', ' ', $start)) + $dur * 60);
        flash('«Tugash» vaqti avtomatik qo‘yildi: ' . str_replace('T', ' ', $_POST['online_end']) . ' (boshlanish + ' . $dur . ' daqiqa)', 'warn');
    }
}

function tg_test_save(int $testId): void
{
    $aud = in_array($_POST['tg_audience'] ?? '', ['reg', 'group', 'all'], true) ? $_POST['tg_audience'] : 'reg';
    $grp = trim((string)($_POST['tg_group'] ?? ''));
    if ($aud === 'group' && $grp === '') { $aud = 'reg'; flash('Guruh tanlanmagani uchun «MOCK ga yozilganlarga» qo‘yildi', 'warn'); }
    q('UPDATE tests SET tg_enabled=?, tg_audience=?, tg_group=? WHERE id=?', [isset($_POST['tg_enabled']) ? 1 : 0, $aud, $grp, $testId]);
}

/** Test sahifasidagi Telegram holati va qo'lda ishga tushirish */
function tg_test_panel(array $t): void
{
    if (empty($t['tg_enabled'])) return;
    $aud = (string)$t['tg_audience'];
    if ($aud === 'all') $tot = (int)val('SELECT COUNT(*) FROM students WHERE archived_at IS NULL');
    elseif ($aud === 'group') $tot = (int)val('SELECT COUNT(*) FROM students WHERE group_name=? AND archived_at IS NULL', [$t['tg_group']]);
    else $tot = (int)val('SELECT COUNT(*) FROM test_registrations WHERE test_id=?', [$t['id']]);
    $linked = count(tg_audience($t));
    $q = row('SELECT SUM(kind="start" AND sent_at IS NOT NULL AND error="") s, SUM(kind="start" AND sent_at IS NULL) p FROM tg_queue WHERE test_id=?', [$t['id']]);
    $unl = [];
    if ($tot > $linked) {
        if ($aud === 'all') $unl = rows('SELECT full_name, code FROM students WHERE tg_chat_id IS NULL AND archived_at IS NULL ORDER BY full_name LIMIT 60');
        elseif ($aud === 'group') $unl = rows('SELECT full_name, code FROM students WHERE tg_chat_id IS NULL AND archived_at IS NULL AND group_name=? ORDER BY full_name LIMIT 60', [$t['tg_group']]);
        else $unl = rows('SELECT s.full_name, s.code FROM students s JOIN test_registrations r ON r.student_id=s.id AND r.test_id=? WHERE s.tg_chat_id IS NULL ORDER BY s.full_name LIMIT 60', [$t['id']]);
    }
    ?>
<div class="card">
  <h2>Telegram holati</h2>
  <p class="small" style="margin:.2rem 0">Auditoriya: <b><?= $tot ?></b> · Telegramga ulangan: <b><?= $linked ?></b> · PDF yuborilgan: <b><?= (int)($q['s'] ?? 0) ?></b> · navbatda: <b><?= (int)($q['p'] ?? 0) ?></b></p>
  <?php if ($unl): ?>
    <details class="small"><summary>Ulanmaganlar (<?= $tot - $linked ?>) — ularga ID va parol bilan botga ulanish kerak</summary>
      <div class="muted"><?= e(implode(', ', array_map(fn($u) => ($u['full_name'] ?: '—') . ' (' . $u['code'] . ')', $unl))) ?><?= $tot - $linked > count($unl) ? ' …' : '' ?></div></details>
  <?php endif; ?>
  <div class="row gap mt wrap">
    <a class="btn sm" href="<?= e(url('tg_monitor', ['id' => $t['id']])) ?>">📡 Jonli nazorat</a>
    <form method="post" class="inline" onsubmit="return confirm('Ulangan auditoriyaga taklif xabari yuborilsinmi? (ro\'yxatda bo\'lmaganlar «Qatnashaman» tugmasi bilan yoziladi)')"><?= csrf_field() ?><input type="hidden" name="action" value="tg_invite"><button class="btn sm">📣 Taklif yuborish</button></form>
    <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="tg_now"><button class="btn sm ghost">Navbatni ishga tushirish</button></form>
  </div>
  <p class="small muted" style="margin:.3rem 0 0">Boshlanish vaqti kelganda PDF avtomatik (cron) yuboriladi; «Navbatni ishga tushirish» — kutmasdan darhol jo'natish uchun.</p>
</div>
    <?php
}
