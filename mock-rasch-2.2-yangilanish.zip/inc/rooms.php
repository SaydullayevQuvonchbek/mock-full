<?php
defined('APP_ROOT') || exit;
/**
 * MOCK ro'yxati: xonalar, o'rinlar va shaxsiy javoblar varaqalari uchun o'quvchilarni tanlash.
 */

/* ---------- 2.2: markazning doimiy xonalari (Sozlamalar → Xonalar) ---------- */

function center_rooms(): array
{
    try { return rows('SELECT * FROM center_rooms ORDER BY sort, id'); } catch (Throwable $e) { return []; }
}

/** Matnni xonalarga ajratadi: har qatorda «Nomi; sig'im; nazoratchi» (ajratuvchi ; , | yoki tab). Qaytaradi [xonalar, xatolar] */
function center_rooms_parse(string $text): array
{
    $out = []; $bad = [];
    foreach (preg_split('/\R/u', $text) as $i => $line) {
        $line = trim($line);
        if ($line === '') continue;
        $p = array_map('trim', preg_split('/\s*[;|\t]\s*|\s*,\s*(?=\d)/u', $line));
        $name = mb_substr($p[0] ?? '', 0, 60);
        $cap = isset($p[1]) && preg_match('/^\d{1,3}$/', $p[1]) ? (int)$p[1] : 0;
        if ($name === '' || $cap < 1 || $cap > 500) { $bad[] = ($i + 1) . '-qator: «' . mb_substr($line, 0, 40) . '»'; continue; }
        $out[] = ['name' => $name, 'capacity' => $cap, 'proctor' => mb_substr($p[2] ?? '', 0, 120)];
    }
    return [$out, $bad];
}

/** Markaz xonalarini MOCK ga qo'shadi (shu nomli xona bo'lsa — o'tkazib yuboriladi). Qo'shilganlar soni */
function center_rooms_apply(int $testId): int
{
    $have = array_flip(array_map('mb_strtolower', array_column(rows('SELECT name FROM test_rooms WHERE test_id=?', [$testId]), 'name')));
    $sort = (int)val('SELECT COALESCE(MAX(sort),0) FROM test_rooms WHERE test_id=?', [$testId]);
    $n = 0;
    foreach (center_rooms() as $r) {
        if (isset($have[mb_strtolower($r['name'])])) continue;
        q('INSERT INTO test_rooms (test_id, name, capacity, proctor, sort) VALUES (?,?,?,?,?)', [$testId, $r['name'], (int)$r['capacity'], $r['proctor'], ++$sort]);
        $n++;
    }
    return $n;
}

/** MOCK xonalari (band o'rinlar soni bilan) */
function test_rooms(int $testId): array
{
    return rows('SELECT r.*, (SELECT COUNT(*) FROM test_registrations x WHERE x.test_id=r.test_id AND x.room_id=r.id) used
                 FROM test_rooms r WHERE r.test_id=? ORDER BY r.sort, r.id', [$testId]);
}

/** O'quvchilarni tartiblash uchun SQL (xona → o'rin / alifbo / maktab-sinf / ro'yxatdan o'tgan vaqt) */
function reg_order_sql(string $order): string
{
    return [
        'room' => 'rm.id IS NULL, rm.sort, rm.id, g.seat, s.full_name',
        'school' => 's.school, s.grade_level, s.full_name',
        'time' => 'g.created_at, s.full_name',
    ][$order] ?? 's.full_name';
}

/** Seed bilan takrorlanadigan aralashtirish (Fisher–Yates, mt_rand) */
function seeded_shuffle(array $a, int $seed): array
{
    mt_srand($seed);
    for ($i = count($a) - 1; $i > 0; $i--) { $j = mt_rand(0, $i); [$a[$i], $a[$j]] = [$a[$j], $a[$i]]; }
    mt_srand();   // tasodifiy holatga qaytarish
    return $a;
}

/**
 * O'tirish ketma-ketligini tuzadi. $list: [['student_id','full_name','group_name','school','grade_level','created_at'], …]
 *  name   — alifbo; school — maktab/sinf; group — guruh bo'yicha; time — ro'yxatdan o'tish vaqti;
 *  random — seed bilan tasodifiy (bir xil seed → bir xil natija);
 *  mix    — aralash: har bir guruh (yoki maktab) o'quvchilari navbat bilan qo'yiladi, shuning uchun bir guruh yonma-yon o'tirmaydi.
 */
function seat_sequence(array $list, string $order, int $seed): array
{
    $cmpName = fn($a, $b) => strcasecmp((string)$a['full_name'], (string)$b['full_name']) ?: ((int)$a['student_id'] <=> (int)$b['student_id']);
    if ($order === 'random') {
        usort($list, fn($a, $b) => (int)$a['student_id'] <=> (int)$b['student_id']);   // barqaror boshlang'ich tartib
        return seeded_shuffle($list, $seed);
    }
    if ($order === 'mix') {
        $buckets = [];
        foreach ($list as $r) {
            $k = trim((string)$r['group_name']) !== '' ? 'g:' . $r['group_name'] : (trim((string)$r['school']) !== '' ? 's:' . $r['school'] : 'n:');
            $buckets[$k][] = $r;
        }
        foreach ($buckets as &$b) { usort($b, $cmpName); $b = seeded_shuffle($b, $seed + count($b)); }
        unset($b);
        uasort($buckets, fn($a, $b) => count($b) <=> count($a));   // eng kattalari birinchi
        $out = []; $left = count($list);
        while ($left > 0) {
            foreach ($buckets as $k => &$b) { if ($b) { $out[] = array_shift($b); $left--; } }
            unset($b);
        }
        return $out;
    }
    usort($list, function ($a, $b) use ($order, $cmpName) {
        if ($order === 'school') return strcasecmp((string)$a['school'], (string)$b['school']) ?: strcasecmp((string)$a['grade_level'], (string)$b['grade_level']) ?: $cmpName($a, $b);
        if ($order === 'group') return strcasecmp((string)$a['group_name'], (string)$b['group_name']) ?: $cmpName($a, $b);
        if ($order === 'time') return strcmp((string)$a['created_at'], (string)$b['created_at']) ?: $cmpName($a, $b);
        return $cmpName($a, $b);
    });
    return $list;
}

/** Teng taqsimlash: har xonaga nechta kishi tushishi ($free: roomId => bo'sh o'rinlar soni; $n kishi) */
function room_quotas(array $free, int $n): array
{
    $q = array_fill_keys(array_keys($free), 0);
    $left = $n;
    while ($left > 0) {
        $moved = false;
        foreach ($free as $rid => $f) {
            if ($left > 0 && $q[$rid] < $f) { $q[$rid]++; $left--; $moved = true; }
        }
        if (!$moved) break;
    }
    return $q;
}

/**
 * Ro'yxatdagilarni xonalarga taqsimlash.
 * $mode: 'all' — hammasini qaytadan, 'new' — faqat xonasizlarni bo'sh o'rinlarga.
 * $order: 'name' | 'school' | 'group' | 'time' | 'random' | 'mix' (seat_sequence ga qarang).
 * $balance: true — xonalar teng to'ldiriladi (masalan 3 xonada 100 kishi: 34/33/33); false — avval birinchi xona to'ladi.
 * $seed: tasodifiy tartib uchun (null — yangisi tanlanadi).
 * Qaytaradi: [taqsimlangan, joy yetmagan, ishlatilgan seed]
 */
function distribute_rooms(int $testId, string $mode = 'new', string $order = 'name', bool $balance = false, ?int $seed = null): array
{
    $seed = $seed ?? random_int(1000, 999999);
    $rooms = test_rooms($testId);
    if (!$rooms) return [0, 0, $seed];
    if ($mode === 'all') q('UPDATE test_registrations SET room_id=NULL, seat=NULL, notified_at=NULL WHERE test_id=?', [$testId]);
    $list = rows('SELECT g.student_id, s.full_name, s.group_name, s.school, s.grade_level, g.created_at
                  FROM test_registrations g JOIN students s ON s.id=g.student_id WHERE g.test_id=? AND g.room_id IS NULL', [$testId]);
    $list = seat_sequence($list, $order, $seed);
    // xonalardagi bo'sh o'rinlar
    $freeSeats = [];
    foreach ($rooms as $r) {
        $taken = array_flip(array_map('intval', array_column(rows('SELECT seat FROM test_registrations WHERE test_id=? AND room_id=? AND seat IS NOT NULL', [$testId, $r['id']]), 'seat')));
        for ($seat = 1; $seat <= (int)$r['capacity']; $seat++) if (!isset($taken[$seat])) $freeSeats[(int)$r['id']][] = $seat;
    }
    $cap = array_map('count', $freeSeats);
    $quota = $balance ? room_quotas($cap, count($list)) : null;
    $up = db()->prepare('UPDATE test_registrations SET room_id=?, seat=?, notified_at=NULL WHERE test_id=? AND student_id=?');
    $done = 0; $i = 0;
    foreach ($rooms as $r) {
        $rid = (int)$r['id'];
        $take = $quota !== null ? ($quota[$rid] ?? 0) : count($freeSeats[$rid] ?? []);
        foreach (array_slice($freeSeats[$rid] ?? [], 0, $take) as $seat) {
            if ($i >= count($list)) break;
            $up->execute([$rid, $seat, $testId, $list[$i]['student_id']]);
            $i++; $done++;
        }
    }
    return [$done, count($list) - $i, $seed];
}

/** Bitta o'quvchini boshqa xonaga (birinchi bo'sh o'ringa) ko'chirish; $roomId=0 — xonasiz */
function move_to_room(int $testId, int $studentId, int $roomId): bool
{
    if (!$roomId) { q('UPDATE test_registrations SET room_id=NULL, seat=NULL, notified_at=NULL WHERE test_id=? AND student_id=?', [$testId, $studentId]); return true; }
    $r = row('SELECT * FROM test_rooms WHERE id=? AND test_id=?', [$roomId, $testId]);
    if (!$r) return false;
    $taken = array_flip(array_map('intval', array_column(rows('SELECT seat FROM test_registrations WHERE test_id=? AND room_id=? AND student_id<>?', [$testId, $roomId, $studentId]), 'seat')));
    for ($seat = 1; $seat <= (int)$r['capacity']; $seat++) {
        if (!isset($taken[$seat])) {
            q('UPDATE test_registrations SET room_id=?, seat=?, notified_at=NULL WHERE test_id=? AND student_id=?', [$roomId, $seat, $testId, $studentId]);
            return true;
        }
    }
    return false;   // xona to'la
}

/**
 * O'quvchini ism, maktab, ID yoki telefon bo'yicha qidirish sharti (students jadvali `s` nomi bilan).
 * Qidiruvda raqam bo'lmasa ID/telefon bo'yicha shart qo'shilmaydi (aks holda '%%' hammaga mos keladi).
 * Qaytaradi: [SQL shart, parametrlar]
 */
function student_search_sql(string $q): array
{
    $d = preg_replace('/\D/', '', $q);
    $p = ["%$q%", "%$q%"];
    if ($d !== '') array_push($p, "%$d%", "%$d%");
    return ['(s.full_name LIKE ? OR s.school LIKE ?' . ($d !== '' ? ' OR s.code LIKE ? OR s.phone LIKE ?' : '') . ')', $p];
}

/**
 * Shaxsiy varaqalar uchun ro'yxatdagilar.
 * $opt: only=new|done (chop etilmagan / etilgan), room=<id>|none, sid=<id>, sids=[id,..] yoki "id,id",
 *       group=<nom>|@none, center=own|<id>, q=<qidiruv>, order=room|name|school|time
 */
function reg_students(int $testId, array $opt = []): array
{
    $w = ['g.test_id=?']; $p = [$testId];
    if (($opt['only'] ?? '') === 'new') $w[] = 'g.printed_at IS NULL';
    elseif (($opt['only'] ?? '') === 'done') $w[] = 'g.printed_at IS NOT NULL';
    if (($opt['room'] ?? '') === 'none') $w[] = 'g.room_id IS NULL';
    elseif ((int)($opt['room'] ?? 0)) { $w[] = 'g.room_id=?'; $p[] = (int)$opt['room']; }
    if ((int)($opt['sid'] ?? 0)) { $w[] = 'g.student_id=?'; $p[] = (int)$opt['sid']; }
    if (!empty($opt['sids'])) {
        $ids = is_array($opt['sids']) ? $opt['sids'] : explode(',', (string)$opt['sids']);
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
        if ($ids) { $w[] = 'g.student_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')'; $p = array_merge($p, $ids); }
        else $w[] = '1=0';   // noto'g'ri ro'yxat berilsa — hech kim (hammasini emas)
    }
    $grp = (string)($opt['group'] ?? '');
    if ($grp === '@none') $w[] = "s.group_name=''";
    elseif ($grp !== '') { $w[] = 's.group_name=?'; $p[] = $grp; }
    $cen = (string)($opt['center'] ?? '');
    if ($cen === 'own') $w[] = 's.center_id IS NULL';
    elseif ($cen !== '') { $w[] = 's.center_id=?'; $p[] = (int)$cen; }
    if (trim((string)($opt['q'] ?? '')) !== '') { [$sw, $sp] = student_search_sql(trim((string)$opt['q'])); $w[] = $sw; $p = array_merge($p, $sp); }
    $order = reg_order_sql($opt['order'] ?? 'room');
    return rows("SELECT s.*, g.room_id, g.seat, g.printed_at, g.notified_at, g.created_at reg_at, rm.name room_name, rm.proctor
                 FROM test_registrations g JOIN students s ON s.id=g.student_id LEFT JOIN test_rooms rm ON rm.id=g.room_id
                 WHERE " . implode(' AND ', $w) . " ORDER BY $order", $p);
}
