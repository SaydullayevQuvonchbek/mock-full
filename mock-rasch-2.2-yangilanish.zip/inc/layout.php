<?php
defined('APP_ROOT') || exit;
/** Sahifa karkasi: admin uchun yon panel, o'quvchi va mehmon uchun yuqori panel */

/** Brauzer eski CSS/JS ni keshdan olmasligi uchun: versiya + fayl o'zgargan vaqt (fayl yangilansa manzil ham o'zgaradi) */
function asset_ver(string $path): string
{
    $t = @filemtime(APP_ROOT . '/' . ltrim($path, '/'));
    return APP_VERSION . ($t ? '.' . $t : '');
}

/** Chiziqli SVG ikonkalar (24×24, stroke) */
function icon(string $name, int $size = 18): string
{
    static $p = [
        'home' => '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M10 21v-6h4v6"/>',
        'tests' => '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',
        'users' => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.6 3.3-5.5 6.5-5.5s5.9 1.9 6.5 5.5"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.8c2 .6 3.2 2.3 3.5 5.2"/>',
        'scan' => '<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M4 12h16"/>',
        'theta' => '<ellipse cx="12" cy="12" rx="6" ry="8.5"/><path d="M6 12h12"/>',
        'logout' => '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3"/><path d="M10 16l-4-4 4-4M6 12h10"/>',
        'moon' => '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
        'sun' => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
        'print' => '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'download' => '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
        'upload' => '<path d="M12 20V9M7 14l5-5 5 5M5 4h14"/>',
        'camera' => '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
        'chart' => '<path d="M4 20V4M4 20h16"/><path d="M8 16v-5M12 16V8M16 16v-3"/>',
        'check' => '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
        'alert' => '<path d="M12 3 2.5 20h19z"/><path d="M12 10v4M12 17.5v.01"/>',
        'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
        'student' => '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c3 2.5 9 2.5 12 0v-5"/>',
        'key' => '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3"/>',
        'book' => '<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 21V5"/>',
        'bank' => '<path d="M12 3 3 7.5l9 4.5 9-4.5z"/><path d="M3 12l9 4.5 9-4.5M3 16.5 12 21l9-4.5"/>',
        'arrow' => '<path d="M5 12h14M13 6l6 6-6 6"/>',
    ];
    return '<svg class="ico" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($p[$name] ?? '') . '</svg>';
}

function page_header(string $title, array $opts = []): void
{
    global $CONFIG;
    $a = admin();
    $s = student();
    $cur = $_GET['p'] ?? '';
    $bare = !empty($opts['bare']);
    $center = app_setting('center');
    $testPages = ['test_edit', 'entry', 'import', 'responses', 'open_review', 'results', 'analysis', 'result_card', 'registrations', 'room_list', 'room_door', 'parent_send', 'tg_monitor'];
    $isActive = fn(string $p) => $cur === $p || ($p === 'tests' && in_array($cur, $testPages, true)) || ($p === 'qb' && in_array($cur, ['qb_questions', 'qb_import'], true)) || ($p === 'student_practice' && $cur === 'student_practice_do');
    $side = function (string $p, string $label, string $ic) use ($isActive) {
        return '<a href="' . e(url($p)) . '"' . ($isActive($p) ? ' class="active" aria-current="page"' : '') . '>' . icon($ic) . '<span>' . e($label) . '</span></a>';
    };
    $top = function (string $p, string $label) use ($cur) {
        return '<a href="' . e(url($p)) . '"' . ($cur === $p ? ' class="active"' : '') . '>' . e($label) . '</a>';
    };
    $shell = $a && !$bare;
    // Oddiy foydalanuvchiga baholash usuli ko'rsatilmaydi: markaz nomi va MOCK — xolos
    $pubMark = mb_strtoupper(mb_substr(trim($center) ?: 'M', 0, 1));
    ?><!doctype html>
<html lang="uz">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> — <?= e($a ? APP_NAME : ($center ?: 'MOCK')) ?></title>
<script>try{var t=localStorage.getItem('moc-theme');if(t)document.documentElement.setAttribute('data-theme',t);}catch(e){}</script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,500;8..60,600&display=swap">
<link rel="stylesheet" href="assets/style.css?v=<?= asset_ver('assets/style.css') ?>">
<meta name="csrf" content="<?= e(csrf_token()) ?>">
</head>
<body class="<?= e(trim(($opts['body'] ?? '') . ($shell ? ' has-shell' : ''))) ?>">
<?php if ($shell): ?>
<aside class="sidebar no-print" id="sidebar">
  <a class="brand" href="<?= e(url('dashboard')) ?>">
    <span class="brand-mark">θ</span>
    <span class="brand-text"><b>MOCK Rasch</b><small><?= e($center) ?></small></span>
  </a>
  <nav class="side-nav">
    <div class="side-label">Boshqaruv</div>
    <?= $side('dashboard', 'Bosh panel', 'home') ?>
    <?= $side('tests', 'Testlar', 'tests') ?>
    <?= $side('students', 'O\'quvchilar', 'users') ?>
    <?= $side('groups', 'Guruhlar', 'student') ?>
    <?= $side('qb', 'Savollar bazasi', 'bank') ?>
    <?= $side('qb_assign', 'Topshiriqlar', 'check') ?>
    <?= $side('qb_mastery', 'O\'zlashtirish', 'chart') ?>
    <?= $side('scan', 'Skaner', 'scan') ?>
    <div class="side-label">Bilim</div>
    <?= $side('rasch', 'Rasch modeli', 'theta') ?>
    <?= $side('settings', 'Sozlamalar', 'key') ?>
  </nav>
  <div class="side-foot">
    <button type="button" class="side-btn theme-toggle" aria-label="Mavzuni almashtirish"><?= icon('moon') ?><span>Tungi rejim</span></button>
    <a class="side-btn" href="<?= e(url('logout')) ?>"><?= icon('logout') ?><span>Chiqish</span></a>
    <div class="side-user"><span class="avatar"><?= e(mb_strtoupper(mb_substr($a['login'], 0, 1))) ?></span><span><?= e($a['name'] ?: $a['login']) ?><small><?= e($a['login']) ?></small></span></div>
  </div>
</aside>
<header class="mobilebar no-print">
  <button class="icon-btn" onclick="document.body.classList.toggle('nav-open')" aria-label="Menyu"><?= icon('menu', 20) ?></button>
  <a class="brand" href="<?= e(url('dashboard')) ?>"><span class="brand-mark sm">θ</span><b>MOCK Rasch</b></a>
</header>
<div class="scrim" onclick="document.body.classList.remove('nav-open')"></div>
<?php elseif (!$bare): ?>
<header class="topbar no-print">
  <a class="brand" href="<?= e(url($s ? 'student_home' : 'home')) ?>">
    <span class="brand-mark"><?= e($pubMark) ?></span>
    <span class="brand-text"><b><?= e($center ?: 'O\'quv markazi') ?></b><small>MOCK sinov imtihonlari</small></span>
  </a>
  <button class="icon-btn nav-toggle" onclick="document.body.classList.toggle('nav-open')" aria-label="Menyu"><?= icon('menu', 20) ?></button>
  <nav class="mainnav">
    <?php if ($s): ?>
      <?= $top('student_home', 'Mening sahifam') ?>
      <?= $top('moc', 'MOCK ga ro\'yxatdan o\'tish') ?>
      <a href="<?= e(url('student_practice')) ?>"<?= in_array($cur, ['student_practice', 'student_practice_do'], true) ? ' class="active"' : '' ?>>Topshiriq va mashq</a>
      <?= $top('student_profile', 'Profil') ?>
      <a href="<?= e(url('student_logout')) ?>" class="muted-link">Chiqish</a>
    <?php else: ?>
      <?= $top('home', 'Bosh sahifa') ?>
      <?= $top('student_login', 'Natijani bilish') ?>
      <?= $top('verify', 'Sertifikatni tekshirish') ?>
      <a class="btn primary sm" href="<?= e(url('register')) ?>">MOCK ga ro'yxatdan o'tish</a>
    <?php endif; ?>
    <button type="button" class="icon-btn theme-toggle" aria-label="Mavzuni almashtirish"><?= icon('moon') ?></button>
  </nav>
</header>
<?php endif; ?>
<main class="container <?= e($opts['main'] ?? '') ?>">
<?php foreach (take_flashes() as $f): ?>
  <div class="alert <?= e($f['type']) ?>"><?= icon($f['type'] === 'ok' ? 'check' : 'alert') ?><span><?= e($f['msg']) ?></span></div>
<?php endforeach;
}

function page_footer(array $scripts = []): void
{
    ?>
</main>
<footer class="foot no-print"><?php if (admin()): ?><?= e(APP_NAME) ?> <?= APP_VERSION ?> · Rasch (1PL) modeli asosida baholash<?php else: ?>© <?= date('Y') ?> <?= e(app_setting('center')) ?> · MOCK sinov imtihonlari<?php endif; ?></footer>
<script src="assets/app.js?v=<?= asset_ver('assets/app.js') ?>"></script>
<?php foreach ($scripts as $s): ?>
<script src="<?= e($s) ?>?v=<?= asset_ver($s) ?>"></script>
<?php endforeach; ?>
</body>
</html><?php
}

/** Test sahifalari uchun sarlavha va ichki menyu */
function test_tabs(array $test, string $active): void
{
    $tabs = [
        'test_edit' => 'Sozlamalar va kalit',
        'registrations' => 'Ro\'yxat',
        'entry' => 'Qo\'lda kiritish',
        'import' => 'Excel/CSV',
        'scan' => 'Skaner',
        'responses' => 'Javoblar',
        'open_review' => 'Ochiq javoblar',
        'results' => 'Natijalar',
        'analysis' => 'Rasch tahlili',
        'parent_send' => 'Ota-onalar',
    ];
    if (!empty($test['tg_enabled'])) $tabs['tg_monitor'] = 'Telegram';
    $n = (int)val('SELECT COUNT(*) FROM responses WHERE test_id=? AND status="submitted"', [$test['id']]);
    echo '<div class="page-head test-head"><div>';
    echo '<nav class="crumbs no-print"><a href="' . e(url('tests')) . '">Testlar</a><span>/</span>#' . (int)$test['id'] . '</nav>';
    echo '<h1>' . e($test['title']) . '</h1>';
    echo '<div class="meta-row"><span>' . e($test['subject']) . '</span><span>' . e($test['test_date'] ?: '—') . '</span><span>' . count(test_items($test)) . ' item</span><span>' . $n . ' ishtirokchi</span>';
    if ($test['online']) echo '<span class="tag blue">Onlayn</span>';
    if ($test['published']) echo '<span class="tag green">E\'lon qilingan</span>';
    echo '</div></div>';
    echo '<a class="btn no-print" href="' . e(url('sheet', ['id' => $test['id']])) . '" target="_blank">' . icon('print') . 'Javoblar varaqasi</a></div>';
    echo '<nav class="tabs no-print">';
    foreach ($tabs as $p => $label) {
        $cls = $p === $active ? ' class="active"' : '';
        echo '<a' . $cls . ' href="' . e(url($p, ['id' => $test['id']])) . '">' . e($label) . '</a>';
    }
    echo '</nav>';
}

function get_test_or_404(): array
{
    $id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
    $t = $id ? test_by_id($id) : null;
    if (!$t) {
        flash('Test topilmadi', 'err');
        redirect('tests');
    }
    return $t;
}
