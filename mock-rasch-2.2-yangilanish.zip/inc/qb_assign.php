<?php
defined('APP_ROOT') || exit;
/**
 * Topshiriqlar (2.1): admin savollar bazasidan test tuzadi va o'quvchilarga (hammaga yoki guruhlarga) muddat bilan yuboradi.
 * Hamma o'quvchiga bir xil savollar. Javoblar avtomatik tekshiriladi. Muddat tugagach ochiq testlar yopiladi,
 * `review=1` bo'lsa o'quvchi xatolarini va to'g'ri javoblarni ko'radi (muddatgacha — faqat sonlar).
 * O'zlashtirish: savollar bazasi bo'limlari (mashq + topshiriq) va MOCK bo'limlari (Algebra/Geometriya).
 * PHP 7.4 bilan mos.
 */

/** Tanlangan bo'limlardan (ichki bo'limlari bilan) kalitli savollardan tasodifiy $n tasi: [['id','section_id','name'],…] */
function qb_pick_questions(array $sectionIds, int $n): array
{
    $sectionIds = array_values(array_filter(array_map('intval', $sectionIds)));
    $all = $sectionIds ? qb_descendants($sectionIds) : array_map('intval', array_column(rows('SELECT id FROM qb_sections'), 'id'));
    if (!$all) return [];
    $in = implode(',', array_fill(0, count($all), '?'));
    $pool = rows("SELECT q.id, q.section_id, s.name FROM qb_questions q JOIN qb_sections s ON s.id=q.section_id WHERE q.answer<>'' AND q.section_id IN ($in)", $all);
    shuffle($pool);
    return array_slice($pool, 0, max(1, $n));
}

/** Auditoriya: ['all'=>1] yoki ['groups'=>[nom,…]] → o'quvchilar [['id','tg_chat_id','full_name','group_name'],…] */
function qb_assign_students(array $aud): array
{
    if (!empty($aud['all'])) return rows('SELECT id, tg_chat_id, full_name, group_name FROM students WHERE archived_at IS NULL ORDER BY full_name');
    $g = array_values(array_filter(array_map('strval', (array)($aud['groups'] ?? []))));
    if (!$g) return [];
    $in = implode(',', array_fill(0, count($g), '?'));
    return rows("SELECT id, tg_chat_id, full_name, group_name FROM students WHERE archived_at IS NULL AND group_name IN ($in) ORDER BY full_name", $g);
}

function qb_assign_aud_label(array $a): string
{
    $aud = json_decode((string)$a['aud'], true) ?: [];
    if (!empty($aud['all'])) return 'Barcha o\'quvchilar';
    $g = (array)($aud['groups'] ?? []);
    return $g ? 'Guruh: ' . implode(', ', $g) : '—';
}

/**
 * Topshiriq yaratadi va o'quvchilarga biriktiradi. $d: title, sections[], n, deadline ('Y-m-d H:i:s'), review, aud[], notify.
 * Qaytaradi: [assign_id|null, xato, o'quvchilar soni]
 */
function qb_assign_create(array $d): array
{
    $n = max(1, min(60, (int)($d['n'] ?? 10)));
    $deadline = (string)($d['deadline'] ?? '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/', $deadline) || strtotime($deadline) <= time() + 60) return [null, 'Muddat kelajakdagi vaqt bo\'lsin', 0];
    $aud = (array)($d['aud'] ?? []);
    $studs = qb_assign_students($aud);
    if (!$studs) return [null, 'Tanlangan auditoriyada o\'quvchi yo\'q', 0];
    $pick = qb_pick_questions((array)($d['sections'] ?? []), $n);
    if (!$pick) return [null, 'Tanlangan bo\'limlarda kalitli savol yo\'q', 0];
    $title = trim((string)($d['title'] ?? ''));
    if ($title === '') {
        $names = [];
        foreach ((array)($d['sections'] ?? []) as $x) { $nm = (string)val('SELECT name FROM qb_sections WHERE id=?', [(int)$x]); if ($nm !== '') $names[] = $nm; }
        $title = 'Topshiriq: ' . ($names ? implode(', ', $names) : 'aralash');
    }
    $title = mb_strimwidth($title, 0, 150, '…');
    $pdo = db();
    $pdo->beginTransaction();
    try {
        q('INSERT INTO qb_assign (title, sections, n, deadline, review, aud) VALUES (?,?,?,?,?,?)',
            [$title, implode(',', array_map('intval', (array)($d['sections'] ?? []))), count($pick), $deadline, !empty($d['review']) ? 1 : 0, json_encode($aud, JSON_UNESCAPED_UNICODE)]);
        $aid = (int)$pdo->lastInsertId();
        $ins = $pdo->prepare('INSERT INTO qb_assign_items (assign_id, pos, question_id, section_id, section_name) VALUES (?,?,?,?,?)');
        foreach ($pick as $i => $r) $ins->execute([$aid, $i + 1, $r['id'], $r['section_id'], $r['name']]);
        $tIns = $pdo->prepare('INSERT INTO qb_tests (student_id, title, n, via, assign_id) VALUES (?,?,?,?,?)');
        $iIns = $pdo->prepare('INSERT INTO qb_items (test_id, pos, question_id, section_id, section_name) VALUES (?,?,?,?,?)');
        foreach ($studs as $s) {
            $tIns->execute([$s['id'], $title, count($pick), 'web', $aid]);
            $tid = (int)$pdo->lastInsertId();
            foreach ($pick as $i => $r) $iIns->execute([$tid, $i + 1, $r['id'], $r['section_id'], $r['name']]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        return [null, 'Saqlab bo\'lmadi: ' . $e->getMessage(), 0];
    }
    if (!empty($d['notify']) && function_exists('tg_enqueue') && tg_ready()) {
        foreach ($studs as $s) if ($s['tg_chat_id'] !== null) tg_enqueue('asg', $aid, (int)$s['id'], (int)$s['tg_chat_id']);
    }
    return [$aid, '', count($studs)];
}

/** O'quvchining shu topshiriqdagi testi */
function qb_assign_test(int $aid, int $sid): ?array
{
    return row('SELECT * FROM qb_tests WHERE assign_id=? AND student_id=? ORDER BY id DESC LIMIT 1', [$aid, $sid]);
}

/** Topshiriq muddati o'tganmi */
function qb_assign_due(array $a): bool
{
    return strtotime((string)$a['deadline']) <= time();
}

/** Muddati o'tgan topshiriqni yopadi: ochiq testlar saqlangan javoblar bilan tekshiriladi, Telegramga natija navbatga qo'yiladi */
function qb_assign_close(int $aid): int
{
    $a = row('SELECT * FROM qb_assign WHERE id=?', [$aid]);
    if (!$a || $a['closed_at'] !== null) return 0;
    $up = q('UPDATE qb_assign SET closed_at=NOW() WHERE id=? AND closed_at IS NULL', [$aid]);
    if (!$up->rowCount()) return 0;   // boshqa jarayon yopdi
    $n = 0;
    foreach (rows('SELECT t.id, (SELECT COUNT(*) FROM qb_items i WHERE i.test_id=t.id AND i.given NOT IN ("","-")) ans FROM qb_tests t WHERE t.assign_id=? AND t.status="open"', [$aid]) as $t) {
        qb_finish((int)$t['id'], []);   // xatolarni ko'rish uchun baribir tekshiriladi
        if ((int)$t['ans'] === 0) q('UPDATE qb_tests SET status="missed" WHERE id=?', [$t['id']]);   // birorta javob yo'q — «topshirmadi» (o'zlashtirishga kirmaydi)
        $n++;
    }
    if (function_exists('tg_enqueue') && tg_ready()) {
        foreach (rows('SELECT t.student_id, s.tg_chat_id FROM qb_tests t JOIN students s ON s.id=t.student_id WHERE t.assign_id=? AND s.tg_chat_id IS NOT NULL', [$aid]) as $r)
            tg_enqueue('asgd', $aid, (int)$r['student_id'], (int)$r['tg_chat_id']);
    }
    return $n;
}

/** Vaqtli ishlar: muddati o'tganlarni yopish, muddatga 1 soat qolganda eslatma. Sahifalardan ham chaqiriladi (arzon) */
function qb_assign_tick(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        foreach (rows('SELECT id FROM qb_assign WHERE closed_at IS NULL AND deadline<=NOW()') as $a) qb_assign_close((int)$a['id']);
        if (function_exists('tg_enqueue') && tg_ready()) {
            foreach (rows('SELECT id FROM qb_assign WHERE closed_at IS NULL AND deadline>NOW() AND deadline<=DATE_ADD(NOW(), INTERVAL 60 MINUTE)') as $a) {
                foreach (rows('SELECT t.student_id, s.tg_chat_id FROM qb_tests t JOIN students s ON s.id=t.student_id WHERE t.assign_id=? AND t.status="open" AND s.tg_chat_id IS NOT NULL', [$a['id']]) as $r)
                    tg_enqueue('asgr', (int)$a['id'], (int)$r['student_id'], (int)$r['tg_chat_id']);
            }
        }
    } catch (Throwable $e) { /* jadval hali yo'q (migratsiyadan oldin) — e'tiborsiz */ }
}

/** Xatolarni ko'rsatish mumkinmi: topshiriq yopilgan va review yoqilgan */
function qb_review_allowed(array $test): bool
{
    if (empty($test['assign_id'])) return false;
    $a = row('SELECT review, closed_at FROM qb_assign WHERE id=?', [(int)$test['assign_id']]);
    return $a && (int)$a['review'] === 1 && $a['closed_at'] !== null && in_array($test['status'], ['done', 'missed'], true);
}

/** Ko'rib chiqish ro'yxati: [['pos','question_id','img','kind','given','answer','ok','section_name'],…] */
function qb_review_items(int $tid): array
{
    return rows('SELECT i.pos, i.question_id, i.given, i.ok, i.section_name, q.img, q.kind, q.answer FROM qb_items i LEFT JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? ORDER BY i.pos', [$tid]);
}

/** Ochiq javobning kalitidagi birinchi variant (ko'rsatish uchun) */
function qb_answer_show(?string $kind, ?string $answer): string
{
    $a = (string)$answer;
    if ($kind === 'open') return str_replace(';', ' yoki ', $a);
    return $a;
}

/* ---------------- O'zlashtirish ---------------- */

/** Bo'lim → eng yuqori (asosiy) bo'lim id xaritasi */
function qb_root_map(): array
{
    $par = [];
    foreach (rows('SELECT id, parent_id FROM qb_sections') as $r) $par[(int)$r['id']] = $r['parent_id'] !== null ? (int)$r['parent_id'] : 0;
    $root = [];
    foreach ($par as $id => $p) {
        $x = $id; $guard = 0;
        while (!empty($par[$x]) && isset($par[$par[$x]]) && $guard++ < 20) $x = $par[$x];
        $root[$id] = $x;
    }
    return $root;
}

/**
 * O'quvchining savollar bazasi bo'limlari bo'yicha o'zlashtirishi (yakunlangan mashq va topshiriqlardan).
 * Qaytaradi daraxt tartibida: [['id','name','depth','n','k','pct'],…] — har bo'lim ichki bo'limlari bilan jamlangan.
 */
function qb_mastery(int $sid): array
{
    $raw = [];
    foreach (rows('SELECT i.section_id, SUM(i.ok IS NOT NULL) n, SUM(i.ok=1) k FROM qb_items i JOIN qb_tests t ON t.id=i.test_id WHERE t.student_id=? AND t.status="done" GROUP BY i.section_id', [$sid]) as $r)
        $raw[(int)$r['section_id']] = [(int)$r['n'], (int)$r['k']];
    if (!$raw) return [];
    $par = [];
    foreach (rows('SELECT id, parent_id FROM qb_sections') as $r) $par[(int)$r['id']] = $r['parent_id'] !== null ? (int)$r['parent_id'] : 0;
    $agg = [];
    foreach ($raw as $id => $nk) {
        $x = $id; $guard = 0;
        while ($x && isset($par[$x]) && $guard++ < 20) {   // o'zi va barcha ota bo'limlariga qo'shamiz
            $agg[$x] = $agg[$x] ?? [0, 0];
            $agg[$x][0] += $nk[0]; $agg[$x][1] += $nk[1];
            $x = $par[$x];
        }
    }
    $out = [];
    foreach (qb_tree() as $s) {
        $id = (int)$s['id'];
        if (empty($agg[$id][0])) continue;
        [$n, $k] = $agg[$id];
        $out[] = ['id' => $id, 'name' => $s['name'], 'depth' => (int)$s['depth'], 'n' => $n, 'k' => $k, 'pct' => (int)round(100 * $k / $n)];
    }
    return $out;
}

/** Guruh (yoki hammasi) bo'yicha: o'quvchi × asosiy bo'lim. Qaytaradi ['roots'=>[id=>nom], 'rows'=>[sid=>[root=>[n,k]]], 'students'=>[…]] */
function qb_mastery_group(string $group = ''): array
{
    $roots = [];
    foreach (qb_tree() as $s) if ((int)$s['depth'] === 0) $roots[(int)$s['id']] = $s['name'];
    $studs = $group !== '' ? rows('SELECT id, code, full_name, group_name FROM students WHERE group_name=? AND archived_at IS NULL ORDER BY full_name', [$group])
                           : rows('SELECT id, code, full_name, group_name FROM students WHERE archived_at IS NULL ORDER BY full_name');
    $rootOf = qb_root_map();
    $data = [];
    if ($studs) {
        $ids = array_map(fn($s) => (int)$s['id'], $studs);
        foreach (array_chunk($ids, 500) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '?'));
            foreach (rows("SELECT t.student_id, i.section_id, SUM(i.ok IS NOT NULL) n, SUM(i.ok=1) k FROM qb_items i JOIN qb_tests t ON t.id=i.test_id
                           WHERE t.status='done' AND t.student_id IN ($in) GROUP BY t.student_id, i.section_id", $chunk) as $r) {
                $root = $rootOf[(int)$r['section_id']] ?? 0;
                if (!$root) continue;
                $d = &$data[(int)$r['student_id']][$root];
                $d = $d ?? [0, 0];
                $d[0] += (int)$r['n']; $d[1] += (int)$r['k'];
                unset($d);
            }
        }
    }
    return ['roots' => $roots, 'rows' => $data, 'students' => $studs];
}

/** O'zlashtirish rangi */
function pct_cls(int $p): string { return $p >= 70 ? 'hi' : ($p >= 40 ? 'mid' : 'lo'); }
