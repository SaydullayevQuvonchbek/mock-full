<?php
defined('APP_ROOT') || exit;
/** Admin: topshiriqlar — tuzish (savollar bazasidan), yuborish, natijalar, savollar statistikasi */
qb_assign_tick();
$aid = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

if (is_post()) {
    csrf_check();
    $a = (string)($_POST['action'] ?? '');
    if ($a === 'create') {
        $dl = str_replace('T', ' ', trim((string)($_POST['deadline'] ?? '')));
        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $dl)) $dl .= ':00';
        $mode = (string)($_POST['aud'] ?? 'groups');
        $aud = $mode === 'all' ? ['all' => 1] : ['groups' => array_values(array_filter(array_map(fn($g) => mb_substr(trim((string)$g), 0, 80), (array)($_POST['groups'] ?? []))))];
        [$id, $err, $cnt] = qb_assign_create([
            'title' => (string)($_POST['title'] ?? ''), 'sections' => (array)($_POST['sec'] ?? []), 'n' => (int)($_POST['n'] ?? 10),
            'deadline' => $dl, 'review' => !empty($_POST['review']), 'aud' => $aud, 'notify' => !empty($_POST['notify']),
        ]);
        if (!$id) { flash($err, 'err'); redirect('qb_assign'); }
        $tg = (int)val('SELECT COUNT(*) FROM tg_queue WHERE kind="asg" AND test_id=?', [$id]);
        if ($tg && tg_ready()) tg_drain_now(10, 300);   // cron kutmasdan darhol yuborish
        flash('Topshiriq yuborildi: ' . $cnt . ' ta o\'quvchi' . ($tg ? ' (Telegramga xabar: ' . $tg . ' ta)' : ''));
        redirect('qb_assign', ['id' => $id]);
    }
    $as = $aid ? row('SELECT * FROM qb_assign WHERE id=?', [$aid]) : null;
    if (!$as) { flash('Topshiriq topilmadi', 'err'); redirect('qb_assign'); }
    if ($a === 'deadline' && $as['closed_at'] === null) {
        $dl = str_replace('T', ' ', trim((string)($_POST['deadline'] ?? '')));
        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $dl)) $dl .= ':00';
        if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $dl) || strtotime($dl) <= time()) flash('Yangi muddat kelajakdagi vaqt bo\'lsin', 'err');
        else {
            q('UPDATE qb_assign SET deadline=? WHERE id=?', [$dl, $aid]);
            q('DELETE FROM tg_queue WHERE kind="asgr" AND test_id=? AND sent_at IS NOT NULL', [$aid]);   // yangi muddat uchun eslatma qayta ketadi
            flash('Muddat o\'zgartirildi: ' . date('d.m.Y H:i', strtotime($dl)));
        }
    } elseif ($a === 'remind' && $as['closed_at'] === null) {
        $n = 0;
        foreach (rows('SELECT t.student_id, s.tg_chat_id FROM qb_tests t JOIN students s ON s.id=t.student_id WHERE t.assign_id=? AND t.status="open" AND s.tg_chat_id IS NOT NULL', [$aid]) as $r) {
            q('DELETE FROM tg_queue WHERE kind="asgn" AND test_id=? AND student_id=?', [$aid, $r['student_id']]);
            if (tg_enqueue('asgn', $aid, (int)$r['student_id'], (int)$r['tg_chat_id'])) $n++;
        }
        if ($n) tg_drain_now(8, 200);
        flash($n ? $n . ' ta o\'quvchiga Telegramda eslatma yuborildi' : 'Telegramga ulangan, hali topshirmagan o\'quvchi yo\'q', $n ? 'ok' : 'warn');
    } elseif ($a === 'close' && $as['closed_at'] === null) {
        q('UPDATE qb_assign SET deadline=? WHERE id=?', [date('Y-m-d H:i:s'), $aid]);
        $n = qb_assign_close($aid);
        $miss = (int)val('SELECT COUNT(*) FROM qb_tests WHERE assign_id=? AND status="missed"', [$aid]);
        tg_drain_now(8, 200);
        flash('Topshiriq yopildi' . ($n ? ' · ' . ($n - $miss) . ' ta yakunlanmagan test saqlangan javoblar bilan tekshirildi' : '') . ($miss ? ' · ' . $miss . ' ta o\'quvchi topshirmadi' : ''));
    } elseif ($a === 'delete') {
        q('DELETE FROM qb_tests WHERE assign_id=?', [$aid]);
        q('DELETE FROM tg_queue WHERE kind IN ("asg","asgr","asgd","asgn") AND test_id=?', [$aid]);
        q('DELETE FROM qb_assign WHERE id=?', [$aid]);
        flash('Topshiriq o\'chirildi');
        redirect('qb_assign');
    }
    redirect('qb_assign', ['id' => $aid]);
}

/* ---------------- Bitta topshiriq ---------------- */
if ($aid) {
    $as = row('SELECT * FROM qb_assign WHERE id=?', [$aid]);
    if (!$as) { flash('Topshiriq topilmadi', 'err'); redirect('qb_assign'); }
    if (isset($_GET['pdf'])) {   // sinfda tarqatish uchun: savollar (javoblar varaqasi va kod bilan) yoki kalit bilan
        $key = $_GET['pdf'] === 'key';
        $qs = rows('SELECT ai.pos AS no, q.id, q.img, q.kind, q.nopt, q.answer, q.label FROM qb_assign_items ai JOIN qb_questions q ON q.id=ai.question_id WHERE ai.assign_id=? ORDER BY ai.pos', [$aid]);
        if (!$key) foreach ($qs as &$x) $x['answer'] = ''; unset($x);
        $pdf = $qs ? qb_pdf((string)$as['title'], 'Topshiriq · ' . (int)$as['n'] . ' ta savol · muddat: ' . date('d.m.Y H:i', strtotime((string)$as['deadline'])), $qs, $key, '#A' . $aid) : null;
        if ($pdf === null) { flash($qs ? 'PDF yaratib bo\'lmadi (serverda GD yo\'q)' : 'Topshiriqda savol qolmagan', 'err'); redirect('qb_assign', ['id' => $aid]); }
        session_write_close();
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="topshiriq-' . $aid . ($key ? '-kalit' : '') . '.pdf"');
        header('Content-Length: ' . strlen($pdf));
        header('Cache-Control: private, no-store');
        echo $pdf;
        exit;
    }
    $closed = $as['closed_at'] !== null;
    $tid = (int)($_GET['tid'] ?? 0);
    if ($tid) {   // bitta o'quvchining javoblari
        $t = row('SELECT t.*, s.full_name, s.code FROM qb_tests t JOIN students s ON s.id=t.student_id WHERE t.id=? AND t.assign_id=?', [$tid, $aid]);
        if (!$t) { flash('Test topilmadi', 'err'); redirect('qb_assign', ['id' => $aid]); }
        page_header('Javoblar — ' . $t['full_name']);
        ?>
<p class="small muted"><a href="<?= e(url('qb_assign', ['id' => $aid])) ?>">← <?= e($as['title']) ?></a></p>
<h1><?= e($t['full_name']) ?> <span class="muted small">ID <?= e($t['code']) ?></span></h1>
<p class="muted"><?= $t['status'] === 'done' ? 'Natija: <b>' . (int)$t['correct'] . ' / ' . (int)$t['n'] . '</b> · ' . e(date('d.m.Y H:i', strtotime((string)$t['finished_at']))) : ($t['status'] === 'missed' ? '<span class="tag red">Topshirmadi</span> — muddatda birorta javob yo\'q' : 'Hali yakunlanmagan') ?></p>
<div class="qb-review">
<?php foreach (qb_review_items($tid) as $it): $ok = $it['ok'] === null ? null : (int)$it['ok']; ?>
  <div class="card qb-rv <?= $ok === 1 ? 'good' : ($ok === 0 ? 'bad' : '') ?>">
    <div class="qb-rv-h"><b><?= (int)$it['pos'] ?>-savol</b> <span class="muted small"><?= e($it['section_name']) ?></span>
      <span class="right">Javob: <b class="mono"><?= $it['given'] !== '' && $it['given'] !== '-' ? e($it['given']) : '—' ?></b> · To'g'ri: <b class="mono"><?= e(qb_answer_show($it['kind'], $it['answer'])) ?></b> <?= $ok === 1 ? '✅' : ($ok === 0 ? '❌' : '') ?></span></div>
    <?php if ($it['img']): ?><img class="qb-qimg" loading="lazy" alt="<?= (int)$it['pos'] ?>-savol" src="<?= e(url('qb_img', ['id' => $it['question_id'], 'v' => substr((string)$it['img'], 1, 8)])) ?>"><?php else: ?><p class="muted small">Savol bazadan o'chirilgan — hisobga olinmadi.</p><?php endif; ?>
  </div>
<?php endforeach; ?>
</div>
        <?php
        page_footer();
        return;
    }
    $tests = rows('SELECT t.*, s.full_name, s.code, s.group_name, s.tg_chat_id, (SELECT COUNT(*) FROM qb_items i WHERE i.test_id=t.id AND i.given NOT IN ("","-")) answered
                   FROM qb_tests t JOIN students s ON s.id=t.student_id WHERE t.assign_id=? ORDER BY FIELD(t.status,"done","open","missed"), t.correct DESC, s.full_name', [$aid]);
    $done = array_values(array_filter($tests, fn($t) => $t['status'] === 'done' && (int)$t['n'] > 0));
    $avg = $done ? round(100 * array_sum(array_map(fn($t) => (int)$t['correct'] / max(1, (int)$t['n']), $done)) / count($done)) : 0;
    $started = count(array_filter($tests, fn($t) => $t['status'] === 'open' && (int)$t['answered'] > 0));
    $missed = count(array_filter($tests, fn($t) => $t['status'] === 'missed' || ($t['status'] === 'open' && (int)$t['answered'] === 0)));
    $qstat = rows('SELECT ai.pos, ai.question_id, ai.section_name, q.img, q.kind, q.answer,
                          SUM(i.ok=1) k, SUM(i.ok IS NOT NULL) n
                   FROM qb_assign_items ai LEFT JOIN qb_questions q ON q.id=ai.question_id
                   LEFT JOIN qb_items i ON i.question_id=ai.question_id AND i.pos=ai.pos AND i.test_id IN (SELECT id FROM qb_tests WHERE assign_id=? AND status="done")
                   WHERE ai.assign_id=? GROUP BY ai.pos, ai.question_id, ai.section_name, q.img, q.kind, q.answer ORDER BY ai.pos', [$aid, $aid]);
    $wrong = [];
    foreach (rows('SELECT i.pos, i.given, COUNT(*) c FROM qb_items i JOIN qb_tests t ON t.id=i.test_id WHERE t.assign_id=? AND t.status="done" AND i.ok=0 AND i.given NOT IN ("","-") GROUP BY i.pos, i.given ORDER BY c DESC', [$aid]) as $w)
        if (!isset($wrong[(int)$w['pos']])) $wrong[(int)$w['pos']] = $w['given'] . ' (' . (int)$w['c'] . ')';
    $secNames = [];
    foreach (array_filter(array_map('intval', explode(',', (string)$as['sections']))) as $x) if (($pth = qb_section_path($x)) !== '') $secNames[] = $pth;
    page_header('Topshiriq — ' . $as['title']);
    ?>
<p class="small muted"><a href="<?= e(url('qb_assign')) ?>">← Topshiriqlar</a></p>
<div class="page-head">
  <div>
    <h1><?= e($as['title']) ?></h1>
    <p class="muted"><?= (int)$as['n'] ?> ta savol · <?= e($secNames ? implode(', ', $secNames) : 'barcha bo\'limlar') ?> · <?= e(qb_assign_aud_label($as)) ?></p>
    <p><?= $closed ? '<span class="tag">Yopilgan ' . e(date('d.m.Y H:i', strtotime((string)$as['closed_at']))) . '</span>' : '<span class="tag green">Ochiq</span> muddat: <b>' . e(date('d.m.Y H:i', strtotime((string)$as['deadline']))) . '</b>' ?>
      · <?= (int)$as['review'] ? 'muddatdan keyin xatolar ko\'rsatiladi' : 'faqat natija soni ko\'rsatiladi' ?> · kod <b class="mono">#A<?= $aid ?></b></p>
  </div>
  <div class="row gap wrap">
    <a class="btn" target="_blank" href="<?= e(url('qb_assign', ['id' => $aid, 'pdf' => 'q'])) ?>" title="Savollar + javoblar varaqasi (kod #A<?= $aid ?>) — sinfda tarqatish uchun"><?= icon('download', 16) ?>PDF (savollar)</a>
    <a class="btn ghost" target="_blank" href="<?= e(url('qb_assign', ['id' => $aid, 'pdf' => 'key'])) ?>"><?= icon('download', 16) ?>PDF (kalit bilan)</a>
  </div>
</div>

<div class="stats4 s5">
  <div class="stat"><span><?= count($tests) ?></span>O'quvchilar</div>
  <div class="stat"><span><?= count($done) ?></span>Topshirdi</div>
  <div class="stat"><span><?= $started ?></span>Jarayonda</div>
  <div class="stat"><span><?= $missed ?></span><?= $closed ? 'Topshirmadi' : 'Boshlamagan' ?></div>
  <div class="stat accent"><span><?= $done ? $avg . '%' : '—' ?></span>O'rtacha natija <small class="muted">(topshirganlar)</small></div>
</div>

<?php if (!$closed): ?>
<div class="card row gap wrap center-v">
  <form method="post" class="row gap wrap center-v"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>"><input type="hidden" name="action" value="deadline">
    <label>Muddatni o'zgartirish <input type="datetime-local" name="deadline" value="<?= e(date('Y-m-d\TH:i', strtotime((string)$as['deadline']))) ?>" required></label>
    <button class="btn">Saqlash</button></form>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>"><button class="btn" name="action" value="remind" <?= tg_ready() ? '' : 'disabled title="Telegram bot ulanmagan"' ?>>🔔 Topshirmaganlarga eslatma (Telegram)</button></form>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>"><button class="btn danger-ghost" name="action" value="close" onclick="return confirm('Topshiriq hozir yopilsinmi? Yakunlanmagan testlar saqlangan javoblar bilan tekshiriladi.')">Hozir yopish</button></form>
</div>
<?php endif; ?>

<h2 class="mt">O'quvchilar</h2>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>O'quvchi</th><th>Guruh</th><th>Holat</th><th class="num">Natija</th><th class="num">%</th><th>Topshirgan vaqti</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($tests as $t): $p = (int)$t['n'] > 0 && $t['status'] === 'done' ? (int)round(100 * (int)$t['correct'] / (int)$t['n']) : null; ?>
    <tr>
      <td><?= e($t['full_name']) ?> <span class="muted small mono"><?= e($t['code']) ?></span><?= $t['tg_chat_id'] !== null ? ' <span class="tag blue" title="Telegram ulangan">TG</span>' : '' ?></td>
      <td><?= e($t['group_name']) ?></td>
      <td><?= $t['status'] === 'missed' ? '<span class="tag red">topshirmadi</span>' : ($t['status'] === 'done' ? '<span class="tag green">topshirdi</span>' : ((int)$t['answered'] > 0 ? '<span class="tag amber">jarayonda · ' . (int)$t['answered'] . '/' . (int)$t['n'] . '</span>' : '<span class="tag">boshlamagan</span>')) ?></td>
      <td class="num"><?= $t['status'] === 'done' ? '<b>' . (int)$t['correct'] . '</b> / ' . (int)$t['n'] : '—' ?></td>
      <td class="num"><?= $p !== null ? '<span class="pct ' . pct_cls($p) . '">' . $p . '%</span>' : '' ?></td>
      <td class="nowrap small"><?= $t['finished_at'] && $t['status'] === 'done' ? e(date('d.m.Y H:i', strtotime((string)$t['finished_at']))) : '' ?></td>
      <td class="right"><?php if ($t['status'] === 'done'): ?><a class="btn sm ghost" href="<?= e(url('qb_assign', ['id' => $aid, 'tid' => $t['id']])) ?>">Javoblari</a><?php endif; ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>

<h2 class="mt">Savollar bo'yicha</h2>
<p class="muted small">Qaysi savol qiyin bo'lganini ko'rsatadi: topshirganlar orasida to'g'ri javob berganlar ulushi va eng ko'p tanlangan xato javob.</p>
<div class="table-wrap"><table class="tbl qb-qtbl">
  <thead><tr><th class="num">№</th><th>Savol</th><th>To'g'ri javob</th><th class="num">To'g'ri</th><th>Ko'p uchragan xato</th></tr></thead>
  <tbody>
  <?php foreach ($qstat as $q): $n = (int)$q['n']; $p = $n ? (int)round(100 * (int)$q['k'] / $n) : null; ?>
    <tr>
      <td class="num"><b><?= (int)$q['pos'] ?></b></td>
      <td><?php if ($q['img']): ?><img class="qb-thumb" loading="lazy" alt="<?= (int)$q['pos'] ?>-savol" src="<?= e(url('qb_img', ['id' => $q['question_id'], 'v' => substr((string)$q['img'], 1, 8)])) ?>"><?php else: ?><span class="muted small">o'chirilgan</span><?php endif; ?>
        <div class="small muted"><?= e($q['section_name']) ?></div></td>
      <td class="mono"><?= e(qb_answer_show($q['kind'], $q['answer'])) ?></td>
      <td class="num"><?= $p !== null ? '<span class="pct ' . pct_cls($p) . '">' . $p . '%</span> <span class="muted small">' . (int)$q['k'] . '/' . $n . '</span>' : '—' ?></td>
      <td class="mono small"><?= e($wrong[(int)$q['pos']] ?? '') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>

<form method="post" class="mt"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>">
  <button class="btn danger-ghost" name="action" value="delete" onclick="return confirm('Topshiriq va o\'quvchilarning shu topshiriqdagi javoblari o\'chirilsinmi?')">Topshiriqni o'chirish</button></form>
    <?php
    page_footer();
    return;
}

/* ---------------- Ro'yxat va yangi topshiriq ---------------- */
$list = rows('SELECT a.*, (SELECT COUNT(*) FROM qb_tests t WHERE t.assign_id=a.id) total, (SELECT COUNT(*) FROM qb_tests t WHERE t.assign_id=a.id AND t.status="done") done,
                     (SELECT AVG(t.correct / NULLIF(t.n,0)) FROM qb_tests t WHERE t.assign_id=a.id AND t.status="done") avgp
              FROM qb_assign a ORDER BY a.id DESC LIMIT 100');
$tree = array_values(array_filter(qb_tree(), fn($s) => $s['ready_total'] > 0));
$groups = array_column(rows('SELECT DISTINCT group_name FROM students WHERE group_name<>"" AND archived_at IS NULL ORDER BY group_name'), 'group_name');
page_header('Topshiriqlar');
?>
<div class="page-head">
  <div><h1>Topshiriqlar</h1>
    <p class="muted">Savollar bazasidan test tuzib, guruhga yoki barcha o'quvchilarga muddat bilan yuboring. Javoblar avtomatik tekshiriladi; o'quvchi saytda yoki Telegram botda yechadi.</p></div>
  <a class="btn ghost" href="<?= e(url('qb_mastery')) ?>"><?= icon('chart', 16) ?>O'zlashtirish</a>
</div>

<?php if (!$tree): ?>
  <div class="card empty">Avval savollar bazasiga kalitli savollar qo'shing. <a href="<?= e(url('qb')) ?>">Savollar bazasi →</a></div>
<?php else: ?>
<details class="card" <?= $list ? '' : 'open' ?>>
  <summary><b>+ Yangi topshiriq</b></summary>
  <form method="post" class="form mt"><?= csrf_field() ?><input type="hidden" name="action" value="create">
    <div class="grid2">
      <div>
        <label>Nomi <input name="title" maxlength="150" placeholder="masalan: Tenglamalar — 1-hafta"></label>
        <fieldset><legend>Bo'limlar <span class="muted small">— tanlanmasa, barcha bo'limlardan</span></legend>
          <div class="qb-pick">
          <?php foreach ($tree as $s): ?>
            <label class="check" style="margin-left: <?= $s['depth'] * 1.3 ?>rem"><input type="checkbox" name="sec[]" value="<?= $s['id'] ?>"><span><?= e($s['name']) ?> <span class="muted small">· <?= $s['ready_total'] ?></span></span></label>
          <?php endforeach; ?>
          </div>
        </fieldset>
      </div>
      <div>
        <div class="grid2">
          <label>Savollar soni <input type="number" name="n" value="10" min="1" max="60" required></label>
          <label>Muddat <input type="datetime-local" name="deadline" value="<?= e(date('Y-m-d\TH:i', strtotime('+3 days 21:00'))) ?>" required></label>
        </div>
        <fieldset><legend>Kimga</legend>
          <label class="check"><input type="radio" name="aud" value="groups" checked> Tanlangan guruhlar</label>
          <div class="qb-pick" style="max-height:10rem">
            <?php foreach ($groups as $g): ?><label class="check"><input type="checkbox" name="groups[]" value="<?= e($g) ?>"><span><?= e($g) ?></span></label><?php endforeach; ?>
            <?php if (!$groups): ?><span class="muted small">Guruhlar yo'q — o'quvchilarga guruh biriktiring yoki «Barcha o'quvchilar» ni tanlang.</span><?php endif; ?>
          </div>
          <label class="check"><input type="radio" name="aud" value="all"> Barcha o'quvchilar</label>
        </fieldset>
        <label class="check"><input type="checkbox" name="review" value="1" checked> Muddat tugagach o'quvchiga xatolari va to'g'ri javoblar ko'rsatilsin</label>
        <label class="check"><input type="checkbox" name="notify" value="1" <?= tg_ready() ? 'checked' : 'disabled' ?>> Telegram botga xabar yuborilsin <?= tg_ready() ? '' : '<span class="muted small">(bot ulanmagan)</span>' ?></label>
      </div>
    </div>
    <button class="btn primary"><?= icon('check', 16) ?>Tuzish va yuborish</button>
  </form>
</details>
<?php endif; ?>

<?php if ($list): ?>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>Topshiriq</th><th>Kimga</th><th class="num">Savol</th><th>Muddat</th><th class="num">Topshirdi</th><th class="num">O'rtacha</th></tr></thead>
  <tbody>
  <?php foreach ($list as $a): $p = $a['avgp'] !== null ? (int)round(100 * (float)$a['avgp']) : null; ?>
    <tr>
      <td><a href="<?= e(url('qb_assign', ['id' => $a['id']])) ?>"><b><?= e($a['title']) ?></b></a></td>
      <td class="small"><?= e(qb_assign_aud_label($a)) ?></td>
      <td class="num"><?= (int)$a['n'] ?></td>
      <td class="nowrap small"><?= e(date('d.m.Y H:i', strtotime((string)$a['deadline']))) ?> <?= $a['closed_at'] !== null ? '<span class="tag">yopilgan</span>' : '<span class="tag green">ochiq</span>' ?></td>
      <td class="num"><?= (int)$a['done'] ?> / <?= (int)$a['total'] ?></td>
      <td class="num"><?= $p !== null ? '<span class="pct ' . pct_cls($p) . '">' . $p . '%</span>' : '—' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php elseif ($tree): ?><div class="card empty">Hali topshiriq yo'q.</div><?php endif; ?>
<?php page_footer();
