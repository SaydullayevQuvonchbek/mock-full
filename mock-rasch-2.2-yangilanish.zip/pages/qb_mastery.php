<?php
defined('APP_ROOT') || exit;
/** Admin: o'quvchilarning bo'limlar bo'yicha o'zlashtirishi — guruh jadvali va bitta o'quvchi tafsiloti */
qb_assign_tick();
$sid = (int)($_GET['sid'] ?? 0);

if ($sid) {
    $s = row('SELECT * FROM students WHERE id=?', [$sid]);
    if (!$s) { flash('O\'quvchi topilmadi', 'err'); redirect('qb_mastery'); }
    $m = qb_mastery($sid);
    $mock = student_section_avg(student_history($sid));
    $tests = rows('SELECT t.*, a.closed_at FROM qb_tests t LEFT JOIN qb_assign a ON a.id=t.assign_id WHERE t.student_id=? ORDER BY t.id DESC LIMIT 60', [$sid]);
    page_header('O\'zlashtirish — ' . $s['full_name']);
    ?>
<p class="small muted"><a href="<?= e(url('qb_mastery', $s['group_name'] !== '' ? ['g' => $s['group_name']] : [])) ?>">← O'zlashtirish</a></p>
<h1><?= e($s['full_name']) ?> <span class="muted small">ID <?= e($s['code']) ?><?= $s['group_name'] ? ' · ' . e($s['group_name']) : '' ?></span></h1>
<?php include __DIR__ . '/_mastery_cards.php'; ?>
<h2 class="mt">Mashq va topshiriqlar</h2>
<?php if (!$tests): ?><div class="card empty">Hali mashq yoki topshiriq yo'q.</div><?php else: ?>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>Sana</th><th>Turi</th><th>Nomi</th><th class="num">Natija</th><th></th></tr></thead>
  <tbody><?php foreach ($tests as $t): $p = $t['status'] === 'done' && (int)$t['n'] > 0 ? (int)round(100 * (int)$t['correct'] / (int)$t['n']) : null; ?>
    <tr><td class="nowrap small"><?= e(date('d.m.Y H:i', strtotime((string)$t['created_at']))) ?></td>
      <td><?= $t['assign_id'] ? '<span class="tag blue">topshiriq</span>' : '<span class="tag">mashq</span>' ?> <?= $t['via'] === 'bot' ? '<span class="muted small">bot</span>' : '' ?></td>
      <td><?= $t['assign_id'] ? '<a href="' . e(url('qb_assign', ['id' => $t['assign_id']])) . '">' . e($t['title']) . '</a>' : e($t['title']) ?></td>
      <td class="num"><?= $p !== null ? '<b>' . (int)$t['correct'] . '</b> / ' . (int)$t['n'] . ' <span class="pct ' . pct_cls($p) . '">' . $p . '%</span>' : ($t['status'] === 'missed' ? '<span class="tag red">topshirmadi</span>' : '<span class="tag amber">ochiq</span>') ?></td>
      <td class="right"><?php if ($t['assign_id'] && $t['status'] === 'done'): ?><a class="btn sm ghost" href="<?= e(url('qb_assign', ['id' => $t['assign_id'], 'tid' => $t['id']])) ?>">Javoblari</a><?php endif; ?></td></tr>
  <?php endforeach; ?></tbody>
</table></div>
<?php endif; ?>
    <?php
    page_footer();
    return;
}

$groups = array_column(rows('SELECT DISTINCT group_name FROM students WHERE group_name<>"" AND archived_at IS NULL ORDER BY group_name'), 'group_name');
$g = (string)($_GET['g'] ?? ($groups[0] ?? ''));
if ($g !== '' && !in_array($g, $groups, true)) $g = '';
$G = qb_mastery_group($g);
$mockBy = [];
foreach ($G['students'] as $s) $mockBy[(int)$s['id']] = student_section_avg(student_history((int)$s['id']));
$cell = function (?array $nk): string {
    if (!$nk || (int)$nk[0] === 0) return '<td class="num muted">—</td>';
    $p = (int)round(100 * $nk[1] / $nk[0]);
    return '<td class="num"><span class="pct ' . pct_cls($p) . '">' . $p . '%</span> <span class="muted small">' . (int)$nk[1] . '/' . (int)$nk[0] . '</span></td>';
};
page_header('O\'zlashtirish');
?>
<div class="page-head">
  <div><h1>O'zlashtirish</h1>
    <p class="muted">Har bir o'quvchining bo'limlar bo'yicha to'g'ri javoblar ulushi: MOCK (Algebra, Geometriya) va savollar bazasi bo'limlari (mashq + topshiriqlar).</p></div>
  <form method="get" class="row gap center-v"><input type="hidden" name="p" value="qb_mastery">
    <label>Guruh <select name="g" onchange="this.form.submit()"><option value="">Barcha o'quvchilar</option>
      <?php foreach ($groups as $x): ?><option value="<?= e($x) ?>" <?= $x === $g ? 'selected' : '' ?>><?= e($x) ?></option><?php endforeach; ?></select></label>
  </form>
</div>
<?php if (!$G['students']): ?><div class="card empty">Bu guruhda o'quvchi yo'q.</div><?php else: ?>
<div class="table-wrap"><table class="tbl mastery-tbl">
  <thead><tr><th>O'quvchi</th>
    <?php foreach (SECTION_NAMES as $k => $nm): ?><th class="num" title="<?= e($nm) ?>">MOCK: <?= $k === 'A' ? 'Algebra' : 'Geometriya' ?></th><?php endforeach; ?>
    <?php foreach ($G['roots'] as $rid => $rn): ?><th class="num"><?= e($rn) ?></th><?php endforeach; ?>
    <th class="num">Bazada jami</th></tr></thead>
  <tbody>
  <?php foreach ($G['students'] as $s): $row = $G['rows'][(int)$s['id']] ?? []; $tn = 0; $tk = 0; foreach ($row as $nk) { $tn += $nk[0]; $tk += $nk[1]; } ?>
    <tr>
      <td><a href="<?= e(url('qb_mastery', ['sid' => $s['id']])) ?>"><?= e($s['full_name']) ?></a> <span class="muted small mono"><?= e($s['code']) ?></span></td>
      <?php foreach (array_keys(SECTION_NAMES) as $k): $mm = $mockBy[(int)$s['id']][$k] ?? null; ?><?= $cell($mm ? [$mm['total'], $mm['ok']] : null) ?><?php endforeach; ?>
      <?php foreach (array_keys($G['roots']) as $rid): ?><?= $cell($row[$rid] ?? null) ?><?php endforeach; ?>
      <?= $cell($tn ? [$tn, $tk] : null) ?>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<p class="small muted">Rang: <span class="pct hi">70%+</span> yaxshi · <span class="pct mid">40–69%</span> o'rtacha · <span class="pct lo">40% dan past</span> — qayta ishlash kerak. Kasr — to'g'ri / jami javob.</p>
<?php endif; ?>
<?php page_footer();
