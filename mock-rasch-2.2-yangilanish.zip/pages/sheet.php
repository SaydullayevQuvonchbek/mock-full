<?php
defined('APP_ROOT') || exit;
require_once APP_ROOT . '/inc/sheet_layout.php';
$test = get_test_or_404();
$L = sheet_layout($test);
global $CONFIG;
$group = $_GET['group'] ?? null;
$regMode = $group === '@reg';
// Chop etilgandan keyin varaqlarni "chop etilgan" deb belgilash (brauzerning afterprint hodisasidan yoki tugmadan)
if (is_post() && ($_POST['action'] ?? '') === 'mark_printed') {
    csrf_check();
    $ids = array_values(array_filter(array_map('intval', explode(',', (string)($_POST['sids'] ?? '')))));
    if ($ids) q('UPDATE test_registrations SET printed_at=NOW() WHERE test_id=? AND student_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', array_merge([$test['id']], $ids));
    json_out(['ok' => true, 'n' => count($ids)]);
}
$students = [];
$regOpt = ['only' => (string)($_GET['only'] ?? ''), 'room' => (string)($_GET['room'] ?? ''), 'sid' => (int)($_GET['sid'] ?? 0), 'order' => (string)($_GET['order'] ?? 'room'),
    // "Ro'yxat" sahifasidagi filtr va belgilanganlar
    'sids' => (string)($_GET['sids'] ?? ''), 'group' => (string)($_GET['fg'] ?? ''), 'center' => (string)($_GET['fc'] ?? ''), 'q' => trim((string)($_GET['q'] ?? ''))];
$regHow = $regOpt['sids'] !== '' ? 'belgilanganlar' : (($regOpt['room'] . $regOpt['group'] . $regOpt['center'] . $regOpt['q']) !== '' || $regOpt['only'] === 'done' ? 'filtr bo\'yicha' : '');
if ($regOpt['only'] === 'new') $regHow = trim($regHow . ($regHow !== '' ? ', ' : '') . 'hali chop etilmaganlar');
if ($group !== null && $group !== '') {
    $students = $group === '*' ? rows('SELECT * FROM students WHERE archived_at IS NULL ORDER BY group_name, full_name')
        : ($regMode ? reg_students((int)$test['id'], $regOpt)
        : rows('SELECT * FROM students WHERE group_name=? AND archived_at IS NULL ORDER BY full_name', [$group]));
}
$hasRooms = $regMode && (bool)val('SELECT 1 FROM test_rooms WHERE test_id=? LIMIT 1', [$test['id']]);
$copies = max(1, min(200, (int)($_GET['copies'] ?? 1)));
$pages = $students ?: array_fill(0, $copies, null);
$groups = array_column(rows('SELECT DISTINCT group_name FROM students WHERE group_name<>"" ORDER BY 1'), 'group_name');

function sheet_svg(array $test, array $L, ?array $st, string $center): string
{
    $r = $L['r'];
    $o = '<svg class="sheet" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 210 297" width="210mm" height="297mm" font-family="Arial, Helvetica, sans-serif">';
    $o .= '<rect x="0" y="0" width="210" height="297" fill="#fff"/>';
    $m = $L['marker'];
    foreach ($L['markers'] as [$x, $y]) $o .= '<rect x="' . ($x - $m / 2) . '" y="' . ($y - $m / 2) . '" width="' . $m . '" height="' . $m . '" fill="#000"/>';
    foreach ($L['sides'] ?? [] as $pair) foreach ($pair as [$x, $y]) $o .= '<rect x="' . ($x - $m / 2) . '" y="' . ($y - $m / 2) . '" width="' . $m . '" height="' . $m . '" fill="#000"/>';
    $or = $L['orient'];
    $o .= '<rect x="' . $or['x'] . '" y="' . $or['y'] . '" width="' . $or['w'] . '" height="' . $or['h'] . '" fill="#000"/>';
    // Sarlavha
    $o .= '<text x="105" y="15" text-anchor="middle" font-size="6" font-weight="700">JAVOBLAR VARAQASI</text>';
    $o .= '<text x="105" y="21.5" text-anchor="middle" font-size="3.4">' . e($center) . ' · ' . e($test['subject']) . ' · milliy sertifikat formatida</text>';
    $o .= '<text x="105" y="27.5" text-anchor="middle" font-size="4" font-weight="700">' . e($test['title']) . '</text>';
    $o .= '<line x1="14" y1="31" x2="196" y2="31" stroke="#000" stroke-width="0.3"/>';
    // F.I.Sh
    $o .= '<text x="16" y="38" font-size="3.2">Familiya, ism:</text><line x1="40" y1="38.6" x2="140" y2="38.6" stroke="#000" stroke-width="0.25"/>';
    if ($st) $o .= '<text x="42" y="37.6" font-size="4" font-weight="700">' . e($st['full_name']) . '</text>';
    if ($st && array_key_exists('room_id', $st) && $st['room_id']) {
        // MOCK ro'yxatidan: guruh o'rniga xona va o'rin
        $o .= '<text x="143" y="38" font-size="3.2">Xona:</text><line x1="152" y1="38.6" x2="196" y2="38.6" stroke="#000" stroke-width="0.25"/>';
        $o .= '<text x="154" y="37.6" font-size="3.8" font-weight="700">' . e($st['room_name']) . ' · o\'rin ' . (int)$st['seat'] . '</text>';
    } else {
        $o .= '<text x="145" y="38" font-size="3.2">Guruh:</text><line x1="157" y1="38.6" x2="196" y2="38.6" stroke="#000" stroke-width="0.25"/>';
        if ($st) $o .= '<text x="159" y="37.6" font-size="3.6">' . e($st['group_name']) . '</text>';
    }
    // ID bloki
    // Ramka ichida, katakchalarning chap chetiga tekislangan (ramka: 16.5–64.5 mm, ustunlar markazi 40.5 mm)
    $o .= '<text x="20" y="46.6" font-size="3.2" font-weight="700">O\'quvchi ID</text>';
    $code = $st['code'] ?? '';
    foreach ($L['id']['cols'] as $d => $col) {
        $x = $col[0]['x'];
        $o .= '<rect x="' . ($x - 3) . '" y="49.5" width="6" height="6.5" fill="none" stroke="#000" stroke-width="0.3"/>';
        if ($code !== '') $o .= '<text x="' . $x . '" y="54.5" text-anchor="middle" font-size="4.2" font-weight="700">' . $code[$d] . '</text>';
        foreach ($col as $b) {
            $filled = $code !== '' && $code[$d] === $b['v'];
            $o .= '<circle cx="' . $b['x'] . '" cy="' . $b['y'] . '" r="' . $r . '" fill="' . ($filled ? '#000' : 'none') . '" stroke="#444" stroke-width="0.25"/>';
            if (!$filled) $o .= '<text x="' . $b['x'] . '" y="' . ($b['y'] + 1.05) . '" text-anchor="middle" font-size="2.6" fill="#b5b5b5">' . $b['v'] . '</text>';
        }
    }
    $o .= '<rect x="16.5" y="41.5" width="48" height="71" fill="none" stroke="#000" stroke-width="0.3" rx="1"/>';
    // Yo'riqnoma
    $ix = 72;
    $lines = [
        ['Diqqat!', 1],
        ['• Doirachani to\'liq, qora yoki ko\'k ruchka bilan bo\'yang:', 0],
        ['• Har bir savolga faqat bitta javob belgilang.', 0],
        ['• Tuzatilgan va bir nechta belgilangan javoblar hisobga olinmaydi.', 0],
        ['• ID raqamingizni katakchalarga yozing va har ustunda bitta raqamni bo\'yang.', 0],
        ['• Ochiq topshiriq javoblarini katakchaga aniq va sodda holda yozing.', 0],
        ['• ✓ / ✗ doirachalarni faqat TEKSHIRUVCHI to\'ldiradi.', 1],
        ['• Varaqni bukmang, chetdagi qora kvadratlarni to\'smang va bo\'yamang.', 0],
    ];
    $y = 50;
    foreach ($lines as [$t, $bold]) { $o .= '<text x="' . $ix . '" y="' . $y . '" font-size="3.1"' . ($bold ? ' font-weight="700"' : '') . '>' . e($t) . '</text>'; $y += 5.4; }
    $o .= '<circle cx="173" cy="54.4" r="' . $r . '" fill="#000"/><text x="177" y="55.4" font-size="2.8">to\'g\'ri</text>';
    $o .= '<circle cx="188" cy="54.4" r="' . $r . '" fill="none" stroke="#444" stroke-width="0.25"/><path d="M186.5,53 l3,3 M189.5,53 l-3,3" stroke="#000" stroke-width="0.5"/>';
    $o .= '<text x="' . $ix . '" y="' . ($y + 3) . '" font-size="3.1">Imzo: ______________________        Sana: ____________</text>';
    // Yopiq savollar
    $o .= '<text x="16" y="118.5" font-size="3.4" font-weight="700">Yopiq test topshiriqlari (1–' . count($L['mc']) . ')</text>';
    $o .= '<line x1="14" y1="120.5" x2="196" y2="120.5" stroke="#000" stroke-width="0.25"/>';
    foreach ($L['mc'] as $q) {
        $o .= '<text x="' . ($q['nx'] + 6.5) . '" y="' . ($q['y'] + 1.3) . '" text-anchor="end" font-size="3.6" font-weight="700">' . e($q['label']) . '</text>';
        foreach ($q['opts'] as $b) {
            $o .= '<circle cx="' . $b['x'] . '" cy="' . $b['y'] . '" r="' . $r . '" fill="none" stroke="#444" stroke-width="0.25"/>';
            $o .= '<text x="' . $b['x'] . '" y="' . ($b['y'] + 1.05) . '" text-anchor="middle" font-size="2.7" fill="#b5b5b5">' . $b['v'] . '</text>';
        }
    }
    // Ochiq topshiriqlar
    if ($L['open']) {
        $o .= '<text x="16" y="192" font-size="3.4" font-weight="700">Ochiq topshiriqlar — javobni katakchaga yozing</text>';
        $o .= '<text x="190" y="192" text-anchor="end" font-size="2.8">Tekshiruvchi to\'liq bo\'yaydi: ✓ — to\'g\'ri, ✗ — noto\'g\'ri</text>';
        $o .= '<line x1="14" y1="194.5" x2="196" y2="194.5" stroke="#000" stroke-width="0.25"/>';
        foreach ($L['open_rows'] as $row) {
            $o .= '<text x="' . ($row['x'] + 7) . '" y="' . ($row['y'] + 1.4) . '" text-anchor="end" font-size="3.8" font-weight="700">' . $row['no'] . '</text>';
        }
        foreach ($L['open'] as $b) {
            $bx = $b['box'];
            $o .= '<text x="' . ($bx['x'] - 1) . '" y="' . ($b['y'] + 1.1) . '" text-anchor="end" font-size="3">' . $b['part'] . ')</text>';
            $o .= '<rect x="' . $bx['x'] . '" y="' . $bx['y'] . '" width="' . $bx['w'] . '" height="' . $bx['h'] . '" fill="none" stroke="#666" stroke-width="0.25" rx="0.8"/>';
            foreach ([[$b['x'], '✓'], [$b['xw'], '✗']] as [$cx, $glyph]) {
                $o .= '<circle cx="' . $cx . '" cy="' . $b['y'] . '" r="' . $r . '" fill="none" stroke="#444" stroke-width="0.25"/>';
                $o .= '<text x="' . $cx . '" y="' . ($b['y'] + 1.0) . '" text-anchor="middle" font-size="2.7" fill="#b5b5b5">' . $glyph . '</text>';
            }
        }
    }
    if ($L['open']) {
        // Tekshiruvchi uchun ko'rsatma: doirachani to'liq bo'yash (ptichka/X emas)
        $o .= '<text x="16" y="264" font-size="2.9" font-weight="700">Tekshiruvchi: ✓ yoki ✗ doirachani TO\'LIQ bo\'yang — ptichka yoki X chizmang. Har qismda faqat bittasi.</text>';
        $o .= '<circle cx="168" cy="263" r="' . $r . '" fill="#000"/><text x="171.5" y="264" font-size="2.6">to\'g\'ri</text>';
        $o .= '<circle cx="184" cy="263" r="' . $r . '" fill="none" stroke="#444" stroke-width="0.25"/><path d="M182.9,263.1 l0.8,0.9 l1.6,-1.9" stroke="#000" stroke-width="0.35" fill="none"/>';
        $o .= '<path d="M181.4,265.6 l5.2,-5.2" stroke="#000" stroke-width="0.3"/><text x="187.5" y="264" font-size="2.6">xato</text>';
    }
    $o .= '<line x1="14" y1="268" x2="196" y2="268" stroke="#000" stroke-width="0.25"/>';
    $o .= '<text x="16" y="274" font-size="3">Tekshiruvchi: ______________________   imzo: __________</text>';
    $o .= '<text x="196" y="274" text-anchor="end" font-size="2.6" fill="#666">Test #' . (int)$test['id'] . '</text>';
    $o .= '</svg>';
    return $o;
}
page_header('Javoblar varaqasi', ['bare' => true, 'body' => 'print-page sheet-page']);
?>
<div class="no-print toolbar">
  <button class="btn primary" onclick="print()">🖨 Chop etish</button>
  <details class="print-help">
    <summary>Xira chiqyaptimi?</summary>
    <div class="print-help-body">
      <p><b>Varaqning o'zi tiniq (vektor)</b> — xiralik printer sozlamasidan. Chrome o'z oynasidan chop etganda printerning <i>standart</i> sozlamalarini oladi, siz printer xususiyatlarida tanlagan sifat va toner zichligini emas. PDF orqali tiniq chiqishining sababi shu.</p>
      <ol>
        <li><b>Tezkor yo'l:</b> <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>P</kbd> bosing — Windows'ning chop etish oynasi ochiladi. Printerni tanlab <b>Xususiyatlar</b> (Свойства / Properties) → sifat: eng yuqori (600 yoki 1200 dpi), <b>toner tejash</b> (Экономия тонера / EconoMode) — o'chiq.</li>
        <li><b>Chrome oynasida:</b> "Yana sozlamalar" (Дополнительные настройки) → <b>Sifat</b>: eng katta dpi; Masshtab: standart (100%); Chekkalar: yo'q.</li>
        <li><b>Bir marta sozlab qo'yish:</b> Windows → Printerlar va skanerlar → printeringiz → <b>Printer xususiyatlari</b> → "Qo'shimcha" (Дополнительно / Advanced) → <b>Chop etish standartlari</b> (Значения по умолчанию / Printing Defaults) — shu yerda sifat va toner tejashni o'zgartiring. Chrome aynan shu sozlamani oladi.</li>
      </ol>
      <p class="muted">Yoki chop etish oynasida printer o'rniga "PDF sifatida saqlash" ni tanlab, PDF faylni chop eting.</p>
    </div>
  </details>
  <form method="get" class="row gap inline">
    <input type="hidden" name="p" value="sheet"><input type="hidden" name="id" value="<?= (int)$test['id'] ?>">
    <label>Bo'sh nusxa: <input type="number" name="copies" value="<?= $copies ?>" min="1" max="200" style="width:70px"></label>
    <label>yoki shaxsiy varaqalar (ism + ID bo'yalgan):
      <select name="group"><option value="">—</option><option value="*" <?= $group === '*' ? 'selected' : '' ?>>Barcha o'quvchilar</option><option value="@reg" <?= $group === '@reg' ? 'selected' : '' ?>>Shu MOCK ro'yxatidagilar</option>
        <?php foreach ($groups as $g): ?><option <?= $g === $group ? 'selected' : '' ?>><?= e($g) ?></option><?php endforeach; ?></select></label>
    <button class="btn">Ko'rsatish</button>
  </form>
  <span class="muted small">Chop etishda: A4, masshtab 100%, "Fon grafikasi" yoqilgan, chekkalar — yo'q.</span>
  <?php if ($regMode): ?>
    <div class="print-status" id="printStatus" data-sids="<?= e(implode(',', array_map(fn($x) => (int)$x['id'], $students))) ?>">
      <?php if ($students): ?>
        <b><?= count($students) ?> ta varaq</b><?= $regHow !== '' ? ' (' . e($regHow) . ')' : '' ?>.
        <button type="button" class="btn sm" id="markPrinted">Chop etildi deb belgilash</button>
        <a class="small" href="<?= e(url('registrations', ['id' => $test['id']])) ?>">← Ro'yxatga qaytish</a>
      <?php else: ?>
        <b>Chop etiladigan varaq yo'q</b> — <?= $regOpt['only'] === 'new' ? 'barcha varaqlar allaqachon chop etilgan.' : ($regHow !== '' ? 'filtrga mos o\'quvchi yo\'q.' : 'ro\'yxat bo\'sh.') ?> <a href="<?= e(url('registrations', ['id' => $test['id']])) ?>">Ro'yxatga qaytish</a>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>
<?php
// Xonalar bo'yicha chop etishda har xona oldidan ajratuvchi varaq (paketlarni xonalarga tarqatish oson bo'lsin)
$sep = $regMode && $hasRooms && $regOpt['order'] === 'room' && !empty($_GET['sep']);
$byRoom = [];
if ($sep) foreach ($students as $x) $byRoom[(string)($x['room_id'] ?? '')][] = $x;
$curRoom = null;
?>
<?php if (!($regMode && !$students)) foreach ($pages as $st): ?>
  <?php if ($sep && $st && (string)($st['room_id'] ?? '') !== $curRoom): $curRoom = (string)($st['room_id'] ?? ''); $grp = $byRoom[$curRoom] ?? []; ?>
  <div class="sheet-wrap room-sep">
    <div class="room-sep-in">
      <div class="rs-test"><?= e($test['title']) ?> · <?= e(app_setting('center')) ?></div>
      <div class="rs-room"><?= $curRoom !== '' ? e($st['room_name']) : 'Xonasiz' ?></div>
      <div class="rs-meta"><b><?= count($grp) ?> ta</b> javoblar varaqasi<?= $curRoom !== '' && ($st['proctor'] ?? '') !== '' ? ' · nazoratchi: <b>' . e($st['proctor']) . '</b>' : '' ?></div>
      <div class="rs-grid <?= count($grp) > 70 ? 'c3' : '' ?>">
        <?php foreach ($grp as $x): ?><div><b><?= $x['seat'] !== null ? (int)$x['seat'] : '—' ?></b> <?= e($x['full_name']) ?> <span class="mono"><?= e($x['code']) ?></span></div><?php endforeach; ?>
      </div>
      <div class="rs-note">Bu ajratuvchi varaq — skanerlanmaydi. Keyingi varaqlar o'rin tartibida.</div>
    </div>
  </div>
  <?php endif; ?>
  <div class="sheet-wrap"><?= sheet_svg($test, $L, $st, app_setting('center')) ?></div>
<?php endforeach; ?>
<?php if ($regMode && $students): ?>
<script>
(function(){
  const box = document.getElementById('printStatus'), btn = document.getElementById('markPrinted');
  const csrf = document.querySelector('meta[name=csrf]').content;
  let marked = false;
  async function mark(){
    if (marked) return; marked = true;
    const fd = new FormData(); fd.append('_csrf', csrf); fd.append('action', 'mark_printed'); fd.append('sids', box.dataset.sids);
    try {
      const r = await fetch(location.href, { method: 'POST', body: fd }).then(r => r.json());
      box.innerHTML = '<b>✓ ' + r.n + ' ta varaq "chop etilgan" deb belgilandi.</b> Keyingi safar "Faqat yangilar" ular chiqmaydi.';
    } catch (e) { marked = false; }
  }
  btn.addEventListener('click', mark);
  // Chop etish oynasi yopilgach so'raymiz (bekor qilingan bo'lishi ham mumkin)
  window.addEventListener('afterprint', () => { if (!marked && confirm('Varaqalar chop etildimi? Ular "chop etilgan" deb belgilansinmi?')) mark(); });
})();
</script>
<?php endif; ?>
<?php page_footer();
