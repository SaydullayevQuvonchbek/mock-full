<?php
defined('APP_ROOT') || exit;
$me = admin();
if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    if ($act === 'general') {
        set_app_setting('center', trim($_POST['center'] ?? ''));
        $pu = trim($_POST['public_url'] ?? '');
        if ($pu !== '' && !preg_match('#^https?://[^\s]+$#i', $pu)) { flash('Sayt manzili http:// yoki https:// bilan boshlansin', 'err'); redirect('settings'); }
        set_app_setting('public_url', $pu);
        flash('Sozlamalar saqlandi');
    }
    if ($act === 'rooms') {
        [$list, $bad] = center_rooms_parse((string)($_POST['rooms'] ?? ''));
        if ($bad) { flash('Xonalar saqlanmadi — tushunarsiz qatorlar: ' . implode(', ', array_slice($bad, 0, 5)) . '. Namuna: «1-xona; 30; Karimova D.»', 'err'); $_SESSION['rooms_draft'] = (string)($_POST['rooms'] ?? ''); redirect('settings'); }
        q('DELETE FROM center_rooms');
        foreach ($list as $i => $r) q('INSERT INTO center_rooms (name, capacity, proctor, sort) VALUES (?,?,?,?)', [$r['name'], $r['capacity'], $r['proctor'], $i + 1]);
        flash($list ? count($list) . ' ta xona saqlandi (jami ' . array_sum(array_column($list, 'capacity')) . ' o\'rin). MOCK ning «Ro\'yxat» sahifasida bir bosishda qo\'shiladi.' : 'Xonalar ro\'yxati tozalandi');
        redirect('settings');
    }
    if (tg_settings_post($act)) redirect('settings');
    if (msg_settings_post($act)) redirect('settings');
    if ($act === 'password') {
        $u = row('SELECT * FROM users WHERE id=?', [$me['id']]);
        $new = (string)($_POST['new'] ?? '');
        if (!password_verify((string)($_POST['old'] ?? ''), $u['pass_hash'])) flash('Joriy parol noto\'g\'ri', 'err');
        elseif (strlen($new) < 8) flash('Yangi parol kamida 8 belgidan iborat bo\'lsin', 'err');
        elseif ($new !== ($_POST['new2'] ?? '')) flash('Yangi parollar mos emas', 'err');
        else {
            $nh = password_hash($new, PASSWORD_DEFAULT);
            q('UPDATE users SET pass_hash=? WHERE id=?', [$nh, $me['id']]);
            session_regenerate_id(true);
            $_SESSION['admin']['sig'] = admin_session_sig($nh);   // joriy sessiya qoladi, boshqa qurilmalardagilar tugaydi
            flash('Parol o\'zgartirildi. Boshqa qurilmalardagi sessiyalar yopildi.');
        }
    }
    if ($act === 'add_admin') {
        $login = trim($_POST['login'] ?? '');
        $pass = (string)($_POST['pass'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_.-]{3,32}$/', $login)) flash('Login: 3–32 lotin harf/raqam', 'err');
        elseif (strlen($pass) < 8) flash('Parol kamida 8 belgi', 'err');
        elseif (val('SELECT 1 FROM users WHERE login=?', [$login])) flash('Bunday login bor', 'err');
        else { q('INSERT INTO users (login, pass_hash, name, role) VALUES (?,?,?,?)', [$login, password_hash($pass, PASSWORD_DEFAULT), trim($_POST['name'] ?? ''), 'admin']); flash('Administrator qo\'shildi'); }
    }
    if ($act === 'del_admin') {
        $id = (int)$_POST['id'];
        if ($id === (int)$me['id']) flash('O\'zingizni o\'chira olmaysiz', 'err');
        elseif ((int)val('SELECT COUNT(*) FROM users') <= 1) flash('Oxirgi administratorni o\'chirib bo\'lmaydi', 'err');
        else { q('DELETE FROM users WHERE id=?', [$id]); flash('Administrator o\'chirildi'); }
    }
    redirect('settings');
}
$users = rows('SELECT id, login, name, last_login, created_at FROM users ORDER BY id');
$fails = rows('SELECT kind, ident, ip, COUNT(*) n, MAX(created_at) last FROM login_attempts WHERE created_at > ? AND kind IN ("admin","student") GROUP BY kind, ident, ip ORDER BY last DESC LIMIT 15', [date('Y-m-d H:i:s', time() - 86400)]);
$installExists = is_file(APP_ROOT . '/install.php');
page_header('Sozlamalar');
?>
<div class="page-head"><div><h1>Sozlamalar</h1><p class="muted" style="margin:0">Markaz ma'lumotlari, administratorlar va xavfsizlik.</p></div></div>
<?php if ($installExists): ?><div class="alert warn"><?= icon('alert') ?><span><b>install.php</b> fayli hali serverda turibdi. U <code>config.php</code> bor paytda ishlamaydi, lekin hostingga chiqarganda uni o'chirib qo'yish tavsiya etiladi.</span></div><?php endif; ?>
<?php if (!is_https() && !in_array($_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1'], true) && !str_starts_with((string)($_SERVER['HTTP_HOST'] ?? ''), 'localhost:')): ?>
  <div class="alert warn"><?= icon('alert') ?><span>Sayt <b>HTTPS</b> siz ishlayapti. Internetga chiqarilganda parollar ochiq uzatiladi — hostingda bepul SSL (Let's Encrypt) ni yoqing.</span></div>
<?php endif; ?>
<div class="grid2 settings-grid">
  <div class="card">
    <h2>Markaz</h2>
    <form method="post" class="form">
      <?= csrf_field() ?><input type="hidden" name="action" value="general">
      <label>O'quv markazi nomi <input name="center" value="<?= e(app_setting('center')) ?>"></label>
      <label>Sayt manzili (internetda) <input name="public_url" value="<?= e(app_setting('public_url')) ?>" placeholder="https://moc.markazim.uz"></label>
      <p class="small muted" style="margin-top:-.4rem">Sertifikatdagi QR va ro'yxat havolasi shu manzil bilan yasaladi. Bo'sh bo'lsa — joriy manzil (localhost) ishlatiladi, u telefondan ochilmaydi.</p>
      <button class="btn primary">Saqlash</button>
    </form>
  </div>
  <?php $cr = center_rooms(); $draft = $_SESSION['rooms_draft'] ?? null; unset($_SESSION['rooms_draft']); ?>
  <div class="card" id="xonalar">
    <h2>Xonalar va sig'im</h2>
    <p class="small muted">Markazdagi imtihon xonalari. Har MOCK da qaytadan kiritish shart emas — «Ro'yxat» sahifasida «Markaz xonalarini qo'shish» tugmasi bilan bir bosishda qo'shiladi.</p>
    <form method="post" class="form">
      <?= csrf_field() ?><input type="hidden" name="action" value="rooms">
      <label>Har qatorda bitta xona: <code>Nomi; sig'im; nazoratchi</code> <span class="muted">(nazoratchi ixtiyoriy)</span>
        <textarea name="rooms" rows="6" class="mono" placeholder="1-xona; 30; Karimova Dilnoza&#10;2-xona; 24&#10;Majlislar zali; 60"><?= e($draft ?? implode("\n", array_map(fn($r) => $r['name'] . '; ' . (int)$r['capacity'] . ($r['proctor'] !== '' ? '; ' . $r['proctor'] : ''), $cr))) ?></textarea></label>
      <?php if ($cr): ?><p class="small muted" style="margin-top:-.4rem"><?= count($cr) ?> ta xona · jami <b><?= array_sum(array_map(fn($r) => (int)$r['capacity'], $cr)) ?></b> o'rin</p><?php endif; ?>
      <button class="btn primary">Saqlash</button>
    </form>
  </div>
  <div class="card">
    <h2>Parolni o'zgartirish</h2>
    <form method="post" class="form" autocomplete="off">
      <?= csrf_field() ?><input type="hidden" name="action" value="password">
      <label>Joriy parol <input type="password" name="old" required autocomplete="current-password"></label>
      <label>Yangi parol (≥ 8 belgi) <input type="password" name="new" required minlength="8" autocomplete="new-password"></label>
      <label>Yangi parol (takror) <input type="password" name="new2" required minlength="8" autocomplete="new-password"></label>
      <button class="btn primary">O'zgartirish</button>
    </form>
  </div>
  <div class="card">
    <h2>Administratorlar</h2>
    <table class="tbl compact-tbl"><thead><tr><th>Login</th><th>Ism</th><th>Oxirgi kirish</th><th></th></tr></thead><tbody>
      <?php foreach ($users as $u): ?>
        <tr><td class="mono"><?= e($u['login']) ?></td><td><?= e($u['name']) ?></td><td class="small muted"><?= e($u['last_login'] ?? '—') ?></td>
          <td class="right"><?php if ((int)$u['id'] !== (int)$me['id']): ?><form method="post" class="inline" onsubmit="return confirm('Administrator o\'chirilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="del_admin"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>"><button class="btn sm danger-ghost">×</button></form><?php else: ?><span class="tag">siz</span><?php endif; ?></td></tr>
      <?php endforeach; ?>
    </tbody></table>
    <form method="post" class="form mt" autocomplete="off">
      <?= csrf_field() ?><input type="hidden" name="action" value="add_admin">
      <div class="grid3"><label>Login <input name="login" required pattern="[A-Za-z0-9_.\-]{3,32}"></label><label>Ism <input name="name"></label><label>Parol <input type="password" name="pass" required minlength="8" autocomplete="new-password"></label></div>
      <button class="btn">Administrator qo'shish</button>
    </form>
  </div>
  <div class="card">
    <h2>Xavfsizlik</h2>
    <ul class="check-list small">
      <li>Parollar <b>bcrypt</b> bilan xeshlanadi, ochiq saqlanmaydi.</li>
      <li>Kirish: 15 daqiqada 5 ta xato urinishdan keyin shu login/ID + IP juftligi bloklanadi (login/ID bo'yicha jami 20, IP bo'yicha 30).</li>
      <li>Barcha formalar CSRF tokeni bilan himoyalangan; SQL so'rovlar parametrlangan (SQL injection yo'q).</li>
      <li>Sessiya cookie: HttpOnly, SameSite; admin 4 soat harakatsiz bo'lsa chiqariladi. Parol o'zgarsa yoki admin o'chirilsa — uning barcha sessiyalari darhol tugaydi.</li>
      <li>HTTP sarlavhalar: CSP, X-Frame-Options, nosniff; <code>inc/</code>, <code>pages/</code>, <code>config.php</code> ga to'g'ridan-to'g'ri kirish yopiq.</li>
      <li>Savollar PDF fayli faqat admin va testni boshlagan o'quvchiga (vaqti tugaguncha) beriladi — to'g'ridan-to'g'ri havola ishlamaydi.</li>
      <li>Sertifikat tekshiruvi: ism va ball faqat QR yoki hujjatdagi o'quvchi ID bilan ochiladi.</li>
      <li>Excel eksportida formula-injeksiyadan himoya; yuklangan PDF haqiqiyligi tekshiriladi.</li>
      <?php if (!behind_trusted_proxy()): ?><li class="muted">Sayt Cloudflare/nginx proksi orqasida bo'lsa <code>config.php</code> ga <code>'trusted_proxy' =&gt; true</code> qo'shing — aks holda barcha tashrifchilar bitta IP ko'rinadi va cheklovlar noto'g'ri ishlaydi.</li><?php endif; ?>
    </ul>
    <h3 class="mt">So'nggi 24 soatdagi xato kirishlar</h3>
    <?php if (!$fails): ?><p class="small muted">Yo'q.</p><?php else: ?>
    <table class="tbl compact-tbl"><thead><tr><th>Tur</th><th>Login/ID</th><th>IP</th><th class="num">Soni</th><th>Oxirgi</th></tr></thead><tbody>
      <?php foreach ($fails as $f): ?><tr class="<?= $f['n'] >= 5 ? 'flag-red' : '' ?>"><td><?= $f['kind'] === 'admin' ? 'Admin' : 'O\'quvchi' ?></td><td class="mono"><?= e($f['ident']) ?></td><td class="mono small"><?= e($f['ip']) ?></td><td class="num"><?= (int)$f['n'] ?></td><td class="small muted"><?= e(substr($f['last'], 11, 5)) ?></td></tr><?php endforeach; ?>
    </tbody></table>
    <?php endif; ?>
  </div>
  <?php msg_settings_card(); ?>
  <?php tg_settings_card(); ?>
</div>
<?php page_footer();
