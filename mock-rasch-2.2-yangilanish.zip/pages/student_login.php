<?php
defined('APP_ROOT') || exit;
// Kirgandan keyin qaytish joyi (faqat ruxsat etilgan sahifa — ochiq yo'naltirishga yo'l qo'yilmaydi)
$next = ($_POST['next'] ?? $_GET['next'] ?? '') === 'moc' ? 'moc' : '';
$nextTest = (int)($_POST['test'] ?? $_GET['test'] ?? 0);
$goNext = function () use ($next, $nextTest) { $next ? redirect('moc', $nextTest ? ['test' => $nextTest] : []) : redirect('student_home'); };
if (student()) $goNext();
$err = '';
$ident = trim((string)($_POST['ident'] ?? $_POST['code'] ?? $_GET['ident'] ?? $_GET['code'] ?? ''));
if (is_post()) {
    csrf_check();
    $pass = (string)($_POST['pass'] ?? $_POST['pin'] ?? '');
    $s = $ident !== '' ? student_find_by_ident($ident) : null;
    $key = student_ident_key($ident, $s);
    $wait = throttle_wait('student', $key);
    if ($wait) {
        $err = "Juda ko'p noto'g'ri urinish. $wait daqiqadan keyin qayta urinib ko'ring.";
    } else {
        $okp = $s && student_pass_check($s, $pass);
        if ($okp && $s['archived_at'] !== null) {
            throttle_clear('student', $key);
            $err = 'Hisobingiz arxivlangan. O\'quv markaziga murojaat qiling.';
        } elseif ($okp) {
            throttle_clear('student', $key);
            $mc = (int)$s['must_change'] === 1;   // admin bergan / eski PIN — o'quvchi o'z parolini belgilaydi
            student_session_start($s, $mc);
            if ($mc) { $_SESSION['after_pass'] = $next ? ['p' => 'moc', 'test' => $nextTest] : null; redirect('student_setpass'); }
            $goNext();
        }
        if ($err === '') {
            throttle_fail('student', $key);
            usleep(300000);
            $err = 'ID/telefon yoki parol noto\'g\'ri';
        }
    }
}
page_header('Kirish', ['main' => 'narrow-main']);
?>
<div class="card narrow">
  <h1>Kirish</h1>
  <?php if ($next === 'moc'): $nt = $nextTest ? val('SELECT title FROM tests WHERE id=?', [$nextTest]) : null; ?>
    <div class="alert info small"><?= icon('key') ?><span><?= $nt ? '<b>' . e($nt) . '</b> ga' : 'MOCK ga' ?> ro'yxatdan o'tish uchun kiring — formani qayta to'ldirish shart emas.</span></div>
  <?php endif; ?>
  <p class="muted">6 xonali ID raqamingiz <b>yoki</b> telefon raqamingiz va parolingizni kiriting. Parolni birinchi marta o'quv markazi bergan bo'lsa, kirgach o'zingiz yangisini belgilaysiz.</p>
  <?php if ($err): ?><div class="alert err"><?= e($err) ?></div><?php endif; ?>
  <form method="post" class="form">
    <?= csrf_field() ?>
    <?php if ($next): ?><input type="hidden" name="next" value="moc"><input type="hidden" name="test" value="<?= (int)$nextTest ?>"><?php endif; ?>
    <label>ID yoki telefon <input name="ident" value="<?= e($ident) ?>" maxlength="20" required autofocus class="big-input" autocomplete="username" placeholder="123456 yoki +998 90 123 45 67"></label>
    <label>Parol <input name="pass" type="password" required class="big-input" autocomplete="current-password"></label>
    <button class="btn primary wide">Kirish</button>
  </form>
  <p class="small mt"><a href="<?= e(url('student_reset')) ?>">Parolni unutdingizmi?</a></p>
  <p class="small muted">Hali ro'yxatdan o'tmaganmisiz? <a href="<?= e(url('register', $nextTest ? ['test' => $nextTest] : [])) ?>">MOCK ga ro'yxatdan o'tish</a></p>
</div>
<?php page_footer();
