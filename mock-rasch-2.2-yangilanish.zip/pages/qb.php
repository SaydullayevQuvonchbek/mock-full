<?php
defined('APP_ROOT') || exit;
/** Savollar bazasi: bo'limlar daraxti (qo'shish, nomini o'zgartirish, tartib, o'chirish) */
if (is_post()) {
    csrf_check();
    $a = (string)($_POST['action'] ?? '');
    $id = (int)($_POST['id'] ?? 0);
    if ($a === 'add') {
        $name = trim(preg_replace('/\s+/u', ' ', (string)($_POST['name'] ?? '')));
        $parent = (int)($_POST['parent_id'] ?? 0);
        if ($name === '' || mb_strlen($name) > 120) flash('Bo\'lim nomini kiriting (120 belgigacha)', 'err');
        elseif ($parent && !row('SELECT 1 FROM qb_sections WHERE id=?', [$parent])) flash('Ota bo\'lim topilmadi', 'err');
        elseif ($parent && count(explode(' › ', qb_section_path($parent))) >= 5) flash('Bo\'limlar 5 darajadan chuqur bo\'lmasin', 'err');
        else {
            $sort = (int)val('SELECT COALESCE(MAX(sort),0) FROM qb_sections WHERE parent_id <=> ?', [$parent ?: null]) + 1;
            q('INSERT INTO qb_sections (parent_id, name, sort) VALUES (?,?,?)', [$parent ?: null, $name, $sort]);
            flash('Bo\'lim qo\'shildi: ' . $name);
        }
    } elseif ($a === 'rename' && $id) {
        $name = trim(preg_replace('/\s+/u', ' ', (string)($_POST['name'] ?? '')));
        if ($name === '' || mb_strlen($name) > 120) flash('Bo\'lim nomi noto\'g\'ri', 'err');
        else { q('UPDATE qb_sections SET name=? WHERE id=?', [$name, $id]); flash('Nomi o\'zgartirildi'); }
    } elseif (($a === 'up' || $a === 'down') && $id) {
        $me = row('SELECT id, parent_id, sort FROM qb_sections WHERE id=?', [$id]);
        if ($me) {
            // tengdosh bo'limlarni tartibda olib, ikkitasining o'rnini almashtiramiz (sort qiymatlari qayta raqamlanadi)
            $sib = rows('SELECT id FROM qb_sections WHERE parent_id <=> ? ORDER BY sort, name, id', [$me['parent_id']]);
            $ids = array_map('intval', array_column($sib, 'id'));
            $i = array_search($id, $ids, true);
            $j = $a === 'up' ? $i - 1 : $i + 1;
            if ($i !== false && isset($ids[$j])) { [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]]; }
            foreach ($ids as $k => $sid) q('UPDATE qb_sections SET sort=? WHERE id=?', [$k + 1, $sid]);
        }
    } elseif ($a === 'delete' && $id) {
        $n = qb_delete_section($id);
        flash('Bo\'lim o\'chirildi' . ($n > 1 ? ' (ichki bo\'limlar bilan: ' . $n . ' ta)' : ''));
    }
    redirect('qb');
}

$tree = qb_tree();
$totQ = (int)val('SELECT COUNT(*) FROM qb_questions');
$totR = (int)val("SELECT COUNT(*) FROM qb_questions WHERE answer<>''");
$nTests = (int)val('SELECT COUNT(*) FROM qb_tests');
page_header('Savollar bazasi');
?>
<div class="page-head">
  <div><h1>Savollar bazasi</h1>
    <p class="muted">Bo'limlar tuzing, PDF dan savollarni qirqib yuklang, javob kalitini kiriting. O'quvchilar shu savollardan tasodifiy mashq testi tuzadi.</p></div>
</div>

<div class="stats4 qb-stats">
  <div class="stat"><span><?= count($tree) ?></span>Bo'limlar</div>
  <div class="stat"><span><?= $totQ ?></span>Savollar</div>
  <div class="stat accent"><span><?= $totR ?></span>Kalitli savollar<small>mashq testlarida ishlatiladi</small></div>
  <div class="stat"><span><?= $nTests ?></span>O'quvchilar mashqlari</div>
</div>
<?php if ($totQ > $totR): ?><div class="alert warn"><?= icon('alert') ?><span><?= $totQ - $totR ?> ta savolga hali javob kaliti kiritilmagan — ular o'quvchilarga chiqmaydi.</span></div><?php endif; ?>

<div class="card">
  <div class="card-head"><h2>Bo'limlar</h2></div>
  <?php if (!$tree): ?><p class="empty">Hali bo'lim yo'q. Quyida birinchi bo'limni qo'shing (masalan, «Algebra» yoki «Geometriya»).</p><?php endif; ?>
  <?php if ($tree): ?>
  <div class="table-wrap"><table class="tbl qb-tbl">
    <thead><tr><th>Bo'lim</th><th class="num">Savol</th><th class="num">Kalitli</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($tree as $s): ?>
      <tr>
        <td style="padding-left: <?= 0.85 + $s['depth'] * 1.4 ?>rem">
          <?php if ($s['depth']): ?><span class="muted">└ </span><?php endif; ?>
          <a href="<?= e(url('qb_questions', ['s' => $s['id']])) ?>"><b><?= e($s['name']) ?></b></a>
        </td>
        <td class="num"><?= $s['own'] ?><?php if ($s['total'] > $s['own']): ?> <span class="muted small" title="ichki bo'limlar bilan">(<?= $s['total'] ?>)</span><?php endif; ?></td>
        <td class="num"><?= $s['ready'] ?><?php if ($s['own'] > $s['ready']): ?> <span class="tag amber" title="kalitsiz savollar"><?= $s['own'] - $s['ready'] ?> kalitsiz</span><?php endif; ?></td>
        <td class="right nowrap">
          <a class="btn sm" href="<?= e(url('qb_import', ['s' => $s['id']])) ?>"><?= icon('upload', 14) ?>PDF dan yuklash</a>
          <a class="btn sm ghost" href="<?= e(url('qb_questions', ['s' => $s['id']])) ?>">Savollar</a>
          <?php if ($s['total']): ?><a class="btn sm ghost" target="_blank" href="<?= e(url('qb_pdf', ['s' => $s['id'], 'key' => 1])) ?>" title="Savollar va javoblar kaliti">PDF</a><?php endif; ?>
          <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $s['id'] ?>"><button class="btn sm ghost" name="action" value="up" title="Yuqoriga">↑</button><button class="btn sm ghost" name="action" value="down" title="Pastga">↓</button></form>
          <button type="button" class="btn sm ghost qb-more-btn" data-dlg="qbdlg<?= $s['id'] ?>" title="Nomini o'zgartirish / o'chirish">⋯</button>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php foreach ($tree as $s): ?>
  <dialog class="qb-dlg" id="qbdlg<?= $s['id'] ?>">
    <form method="dialog" class="qb-dlg-x"><button class="btn sm ghost" aria-label="Yopish">×</button></form>
    <h3><?= e($s['name']) ?></h3>
    <form method="post" class="form"><?= csrf_field() ?><input type="hidden" name="action" value="rename"><input type="hidden" name="id" value="<?= $s['id'] ?>">
      <label>Nomini o'zgartirish<input name="name" value="<?= e($s['name']) ?>" maxlength="120" required></label>
      <button class="btn primary">Saqlash</button></form>
    <form method="post" class="mt" onsubmit="return confirm('«<?= e(addslashes($s['name'])) ?>» bo\'limi, ichki bo\'limlari va barcha savollari (<?= (int)$s['total'] ?> ta) o\'chiriladi. Davom etamizmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $s['id'] ?>">
      <button class="btn sm danger-ghost">Bo'limni o'chirish</button></form>
  </dialog>
  <?php endforeach; ?>
  <script>
  document.querySelectorAll('.qb-more-btn').forEach(b => b.addEventListener('click', () => { const d = document.getElementById(b.dataset.dlg); if (!d) return; if (d.showModal) d.showModal(); else d.setAttribute('open', ''); const i = d.querySelector('input[name=name]'); if (i) { i.focus(); i.select(); } }));
  document.querySelectorAll('.qb-dlg').forEach(d => d.addEventListener('click', e => { if (e.target === d) d.close(); }));
  </script>
  <?php endif; ?>
</div>

<div class="card">
  <h3>Yangi bo'lim</h3>
  <form method="post" class="form row gap wrap qb-add"><?= csrf_field() ?><input type="hidden" name="action" value="add">
    <label>Nomi<input name="name" maxlength="120" required placeholder="Masalan: Tenglamalar"></label>
    <label>Qayerga<select name="parent_id"><option value="0">— Asosiy bo'lim —</option>
      <?php foreach ($tree as $s): ?><option value="<?= $s['id'] ?>"><?= str_repeat('— ', $s['depth']) . e($s['name']) ?></option><?php endforeach; ?></select></label>
    <label>&nbsp;<button class="btn primary"><?= icon('plus', 16) ?>Qo'shish</button></label>
  </form>
</div>
<?php page_footer();
