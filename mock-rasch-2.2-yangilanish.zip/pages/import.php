<?php
defined('APP_ROOT') || exit;
require_once APP_ROOT . '/inc/xlsx.php';
$test = get_test_or_404();
$items = test_items($test);
$byLabel = [];
foreach ($items as $it) $byLabel[$it['label']] = $it;

function imp_norm_header(string $h): string
{
    $h = mb_strtolower(trim($h));
    $h = str_replace([' ', '.', '-', '_', '№', '#'], '', $h);
    if (preg_match('/^(q|savol|s)(\d+[ab]?)$/u', $h, $m)) $h = $m[2];
    return $h;
}
function imp_letter(string $v): string
{
    $v = mb_strtoupper(trim($v));
    $map = ['А' => 'A', 'В' => 'B', 'Б' => 'B', 'С' => 'C', 'Ц' => 'C', 'Д' => 'D', 'Е' => 'E', 'Ф' => 'F',
            '1' => 'A', '2' => 'B', '3' => 'C', '4' => 'D', '5' => 'E', '6' => 'F'];
    return $map[$v] ?? $v;
}

$report = null;
if (is_post()) {
    csrf_check();
    $f = $_FILES['file'] ?? null;
    if (!$f || !is_uploaded_file($f['tmp_name'])) { flash('Fayl tanlanmadi', 'err'); redirect('import', ['id' => $test['id']]); }
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    try {
        $data = $ext === 'xlsx' ? xlsx_read($f['tmp_name']) : csv_read($f['tmp_name']);
    } catch (Throwable $ex) {
        flash($ex->getMessage(), 'err'); redirect('import', ['id' => $test['id']]);
    }
    $judged01 = isset($_POST['judged01']);
    $defCenter = (int)($_POST['center_id'] ?? 0) ?: null;
    $overwrite = isset($_POST['overwrite']);
    // Sarlavha qatorini topish
    $hdrIdx = 0;
    foreach ($data as $i => $r) {
        $norm = array_map(fn($x) => imp_norm_header((string)$x), $r);
        if (array_intersect($norm, ['1', 'id', 'kod', 'code'])) { $hdrIdx = $i; break; }
    }
    $hdr = array_map(fn($x) => imp_norm_header((string)$x), $data[$hdrIdx] ?? []);
    $col = ['code' => null, 'name' => null, 'group' => null, 'mcstr' => null, 'center' => null, 'phone' => null];
    $itemCol = [];
    foreach ($hdr as $c => $h) {
        if (in_array($h, ['id', 'kod', 'code', 'idraqam', 'shaxsiykod'], true)) $col['code'] = $c;
        elseif (in_array($h, ['fish', 'fio', 'ism', 'name', 'familiyaism', 'ismfamiliya', 'oquvchi', "o'quvchi", 'ф.и.о', 'фио'], true)) $col['name'] = $c;
        elseif (in_array($h, ['guruh', 'group', 'sinf', 'группа'], true)) $col['group'] = $c;
        elseif (in_array($h, ['markaz', 'center', 'oquvmarkaz', "o'quvmarkaz", 'filial'], true)) $col['center'] = $c;
        elseif (in_array($h, ['telefon', 'phone', 'tel', 'телефон'], true)) $col['phone'] = $c;
        elseif (in_array($h, ['javoblar', 'answers', 'javob', 'ответы'], true)) $col['mcstr'] = $c;
        elseif (isset($byLabel[$h])) $itemCol[$h] = $c;
    }
    $report = ['ok' => 0, 'new' => 0, 'skip' => 0, 'errors' => []];
    $mcItems = array_values(array_filter($items, fn($i) => $i['type'] === 'mc'));
    for ($i = $hdrIdx + 1; $i < count($data); $i++) {
        $r = $data[$i];
        if (!array_filter($r, fn($x) => trim((string)$x) !== '')) continue;
        $code = $col['code'] !== null ? preg_replace('/\D/', '', (string)($r[$col['code']] ?? '')) : '';
        $name = $col['name'] !== null ? trim((string)($r[$col['name']] ?? '')) : '';
        $grp = $col['group'] !== null ? trim((string)($r[$col['group']] ?? '')) : '';
        if ($code === '' && $name === '') { $report['errors'][] = 'Qator ' . ($i + 1) . ': ID ham, ism ham yo\'q'; continue; }
        $existed = $code !== '' && val('SELECT 1 FROM students WHERE code=?', [$code]);
        $cid = $defCenter;
        if ($col['center'] !== null && ($cn = trim((string)($r[$col['center']] ?? ''))) !== '') {
            $cid = (int)val('SELECT id FROM centers WHERE name=?', [$cn]);
            if (!$cid) { q('INSERT INTO centers (name) VALUES (?)', [$cn]); $cid = (int)db()->lastInsertId(); }
        }
        $st = find_or_create_student($code, $name, $grp, $cid);
        if ($cid && !$st['center_id']) q('UPDATE students SET center_id=? WHERE id=?', [$cid, $st['id']]);
        if ($col['phone'] !== null && ($ph = norm_phone((string)($r[$col['phone']] ?? ''))) && !$st['phone'] && !val('SELECT 1 FROM students WHERE phone=?', [$ph])) q('UPDATE students SET phone=? WHERE id=?', [$ph, $st['id']]);
        if (!$existed) $report['new']++;
        if (!$overwrite && val('SELECT 1 FROM responses WHERE test_id=? AND student_id=?', [$test['id'], $st['id']])) { $report['skip']++; continue; }
        $ans = [];
        if ($col['mcstr'] !== null) {
            $s = preg_replace('/\s/u', '', (string)($r[$col['mcstr']] ?? ''));
            $chars = mb_str_split($s);
            foreach ($mcItems as $k => $it) {
                $ch = imp_letter($chars[$k] ?? '');
                $ans[$it['label']] = in_array($ch, $it['opts'], true) ? $ch : '';
            }
        }
        foreach ($itemCol as $lab => $c) {
            $v = trim((string)($r[$c] ?? ''));
            $it = $byLabel[$lab];
            if ($it['type'] === 'mc') {
                $ch = imp_letter($v);
                $ans[$lab] = in_array($ch, $it['opts'], true) ? $ch : '';
            } else {
                if ($v === '+' || ($judged01 && $v === '1')) $v = '#1';
                elseif ($v === '-' || ($judged01 && $v === '0')) $v = '#0';
                $ans[$lab] = $v;
            }
        }
        save_response((int)$test['id'], (int)$st['id'], $ans, 'import');
        $report['ok']++;
    }
    if (!$itemCol && $col['mcstr'] === null) $report['errors'][] = 'Savol ustunlari topilmadi. Sarlavhada 1, 2, …, 36a, 36b kabi ustun nomlari bo\'lishi kerak.';
}
page_header('Import — ' . $test['title']);
test_tabs($test, 'import');
?>
<div class="grid-side">
<div class="card">
  <h2>Excel yoki CSV fayldan javoblarni yuklash</h2>
  <?php if ($report): ?>
    <div class="alert <?= $report['errors'] ? 'warn' : 'ok' ?>">
      Yuklandi: <b><?= $report['ok'] ?></b> ta javob; yangi o'quvchi: <?= $report['new'] ?>; o'tkazib yuborildi: <?= $report['skip'] ?>.
      <?php foreach (array_slice($report['errors'], 0, 20) as $er): ?><div class="small"><?= e($er) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="form">
    <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$test['id'] ?>">
    <label>Fayl (.xlsx yoki .csv) <input type="file" name="file" accept=".xlsx,.csv,.txt" required></label>
    <?php if ($cl = centers_list()): ?><label>Markaz (yangi o'quvchilar uchun)
      <select name="center_id"><option value="0">O'z markazimiz</option><?php foreach ($cl as $cid => $cn): ?><option value="<?= $cid ?>"><?= e($cn) ?></option><?php endforeach; ?></select></label><?php endif; ?>
    <label class="check"><input type="checkbox" name="judged01"> Ochiq savol ustunlarida <b>1/0</b> — tekshiruvchi bahosi (to'g'ri/noto'g'ri)</label>
    <label class="check"><input type="checkbox" name="overwrite" checked> Mavjud javoblarni yangilash</label>
    <button class="btn primary">Yuklash</button>
  </form>
</div>
<div class="card">
  <h3>Fayl tuzilishi</h3>
  <p class="small">Birinchi qator — sarlavha. Ustunlar:</p>
  <ul class="small">
    <li><code>ID</code> — 6 xonali o'quvchi ID (bo'lmasa yangi yaratiladi)</li>
    <li><code>F.I.Sh</code>, <code>Guruh</code>, <code>Telefon</code>, <code>Markaz</code> — ixtiyoriy (Markaz ustuni bo'lsa, markaz avtomatik yaratiladi)</li>
    <li><code>1</code> … <code><?= closed_count($test) ?></code> — A/B/C/D(/E/F) harflari (kirillcha ham bo'ladi)</li>
    <li><code>36a</code>, <code>36b</code> … — ochiq javob matni, yoki <code>+</code>/<code>-</code></li>
    <li>Yoki bitta <code>Javoblar</code> ustunida yopiq javoblar ketma-ket: <code>ABCDDA…</code></li>
  </ul>
  <a class="btn ghost" href="<?= e(url('export', ['what' => 'template', 'id' => $test['id']])) ?>">⬇ Namuna shablon (CSV)</a>
</div>
</div>
<?php page_footer();
