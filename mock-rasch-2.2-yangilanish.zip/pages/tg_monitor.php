<?php
defined('APP_ROOT') || exit;
/**
 * Telegram orqali o'tayotgan onlayn MOCK ning jonli nazorati:
 * kim ulangan, kimga PDF ketgan, kim boshlagan, nechta javob kiritgan, kim topshirgan.
 * Sahifa test ochiq paytda har 30 soniyada o'zi yangilanadi.
 */
$test = get_test_or_404();
if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    if ($act === 'nudge') {
        q('DELETE FROM tg_queue WHERE kind="nudge" AND test_id=?', [$test['id']]);
        $n = 0;
        foreach (tg_audience($test) as $s) {
            if (val('SELECT 1 FROM responses WHERE test_id=? AND student_id=? AND status="submitted"', [$test['id'], $s['id']])) continue;
            if (tg_enqueue('nudge', (int)$test['id'], (int)$s['id'], (int)$s['tg_chat_id'])) $n++;
        }
        tg_tick(20);
        flash("$n ta o'quvchiga eslatma yuborildi (topshirmaganlarga)");
    }
    if ($act === 'extend') {
        if (empty($test['online_end'])) flash('Bu testda tugash vaqti belgilanmagan', 'err');
        else {
            $new = date('Y-m-d H:i:s', strtotime($test['online_end']) + 10 * 60);
            q('UPDATE tests SET online_end=? WHERE id=?', [$new, $test['id']]);
            q('DELETE FROM tg_queue WHERE kind IN ("extend","rem30","rem10") AND test_id=?', [$test['id']]);
            foreach (tg_audience($test) as $s) tg_enqueue('extend', (int)$test['id'], (int)$s['id'], (int)$s['tg_chat_id'], ['end' => date('d.m.Y H:i', strtotime($new))]);
            tg_tick(20);
            flash('Muddat 10 daqiqaga uzaytirildi: yangi tugash ' . date('d.m H:i', strtotime($new)));
        }
    }
    if ($act === 'run') {
        $r = tg_tick(20);
        flash(!empty($r['busy']) ? 'Navbat band — bir oz kutib qayta urining' : 'Navbat ishlandi: yuborildi ' . ($r['sent'] ?? 0) . ', xato ' . ($r['failed'] ?? 0));
    }
    redirect('tg_monitor', ['id' => $test['id']]);
}

$items = test_items($test);
$total = count($items);
// Auditoriya: ro'yxatga qarab (Telegramga ulanmaganlar ham ko'rinadi)
$aud = (string)($test['tg_audience'] ?? 'reg');
if ($aud === 'all') $students = rows('SELECT * FROM students WHERE archived_at IS NULL ORDER BY full_name');
elseif ($aud === 'group') $students = rows('SELECT * FROM students WHERE group_name=? AND archived_at IS NULL ORDER BY full_name', [(string)$test['tg_group']]);
else $students = rows('SELECT s.* FROM students s JOIN test_registrations r ON r.student_id=s.id AND r.test_id=? ORDER BY s.full_name', [$test['id']]);
$resp = [];
foreach (rows('SELECT * FROM responses WHERE test_id=?', [$test['id']]) as $r) $resp[(int)$r['student_id']] = $r;
$pdfSent = [];
foreach (rows('SELECT student_id, sent_at, error FROM tg_queue WHERE kind="start" AND test_id=?', [$test['id']]) as $r) $pdfSent[(int)$r['student_id']] = $r;
$cnt = ['linked' => 0, 'pdf' => 0, 'started' => 0, 'done' => 0];
$list = [];
foreach ($students as $s) {
    $r = $resp[(int)$s['id']] ?? null;
    $qd = $pdfSent[(int)$s['id']] ?? null;
    $ansArr = $r ? (json_decode($r['answers'] ?: '{}', true) ?: []) : [];
    $nAns = $r ? tg_ans_counts($items, $ansArr) : 0;
    $row = ['s' => $s, 'r' => $r, 'q' => $qd, 'n' => $nAns];
    if ($s['tg_chat_id'] !== null) $cnt['linked']++;
    if ($qd && $qd['sent_at'] && $qd['error'] === '') $cnt['pdf']++;
    if ($r) $cnt['started']++;
    if ($r && $r['status'] === 'submitted') $cnt['done']++;
    $list[] = $row;
}
$open = online_open($test);
page_header('Jonli nazorat — ' . $test['title']);
test_tabs($test, 'tg_monitor');
if ($open) echo '<script>setTimeout(function(){ location.replace(location.href); }, 30000);</script>';
?>
<div class="card">
  <div class="row between center-v wrap">
    <div>
      <h2 style="margin:0">Telegram — jonli nazorat</h2>
      <p class="small muted" style="margin:.2rem 0 0">
        <?= $test['online_start'] ? 'Boshlanish: <b>' . e(date('d.m H:i', strtotime($test['online_start']))) . '</b> · ' : '' ?>
        <?= $test['online_end'] ? 'Tugash: <b>' . e(date('d.m H:i', strtotime($test['online_end']))) . '</b> · ' : '' ?>
        <?= $open ? '<span class="tag green">test ochiq — sahifa har 30 soniyada yangilanadi</span>' : '<span class="tag">test hozir ochiq emas</span>' ?>
      </p>
    </div>
    <div class="row gap wrap">
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="run"><button class="btn sm ghost">Navbatni ishga tushirish</button></form>
      <form method="post" onsubmit="return confirm('Topshirmagan barcha o\'quvchilarga eslatma yuborilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="nudge"><button class="btn sm">⏰ Eslatma yuborish</button></form>
      <?php if ($test['online_end']): ?><form method="post" onsubmit="return confirm('Tugash vaqti 10 daqiqaga surilsinmi? Hammaga xabar ketadi.')"><?= csrf_field() ?><input type="hidden" name="action" value="extend"><button class="btn sm">🕒 +10 daqiqa</button></form><?php endif; ?>
    </div>
  </div>
  <div class="row gap mt" style="flex-wrap:wrap">
    <span class="tag">Auditoriya: <b><?= count($list) ?></b></span>
    <span class="tag <?= $cnt['linked'] < count($list) ? 'amber' : 'green' ?>">Telegramga ulangan: <b><?= $cnt['linked'] ?></b></span>
    <span class="tag">PDF yetib borgan: <b><?= $cnt['pdf'] ?></b></span>
    <span class="tag blue">Boshlagan: <b><?= $cnt['started'] ?></b></span>
    <span class="tag green">Topshirgan: <b><?= $cnt['done'] ?></b></span>
  </div>
  <div class="table-wrap mt"><table class="tbl compact-tbl">
    <thead><tr><th>№</th><th>F.I.Sh</th><th>ID</th><th>Telegram</th><th>PDF</th><th>Boshladi</th><th class="num">Javoblar</th><th>Holat</th><th>Oxirgi saqlash</th></tr></thead>
    <tbody>
    <?php foreach ($list as $i => $x): $s = $x['s']; $r = $x['r']; $qd = $x['q']; ?>
      <tr class="<?= $r && $r['status'] === 'submitted' ? '' : ($open && !$r ? 'flag-red' : '') ?>">
        <td class="num"><?= $i + 1 ?></td>
        <td><?= e($s['full_name'] ?: '—') ?><?= $s['group_name'] ? ' <span class="small muted">' . e($s['group_name']) . '</span>' : '' ?></td>
        <td class="mono"><?= e($s['code']) ?></td>
        <td><?= $s['tg_chat_id'] !== null ? '<span class="tag green">ulangan</span>' : '<span class="tag red">yo\'q</span>' ?></td>
        <td class="small"><?php if ($qd && $qd['sent_at'] && $qd['error'] === ''): ?>✅ <?= e(substr($qd['sent_at'], 11, 5)) ?><?php elseif ($qd && $qd['error']): ?><span class="warn" title="<?= e($qd['error']) ?>">⚠ xato</span><?php else: ?>—<?php endif; ?></td>
        <td class="small"><?= $r && $r['started_at'] ? e(substr($r['started_at'], 11, 5)) : '—' ?></td>
        <td class="num"><b><?= $r ? $x['n'] : '—' ?></b><?= $r ? ' / ' . $total : '' ?></td>
        <td><?php if (!$r): ?><span class="muted small">boshlamagan</span><?php elseif ($r['status'] === 'submitted'): ?><span class="tag green">topshirdi</span><?php else: ?><span class="tag blue">ishlamoqda</span><?php endif; ?></td>
        <td class="small muted"><?= $r && $r['updated_at'] ? e(substr($r['updated_at'], 11, 8)) : '—' ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$list): ?><tr><td colspan="9" class="empty">Auditoriya bo'sh — avval o'quvchilarni MOCK ro'yxatiga qo'shing.</td></tr><?php endif; ?>
    </tbody>
  </table></div>
  <p class="small muted mt">«Javoblar» soni o'quvchi har saqlaganda yangilanadi (bot yoki saytda). Qizil qatordagilar test ochiq bo'lsa ham hali boshlamagan.</p>
</div>
<?php page_footer();
