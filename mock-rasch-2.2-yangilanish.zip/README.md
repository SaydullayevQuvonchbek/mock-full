# MOCK Rasch 2.2

Matematika milliy sertifikat MOCK imtihonlarini **Rasch (1PL)** modeli bilan baholash platformasi.
PHP 7.4+ · MySQL/MariaDB · tashqi AI yo'q · baholash kodi (`inc/rasch.php`, `inc/scoring.php`) o'zgartirilmagan.

## 1. O'rnatish / yangilash
1. ZIP dagi fayllarni hostingdagi sayt papkasiga yuklang (mavjud fayllar ustiga yoziladi). **`config.php` va `uploads/` tegilmaydi** (ZIP da yo'q).
2. Saytni bir marta oching — baza o'zi **schema 10** ga yangilanadi (eski ma'lumotlar saqlanadi).
3. Yangi bazaga birinchi o'rnatish alohida o'rnatuvchi (`install.php`) orqali bajariladi — u bu ZIP ga kirmaydi; mavjud saytni yangilash uchun kerak emas.
4. Talab: PHP 7.4+, `pdo_mysql`, `mbstring`, `curl` (bot/SMS uchun), `gd` (mashq testi PDF si uchun), `iconv`.

## 2. Sozlamalar (admin → Sozlamalar)
| Karta | Nima qilinadi |
|---|---|
| **Markaz** | Markaz nomi va **sayt manzili (https://…)** — botdagi, SMS dagi va ota-ona havolalari shundan yasaladi. |
| **Telegram bot** | BotFather tokeni → «Webhook ulash» → cron kaliti → ispmanager «Планировщик» ga **har daqiqada** cron buyrug'i (kartada tayyor ko'rinadi). |
| **Xabarlar → Eskiz.uz** | my.eskiz.uz dagi email va API paroli, jo'natuvchi (standart 4546) → «Ulanishni tekshirish» (balans ko'rinadi) → «Sinov SMS». |
| **Xabarlar → Telegram Gateway** | gateway.telegram.org dagi token → «Tekshirish». Ixtiyoriy. |
| **Kod yuborish tartibi** | `bot → gateway → sms` (o'zgartirish mumkin). Bot bepul, shuning uchun birinchi. |

### Eskiz shablonlari (MUHIM)
Eskiz faqat **oldindan tasdiqlangan matnlarni** o'tkazadi. Quyidagi 4 matnni my.eskiz.uz → «Шаблоны» da tasdiqlating
(`{…}` o'rniga Eskiz o'zining o'zgaruvchisini qo'yadi; aniq matn Sozlamalar → Xabarlar kartasida ham bor):
- `MOCK Rasch: tasdiqlash kodi {code}. 5 daqiqa amal qiladi. Hech kimga bermang.`
- `MOCK Rasch: ID {id}, vaqtinchalik parol {pass}. Kirgach parolni almashtiring.`
- `MOCK Rasch: {test}, {date}. Siz {room}, {seat}-o'rin. 15 daqiqa oldin keling.`
- `MOCK Rasch: {name}, {test}: {ball} ball ({grade}), {rank}-o'rin. {url}`

Tasdiqlanmaguncha SMS lar Eskiz tomonidan rad etiladi (jurnalda xato ko'rinadi); Telegram yo'li shundan ta'sirlanmaydi.

## 3. Imkoniyatlar
**2.2 da yangi.** (1) Server vaqti: MySQL UTC bo'lsa ham ulanishda vaqt zonasi PHP ga (Asia/Tashkent) tenglanadi — navbatdagi Telegram xabarlari, muddatlar va «Hozir yopish» to'g'ri ishlaydi. (2) Topshiriq: umuman boshlamaganlar yopilganda **«topshirmadi»** (o'rtacha natija va o'zlashtirishga kirmaydi, botga «bajarmadingiz» xabari); admin sahifasida «PDF (savollar)» va «PDF (kalit bilan)», topshiriq kodi `#A<id>` hamma o'quvchida bir xil — bot javobni yuborgan o'quvchining o'z testiga yozadi. Yaratilganda xabarlar cron kutmasdan darhol yuboriladi. (3) Bot: «🌐 Kabinetga kirish» (`/kabinet`) — saytga parolsiz bir martalik havola. (4) **O'quvchilarni arxivlash** (O'quvchilar → belgilab «Arxivlash» yoki tahrir oynasida): natijalari saqlanadi, lekin ro'yxat, topshiriq, MOCK ro'yxati va bot xabarlarida chiqmaydi, kabinetga kira olmaydi; «arxivda: N ta» havolasidan qaytarish mumkin. (5) **Sozlamalar → Xonalar va sig'im** — markaz xonalari bir marta kiritiladi; MOCK «Ro'yxat» sahifasi 4 qadamga soddalashtirildi: 1) Ro'yxat 2) Xonalar («Markaz xonalarini qo'shish» bir bosishda) 3) Joylashtirish 4) Tasdiqlash — varaqlar xonalar bo'yicha va xona/o'rin xabarini yuborish. (6) «Hamkor markazlar» bo'limi olib tashlandi (bazadagi ma'lumot saqlanadi).

**2.2 kod tahlili bo'yicha tuzatishlar.** O'quvchilar: «Yangi vaqtinchalik parol» tugmasi ishlamasdi (action nomi mos emas edi); ism bo'yicha qidiruv hammani chiqarardi (telefon sharti bo'sh bo'lganda); band ID bilan qo'shish mavjud o'quvchining ustiga yozardi; telefon xato bo'lsa yarim yozuv qolardi. Import: savol ustunlari topilmasa ham javoblar bo'sh bilan yozilardi — endi hech narsa o'zgartirilmaydi. Arxivlash: hali topshirilmagan MOCK ro'yxatlaridan chiqariladi, kutayotgan bot/SMS xabarlari bekor qilinadi, ro'yxat/varaq/xona xabarlaridan chiqadi, ID bilan qayta qo'shib bo'lmaydi. Bot navbati: xabar yuborish paytida chat qayta aniqlanadi (o'quvchi botni uzgan/boshqa chatga ulangan/arxivlangan bo'lsa eski chatga ketmaydi); sahifalardan navbat qulf bilan bo'shatiladi (cron bilan ikki marta yubormaslik); 6 soatdan eski «javob kutish» rejimi oddiy xabarni yutmaydi, /menu rejimni tozalaydi; vaqtinchalik parolni qayta yuborish avvalgi xato urinishni tozalaydi. Mashq/topshiriq: PDF raqamlari testdagi haqiqiy raqamga mos (savol bazadan o'chirilgan bo'lsa ham), o'chirilgan savol «javobsiz» deb turmaydi, «#kod -3» da minus javobga tegishli, ochiq savolga faqat harf yuborilsa rad etiladi, ochiq javob chegarasi hamma joyda 80 belgi, saytda tozalangan javob yakunlashda ham tozalangan hisoblanadi, topshiriq ochilganda bo'sh avtosaqlash yuborilmaydi, katta skanli PDF uchun xotira oshirildi. Botdagi «Kabinetga kirish» havolasi vaqtinchalik parol bo'lsa avval almashtirishni so'raydi.

**Parol va kirish.** PIN bekor: o'quvchi o'z parolini belgilaydi (≥ 6 belgi). Admin qo'shgan o'quvchiga *vaqtinchalik parol* beriladi — birinchi kirishda almashtirish majburiy. Eski PIN lar vaqtinchalik parol sifatida ishlayveradi. Kirish: **ID yoki telefon + parol**. Parol tiklash: ID/telefon → kod (bot / Telegram Gateway / SMS) → yangi parol; kod 5 daqiqa, 3 urinish; kuniga 5 kod raqamga, 20 kod IP ga.

**O'quvchi kabineti.** MOCK lar (xona va o'rin bilan), onlayn testlar, natijalar (ball, daraja, o'rin, bo'limlar bo'yicha to'g'ri javoblar, o'sish grafigi), profil (telefonni kod bilan tasdiqlash, ota-ona raqamlari, parol almashtirish), Telegramni bir bosishda ulash.

**Xonalar.** Test → Ro'yxat: xonalar, sig'im, nazoratchi; **avto-joylashtirish** (alifbo / guruhlar aralash / tasodifiy `seed` bilan), qo'lda ko'chirish; eshik ro'yxati, xona bo'yicha davomat ro'yxati; **javoblar varaqalari xonalar bo'yicha** — «Xonalar bo'yicha (ajratuvchi bilan)» tugmasi xona → o'rin tartibida chop etadi, har xona oldidan *ajratuvchi varaq* (xona nomi, nazoratchi, varaqlar soni, o'rin–ism–ID ro'yxati); har xona qatoridagi 🖨 tugmasi faqat shu xonani chop etadi; varaqning o'zida xona va o'rin yozilgan; «Xona haqida xabar yuborish» (Telegram, bo'lmasa SMS).

**Ota-onalar.** O'quvchi kartasida ota-ona ismi va 2 ta telefon (import ustuni ham bor). Natijalar e'lon qilingach Test → «Ota-onalar» → oldindan ko'rish (nechta Telegram / SMS) → tasdiqlash → navbat → hisobot va «qayta yuborish». Natija havolasi — imzolangan, faqat shu o'quvchi uchun. Ota-ona xabardan voz kecha oladi.

**Savollar bazasi (Savollar bazasi menyusi).**
1. Bo'limlar daraxti (Algebra › Tenglamalar …).
2. **PDF dan yuklash**: PDF ni tanlang → brauzerda qirqiladi (avtomatik bo'sh joy bo'yicha / har sahifa=1 savol / sichqoncha bilan qo'lda; 2 ustunli sahifalar ham) → oldindan ko'rib, keraksizini belgisini olib tashlang, bo'laklarni «↓ birlashtirish» bilan tuzating → yuklang. Kalitni shu yerning o'zida (`ACDB…`) yoki keyin «Savollar» sahifasida kiriting.
3. Kalitsiz savollar o'quvchilarga chiqmaydi. Savol raqami («7.», «12)») qirqishda avtomatik olib tashlanadi (belgini o'chirish mumkin; har bo'lakda «↺ asl holi» tugmasi). Bazadagi eski savollar uchun «Savollar» sahifasida «✂ Savol raqamlarini olib tashlash» tugmasi bor — o'zgarishni oldindan ko'rsatadi, tasdiqlangach saqlaydi. Ochiq savolda bir nechta to'g'ri variant `0.5;1/2` ko'rinishida.
4. **O'quvchi** «Mashq testlari» da bo'lim(lar) va savollar sonini tanlaydi → tizim tasodifiy test tuzadi (oxirgi 3 mashqdagi savollarni takrorlamaydi) → javob beradi → natijada **faqat nechta to'g'ri** (umumiy va bo'limlar bo'yicha); qaysi savol xato ekani va to'g'ri javoblar ko'rsatilmaydi. Testni **PDF** qilib yuklab olish (javoblar varaqasi bilan, kalitsiz). Admin bo'lim PDF ni kalit bilan oladi.
5. Telegram botda `/mashq` — bo'limlar raqamlangan (tugma yoki raqam yozib tanlash, 0 — aralash), savollar soni tugma yoki raqam bilan, savol izohida progress, yakunda baho va keyingi qadam tugmalari («Yana shu bo'limdan», «Boshqa bo'lim», «O'zlashtirishim»). Noma'lum matnga do'stona javob va menyu.
6. **Test kodi.** Har bir mashq/topshiriq testining kodi bor (`#123`): sayt sahifasida, PDF ning har sahifasida («TEST KODI» katagi) va bot xabarlarida. Botda «📄 PDF yuklab olish» → qog'ozda yechish → javoblarni **bitta xabarda kod bilan** yuborish: `#123 ABCDA…` (har harf — bitta savol) yoki `#123 1:A 2:C 9:12` (ochiq savollar bilan). Bot qaysi test ekanini, qabul qilingan / noto'g'ri / javobsiz raqamlarni ko'rsatadi; tuzatish uchun faqat o'sha raqamlarni qayta yuborish kifoya; «✅ Yakunlash va tekshirish». Boshqa o'quvchining kodi, yakunlangan yoki muddati o'tgan test javobi qabul qilinmaydi.
**Topshiriqlar (Topshiriqlar menyusi).** Admin savollar bazasidan bo'lim(lar) va savollar sonini tanlab topshiriq tuzadi, guruh(lar)ga yoki barcha o'quvchilarga **muddat** bilan yuboradi. Hammaga bir xil savollar. O'quvchi saytda («Topshiriq va mashq») yoki botda yechadi — javoblar avtomatik saqlanadi va tekshiriladi. Muddatgacha o'quvchi faqat nechta to'g'ri topganini ko'radi; muddat tugagach (belgilangan bo'lsa) qaysi savolda xato qilgani va to'g'ri javoblar ochiladi (saytda va botda «🔍 Xatolarimni ko'rish»). Muddat tugaganda yakunlanmagan testlar saqlangan javoblar bilan tekshiriladi. Admin: holatlar (topshirdi / jarayonda / boshlamagan), har o'quvchining javoblari, savollar bo'yicha statistika (to'g'ri %, ko'p uchragan xato), muddatni o'zgartirish, Telegram eslatma, hozir yopish. Botga avtomatik: yangi topshiriq, muddatga 1 soat qolganda eslatma, muddat tugagach natija.

**O'zlashtirish (O'zlashtirish menyusi).** Har bir o'quvchining bo'limlar bo'yicha to'g'ri javoblar ulushi: MOCK (Algebra, Geometriya — e'lon qilingan natijalardan) va savollar bazasi bo'limlari (mashq + topshiriqlar; bo'lim ichki bo'limlari bilan jamlanadi). Guruh jadvali (rangli: 70%+ / 40–69% / 40% dan past), o'quvchi tafsiloti; o'quvchi o'zinikini kabinetda va botda («📈 O'zlashtirish») ko'radi.

Rasmlar `uploads/qb/` da, to'g'ridan-to'g'ri ochilmaydi: faqat `index.php?p=qb_img` orqali (admin yoki shu savol o'z mashqida bor o'quvchi).

## 4. Telegram bot buyruqlari (o'quvchi)
Ulangan o'quvchida doimiy **tugmalar menyusi**: 📝 Mashq testi · 📋 Topshiriqlar · 📈 O'zlashtirish · 📊 Natijalarim · 🗓 MOCKlarim · ℹ️ Yordam. Buyruqlar: `/start` ulanish · `/menu` · `/mashq` · `/topshiriq` · `/ozlashtirish` · `/natija` · `/mening` · `/uzish` · `/help` (Webhook ulanganda «/» menyusiga ham yoziladi). Topshiriq xabarida test kodi va «▶️ Botda yechish», «📄 PDF yuklab olish», «🌐 Saytda yechish» (bir martalik havola) tugmalari. PDF dagi javoblar: `#kod ABCD…` — bitta xabarda. Ulanish: kabinetdagi «Telegramni ulash» havolasi yoki bitta xabarda `ID parol`. Ota-ona: kabinet/karta havolasi orqali ulanadi, `/natija`, `/uzish`.

## 5. Xavfsizlik
Parollar bcrypt; sessiya parol o'zgarganda tugaydi; barcha formalarda CSRF; OTP kodlar HMAC bilan saqlanadi; CSP (`script-src 'self'`); yuklangan fayllar `.htaccess` bilan yopiq; token/parollar sahifalarda ko'rsatilmaydi; throttle: kirish, bot ulash, kod yuborish.

## 6. Muammolar
- **SMS ketmayapti** — Sozlamalar → Xabarlar jurnali: 4xx = shablon tasdiqlanmagan / balans yo'q. «Ulanishni tekshirish» ni bosing.
- **Navbat yurmayapti** — cron o'rnatilganini tekshiring (Sozlamalar → Telegram: «So'nggi chaqiruv»); aks holda «Navbatni hozir ishga tushirish».
- **Mashq PDF chiqmayapti** — serverda PHP `gd` yoqilmagan; sahifada yechish ishlayveradi.
- **PDF dan qirqish ishlamayapti** — brauzer eski; Chrome/Edge/Firefox yangilang. Rasm (PNG/JPG) yuklash ham mumkin.

## 7. Texnik
Schema: 8 — parol/OTP/navbat kanali/ota-ona/`tg_links`/nazoratchi; 9 — `qb_sections`, `qb_questions`, `qb_tests`, `qb_items`; 10 — `qb_assign`, `qb_assign_items`, `qb_tests.assign_id` (topshiriqlar). Kirish nuqtasi `index.php?p=<sahifa>`; yo'nalishlar jadvali `index.php` da. PHP 7.4 mosligi uchun `inc/compat.php`; PHP 8 sintaksisi (`match`, `?->`, union turlar) ishlatilmagan.
