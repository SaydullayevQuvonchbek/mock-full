<?php
defined('APP_ROOT') || exit;
/**
 * Telegram bot: /mashq — savollar bazasidan tasodifiy mashq testi (rasmli savollar, tugmali javoblar).
 * Yakunda faqat nechta to'g'ri topilgani (umumiy va bo'limlar bo'yicha) yuboriladi. PHP 7.4 bilan mos.
 * Holat: tg_state(step='qb', data='<test>:<pos>') — ochiq savolga matn bilan javob uchun.
 */

function tg_qb_state(int $chat, string $data): void
{
    q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'qb', $data]);
}

/** /mashq — bo'lim tanlash menyusi */
/** Botda ko'rsatiladigan bo'limlar (kalitli savoli borlar), menyudagi tartibda. Yopiq bo'lim va savollar o'quvchiga chiqmaydi (2.5.2) */
function tg_qb_sections(): array
{
    return array_values(array_filter(qb_tree(true), function ($s) { return $s['ready_total'] > 0; }));
}

/** Savollar soni so'rovi: tugmalar + yozib yuborish mumkin (holat qbcnt) */
function tg_qb_ask_count(int $chat, int $sec, int $pool, string $secName): void
{
    $max = min(60, $pool);
    $row = [];
    foreach ([5, 10, 15, 20, 30] as $n) if ($n < $max) $row[] = ['text' => (string)$n, 'callback_data' => 'qbn:' . $sec . ':' . $n];
    $row[] = ['text' => ($max === $pool ? 'Hammasi' : 'Maks.') . ' (' . $max . ')', 'callback_data' => 'qbn:' . $sec . ':' . $max];
    $kb = array_chunk($row, 3);
    $kb[] = [['text' => '⬅️ Bo‘limlar', 'callback_data' => 'qbh:0']];
    q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'qbcnt', (string)$sec]);
    tg_send($chat, "🔢 <b>" . tg_h($secName) . "</b> · bazada <b>$pool</b> ta tayyor savol\n\nNechta savol bo‘lsin? Tugmani bosing yoki <b>raqam yozib yuboring</b> (1–$max).", ['inline_keyboard' => $kb]);
}

/** /mashq — bo'lim tanlash menyusi (raqam yozib ham tanlash mumkin — holat qbsec) */
function tg_qb_menu(int $chat, array $st): void
{
    $tree = tg_qb_sections();
    if (!$tree) { tg_send($chat, '📚 Hozircha mashq savollari qo‘shilmagan. O‘qituvchingiz bazani to‘ldirgach shu yerda chiqadi.'); return; }
    $kb = [];
    $open = row('SELECT t.id, t.n, (SELECT COUNT(*) FROM qb_items i WHERE i.test_id=t.id AND i.given NOT IN ("","-")) d FROM qb_tests t WHERE t.student_id=? AND t.status="open" AND t.via="bot" AND t.assign_id IS NULL ORDER BY t.id DESC LIMIT 1', [$st['id']]);
    if ($open) $kb[] = [['text' => '▶️ Davom ettirish — ' . (int)$open['d'] . '/' . (int)$open['n'] . ' yechilgan', 'callback_data' => 'qbr:' . (int)$open['id']]];
    $wrong = qb_wrong_count((int)$st['id']);
    if ($wrong > 0) $kb[] = [['text' => '🔁 Xatolarim ustida ishlash (' . $wrong . ' ta savol)', 'callback_data' => 'qbe:0:10']];
    $kb[] = [['text' => '🎲 Barcha bo‘limlardan aralash', 'callback_data' => 'qbs:0']];
    $lines = [];
    foreach (array_slice($tree, 0, 30) as $i => $s) {
        $kb[] = [['text' => ($i + 1) . '. ' . str_repeat('· ', (int)$s['depth']) . mb_strimwidth((string)$s['name'], 0, 36, '…') . ' (' . (int)$s['ready_total'] . ')', 'callback_data' => 'qbs:' . (int)$s['id']]];
    }
    q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'qbsec', '']);
    tg_send($chat, "📚 <b>Mashq testi</b>\n\nBo‘limni tanlang — savollar bo‘limlar bo‘yicha teng olinadi: avval xato qilgan yoki javobsiz qoldirgan savollaringiz, qolgani yangi savollar; to‘g‘ri yechganlaringiz takrorlanmaydi. Yakunda nechta to‘g‘ri topganingiz ko‘rsatiladi.\nTugmani bosing yoki <b>bo‘lim raqamini yozib yuboring</b> (0 — aralash).", ['inline_keyboard' => $kb]);
}

/** Yozib yuborilgan raqam: bo'lim tanlash (qbsec) yoki savollar soni (qbcnt). true — qabul qilindi */
function tg_qb_pick_text(int $chat, array $st, array $state, string $text): bool
{
    $text = trim($text);
    if (!preg_match('/^\d{1,3}$/', $text)) {
        tg_send($chat, $state['step'] === 'qbsec' ? 'Bo‘lim raqamini yozing yoki tugmani bosing. Chiqish: /menu' : 'Savollar sonini raqam bilan yozing yoki tugmani bosing. Chiqish: /menu');
        return true;
    }
    $n = (int)$text;
    if ($state['step'] === 'qbsec') {
        $tree = tg_qb_sections();
        if ($n === 0) { $sec = 0; $name = 'Barcha bo‘limlar'; }
        elseif (isset($tree[$n - 1])) { $sec = (int)$tree[$n - 1]['id']; $name = (string)$tree[$n - 1]['name']; }
        else { tg_send($chat, 'Bunday raqamli bo‘lim yo‘q (1–' . count($tree) . ', 0 — aralash).'); return true; }
        $pool = count(qb_practice_pool((int)$st['id'], $sec ? [$sec] : []));
        if ($pool < 1) { tg_send($chat, 'Bu bo‘limda tayyor savol yo‘q.'); return true; }
        tg_qb_ask_count($chat, $sec, $pool, $name);
        return true;
    }
    $sec = (int)$state['data'];
    $pool = count(qb_practice_pool((int)$st['id'], $sec ? [$sec] : []));
    $max = min(60, $pool);
    if ($n < 1 || $n > $max) { tg_send($chat, "1 dan $max gacha raqam yozing."); return true; }
    tg_qb_start($chat, $st, $sec, $n, null, 0);
    return true;
}

/** Yangi mashq tuzib, birinchi savolni yuboradi (tugmadan ham, yozilgan raqamdan ham) */
function tg_qb_start(int $chat, array $st, int $sec, int $n, ?callable $cb, int $msgId, string $mode = 'mix'): void
{
    $sid = (int)$st['id'];
    $fail = function (string $m) use ($cb, $chat) { if ($cb) $cb($m, true); else tg_send($chat, '⚠️ ' . $m); };
    $open = (int)val('SELECT COUNT(*) FROM qb_tests WHERE student_id=? AND status="open" AND assign_id IS NULL', [$sid]);
    $today = (int)val('SELECT COUNT(*) FROM qb_tests WHERE student_id=? AND assign_id IS NULL AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [$sid]);
    if ($open >= 8) { $fail('Yakunlanmagan mashqlaringiz ko‘p. Avval ularni yakunlang (▶️ Davom ettirish yoki saytdagi «Topshiriq va mashq»).'); return; }
    if ($today >= 40) { $fail('Bugungi mashq limiti (40 ta) tugadi. Ertaga davom eting.'); return; }
    [$tid, $err, $info] = qb_build_test($sid, $sec ? [$sec] : [], max(1, $n), 'bot', ['mode' => $mode]);
    if (!$tid) { $fail((string)$err); return; }
    if ($cb) $cb();
    tg_qb_clear_kb($chat, $msgId);
    $cnt = (int)val('SELECT n FROM qb_tests WHERE id=?', [$tid]);
    $secName = $sec ? (string)val('SELECT name FROM qb_sections WHERE id=?', [$sec]) : 'Barcha bo‘limlar';
    $note = qb_build_note((array)$info);
    tg_send($chat, "🎯 <b>" . ($mode === 'errors' ? 'Xatolar ustida mashq' : 'Mashq tayyor') . "</b> · " . qb_code((int)$tid) . "\n" . tg_h($secName) . " · <b>$cnt ta savol</b>" . ($note !== '' ? "\n♻️ " . tg_h($note) : '') . "\n\nHar savol rasm bilan keladi: javob tugmasini bosing, ochiq savolga matn yozing. Istalgan payt 🏁 bilan yakunlashingiz mumkin.\n📄 Qog‘ozda yechish uchun PDF ni yuklab oling — javoblarni kod bilan bitta xabarda yuborasiz.", tg_kb_cb('📄 PDF yuklab olish', 'qbp:' . (int)$tid));
    tg_qb_next($chat, $st, (int)$tid, 0);
}

function tg_qb_own_test(int $tid, int $sid): ?array
{
    return row('SELECT * FROM qb_tests WHERE id=? AND student_id=? AND status="open" AND via<>"pap"', [$tid, $sid]);   // sinf testi botda yechilmaydi
}

/** Savol xabaridagi tugmalarni olib tashlaydi (javob berilgach) */
function tg_qb_clear_kb(int $chat, int $msgId): void
{
    if ($msgId) tg_call('editMessageReplyMarkup', ['chat_id' => $chat, 'message_id' => $msgId, 'reply_markup' => ['inline_keyboard' => []]]);
}

/** «qb…» tugmalari */
function tg_qb_cb(int $chat, array $st, string $data, callable $cb, int $msgId = 0): void
{
    $sid = (int)$st['id'];
    if (!preg_match('/^qb([a-zA-Z]):(\d+)(?::(\d+))?(?::([A-F]))?$/', $data, $m)) { $cb(); return; }
    $act = $m[1]; $a = (int)$m[2]; $b = isset($m[3]) ? (int)$m[3] : 0; $L = $m[4] ?? '';
    qb_assign_tick();   // muddati o'tgan topshiriq javob qabul qilmasin

    if ($act === 'x') { $cb(); tg_asg_review($chat, $st, $a); return; }       // xatolarni ko'rish
    if ($act === 'l') { $cb(); tg_asg_list($chat, $st); return; }             // topshiriqlar ro'yxati
    if ($act === 'w') {                                   // saytda yechish — bir martalik havola
        $own = row('SELECT id FROM qb_tests WHERE id=? AND student_id=?', [$a, $sid]);
        if (!$own) { $cb('Topilmadi', true); return; }
        $link = tg_make_link($sid, $a, 'qb');
        if ($link === null) { $cb(tg_site_url() === '' ? 'Sayt manzili sozlanmagan — markazga xabar bering' : 'Avvalgi havolalar hali amalda — bir oz kuting', true); return; }
        $cb();
        tg_send($chat, 'Havola 15 daqiqa amal qiladi va bir marta ishlaydi.', tg_kb_url('🌐 Saytda ochish', $link));
        return;
    }

    if ($act === 'h') { $cb(); tg_qb_clear_kb($chat, $msgId); tg_qb_menu($chat, $st); return; }   // bo'limlar ro'yxatiga qaytish
    if ($act === 'o') { $cb(); tg_send($chat, tg_mastery_text($st)); return; }                 // o'zlashtirish
    if ($act === 's') {                                   // bo'lim tanlandi → savollar soni
        $pool = count(qb_practice_pool((int)$st['id'], $a ? [$a] : []));
        if ($pool < 1) { $cb('Bu bo‘limda tayyor savol yo‘q', true); return; }
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_ask_count($chat, $a, $pool, $a ? (string)val('SELECT name FROM qb_sections WHERE id=?', [$a]) : 'Barcha bo‘limlar');
        return;
    }
    if ($act === 'n') { tg_qb_start($chat, $st, $a, max(1, $b), $cb, $msgId); return; }   // test tuzish
    if ($act === 'e') { tg_qb_start($chat, $st, $a, max(5, $b ?: 10), $cb, $msgId, 'errors'); return; }   // xatolar ustida ishlash
    $t = tg_qb_own_test($a, $sid);
    if (!$t) { $cb('Bu test topilmadi yoki yakunlangan (topshiriq muddati tugagan bo‘lishi mumkin)', true); return; }
    $tid = (int)$t['id'];

    if ($act === 'a') {                                   // javob (tugma)
        $it = row('SELECT i.given, q.kind, q.nopt FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND i.pos=?', [$tid, $b]);
        if (!$it || $it['kind'] === 'open' || $L === '' || ord($L) - 64 > ((int)$it['nopt'] === 6 ? 6 : 4)) { $cb('Bu savolga matn bilan javob bering', true); return; }
        if ((string)$it['given'] !== '' && (string)$it['given'] !== '-') { $cb('Bu savolga javob berilgan'); return; }
        q('UPDATE qb_items SET given=? WHERE test_id=? AND pos=?', [$L, $tid, $b]);
        $cb($b . '-savol → ' . $L);
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, $b);
        return;
    }
    if ($act === 'k') {                                   // o'tkazish
        $up = q('UPDATE qb_items SET given="-" WHERE test_id=? AND pos=? AND given=""', [$tid, $b]);
        if (!$up->rowCount()) { $cb('Bu savol allaqachon o‘tkazilgan yoki javob berilgan'); tg_qb_clear_kb($chat, $msgId); return; }   // qayta bosish keyingi savolni ikki marta yubormasin
        $cb('O‘tkazildi');
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, $b);
        return;
    }
    if ($act === 'f') {                                   // yakunlashni so'rash
        $cb();
        $n = (int)$t['n'];
        $done = (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given NOT IN ("","-")', [$tid]);
        tg_send($chat, "Mashqni yakunlaysizmi?\nJavob berilgan: <b>$done / $n</b>." . ($done < $n ? "\n⚠️ Javobsiz savollar noto‘g‘ri hisoblanadi." : ''), ['inline_keyboard' => [
            [['text' => '✅ Ha, yakunlash', 'callback_data' => 'qbF:' . $tid]],
            [['text' => '↩️ Davom etaman', 'callback_data' => 'qbr:' . $tid]],
        ]]);
        return;
    }
    if ($act === 'F') {                                   // yakunlash
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_finish($chat, $tid);
        return;
    }
    if ($act === 'q') {                                   // o'tkazilganlarni qayta yechish
        q('UPDATE qb_items SET given="" WHERE test_id=? AND given="-"', [$tid]);
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, 0);
        return;
    }
    if ($act === 'p') {                                   // PDF + kalitlarni bitta xabarda yuborish
        $cb('PDF tayyorlanmoqda…');
        tg_qb_send_pdf($chat, $t);
        return;
    }
    if ($act === 'j') {                                   // javoblarni bitta xabarda yuborish rejimi
        $cb();
        q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'qbkeys', (string)$tid]);
        tg_send($chat, tg_qb_keys_help($t));
        return;
    }
    if ($act === 'r') {                                   // davom ettirish
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, 0);
        return;
    }
    $cb();
}

/** Keyingi javobsiz savolni yuboradi (bo'lmasa — yakunlash taklifi) */
function tg_qb_next(int $chat, array $st, int $tid, int $afterPos): void
{
    $t = tg_qb_own_test($tid, (int)$st['id']);
    if (!$t) { tg_send($chat, 'Bu mashq topilmadi yoki yakunlangan. /mashq'); return; }
    $left = array_map('intval', array_column(rows('SELECT pos FROM qb_items WHERE test_id=? AND given="" ORDER BY pos', [$tid]), 'pos'));
    $pos = null;
    foreach ($left as $p) if ($p > $afterPos) { $pos = $p; break; }
    if ($pos === null && $left) $pos = $left[0];
    if ($pos === null) {
        $n = (int)$t['n'];
        $done = (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given NOT IN ("","-")', [$tid]);
        $skipped = (int)val('SELECT COUNT(*) FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND i.given="-"' . qb_test_open_sql($t), [$tid]);   // o'chirilgan / (mashqda) yopilgan savol — qayta yechishga taklif qilinmaydi
        $kb = [[['text' => '✅ Yakunlash', 'callback_data' => 'qbF:' . $tid]]];
        if ($skipped) $kb[] = [['text' => '↩️ O‘tkazilganlarni yechish (' . $skipped . ')', 'callback_data' => 'qbq:' . $tid]];
        q('DELETE FROM tg_state WHERE chat_id=? AND step="qb"', [$chat]);
        tg_send($chat, "Barcha savollarga o‘tdingiz.\nJavob berilgan: <b>$done / $n</b>." . ($skipped ? "\nO‘tkazilgan: <b>$skipped</b>." : ''), ['inline_keyboard' => $kb]);
        return;
    }
    tg_qb_send_question($chat, $st, $t, $pos);
}

function tg_qb_send_question(int $chat, array $st, array $t, int $pos): void
{
    $tid = (int)$t['id'];
    $it = row('SELECT i.pos, i.section_name, q.id, q.img, q.kind, q.nopt FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND i.pos=?' . qb_test_open_sql($t), [$tid, $pos]);
    $path = $it ? qb_dir() . '/' . basename((string)$it['img']) : '';
    if (!$it || !is_file($path)) {                         // savol bazadan olib tashlangan (yoki mashqda — yopilgan) — o'tkazib yuboramiz
        q('UPDATE qb_items SET given="-" WHERE test_id=? AND pos=?', [$tid, $pos]);
        tg_qb_next($chat, $st, $tid, $pos);
        return;
    }
    $done = (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given NOT IN ("","-")', [$tid]);
    $n = max(1, (int)$t['n']); $bar = str_repeat('▰', (int)round(10 * $done / $n)) . str_repeat('▱', 10 - (int)round(10 * $done / $n));
    $cap = '<b>Savol ' . $pos . ' / ' . $n . '</b>  ' . $bar . "\n" . tg_h($it['section_name']) . ' · ' . qb_code($tid);
    $kb = [];
    if ($it['kind'] === 'open') {
        $cap .= "\n\n✍️ Javobni matn bilan yuboring (kasr: <code>1/2</code>, o‘nlik: <code>0.5</code>).";
    } else {
        $row = [];
        for ($k = 0; $k < ((int)$it['nopt'] === 6 ? 6 : 4); $k++) { $L = chr(65 + $k); $row[] = ['text' => $L, 'callback_data' => 'qba:' . $tid . ':' . $pos . ':' . $L]; }
        $kb[] = $row;
    }
    $kb[] = [['text' => '⏭ O‘tkazish', 'callback_data' => 'qbk:' . $tid . ':' . $pos], ['text' => '🏁 Yakunlash', 'callback_data' => 'qbf:' . $tid]];
    tg_qb_state($chat, $tid . ':' . $pos);
    tg_call('sendChatAction', ['chat_id' => $chat, 'action' => 'upload_photo']);
    $base = ['chat_id' => $chat, 'caption' => $cap, 'parse_mode' => 'HTML', 'reply_markup' => ['inline_keyboard' => $kb]];
    $r = tg_call('sendPhoto', $base + ['photo' => new CURLFile($path, 'image/png', 'savol.png')], null, 60);
    if (!$r['ok'] && $r['code'] === 400) {                 // juda cho'zinchoq rasm kabi hollarda — fayl sifatida
        $r = tg_call('sendDocument', $base + ['document' => new CURLFile($path, 'image/png', 'savol-' . $pos . '.png')], null, 60);
    }
    if (!$r['ok']) tg_send($chat, 'Savolni yuborib bo‘lmadi. Birozdan keyin /mashq orqali davom eting.');
}

/** Ochiq savolga (yoki harf bilan) matnli javob. true — qabul qilindi */
function tg_qb_text(int $chat, array $st, array $state, string $text): bool
{
    if (!preg_match('/^(\d+):(\d+)$/', (string)$state['data'], $m)) return false;
    $tid = (int)$m[1]; $pos = (int)$m[2];
    $t = tg_qb_own_test($tid, (int)$st['id']);
    if (!$t) { q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); return false; }
    $it = row('SELECT i.given, q.kind, q.nopt FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND i.pos=?', [$tid, $pos]);
    if (!$it) return false;
    $val = trim($text);
    if ($it['kind'] === 'open') {
        if (mb_strlen($val) > 80) { tg_send($chat, 'Javob juda uzun (80 belgigacha). Eng sodda ko‘rinishda yozing.'); return true; }
    } else {
        $val = strtoupper($val);
        $max = (int)$it['nopt'] === 6 ? 'F' : 'D';
        if (!preg_match('/^[A-F]$/', $val) || $val > $max) { tg_send($chat, 'Bu savolga tugmalar bilan javob bering (A–' . $max . ').'); return true; }
    }
    q('UPDATE qb_items SET given=? WHERE test_id=? AND pos=?', [$val, $tid, $pos]);
    tg_send($chat, '✔️ ' . $pos . '-savol: <code>' . tg_h($val) . '</code>');
    tg_qb_next($chat, $st, $tid, $pos);
    return true;
}

/** Mashqni yakunlaydi va faqat sonlarni yuboradi */
function tg_qb_finish(int $chat, int $tid): void
{
    qb_finish($tid, []);
    q('DELETE FROM tg_state WHERE chat_id=? AND step IN ("qb","qbkeys")', [$chat]);
    $r = qb_result($tid);
    $pct = $r['total'] > 0 ? round(100 * $r['ok'] / $r['total']) : 0;
    $asg = !empty($r['test']['assign_id']) ? row('SELECT * FROM qb_assign WHERE id=?', [(int)$r['test']['assign_id']]) : null;
    $s = "🏁 <b>" . ($asg ? 'Topshiriq topshirildi' : 'Mashq yakunlandi') . '</b> · ' . qb_code($tid) . ($asg ? "\n" . tg_h($asg['title']) : '') . "\n\nTo‘g‘ri javoblar: <b>" . $r['ok'] . ' / ' . $r['total'] . "</b> ($pct%)";
    if (count($r['sections']) > 1) {
        $s .= "\n\n<b>Bo‘limlar bo‘yicha:</b>";
        foreach ($r['sections'] as $x) $s .= "\n• " . tg_h($x['name']) . ': ' . $x['ok'] . ' / ' . $x['total'];
    }
    if ($asg && (int)$asg['review'] && $asg['closed_at'] === null) $s .= "\n\nXatolaringiz va to‘g‘ri javoblar muddat tugagach (<b>" . tg_dt($asg['deadline']) . "</b>) yuboriladi.";
    $s .= $pct >= 80 ? "\n\n🌟 Zo‘r natija! Shunday davom eting." : ($pct >= 50 ? "\n\n👍 Yaxshi. Xato qilgan mavzularni yana bir ishlab ko‘ring." : "\n\n💪 Bu mavzuni yana mashq qilish kerak — qayta urinib ko‘ring.");
    $kb = [];
    if (!$asg) {
        $secs = array_values(array_unique(array_map('intval', array_column(rows('SELECT DISTINCT section_id FROM qb_items WHERE test_id=?', [$tid]), 'section_id'))));
        $one = count($secs) === 1 && $secs[0] > 0 && !qb_section_closed($secs[0]) ? $secs[0] : 0;   // bo'lim keyin yopilgan bo'lsa — tugmasi yo'q (2.5.2)
        if ($one) $kb[] = [['text' => '🔁 Yana shu bo‘limdan', 'callback_data' => 'qbs:' . $one]];
        if ((int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND ok=0', [$tid]) > 0) $kb[] = [['text' => '🎯 Xatolarim ustida ishlash', 'callback_data' => 'qbe:' . $one . ':10']];
        $kb[] = [['text' => '📚 Boshqa bo‘lim', 'callback_data' => 'qbh:0'], ['text' => '📈 O‘zlashtirishim', 'callback_data' => 'qbo:0']];
    } else $kb[] = [['text' => '📋 Topshiriqlarim', 'callback_data' => 'qbl:0'], ['text' => '📝 Mashq qilish', 'callback_data' => 'qbh:0']];
    tg_send($chat, $s, ['inline_keyboard' => $kb]);
}

/* ---------------- 2.1: topshiriqlar, o'zlashtirish, menyu ---------------- */

/** Topshiriq xabari tugmalari (botda / saytda yechish) */
function tg_asg_kb(int $tid): array
{
    return ['inline_keyboard' => [
        [['text' => '▶️ Botda yechish', 'callback_data' => 'qbr:' . $tid]],
        [['text' => '📄 PDF yuklab olish', 'callback_data' => 'qbp:' . $tid], ['text' => '🌐 Saytda yechish', 'callback_data' => 'qbw:' . $tid]],
    ]];
}

/** Navbat: asg (yangi topshiriq), asgr/asgn (eslatma), asgd (muddat tugadi — natija) */
function tg_asg_job(array $j): array
{
    $a = row('SELECT * FROM qb_assign WHERE id=?', [(int)$j['test_id']]);
    if (!$a) return ['ok' => true, 'skip' => 'topshiriq o‘chirilgan'];
    $t = qb_assign_test((int)$a['id'], (int)$j['student_id']);
    if (!$t) return ['ok' => true, 'skip' => 'o‘quvchiga biriktirilmagan'];
    $chat = (int)$j['chat_id'];
    $dl = tg_dt($a['deadline']);
    if (qb_assign_is_paper($a)) {   // sinf testi: faqat natija (javoblari kiritilgan o'quvchilarga)
        if ($j['kind'] !== 'asgd') return ['ok' => true, 'skip' => 'sinf testi'];
        $t = row('SELECT * FROM qb_tests WHERE id=?', [$t['id']]);
        if (!$t || $t['status'] !== 'done') return ['ok' => true, 'skip' => 'natija kiritilmagan'];
        $r = qb_result((int)$t['id']);
        $pct = $r['total'] > 0 ? round(100 * $r['ok'] / $r['total']) : 0;
        $s = "📝 <b>" . tg_h($a['title']) . "</b> — sinf testi natijasi\n\nNatijangiz: <b>" . $r['ok'] . ' / ' . $r['total'] . "</b> ($pct%)";
        if (count($r['sections']) > 1) foreach ($r['sections'] as $x) $s .= "\n• " . tg_h($x['name']) . ': ' . $x['ok'] . ' / ' . $x['total'];
        $kb = (int)$a['review'] && $r['ok'] < $r['total'] ? tg_kb_cb('🔍 Xatolarimni ko‘rish', 'qbx:' . (int)$t['id']) : null;
        return tg_send($chat, $s, $kb);
    }
    if ($j['kind'] === 'asg') {
        if ($t['status'] !== 'open') return ['ok' => true, 'skip' => 'topshirgan'];
        $s = "📋 <b>Yangi topshiriq</b>\n\n<b>" . tg_h($a['title']) . "</b>\nTest kodi: <b>" . qb_code((int)$t['id']) . "</b>\nSavollar: <b>" . (int)$t['n'] . " ta</b>\nMuddat: <b>$dl</b> gacha"
           . ((int)$a['review'] ? "\n\nMuddat tugagach qaysi savollarda xato qilganingiz va to‘g‘ri javoblar ko‘rsatiladi." : '')
           . "\n\nBotda, PDF da (javoblarni kod bilan bitta xabarda yuborasiz) yoki saytda yechishingiz mumkin — javoblar bitta joyga saqlanadi.";
        return tg_send($chat, $s, tg_asg_kb((int)$t['id']));
    }
    if ($j['kind'] === 'asgr' || $j['kind'] === 'asgn') {
        if ($t['status'] !== 'open' || $a['closed_at'] !== null) return ['ok' => true, 'skip' => 'topshirgan'];
        $done = (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given NOT IN ("","-")', [$t['id']]);
        $s = "⏰ <b>" . tg_h($a['title']) . '</b> · ' . qb_code((int)$t['id']) . "\nMuddat: <b>$dl</b>" . ($j['kind'] === 'asgr' ? ' — 1 soatdan kam qoldi!' : '')
           . "\nJavob berilgan: <b>$done / " . (int)$t['n'] . "</b>" . ($done === 0 ? "\n⚠️ Hali boshlamadingiz." : '');
        return tg_send($chat, $s, tg_asg_kb((int)$t['id']));
    }
    if ($j['kind'] === 'asgd') {
        $t = row('SELECT * FROM qb_tests WHERE id=?', [$t['id']]);
        if (!$t || $t['status'] === 'open') return ['ok' => true, 'skip' => 'yakunlanmagan'];
        if ($t['status'] === 'missed') {
            $s = "⚠️ <b>" . tg_h($a['title']) . '</b> · ' . qb_code((int)$t['id']) . " — muddat tugadi.\nSiz bu topshiriqni bajarmadingiz (birorta javob yuborilmadi).";
            return tg_send($chat, $s, (int)$a['review'] ? tg_kb_cb('🔍 Savollar va to‘g‘ri javoblar', 'qbx:' . (int)$t['id']) : null);
        }
        $r = qb_result((int)$t['id']);
        $pct = $r['total'] > 0 ? round(100 * $r['ok'] / $r['total']) : 0;
        $s = "🏁 <b>" . tg_h($a['title']) . '</b> · ' . qb_code((int)$t['id']) . " — muddat tugadi\n\nNatijangiz: <b>" . $r['ok'] . ' / ' . $r['total'] . "</b> ($pct%)";
        if (count($r['sections']) > 1) foreach ($r['sections'] as $x) $s .= "\n• " . tg_h($x['name']) . ': ' . $x['ok'] . ' / ' . $x['total'];
        $kb = (int)$a['review'] && $r['ok'] < $r['total'] ? tg_kb_cb('🔍 Xatolarimni ko‘rish', 'qbx:' . (int)$t['id']) : null;
        return tg_send($chat, $s, $kb);
    }
    return ['ok' => true, 'skip' => 'noma’lum tur'];
}

/** «📋 Topshiriqlar»: ochiq va yaqinda yopilgan topshiriqlar */
function tg_asg_list(int $chat, array $st): void
{
    qb_assign_tick();
    $list = rows('SELECT t.*, a.deadline, a.closed_at, a.review, a.mode FROM qb_tests t JOIN qb_assign a ON a.id=t.assign_id WHERE t.student_id=? AND NOT (a.mode="paper" AND t.status="open")
                  AND (t.status="open" OR a.closed_at IS NULL OR a.closed_at > DATE_SUB(NOW(), INTERVAL 14 DAY)) ORDER BY t.status="open" DESC, a.deadline LIMIT 10', [$st['id']]);
    if (!$list) { tg_send($chat, '📋 Hozircha topshiriq yo‘q. Mashq qilish: /mashq'); return; }
    foreach ($list as $t) {
        $s = ($t['mode'] ?? '') === 'paper'
            ? "📝 <b>" . tg_h($t['title']) . "</b> · sinf testi\n" . (int)$t['n'] . ' ta savol · ' . tg_h(date('d.m.Y', strtotime((string)$t['deadline'])))
            : "📋 <b>" . tg_h($t['title']) . '</b> · ' . qb_code((int)$t['id']) . "\n" . (int)$t['n'] . ' ta savol · muddat: <b>' . tg_dt($t['deadline']) . '</b>';
        if ($t['status'] === 'open') { tg_send($chat, $s, tg_asg_kb((int)$t['id'])); continue; }
        $s .= $t['status'] === 'missed' ? (($t['mode'] ?? '') === 'paper' ? "\n❌ Qatnashmadi" : "\n❌ Topshirilmadi") : "\nNatija: <b>" . (int)$t['correct'] . ' / ' . (int)$t['n'] . '</b>';
        $kb = null;
        if ((int)$t['review'] && $t['closed_at'] !== null && !(($t['mode'] ?? '') === 'paper' && $t['status'] !== 'done')) $kb = tg_kb_cb('🔍 Xatolarimni ko‘rish', 'qbx:' . (int)$t['id']);
        elseif ((int)$t['review']) $s .= ($t['mode'] ?? '') === 'paper' ? "\nXatolar o‘qituvchi testni yakunlagach ko‘rsatiladi." : "\nXatolar muddat tugagach ko‘rsatiladi.";
        tg_send($chat, $s, $kb);
    }
}

/** Muddatdan keyin: xato savollar (rasm + sizning javob + to'g'ri javob) */
function tg_asg_review(int $chat, array $st, int $tid): void
{
    $t = row('SELECT * FROM qb_tests WHERE id=? AND student_id=?', [$tid, $st['id']]);
    if (!$t || !qb_review_allowed($t)) { tg_send($chat, 'Xatolar topshiriq muddati tugagach ko‘rsatiladi.'); return; }
    $items = qb_review_items($tid);
    $lines = [];
    $wrong = [];
    foreach ($items as $it) {
        if ($it['ok'] === null) continue;
        $g = $it['given'] !== '' && $it['given'] !== '-' ? $it['given'] : '—';
        if ((int)$it['ok'] === 1) $lines[] = (int)$it['pos'] . '. ✅ ' . tg_h($g);
        else { $lines[] = (int)$it['pos'] . '. ❌ ' . tg_h($g) . ' → <b>' . tg_h(qb_answer_show($it['kind'], $it['answer'])) . '</b>'; $wrong[] = $it; }
    }
    tg_send($chat, "🔍 <b>" . tg_h($t['title']) . '</b> · ' . qb_code($tid) . "\n\n" . implode("\n", $lines));
    foreach (array_slice($wrong, 0, 10) as $it) {
        $path = qb_dir() . '/' . basename((string)$it['img']);
        if (!$it['img'] || !is_file($path)) continue;
        $cap = '<b>' . (int)$it['pos'] . '-savol</b> · ' . tg_h($it['section_name']) . "\nSizning javob: <b>" . tg_h($it['given'] !== '' && $it['given'] !== '-' ? $it['given'] : '—') . "</b>\nTo‘g‘ri javob: <b>" . tg_h(qb_answer_show($it['kind'], $it['answer'])) . '</b>';
        $r = tg_call('sendPhoto', ['chat_id' => $chat, 'caption' => $cap, 'parse_mode' => 'HTML', 'photo' => new CURLFile($path, 'image/png', 'savol.png')], null, 60);
        if (!$r['ok'] && $r['code'] === 400) tg_call('sendDocument', ['chat_id' => $chat, 'caption' => $cap, 'parse_mode' => 'HTML', 'document' => new CURLFile($path, 'image/png', 'savol-' . (int)$it['pos'] . '.png')], null, 60);
    }
    if (count($wrong) > 10) tg_send($chat, 'Qolgan ' . (count($wrong) - 10) . ' ta xato savolni saytdagi «Topshiriq va mashq» bo‘limida ko‘ring.');
}

/** «📈 O'zlashtirish» matni */
function tg_mastery_text(array $st): string
{
    $sid = (int)$st['id'];
    $bar = function (int $p): string { $n = (int)round($p / 10); return str_repeat('▰', $n) . str_repeat('▱', 10 - $n); };
    $s = "📈 <b>O‘zlashtirishim</b>";
    $mock = student_section_avg(student_history($sid));
    $any = false;
    foreach ($mock as $x) if ((int)$x['total'] > 0) { if (!$any) $s .= "\n\n<b>MOCK bo‘limlari:</b>"; $any = true; $s .= "\n" . $bar((int)$x['pct']) . ' ' . (int)$x['pct'] . '% — ' . tg_h($x['name']); }
    $m = qb_mastery($sid);
    if ($m) {
        $s .= "\n\n<b>Savollar bazasi bo‘limlari:</b>";
        foreach (array_slice($m, 0, 25) as $x) $s .= "\n" . str_repeat('  ', (int)$x['depth']) . ($x['depth'] ? '· ' : '') . $bar((int)$x['pct']) . ' ' . (int)$x['pct'] . '% — ' . tg_h($x['name']) . ' <i>(' . (int)$x['k'] . '/' . (int)$x['n'] . ')</i>';
        $cs = qb_closed_sections();   // yopiq bo'limni /mashq da tanlab bo'lmaydi — maslahatga qo'shilmaydi (2.5.2)
        $weak = array_values(array_filter($m, fn($x) => $x['pct'] < 50 && $x['n'] >= 3 && !isset($cs[(int)$x['id']])));
        if ($weak) $s .= "\n\n💡 Ko‘proq ishlash kerak: " . implode(', ', array_map(fn($x) => tg_h($x['name']), array_slice($weak, 0, 3))) . '. /mashq';
    }
    if (!$any && !$m) $s .= "\n\nHali ma’lumot yo‘q — mashq qiling (/mashq) yoki MOCK natijasini kuting.";
    return $s;
}

/* ---------------- PDF va javoblarni bitta xabarda yuborish ---------------- */

/** Kalit yuborish namunasi (testdagi savol turlariga qarab) */
function tg_qb_keys_help(array $t): string
{
    $tid = (int)$t['id'];
    $c = qb_code($tid);
    $open = array_map('intval', array_column(rows('SELECT i.pos FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND q.kind="open"' . qb_test_open_sql($t) . ' ORDER BY i.pos', [$tid]), 'pos'));
    $n = (int)$t['n'];
    $s = "✍️ <b>$c</b> · " . tg_h($t['title']) . "\n$n ta savol javobini <b>bitta xabarda</b> yuboring, kod bilan boshlab:\n";
    if (!$open) $s .= "<code>$c " . substr(str_repeat('ABCD', (int)ceil(max(1, $n) / 4)), 0, min($n, 12)) . ($n > 12 ? '…' : '') . "</code>\n(har harf — bitta savol, tartib bilan)";
    else $s .= "<code>$c 1:A 2:C " . $open[0] . ":12</code>\n(raqam:javob; ochiq savollar: " . implode(', ', array_slice($open, 0, 10)) . ")";
    return $s . "\n\nXatoni tuzatish uchun faqat o‘sha raqamlarni qayta yuborsangiz bo‘ladi: <code>$c 5:B</code>";
}

/** O'quvchining testi PDF ko'rinishida (test kodi har sahifada) */
function tg_qb_send_pdf(int $chat, array $t): void
{
    $tid = (int)$t['id'];
    $pdf = qb_test_pdf($t);
    if ($pdf === null) { tg_send($chat, 'PDF yaratib bo‘lmadi. Savollarni botda yoki saytda yeching.', tg_asg_kb($tid)); return; }
    $tmp = tempnam(sys_get_temp_dir(), 'qbpdf');
    if ($tmp === false || file_put_contents($tmp, $pdf) === false) { tg_send($chat, 'PDF yaratib bo‘lmadi. Birozdan keyin urinib ko‘ring.'); return; }
    $as = !empty($t['assign_id']) ? row('SELECT deadline FROM qb_assign WHERE id=?', [(int)$t['assign_id']]) : null;
    $c = qb_code($tid);
    $cap = "📄 Test kodi: <b>$c</b>\n<b>" . tg_h($t['title']) . '</b> · ' . (int)$t['n'] . ' ta savol' . ($as ? "\nMuddat: <b>" . tg_dt($as['deadline']) . '</b> gacha' : '')
         . "\n\nYechib bo‘lgach javoblarni bitta xabarda yuboring: <code>$c ABCD…</code>\nyoki «✍️ Javoblarni yuborish» tugmasini bosing.";
    $kb = ['inline_keyboard' => [[['text' => '✍️ Javoblarni yuborish', 'callback_data' => 'qbj:' . $tid]]]];
    $r = tg_call('sendDocument', ['chat_id' => $chat, 'caption' => $cap, 'parse_mode' => 'HTML', 'reply_markup' => $kb,
        'document' => new CURLFile($tmp, 'application/pdf', 'test-' . $tid . '.pdf')], null, 120);
    @unlink($tmp);
    if (!$r['ok']) tg_send($chat, 'PDF ni yuborib bo‘lmadi. Birozdan keyin qayta urinib ko‘ring yoki saytdan yuklab oling.');
}

/**
 * Bitta xabardagi javoblar: «#123 ABCD…» (kod bilan) yoki «✍️ Javoblarni yuborish» rejimida kodsiz.
 * true — xabar shu yerda qayta ishlandi
 */
function tg_qb_keys(int $chat, array $st, int $tid, string $text): bool
{
    qb_assign_tick();
    $sid = (int)$st['id'];
    $c = qb_code($tid);
    $t = tg_qb_own_test($tid, $sid);
    if (!$t) {
        $any = row('SELECT t.status, a.closed_at FROM qb_tests t LEFT JOIN qb_assign a ON a.id=t.assign_id WHERE t.id=? AND t.student_id=?', [$tid, $sid]);
        q('DELETE FROM tg_state WHERE chat_id=? AND step="qbkeys"', [$chat]);
        tg_send($chat, $any ? "<b>$c</b> testi allaqachon yakunlangan" . ($any['closed_at'] !== null ? ' (topshiriq muddati tugagan)' : '') . '. Javoblar qabul qilinmadi.'
                            : "<b>$c</b> kodli test sizda topilmadi. Kodni PDF dagi «TEST KODI» yozuvidan tekshiring.");
        return true;
    }
    $body = trim((string)preg_replace('/^#[Aa]?\d+(?:\s*:\s*|\s+-\s+|\s+|$)/u', '', trim($text)));
    if ($body === '') {                                   // faqat kod yuborildi — shu test uchun javob kutamiz
        q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'qbkeys', (string)$tid]);
        tg_send($chat, tg_qb_keys_help($t));
        return true;
    }
    $r = qb_apply_keys($tid, $text);
    q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'qbkeys', (string)$tid]);   // tuzatishlarni kodsiz ham yuborsa bo'ladi
    if (!$r['saved'] && !$r['bad']) { tg_send($chat, "Javob topilmadi.\n\n" . tg_qb_keys_help($t)); return true; }
    $s = "📥 <b>$c</b> · " . tg_h($t['title']);
    if ($r['saved']) {
        $parts = [];
        foreach ($r['saved'] as $p => $v) $parts[] = $p . '-' . tg_h((string)$v);
        $s .= "\n\n✔️ Qabul qilindi: <b>" . count($r['saved']) . " ta</b>\n<code>" . implode(' ', $parts) . '</code>';
    }
    if ($r['bad']) {
        $parts = [];
        foreach (array_slice($r['bad'], 0, 15, true) as $p => $why) $parts[] = $p . ' (' . $why . ')';
        $s .= "\n\n⚠️ Qabul qilinmadi: " . tg_h(implode(', ', $parts));
    }
    $miss = $r['missing'];
    $s .= $miss ? "\n\n❔ Javobsiz: <b>" . count($miss) . ' ta</b> — ' . implode(', ', array_slice($miss, 0, 30)) . (count($miss) > 30 ? '…' : '') . "\n(yakunlasangiz javobsizlar noto‘g‘ri hisoblanadi)"
                : "\n\nBarcha " . (int)$r['total'] . ' ta savolga javob bor ✅';
    $s .= "\n\nTekshirish uchun «Yakunlash» ni bosing. Tuzatish: o‘sha raqamlarni qayta yuboring (<code>$c 5:B</code>).";
    tg_send($chat, $s, ['inline_keyboard' => [
        [['text' => '✅ Yakunlash va tekshirish', 'callback_data' => 'qbF:' . $tid]],
        [['text' => '✏️ Qayta yuborish', 'callback_data' => 'qbj:' . $tid]],
    ]]);
    return true;
}
