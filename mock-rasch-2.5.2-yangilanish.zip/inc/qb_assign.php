<?php
defined('APP_ROOT') || exit;
/**
 * Topshiriqlar (2.1): admin savollar bazasidan test tuzadi va o'quvchilarga (hammaga, guruhlarga yoki tanlangan o'quvchilarga) beradi.
 *  - onlayn (mode=online): hamma o'quvchiga bir xil tartib, muddat bilan; o'quvchi saytda yoki botda yechadi, javoblar avtomatik tekshiriladi.
 *    Muddat tugagach ochiq testlar yopiladi, `review=1` bo'lsa o'quvchi xatolarini va to'g'ri javoblarni ko'radi (muddatgacha — faqat sonlar).
 *  - sinf testi (mode=paper, 2.4): savollar bir xil, lekin har o'quvchida tartib boshqa (variant). Ismli varaqlar va bitta kalitlar varag'i
 *    chop etiladi; o'qituvchi javoblarni kiritsa — baholanadi. O'quvchi saytda/botda yecha olmaydi, natija kiritilgach ko'radi.
 * O'zlashtirish: savollar bazasi bo'limlari (mashq + topshiriq) va MOCK bo'limlari (Algebra/Geometriya).
 * PHP 7.4 bilan mos.
 */

/** Savollar avvalgi topshiriqlarda necha marta berilgan: [question_id => soni] */
function qb_usage_counts(): array
{
    $out = [];
    foreach (rows('SELECT question_id, COUNT(*) c FROM qb_assign_items GROUP BY question_id') as $r) $out[(int)$r['question_id']] = (int)$r['c'];
    return $out;
}

/** Barqaror tartiblash (PHP 7.4 da usort barqaror emas): teng elementlar avvalgi tartibida qoladi */
function qb_stable_sort(array $list, callable $key): array
{
    $dec = [];
    foreach (array_values($list) as $i => $r) $dec[] = [$key($r), $i, $r];
    usort($dec, function ($a, $b) { return [$a[0], $a[1]] <=> [$b[0], $b[1]]; });
    return array_map(function ($x) { return $x[2]; }, $dec);
}

/**
 * Topshiriq savollari (2.4): tanlangan bo'limlardan NAVBAT bilan — har bo'limdan bittadan, keyin yana tartib bo'yicha
 * (3 ta qiyin bo'lim, 5 ta qiyin savol → 1-, 2-, 3-, yana 1- va 2-bo'limdan). Bo'lim ichida avvalgi topshiriqlarda kam berilgan savollar ustuvor.
 * $levelCounts — [daraja => soni] (masalan [1=>3, 2=>5, 3=>2]); bo'sh bo'lsa, darajasidan qat'i nazar $n ta.
 * Tartib: osondan qiyinga, bir daraja ichida — bo'limlar navbati. Qaytaradi: [['id','section_id','name','level'],…]
 * $withClosed (2.5.2) — yopiq savollar ham olinadi (shaklda «Yopiq savollarni ham qo'shish»); odatda olinmaydi.
 */
function qb_pick_questions(array $sectionIds, int $n, array $levelCounts = [], bool $withClosed = false): array
{
    $levelCounts = array_filter(array_map('intval', $levelCounts), function ($c) { return $c > 0; });
    ksort($levelCounts);
    $used = qb_usage_counts();
    $order = function (array $list) use ($used) {
        shuffle($list);
        return qb_stable_sort($list, function ($r) use ($used) { return $used[(int)$r['id']] ?? 0; });
    };
    if ($levelCounts) {
        $out = [];
        foreach ($levelCounts as $lv => $c) $out = array_merge($out, qb_pick_balanced(qb_pool($sectionIds, [(int)$lv], $withClosed), $sectionIds, $c, $order, true));
        return $out;
    }
    $out = qb_pick_balanced(qb_pool($sectionIds, null, $withClosed), $sectionIds, max(1, $n), $order, true);
    return qb_stable_sort($out, function ($r) { return qb_level_rank((int)$r['level']); });
}

/** Tanlangan bo'limlardagi kalitli savollar darajalar bo'yicha: [0=>…, 1=>…, 2=>…, 3=>…]. $withClosed — yopiqlari bilan (2.5.2) */
function qb_level_counts(array $sectionIds, bool $withClosed = false): array
{
    $out = [0 => 0, 1 => 0, 2 => 0, 3 => 0];
    foreach (qb_pool($sectionIds, null, $withClosed) as $r) { $lv = (int)$r['level']; $out[isset($out[$lv]) ? $lv : 0]++; }
    return $out;
}

/**
 * Auditoriya: ['all'=>1], ['groups'=>[nom,…]] yoki ['students'=>[id,…]] (2.4) →
 * o'quvchilar [['id','code','tg_chat_id','full_name','group_name'],…] (F.I.Sh bo'yicha)
 */
function qb_assign_students(array $aud): array
{
    $cols = 'id, code, tg_chat_id, full_name, group_name';
    if (!empty($aud['all'])) return rows("SELECT $cols FROM students WHERE archived_at IS NULL ORDER BY full_name, id");
    if (isset($aud['students'])) {
        $ids = array_values(array_unique(array_filter(array_map('intval', (array)$aud['students']))));
        if (!$ids) return [];
        $in = implode(',', array_fill(0, count($ids), '?'));
        return rows("SELECT $cols FROM students WHERE archived_at IS NULL AND id IN ($in) ORDER BY full_name, id", $ids);
    }
    $g = array_values(array_filter(array_map('strval', (array)($aud['groups'] ?? []))));
    if (!$g) return [];
    $in = implode(',', array_fill(0, count($g), '?'));
    return rows("SELECT $cols FROM students WHERE archived_at IS NULL AND group_name IN ($in) ORDER BY full_name, id", $g);
}

function qb_assign_aud_label(array $a): string
{
    $aud = json_decode((string)$a['aud'], true) ?: [];
    if (isset($aud['anon'])) return 'Ismsiz: ' . (int)$aud['anon'] . ' ta variant';
    if (!empty($aud['all'])) return 'Barcha o\'quvchilar';
    if (isset($aud['students'])) return 'Tanlangan: ' . count((array)$aud['students']) . ' ta o\'quvchi';
    $g = (array)($aud['groups'] ?? []);
    return $g ? 'Guruh: ' . implode(', ', $g) : '—';
}

/** Sinf testimi (qog'oz varaqlar, har o'quvchiga alohida tartib) */
function qb_assign_is_paper(?array $a): bool
{
    return $a !== null && ($a['mode'] ?? 'online') === 'paper';
}

/** Sinf testi ismsiz variantlardanmi (o'quvchi tanlanmagan — ism varaqqa qo'lda yoziladi) */
function qb_assign_is_anon(?array $a): bool
{
    if (!qb_assign_is_paper($a)) return false;
    $aud = json_decode((string)($a['aud'] ?? ''), true);
    return is_array($aud) && isset($aud['anon']);
}

/** O'quvchi testi sinf testiga tegishlimi */
function qb_test_is_paper(array $t): bool
{
    static $c = [];
    $aid = (int)($t['assign_id'] ?? 0);
    if (!$aid) return false;
    if (!array_key_exists($aid, $c)) $c[$aid] = (string)val('SELECT mode FROM qb_assign WHERE id=?', [$aid]) === 'paper';
    return $c[$aid];
}

/** Javob varag'i turlari (sinf testi) */
const QB_SHEETS = ['bubble' => 'Bo\'yash (doirachalar)', 'write' => 'Yozish (katakchalar)'];
/** Ismsiz variantlar soni chegarasi (bitta sinf testida) */
const QB_ANON_MAX = 300;

/**
 * Sinf testi variantlari: $count ta har xil tartib (savollar bir xil, joylari boshqa). Har yangi variant oldingilaridan iloji boricha
 * farq qiladi — bir joyda bir xil savol va bir xil javob harfi kam bo'lsin (yonidagidan ko'chirsa ham foydasi bo'lmasin).
 * $keys — savollar javoblari (asl tartibda); $existing — mavjud variantlar (yangilari ulardan ham farq qilsin).
 * Qaytaradi: faqat yangi variantlar [[asl indekslar…], …]
 */
function qb_variants(array $keys, int $count, array $existing = []): array
{
    $keys = array_values(array_map(function ($k) { return strtoupper(trim((string)$k)); }, $keys));
    $n = count($keys);
    $base = range(0, max(0, $n - 1));
    $out = array_values($existing); $seen = [];
    foreach ($out as $e) $seen[implode(',', $e)] = 1;
    $first = count($out);
    $t0 = microtime(true);
    for ($v = 0; $v < $count; $v++) {
        $cmp = array_slice($out, -40);   // oldingi variantlar (ko'p bo'lsa — oxirgi 40 tasi, tezlik uchun)
        $last = count($cmp) - 1;          // oxirgisi — keyingi raqamli varaq (odatda yonma-yon tarqatiladi)
        // baho: eng o'xshash variant bilan (bir joyda bir xil savol — 3, boshqa savol lekin bir xil javob harfi — 1), keyin oldingi raqam bilan, keyin jami
        $score = function (array $p) use ($cmp, $keys, $n, $last): int {
            $worst = 0; $sum = 0; $adj = 0;
            foreach ($cmp as $qi => $q) {
                $c = 0;
                for ($i = 0; $i < $n; $i++) {
                    if ($p[$i] === $q[$i]) $c += 3;
                    elseif ($keys[$p[$i]] !== '' && $keys[$p[$i]] === $keys[$q[$i]]) $c++;
                }
                if ($c > $worst) $worst = $c;
                if ($qi === $last) $adj = $c;
                $sum += $c;
            }
            return $worst * 10000000 + $adj * 10000 + $sum;
        };
        $slow = microtime(true) - $t0 > 2.5;   // juda ko'p o'quvchi/savol — oddiy aralashtirish bilan tugatamiz
        $tries = $n <= 1 ? 1 : ($slow ? 3 : ($n <= 3 ? 12 : 60));
        $best = null; $bestScore = PHP_INT_MAX;
        for ($t = 0; $t < $tries; $t++) {
            $p = $base;
            if ($n > 1) shuffle($p);
            $sc = isset($seen[implode(',', $p)]) ? PHP_INT_MAX - 1 : ($cmp ? $score($p) : 0);
            if ($sc < $bestScore) { $best = $p; $bestScore = $sc; }
        }
        if ($n > 3 && $cmp && !$slow) {   // mahalliy yaxshilash: ikki savol o'rnini almashtirib ko'ramiz
            for ($s = 0; $s < 4 * $n; $s++) {
                $i = mt_rand(0, $n - 1); $j = mt_rand(0, $n - 1);
                if ($i === $j) continue;
                $p = $best; $x = $p[$i]; $p[$i] = $p[$j]; $p[$j] = $x;
                if (isset($seen[implode(',', $p)])) continue;
                $sc = $score($p);
                if ($sc < $bestScore) { $best = $p; $bestScore = $sc; }
            }
        }
        $seen[implode(',', $best)] = 1;
        $out[] = $best;
    }
    return array_slice($out, $first);
}

/**
 * Sinf testiga o'quvchi qo'shish (kech kelgan yoki unutilgan): savollar o'sha, tartibi — yangi variant. Qaytaradi: qo'shilganlar soni
 */
function qb_paper_add_students(int $aid, array $ids): int
{
    $a = row('SELECT * FROM qb_assign WHERE id=?', [$aid]);
    if (!qb_assign_is_paper($a) || qb_assign_is_anon($a)) return 0;
    $have = array_map('intval', array_column(rows('SELECT student_id FROM qb_tests WHERE assign_id=?', [$aid]), 'student_id'));
    $ids = array_values(array_diff(array_unique(array_filter(array_map('intval', $ids))), $have));
    if (!$ids) return 0;
    $studs = qb_assign_students(['students' => $ids]);
    if (!$studs) return 0;
    return qb_paper_add_tests($a, array_map(function ($s) { return (int)$s['id']; }, $studs));
}

/** Ismsiz sinf testiga yana $k ta variant (har biri avvalgilaridan farqli tartibda). Qaytaradi: qo'shilganlar soni */
function qb_paper_add_variants(int $aid, int $k): int
{
    $a = row('SELECT * FROM qb_assign WHERE id=?', [$aid]);
    if (!qb_assign_is_anon($a) || $k < 1) return 0;
    $have = (int)val('SELECT COUNT(*) FROM qb_tests WHERE assign_id=?', [$aid]);
    $k = min($k, 100, max(0, QB_ANON_MAX - $have));
    return $k ? qb_paper_add_tests($a, array_fill(0, $k, null)) : 0;
}

/** Sinf testiga yangi variantlar: $sids — o'quvchilar id si (ismsiz variant uchun null). Auditoriya ham yangilanadi */
function qb_paper_add_tests(array $a, array $sids): int
{
    $aid = (int)$a['id'];
    if (!$sids) return 0;
    $base = rows('SELECT ai.pos, ai.question_id, ai.section_id, ai.section_name, q.answer FROM qb_assign_items ai LEFT JOIN qb_questions q ON q.id=ai.question_id WHERE ai.assign_id=? ORDER BY ai.pos', [$aid]);
    if (!$base) return 0;
    $idx = [];
    foreach ($base as $i => $r) $idx[(int)$r['question_id']] = $i;
    $existing = [];
    foreach (rows('SELECT id FROM qb_tests WHERE assign_id=? ORDER BY var_no', [$aid]) as $t) {
        $o = [];
        foreach (rows('SELECT question_id FROM qb_items WHERE test_id=? ORDER BY pos', [$t['id']]) as $it) if (isset($idx[(int)$it['question_id']])) $o[] = $idx[(int)$it['question_id']];
        if (count($o) === count($base)) $existing[] = $o;
    }
    $orders = qb_variants(array_map(function ($r) { return (string)$r['answer']; }, $base), count($sids), $existing);
    $var = (int)val('SELECT COALESCE(MAX(var_no),0) FROM qb_tests WHERE assign_id=?', [$aid]);
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $tIns = $pdo->prepare('INSERT INTO qb_tests (student_id, title, n, via, assign_id, var_no) VALUES (?,?,?,?,?,?)');
        $iIns = $pdo->prepare('INSERT INTO qb_items (test_id, pos, question_id, section_id, section_name) VALUES (?,?,?,?,?)');
        foreach (array_values($sids) as $k => $sid) {
            $tIns->execute([$sid, $a['title'], count($base), 'pap', $aid, ++$var]);
            $tid = (int)$pdo->lastInsertId();
            foreach ($orders[$k] as $i => $j) { $r = $base[$j]; $iIns->execute([$tid, $i + 1, $r['question_id'], $r['section_id'], $r['section_name']]); }
            // yakunlangan testga qo'shilsa ham «javobi kiritilmagan» (open) — o'quvchi savollarni oldindan ko'ra olmaydi
        }
        if (qb_assign_is_anon($a)) {   // ismsiz: variantlar soni
            q('UPDATE qb_assign SET aud=? WHERE id=?', [json_encode(['anon' => (int)val('SELECT COUNT(*) FROM qb_tests WHERE assign_id=?', [$aid])]), $aid]);
        } else {                       // auditoriya endi — aniq o'quvchilar ro'yxati (guruh bilan tuzilgan bo'lsa ham)
            $all = array_map('intval', array_column(rows('SELECT student_id FROM qb_tests WHERE assign_id=? AND student_id IS NOT NULL ORDER BY var_no', [$aid]), 'student_id'));
            q('UPDATE qb_assign SET aud=? WHERE id=?', [json_encode(['students' => $all]), $aid]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        return 0;
    }
    return count($sids);
}

/**
 * Topshiriq yaratadi va o'quvchilarga biriktiradi. $d: title, sections[], n, deadline ('Y-m-d H:i:s'), review, aud[], notify, levels[],
 * mode ('online' | 'paper' — sinf testi), sheet ('bubble' | 'write' — sinf testining javob varag'i),
 * closed (2.5.2) — yopiq savollar ham olinsin (odatda — yo'q: yopiq savollar faqat shu belgi bilan topshiriqqa kiradi).
 * Qaytaradi: [assign_id|null, xato, o'quvchilar soni]
 */
function qb_assign_create(array $d): array
{
    $n = max(1, min(60, (int)($d['n'] ?? 10)));
    $withClosed = !empty($d['closed']);
    $closedHint = function () use ($d, $withClosed): string {   // yopiq savollar hisobga olinmagani uchun yetmagan bo'lsa — maslahat
        if ($withClosed) return '';
        $secs = (array)($d['sections'] ?? []);
        $k = qb_pool_size($secs, null, true) - qb_pool_size($secs);
        return $k > 0 ? ' Bu bo\'limlarda yana ' . $k . ' ta yopiq savol bor — kerak bo\'lsa «Yopiq savollarni ham qo\'shish» ni belgilang.' : '';
    };
    $paper = ($d['mode'] ?? 'online') === 'paper';
    $sheet = $paper ? (isset(QB_SHEETS[(string)($d['sheet'] ?? '')]) ? (string)$d['sheet'] : 'bubble') : '';
    $deadline = $paper ? date('Y-m-d H:i:s') : (string)($d['deadline'] ?? '');   // sinf testida muddat yo'q — sanasi saqlanadi
    if (!$paper && (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/', $deadline) || strtotime($deadline) <= time() + 60)) return [null, 'Muddat kelajakdagi vaqt bo\'lsin', 0];
    // 2.3: darajalar bo'yicha soni (ixtiyoriy) — [1=>oson, 2=>o'rta, 3=>qiyin]
    $lv = [];
    foreach ((array)($d['levels'] ?? []) as $k => $c) if (isset(QB_LEVELS[(int)$k]) && (int)$c > 0) $lv[(int)$k] = min(60, (int)$c);
    ksort($lv);
    if ($lv) {
        if (array_sum($lv) > 60) return [null, 'Jami savollar soni 60 tadan oshmasin', 0];
        $have = qb_level_counts((array)($d['sections'] ?? []), $withClosed);
        $short = [];
        foreach ($lv as $k => $c) if ($have[$k] < $c) $short[] = QB_LEVELS[$k] . ': so\'ralgan ' . $c . ', bor ' . $have[$k];
        if ($short) return [null, 'Tanlangan bo\'limlarda savol yetarli emas — ' . implode('; ', $short) . '. Sonini kamaytiring yoki boshqa bo\'limlarni ham belgilang.' . $closedHint(), 0];
        $n = array_sum($lv);
    }
    $aud = (array)($d['aud'] ?? []);
    if (isset($aud['anon'])) {   // 2.4.2: ismsiz variantlar — o'quvchi tanlanmaydi, ism varaqqa qo'lda yoziladi
        if (!$paper) return [null, 'Ismsiz variantlar faqat sinf testida bo\'ladi', 0];
        $cnt = (int)$aud['anon'];
        if ($cnt < 1 || $cnt > QB_ANON_MAX) return [null, 'Variantlar soni 1 dan ' . QB_ANON_MAX . ' gacha bo\'lsin', 0];
        $studs = array_fill(0, $cnt, ['id' => null, 'tg_chat_id' => null]);
        $aud = ['anon' => $cnt];
    } else {
        $studs = qb_assign_students($aud);
        if (!$studs) return [null, isset($aud['students']) ? 'O\'quvchilarni belgilang' : 'Tanlangan auditoriyada o\'quvchi yo\'q', 0];
        if (isset($aud['students'])) $aud = ['students' => array_map(function ($s) { return (int)$s['id']; }, $studs)];
    }
    $pick = qb_pick_questions((array)($d['sections'] ?? []), $n, $lv, $withClosed);
    if (!$pick) { $h = $closedHint(); return [null, 'Tanlangan bo\'limlarda kalitli savol yo\'q' . ($h !== '' ? '.' . $h : ''), 0]; }
    $orders = [];   // o'quvchi → savollar tartibi (asl indekslar)
    if ($paper) {
        $ans = [];
        $ids = array_map(function ($r) { return (int)$r['id']; }, $pick);
        foreach (rows('SELECT id, answer FROM qb_questions WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', $ids) as $r) $ans[(int)$r['id']] = (string)$r['answer'];
        $orders = qb_variants(array_map(function ($r) use ($ans) { return $ans[(int)$r['id']] ?? ''; }, $pick), count($studs));
    }
    $title = trim((string)($d['title'] ?? ''));
    if ($title === '') {
        $names = [];
        foreach ((array)($d['sections'] ?? []) as $x) { $nm = (string)val('SELECT name FROM qb_sections WHERE id=?', [(int)$x]); if ($nm !== '') $names[] = $nm; }
        $title = ($paper ? 'Sinf testi: ' : 'Topshiriq: ') . ($names ? implode(', ', $names) : 'aralash');
    }
    $title = mb_strimwidth($title, 0, 150, '…');
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $lvStr = implode(',', array_map(function ($k, $c) { return $k . ':' . $c; }, array_keys($lv), $lv));
        q('INSERT INTO qb_assign (title, sections, n, deadline, review, aud, levels, mode, sheet) VALUES (?,?,?,?,?,?,?,?,?)',
            [$title, implode(',', array_map('intval', (array)($d['sections'] ?? []))), count($pick), $deadline, !empty($d['review']) ? 1 : 0, json_encode($aud, JSON_UNESCAPED_UNICODE), $lvStr,
             $paper ? 'paper' : 'online', $sheet]);
        $aid = (int)$pdo->lastInsertId();
        $ins = $pdo->prepare('INSERT INTO qb_assign_items (assign_id, pos, question_id, section_id, section_name) VALUES (?,?,?,?,?)');
        foreach ($pick as $i => $r) $ins->execute([$aid, $i + 1, $r['id'], $r['section_id'], $r['name']]);
        $tIns = $pdo->prepare('INSERT INTO qb_tests (student_id, title, n, via, assign_id, var_no) VALUES (?,?,?,?,?,?)');
        $iIns = $pdo->prepare('INSERT INTO qb_items (test_id, pos, question_id, section_id, section_name) VALUES (?,?,?,?,?)');
        foreach (array_values($studs) as $k => $s) {
            $tIns->execute([$s['id'], $title, count($pick), $paper ? 'pap' : 'web', $aid, $paper ? $k + 1 : null]);
            $tid = (int)$pdo->lastInsertId();
            $ord = $paper ? $orders[$k] : array_keys($pick);
            foreach ($ord as $i => $j) { $r = $pick[$j]; $iIns->execute([$tid, $i + 1, $r['id'], $r['section_id'], $r['name']]); }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        return [null, 'Saqlab bo\'lmadi: ' . $e->getMessage(), 0];
    }
    if (!$paper && !empty($d['notify']) && function_exists('tg_enqueue') && tg_ready()) {
        foreach ($studs as $s) if ($s['tg_chat_id'] !== null) tg_enqueue('asg', $aid, (int)$s['id'], (int)$s['tg_chat_id']);
    }
    return [$aid, '', count($studs)];
}

/* ---------------- Sinf testi (2.4) ---------------- */

/**
 * Sinf testining variantlari (o'quvchilar tartibida): [['tid','var_no','student_id','full_name','code','group_name','status','correct','n','finished_at',
 *  'items'=>[['pos','question_id','kind','nopt','answer','img','w','h','given','ok','section_name'],…]],…]
 */
function qb_paper_rows(int $aid): array
{
    $tests = rows('SELECT t.id tid, t.var_no, t.student_id, t.status, t.correct, t.n, t.finished_at, COALESCE(s.full_name, "") full_name, COALESCE(s.code, "") code, COALESCE(s.group_name, "") group_name
                   FROM qb_tests t LEFT JOIN students s ON s.id=t.student_id WHERE t.assign_id=? ORDER BY COALESCE(t.var_no, 99999), s.full_name, t.id', [$aid]);
    if (!$tests) return [];
    $by = [];
    $ids = array_map(function ($t) { return (int)$t['tid']; }, $tests);
    foreach (array_chunk($ids, 400) as $ch) {
        foreach (rows('SELECT i.test_id, i.pos, i.question_id, i.given, i.ok, i.section_name, q.kind, q.nopt, q.answer, q.img, q.w, q.h
                       FROM qb_items i LEFT JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id IN (' . implode(',', array_fill(0, count($ch), '?')) . ') ORDER BY i.test_id, i.pos', $ch) as $it)
            $by[(int)$it['test_id']][] = $it;
    }
    foreach ($tests as $k => $t) { $tests[$k]['items'] = $by[(int)$t['tid']] ?? []; if ($tests[$k]['var_no'] === null) $tests[$k]['var_no'] = $k + 1; }
    return $tests;
}

/** Kalitni qisqa ko'rsatish (sinf testi kalitlar varag'i): test — harf, ochiq — birinchi variant */
function qb_paper_key(?string $kind, ?string $answer): string
{
    $a = trim((string)$answer);
    if ($kind === 'open') { $a = trim(explode(';', $a)[0]); return $a; }
    return strtoupper($a);
}

/**
 * O'qituvchi kiritgan javoblar qatorini tahlil qiladi (o'quvchining o'z tartibida). Bo'sh joy bilan ajratilgan bo'laklar:
 *  «ABCDA BCD-A» — harflar test savollariga ketma-ket (ochiq savollar o'tkazib yuboriladi), «-» yoki «_» — javobsiz;
 *  «5», «12,5», «-3» kabi boshqa bo'lak — keyingi ochiq savolga; «6:5» yoki «6:-» — aniq joyga (keyingilari undan davom etadi).
 * Qaytaradi: ['vals'=>[pos=>javob ('' — javobsiz)], 'bad'=>[pos=>sabab]]
 */
function qb_paper_parse(array $items, string $text): array
{
    $byPos = [];
    foreach ($items as $it) $byPos[(int)$it['pos']] = $it;
    ksort($byPos);
    $open = function (int $p) use ($byPos): bool { return isset($byPos[$p]) && ($byPos[$p]['kind'] ?? 'mc') === 'open'; };
    $next = function (int $from, bool $wantOpen) use ($byPos, $open): int {
        foreach (array_keys($byPos) as $p) if ($p > $from && $open($p) === $wantOpen) return $p;
        return 0;
    };
    $blank = ['-', '_', '*', '?', ''];
    $raw = []; $out = ['vals' => [], 'bad' => []];
    $cur = 0;
    foreach (preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY) as $tok) {
        if (preg_match('/^(\d{1,3})[:=)](.*)$/u', $tok, $m)) { $cur = (int)$m[1]; $raw[$cur] = in_array($m[2], $blank, true) ? '' : $m[2]; continue; }
        if (preg_match('/^[A-Fa-f\-_*?]+$/', $tok)) {   // harflar — test savollariga
            foreach (str_split($tok) as $ch) {
                $p = $next($cur, false);
                if (!$p) { $out['bad'][max(array_merge([0], array_keys($byPos))) + 1] = 'ortiqcha javob — test savollari ' . count(array_filter(array_keys($byPos), function ($x) use ($open) { return !$open($x); })) . ' ta'; break 2; }
                $raw[$p] = ctype_alpha($ch) ? strtoupper($ch) : '';
                $cur = $p;
            }
            continue;
        }
        $p = $next($cur, true);   // son yoki boshqa yozuv — keyingi ochiq savolga
        if (!$p) { $out['bad'][$cur + 1] = 'tushunarsiz: «' . mb_substr($tok, 0, 12) . '» (ochiq savol qolmagan)'; continue; }
        $raw[$p] = $tok; $cur = $p;
    }
    foreach ($raw as $pos => $v) {
        if (!isset($byPos[$pos])) { $out['bad'][$pos] = 'bunday savol yo\'q'; continue; }
        $it = $byPos[$pos];
        if ($v === '') { $out['vals'][$pos] = ''; continue; }
        if (($it['kind'] ?? 'mc') === 'open') {
            if (mb_strlen($v) > 80) { $out['bad'][$pos] = 'javob 80 belgidan oshmasin'; continue; }
            $out['vals'][$pos] = $v;
        } else {
            $v = strtoupper($v); $max = (int)($it['nopt'] ?? 4) === 6 ? 'F' : 'D';
            if (!preg_match('/^[A-F]$/', $v) || $v > $max) { $out['bad'][$pos] = 'A–' . $max . ' bo\'lishi kerak'; continue; }
            $out['vals'][$pos] = $v;
        }
    }
    ksort($out['vals']); ksort($out['bad']);
    return $out;
}

/**
 * Saqlangan javoblardan qator (kiritish maydonini to'ldirish uchun; qb_paper_parse bilan bir xil ko'rinish).
 * $done — test baholangan: hamma javob bo'sh bo'lsa ham «-----» ko'rinadi (o'chirib, «kiritilmagan» ga qaytarish mumkin bo'lsin).
 */
function qb_paper_answers_str(array $items, bool $done = false): string
{
    $any = $done;
    foreach ($items as $it) if (!in_array((string)$it['given'], ['', '-'], true)) { $any = true; break; }
    if (!$any) return '';
    $parts = []; $grp = ''; $k = 0;
    foreach (array_values($items) as $it) {
        $g = in_array((string)$it['given'], ['', '-'], true) ? '' : (string)$it['given'];
        if (($it['kind'] ?? 'mc') === 'open') {
            if ($grp !== '') { $parts[] = $grp; $grp = ''; }
            $parts[] = $g !== '' && !preg_match('/\s/u', $g) && !preg_match('/^[A-Fa-f\-_*?]+$/', $g) && !preg_match('/^\d{1,3}[:=)]/', $g) ? $g : (int)$it['pos'] . ':' . ($g === '' ? '-' : $g);
            $k = 0;
            continue;
        }
        if ($k && $k % 5 === 0) { $parts[] = $grp; $grp = ''; }
        $grp .= $g === '' ? '-' : strtoupper($g);
        $k++;
    }
    if ($grp !== '') $parts[] = $grp;
    return implode(' ', $parts);
}

/**
 * Sinf testi: o'qituvchi kiritgan javoblarni saqlab baholaydi (qayta kiritilsa — qayta baholanadi). Bo'sh qator — javoblar o'chiriladi, test «kutilmoqda» ga qaytadi.
 * Qaytaradi: ['ok'=>bool, 'error'=>'', 'correct'=>n, 'n'=>jami, 'bad'=>[pos=>sabab]]
 */
function qb_paper_save(int $tid, string $text): array
{
    $t = row('SELECT t.*, a.closed_at, a.mode FROM qb_tests t JOIN qb_assign a ON a.id=t.assign_id WHERE t.id=?', [$tid]);
    if (!$t || $t['mode'] !== 'paper') return ['ok' => false, 'error' => 'Test topilmadi', 'correct' => 0, 'n' => 0, 'bad' => []];
    $items = rows('SELECT i.pos, q.kind, q.nopt FROM qb_items i LEFT JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? ORDER BY i.pos', [$tid]);
    $p = qb_paper_parse($items, $text);
    if ($p['bad']) return ['ok' => false, 'error' => 'Noto\'g\'ri: ' . implode('; ', array_map(function ($pos, $why) { return $pos . '-savol — ' . $why; }, array_keys($p['bad']), $p['bad'])), 'correct' => 0, 'n' => count($items), 'bad' => $p['bad']];
    $pdo = db();
    $pdo->beginTransaction();
    try {
        q('UPDATE qb_items SET given="", ok=NULL WHERE test_id=?', [$tid]);
        if (trim($text) === '') {   // «javobi kiritilmagan» ga qaytadi (yakunlangan bo'lsa ham)
            q('UPDATE qb_tests SET status="open", correct=NULL, finished_at=NULL WHERE id=?', [$tid]);
            $pdo->commit();
            return ['ok' => true, 'error' => '', 'correct' => 0, 'n' => count($items), 'bad' => [], 'cleared' => true];
        }
        foreach ($p['vals'] as $pos => $v) q('UPDATE qb_items SET given=? WHERE test_id=? AND pos=?', [$v, $tid, $pos]);
        q('UPDATE qb_tests SET status="open" WHERE id=?', [$tid]);
        $ok = qb_finish($tid, []);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        return ['ok' => false, 'error' => 'Saqlab bo\'lmadi: ' . $e->getMessage(), 'correct' => 0, 'n' => count($items), 'bad' => []];
    }
    return ['ok' => true, 'error' => '', 'correct' => $ok, 'n' => (int)val('SELECT n FROM qb_tests WHERE id=?', [$tid]), 'bad' => []];
}

/** O'quvchining shu topshiriqdagi testi */
function qb_assign_test(int $aid, int $sid): ?array
{
    return row('SELECT * FROM qb_tests WHERE assign_id=? AND student_id=? ORDER BY id DESC LIMIT 1', [$aid, $sid]);
}

/** Topshiriq muddati o'tganmi */
function qb_assign_due(array $a): bool
{
    return strtotime((string)$a['deadline']) <= time();
}

/** Muddati o'tgan topshiriqni yopadi: ochiq testlar saqlangan javoblar bilan tekshiriladi, Telegramga natija navbatga qo'yiladi */
function qb_assign_close(int $aid): int
{
    $a = row('SELECT * FROM qb_assign WHERE id=?', [$aid]);
    if (!$a || $a['closed_at'] !== null) return 0;
    $up = q('UPDATE qb_assign SET closed_at=NOW() WHERE id=? AND closed_at IS NULL', [$aid]);
    if (!$up->rowCount()) return 0;   // boshqa jarayon yopdi
    $n = 0;
    foreach (rows('SELECT t.id, (SELECT COUNT(*) FROM qb_items i WHERE i.test_id=t.id AND i.given NOT IN ("","-")) ans FROM qb_tests t WHERE t.assign_id=? AND t.status="open"', [$aid]) as $t) {
        qb_finish((int)$t['id'], []);   // xatolarni ko'rish uchun baribir tekshiriladi
        if ((int)$t['ans'] === 0) q('UPDATE qb_tests SET status="missed" WHERE id=?', [$t['id']]);   // birorta javob yo'q — «topshirmadi» (o'zlashtirishga kirmaydi)
        $n++;
    }
    if (function_exists('tg_enqueue') && tg_ready()) {   // sinf testida — faqat javoblari kiritilganlarga (kelmaganlarga «bajarmadingiz» yuborilmaydi)
        foreach (rows('SELECT t.student_id, s.tg_chat_id FROM qb_tests t JOIN students s ON s.id=t.student_id WHERE t.assign_id=? AND s.tg_chat_id IS NOT NULL' . (qb_assign_is_paper($a) ? ' AND t.status="done"' : ''), [$aid]) as $r)
            tg_enqueue('asgd', $aid, (int)$r['student_id'], (int)$r['tg_chat_id']);
    }
    return $n;
}

/** Vaqtli ishlar: muddati o'tganlarni yopish, muddatga 1 soat qolganda eslatma. Sahifalardan ham chaqiriladi (arzon) */
function qb_assign_tick(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        foreach (rows('SELECT id FROM qb_assign WHERE closed_at IS NULL AND deadline<=NOW() AND mode<>"paper"') as $a) qb_assign_close((int)$a['id']);   // sinf testi muddatsiz — o'qituvchi yakunlaydi
        if (function_exists('tg_enqueue') && tg_ready()) {
            foreach (rows('SELECT id FROM qb_assign WHERE closed_at IS NULL AND mode<>"paper" AND deadline>NOW() AND deadline<=DATE_ADD(NOW(), INTERVAL 60 MINUTE)') as $a) {
                foreach (rows('SELECT t.student_id, s.tg_chat_id FROM qb_tests t JOIN students s ON s.id=t.student_id WHERE t.assign_id=? AND t.status="open" AND s.tg_chat_id IS NOT NULL', [$a['id']]) as $r)
                    tg_enqueue('asgr', (int)$a['id'], (int)$r['student_id'], (int)$r['tg_chat_id']);
            }
        }
    } catch (Throwable $e) { /* jadval hali yo'q (migratsiyadan oldin) — e'tiborsiz */ }
}

/**
 * Xatolarni ko'rsatish mumkinmi: topshiriq yopilgan va review yoqilgan. Sinf testida — faqat javoblari kiritilgan (done) o'quvchiga:
 * kelmagan o'quvchi savol va kalitlarni ko'rmaydi (keyin qog'ozda yozib berishi mumkin).
 */
function qb_review_allowed(array $test): bool
{
    if (empty($test['assign_id'])) return false;
    $a = row('SELECT review, closed_at, mode FROM qb_assign WHERE id=?', [(int)$test['assign_id']]);
    if (!$a || (int)$a['review'] !== 1 || $a['closed_at'] === null) return false;
    return ($a['mode'] ?? 'online') === 'paper' ? $test['status'] === 'done' : in_array($test['status'], ['done', 'missed'], true);
}

/** Ko'rib chiqish ro'yxati: [['pos','question_id','img','kind','given','answer','ok','section_name'],…] */
function qb_review_items(int $tid): array
{
    return rows('SELECT i.pos, i.question_id, i.given, i.ok, i.section_name, q.img, q.kind, q.answer FROM qb_items i LEFT JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? ORDER BY i.pos', [$tid]);
}

/** Ochiq javobning kalitidagi birinchi variant (ko'rsatish uchun) */
function qb_answer_show(?string $kind, ?string $answer): string
{
    $a = (string)$answer;
    if ($kind === 'open') return str_replace(';', ' yoki ', $a);
    return $a;
}

/* ---------------- O'zlashtirish ---------------- */

/** Bo'lim → eng yuqori (asosiy) bo'lim id xaritasi */
function qb_root_map(): array
{
    $par = [];
    foreach (rows('SELECT id, parent_id FROM qb_sections') as $r) $par[(int)$r['id']] = $r['parent_id'] !== null ? (int)$r['parent_id'] : 0;
    $root = [];
    foreach ($par as $id => $p) {
        $x = $id; $guard = 0;
        while (!empty($par[$x]) && isset($par[$par[$x]]) && $guard++ < 20) $x = $par[$x];
        $root[$id] = $x;
    }
    return $root;
}

/**
 * O'quvchining savollar bazasi bo'limlari bo'yicha o'zlashtirishi (yakunlangan mashq va topshiriqlardan).
 * Qaytaradi daraxt tartibida: [['id','name','depth','n','k','pct'],…] — har bo'lim ichki bo'limlari bilan jamlangan.
 */
function qb_mastery(int $sid): array
{
    $raw = [];
    foreach (rows('SELECT i.section_id, SUM(i.ok IS NOT NULL) n, SUM(i.ok=1) k FROM qb_items i JOIN qb_tests t ON t.id=i.test_id WHERE t.student_id=? AND t.status="done" GROUP BY i.section_id', [$sid]) as $r)
        $raw[(int)$r['section_id']] = [(int)$r['n'], (int)$r['k']];
    if (!$raw) return [];
    $par = [];
    foreach (rows('SELECT id, parent_id FROM qb_sections') as $r) $par[(int)$r['id']] = $r['parent_id'] !== null ? (int)$r['parent_id'] : 0;
    $agg = [];
    foreach ($raw as $id => $nk) {
        $x = $id; $guard = 0;
        while ($x && isset($par[$x]) && $guard++ < 20) {   // o'zi va barcha ota bo'limlariga qo'shamiz
            $agg[$x] = $agg[$x] ?? [0, 0];
            $agg[$x][0] += $nk[0]; $agg[$x][1] += $nk[1];
            $x = $par[$x];
        }
    }
    $out = [];
    foreach (qb_tree() as $s) {
        $id = (int)$s['id'];
        if (empty($agg[$id][0])) continue;
        [$n, $k] = $agg[$id];
        $out[] = ['id' => $id, 'name' => $s['name'], 'depth' => (int)$s['depth'], 'n' => $n, 'k' => $k, 'pct' => (int)round(100 * $k / $n)];
    }
    return $out;
}

/** Guruh (yoki hammasi) bo'yicha: o'quvchi × asosiy bo'lim. Qaytaradi ['roots'=>[id=>nom], 'rows'=>[sid=>[root=>[n,k]]], 'students'=>[…]] */
function qb_mastery_group(string $group = ''): array
{
    $roots = [];
    foreach (qb_tree() as $s) if ((int)$s['depth'] === 0) $roots[(int)$s['id']] = $s['name'];
    $studs = $group !== '' ? rows('SELECT id, code, full_name, group_name FROM students WHERE group_name=? AND archived_at IS NULL ORDER BY full_name', [$group])
                           : rows('SELECT id, code, full_name, group_name FROM students WHERE archived_at IS NULL ORDER BY full_name');
    $rootOf = qb_root_map();
    $data = [];
    if ($studs) {
        $ids = array_map(fn($s) => (int)$s['id'], $studs);
        foreach (array_chunk($ids, 500) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '?'));
            foreach (rows("SELECT t.student_id, i.section_id, SUM(i.ok IS NOT NULL) n, SUM(i.ok=1) k FROM qb_items i JOIN qb_tests t ON t.id=i.test_id
                           WHERE t.status='done' AND t.student_id IN ($in) GROUP BY t.student_id, i.section_id", $chunk) as $r) {
                $root = $rootOf[(int)$r['section_id']] ?? 0;
                if (!$root) continue;
                $d = &$data[(int)$r['student_id']][$root];
                $d = $d ?? [0, 0];
                $d[0] += (int)$r['n']; $d[1] += (int)$r['k'];
                unset($d);
            }
        }
    }
    return ['roots' => $roots, 'rows' => $data, 'students' => $studs];
}

/** O'zlashtirish rangi */
function pct_cls(int $p): string { return $p >= 70 ? 'hi' : ($p >= 40 ? 'mid' : 'lo'); }
