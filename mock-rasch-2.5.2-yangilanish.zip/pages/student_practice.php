<?php
defined('APP_ROOT') || exit;
/** O'quvchi: mashq testi tuzish (bo'limlar bo'yicha tasodifiy), mashqlar tarixi va bo'limlar bo'yicha umumiy natija */
$me = student();
$sid = (int)$me['id'];
qb_assign_tick();
if (is_post()) {
    csrf_check();
    $secs = array_values(array_filter(array_map('intval', (array)($_POST['sec'] ?? []))));
    $n = (int)($_POST['n'] ?? 10);
    $mode = ($_POST['mode'] ?? 'mix') === 'errors' ? 'errors' : 'mix';
    $lvs = array_values(array_filter(array_map('intval', (array)($_POST['lv'] ?? [])), fn($x) => isset(QB_LEVELS[$x])));
    $open = (int)val('SELECT COUNT(*) FROM qb_tests WHERE student_id=? AND status="open" AND assign_id IS NULL', [$sid]);
    $today = (int)val('SELECT COUNT(*) FROM qb_tests WHERE student_id=? AND assign_id IS NULL AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [$sid]);
    if ($open >= 8) flash('Yakunlanmagan mashqlaringiz ko\'p. Avval ularni topshiring yoki o\'chiring.', 'err');
    elseif ($today >= 40) flash('Bugungi mashq limiti tugadi. Ertaga davom eting.', 'warn');
    else {
        [$tid, $err, $info] = qb_build_test($sid, $secs, $n, 'web', ['mode' => $mode, 'levels' => $lvs]);
        if ($tid) { $note = qb_build_note((array)$info); if ($note !== '') flash($note, 'info'); redirect('student_practice_do', ['id' => $tid]); }
        flash($err, 'err');
    }
    redirect('student_practice');
}
$tree = qb_tree(true);   // 2.5.2: yopiq bo'lim va savollar o'quvchiga ko'rinmaydi
$tests = rows('SELECT * FROM qb_tests WHERE student_id=? AND assign_id IS NULL ORDER BY id DESC LIMIT 20', [$sid]);
// sinf testi (qog'ozda) — natijasi kiritilgandan keyin ko'rinadi
$asg = rows('SELECT t.*, a.deadline, a.closed_at, a.review, a.mode FROM qb_tests t JOIN qb_assign a ON a.id=t.assign_id WHERE t.student_id=? AND NOT (a.mode="paper" AND t.status="open")
             ORDER BY a.closed_at IS NULL DESC, a.deadline DESC LIMIT 30', [$sid]);
$m = qb_mastery($sid);
$mock = student_section_avg(student_history($sid));
$ready = array_filter($tree, fn($s) => $s['ready_total'] > 0);
$wrongN = $ready ? qb_wrong_count($sid) : 0;
$hasLv = $ready && (int)val("SELECT COUNT(*) FROM qb_questions WHERE answer<>'' AND level>0 AND " . qb_open_sql('')) > 0;
page_header('Topshiriq va mashq');
?>
<h1>Topshiriq va mashq</h1>

<?php if ($asg): ?>
<h2>Topshiriqlar</h2>
<?php foreach ($asg as $t): $closed = $t['closed_at'] !== null; $done = $t['status'] !== 'open'; $miss = $t['status'] === 'missed'; $left = strtotime((string)$t['deadline']) - time(); $pap = ($t['mode'] ?? '') === 'paper'; ?>
  <div class="card row between center-v asg-row">
    <div><b><?= e($t['title']) ?></b><?= $pap ? ' <span class="tag blue">sinf testi</span>' : '' ?>
      <?php if ($pap): ?><div class="small muted"><?= (int)$t['n'] ?> ta savol · sana: <b><?= e(date('d.m.Y', strtotime((string)$t['deadline']))) ?></b></div>
      <?php else: ?><div class="small muted"><?= (int)$t['n'] ?> ta savol · muddat: <b><?= e(date('d.m.Y H:i', strtotime((string)$t['deadline']))) ?></b><?php if (!$closed && $left > 0 && $left < 86400): ?> <span class="tag amber">~<?= max(1, (int)ceil($left / 3600)) ?> soat qoldi</span><?php endif; ?></div><?php endif; ?>
      <?php if ($miss): ?><div class="small"><span class="tag red"><?= $pap ? 'Qatnashmadi' : 'Topshirilmadi' ?></span> <span class="muted"><?= $pap ? 'sinf testida qatnashmadingiz' : 'muddatda birorta javob yuborilmadi' ?></span></div>
      <?php elseif ($done): ?><div class="small">Natija: <b><?= (int)$t['correct'] ?> / <?= (int)$t['n'] ?></b><?= !$closed && (int)$t['review'] ? ' · <span class="muted">xatolaringiz ' . ($pap ? 'o\'qituvchi testni yakunlagach' : 'muddat tugagach') . ' ko\'rinadi</span>' : '' ?></div><?php endif; ?>
    </div>
    <div class="right nowrap">
      <?php if (!$done): ?><a class="btn primary" href="<?= e(url('student_practice_do', ['id' => $t['id']])) ?>"><?= (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given NOT IN ("","-")', [$t['id']]) ? 'Davom ettirish' : 'Boshlash' ?></a>
      <?php else: $rv = $closed && (int)$t['review'] && !($pap && $miss); ?><a class="btn <?= $rv ? '' : 'ghost' ?>" href="<?= e(url('student_practice_do', ['id' => $t['id']])) ?>"><?= $rv ? 'Xatolarni ko\'rish' : 'Natija' ?></a><?php endif; ?>
    </div>
  </div>
<?php endforeach; ?>
<?php endif; ?>

<h2 class="mt">O'zlashtirishim</h2>
<?php include __DIR__ . '/_mastery_cards.php'; ?>

<h2 class="mt">Mashq testi</h2>
<p class="muted">Bo'limlarni tanlang — savollar bo'limlar bo'yicha teng olinadi. Avval xato qilgan yoki javobsiz qoldirgan savollaringiz ham qo'shiladi, to'g'ri yechganlaringiz qayta berilmaydi. Yakunda nechta savolni to'g'ri yechganingiz ko'rsatiladi.</p>

<?php if (!$ready): ?>
  <div class="card empty">Hozircha mashq savollari qo'shilmagan. Keyinroq qayta urinib ko'ring.</div>
<?php else: ?>
<form method="post" class="card form qb-build"><?= csrf_field() ?>
  <h3>Yangi mashq testi</h3>
  <div class="mode-pick" role="radiogroup" aria-label="Mashq turi">
    <label class="mode-opt"><input type="radio" name="mode" value="mix" checked><span><b>Yangi mashq</b><small>yangi savollar + avvalgi xatolaringiz</small></span></label>
    <label class="mode-opt<?= $wrongN ? '' : ' off' ?>"><input type="radio" name="mode" value="errors" <?= $wrongN ? '' : 'disabled' ?>><span><b>Xatolarim ustida ishlash</b><small><?= $wrongN ? $wrongN . ' ta savolda xato qilgansiz yoki javobsiz qoldirgansiz' : 'hozircha xato qilingan savol yo\'q' ?></small></span></label>
  </div>
  <fieldset><legend>Bo'limlar <span class="muted small">— hech narsa tanlanmasa, barcha bo'limlardan; bo'limni belgilasangiz, ichki bo'limlari ham kiradi</span></legend>
    <div class="qb-pick">
    <?php foreach ($ready as $s): ?>
      <label class="check" style="margin-left: <?= $s['depth'] * 1.3 ?>rem"><input type="checkbox" name="sec[]" value="<?= $s['id'] ?>">
        <span><?= e($s['name']) ?> <span class="muted small">· <?= $s['ready_total'] ?> ta savol</span></span></label>
    <?php endforeach; ?>
    </div>
  </fieldset>
  <?php if ($hasLv): ?>
  <fieldset><legend>Qiyinlik <span class="muted small">— tanlanmasa, hamma darajadan</span></legend>
    <div class="row gap wrap"><?php foreach (QB_LEVELS as $k => $nm): ?><label class="check lv-check"><input type="checkbox" name="lv[]" value="<?= $k ?>"><span class="lv lv<?= $k ?>"><?= e($nm) ?></span></label><?php endforeach; ?></div>
  </fieldset>
  <?php endif; ?>
  <div class="row gap wrap center-v">
    <label>Savollar soni
      <input type="number" name="n" id="qbN" value="10" min="5" max="60" style="width:6rem"></label>
    <div class="row gap wrap" style="margin-top:.2rem">
      <?php foreach ([5, 10, 20, 30, 45, 60] as $k): ?><button type="button" class="btn sm ghost" onclick="document.getElementById('qbN').value=<?= $k ?>"><?= $k ?></button><?php endforeach; ?>
    </div>
    <button class="btn primary"><?= icon('tests', 16) ?>Test tuzish</button>
  </div>
</form>
<?php endif; ?>



<h2 class="mt">Mashqlarim</h2>
<?php if (!$tests): ?><div class="card empty">Hali mashq testi yo'q.</div><?php else: ?>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>Sana</th><th>Test</th><th class="num">Savol</th><th class="num">To'g'ri</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($tests as $t): ?>
    <tr>
      <td class="nowrap"><?= e(date('d.m.Y H:i', strtotime($t['created_at']))) ?></td>
      <td><?= e($t['title']) ?></td>
      <td class="num"><?= (int)$t['n'] ?></td>
      <td class="num"><?= $t['status'] === 'done' ? '<b>' . (int)$t['correct'] . ' / ' . (int)$t['n'] . '</b>' : '<span class="tag amber">davom etmoqda</span>' ?></td>
      <td class="right nowrap">
        <a class="btn sm <?= $t['status'] === 'done' ? 'ghost' : 'primary' ?>" href="<?= e(url('student_practice_do', ['id' => $t['id']])) ?>"><?= $t['status'] === 'done' ? 'Natija' : 'Davom ettirish' ?></a>
        <a class="btn sm ghost" target="_blank" href="<?= e(url('student_practice_pdf', ['id' => $t['id']])) ?>">PDF</a>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php endif; ?>
<?php page_footer();
