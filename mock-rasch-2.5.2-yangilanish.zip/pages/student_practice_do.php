<?php
defined('APP_ROOT') || exit;
/** Mashq testini yechish va natijani ko'rish. Natijada faqat to'g'ri javoblar soni (umumiy va bo'limlar bo'yicha) ko'rsatiladi. */
$me = student();
$sid = (int)$me['id'];
$tid = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
qb_assign_tick();   // muddati o'tgan topshiriqlar yopiladi
$t = $tid ? row('SELECT * FROM qb_tests WHERE id=? AND student_id=?', [$tid, $sid]) : null;
if (!$t) { flash('Mashq testi topilmadi', 'err'); redirect('student_practice'); }
$as = !empty($t['assign_id']) ? row('SELECT * FROM qb_assign WHERE id=?', [(int)$t['assign_id']]) : null;
$paper = qb_assign_is_paper($as);
if ($paper && $t['status'] === 'open') {   // sinf testi qog'ozda yechiladi — javoblarni o'qituvchi kiritadi
    if (is_post()) { if (($_POST['action'] ?? '') === 'save') json_out(['ok' => false, 'closed' => true]); redirect('student_practice'); }
    page_header('Sinf testi');
    ?>
<?= crumbs([['Topshiriq va mashq', url('student_practice')], $t['title']]) ?>
<h1><?= e($t['title']) ?></h1>
<div class="card empty">Bu — sinf testi: savollar qog'ozda yechiladi. Natijangiz o'qituvchi javoblaringizni kiritgach shu yerda ko'rinadi.</div>
<p><a class="btn" href="<?= e(url('student_practice')) ?>">← Topshiriq va mashq</a></p>
    <?php
    page_footer();
    return;
}

if (is_post()) {
    csrf_check();
    $a = (string)($_POST['action'] ?? 'submit');
    if ($a === 'save') {   // avtomatik saqlash (practice.js) — muddat tugasa ham javoblar yo'qolmasin
        if ($t['status'] !== 'open') json_out(['ok' => false, 'closed' => true]);
        $n = 0;
        foreach ((array)($_POST['a'] ?? []) as $pos => $v) {
            if (!is_scalar($v)) continue;
            $v = mb_substr(trim((string)$v), 0, 80);
            $n += q('UPDATE qb_items SET given=? WHERE test_id=? AND pos=?', [$v, $tid, (int)$pos])->rowCount();
        }
        json_out(['ok' => true, 'saved' => $n]);
    }
    if ($a === 'submit' && $t['status'] === 'open') {
        $ans = [];
        foreach ((array)($_POST['a'] ?? []) as $pos => $v) if (is_scalar($v)) $ans[(int)$pos] = (string)$v;
        qb_finish($tid, $ans);
        flash('Test yakunlandi');
    } elseif ($a === 'submit' && $as) {
        flash('Topshiriq muddati tugagan — oxirgi saqlangan javoblaringiz tekshirildi', 'warn');
    } elseif ($a === 'delete' && $t['status'] === 'open' && !$as) {
        q('DELETE FROM qb_tests WHERE id=? AND student_id=?', [$tid, $sid]);
        flash('Mashq o\'chirildi');
        redirect('student_practice');
    }
    redirect('student_practice_do', ['id' => $tid]);
}

if ($t['status'] === 'done' || $t['status'] === 'missed') {
    $r = qb_result($tid);
    $pct = $r['total'] > 0 ? round(100 * $r['ok'] / $r['total']) : 0;
    $secIds = qb_without_closed(array_column(rows('SELECT DISTINCT section_id FROM qb_items WHERE test_id=?', [$tid]), 'section_id'));   // keyin yopilgan bo'lim — qayta mashq qilinmaydi (2.5.2)
    $review = $as && qb_review_allowed($t);
    page_header($as ? 'Topshiriq natijasi' : 'Mashq natijasi');
    ?>
<?= crumbs([['Topshiriq va mashq', url('student_practice')], $t['title']]) ?>
<h1>Natija</h1>
<?php if ($t['status'] === 'missed'): ?><div class="alert warn"><?= icon('alert') ?><span><?= $paper ? 'Bu sinf testida qatnashmadingiz.' : 'Bu topshiriqni muddatida bajarmadingiz — birorta javob yuborilmagan.' ?><?= $review ? ' Quyida savollar va to\'g\'ri javoblarni ko\'rib chiqing.' : '' ?></span></div><?php endif; ?>
<div class="card qb-score">
  <div class="qb-big"><b><?= $r['ok'] ?></b><span> / <?= $r['total'] ?></span></div>
  <div class="muted">ta savolga to'g'ri javob berdingiz · <b><?= $pct ?>%</b></div>
  <div class="qb-track lg" role="img" aria-label="<?= $pct ?>%"><i style="width:<?= $pct ?>%" class="<?= $pct >= 70 ? 'hi' : ($pct >= 40 ? 'mid' : 'lo') ?>"></i></div>
  <p class="small muted mt"><?= e($t['title']) ?> · <?= e(date('d.m.Y H:i', strtotime((string)($t['finished_at'] ?: $t['created_at'])))) ?></p>
</div>
<?php if (count($r['sections']) > 0): ?>
<div class="card">
  <h3>Bo'limlar bo'yicha</h3>
  <div class="qb-secbars">
  <?php foreach ($r['sections'] as $s): $p = $s['total'] > 0 ? round(100 * $s['ok'] / $s['total']) : 0; ?>
    <div class="qb-secbar"><span><?= e($s['name']) ?></span><div class="qb-track" role="img" aria-label="<?= $p ?>%"><i style="width:<?= $p ?>%" class="<?= $p >= 70 ? 'hi' : ($p >= 40 ? 'mid' : 'lo') ?>"></i></div><b><?= $s['ok'] ?> / <?= $s['total'] ?></b></div>
  <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>
<?php if ($as && !$review): ?>
  <div class="alert info"><?= icon('alert') ?><span><?= (int)$as['review'] ? ($paper ? 'Qaysi savollarda xato qilganingiz va to\'g\'ri javoblar o\'qituvchi sinf testini yakunlagach shu yerda ko\'rinadi.' : 'Qaysi savollarda xato qilganingiz va to\'g\'ri javoblar topshiriq muddati tugagach — <b>' . e(date('d.m.Y H:i', strtotime((string)$as['deadline']))) . '</b> dan keyin shu yerda ko\'rinadi.') : 'Bu topshiriqda faqat to\'g\'ri javoblar soni ko\'rsatiladi.' ?></span></div>
<?php endif; ?>
<?php if ($review): ?>
<h2 class="mt">Javoblarim</h2>
<div class="qb-review">
<?php foreach (qb_review_items($tid) as $it): $ok = $it['ok'] === null ? null : (int)$it['ok']; ?>
  <div class="card qb-rv <?= $ok === 1 ? 'good' : ($ok === 0 ? 'bad' : '') ?>">
    <div class="qb-rv-h"><b><?= (int)$it['pos'] ?>-savol</b> <span class="muted small"><?= e($it['section_name']) ?></span>
      <span class="right">Sizning javob: <b class="mono"><?= $it['given'] !== '' && $it['given'] !== '-' ? e($it['given']) : '—' ?></b><?= $ok === 0 ? ' · To\'g\'ri: <b class="mono">' . e(qb_answer_show($it['kind'], $it['answer'])) . '</b>' : '' ?> <?= $ok === 1 ? '✅' : ($ok === 0 ? '❌' : '') ?></span></div>
    <?php if ($it['img']): ?><img class="qb-qimg" loading="lazy" alt="<?= (int)$it['pos'] ?>-savol" src="<?= e(url('qb_img', ['id' => $it['question_id'], 'v' => substr((string)$it['img'], 1, 8)])) ?>"><?php else: ?><p class="muted small">Bu savol bazadan olib tashlangan — hisobga olinmadi.</p><?php endif; ?>
  </div>
<?php endforeach; ?>
</div>
<?php endif; ?>
<div class="row gap wrap">
  <?php if (!$as && $secIds): ?>
  <form method="post" action="<?= e(url('student_practice')) ?>"><?= csrf_field() ?><input type="hidden" name="n" value="<?= (int)$t['n'] ?>">
    <?php foreach ($secIds as $x): ?><input type="hidden" name="sec[]" value="<?= $x ?>"><?php endforeach; ?>
    <button class="btn primary">Shu bo'limlardan yana mashq</button></form>
  <?php endif; ?>
  <a class="btn" href="<?= e(url('student_practice')) ?>">Boshqa bo'limlar</a>
  <a class="btn ghost" target="_blank" href="<?= e(url('student_practice_pdf', ['id' => $tid])) ?>">Testni PDF yuklab olish</a>
</div>
<?php
    page_footer();
    return;
}

$items = rows('SELECT i.pos, i.question_id, i.given, q.kind, q.nopt, q.w, q.h, q.img FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=?' . qb_test_open_sql($t) . ' ORDER BY i.pos', [$tid]);
$missing = (int)$t['n'] - count($items);   // savol o'chirilgan (mashqda — yopilgan, 2.5.2) bo'lishi mumkin
page_header($as ? 'Topshiriq' : 'Mashq testi');
?>
<?= crumbs([['Topshiriq va mashq', url('student_practice')], $as ? 'Topshiriq' : 'Mashq testi']) ?>
<div class="row between center-v wrap">
  <div><h1 style="margin-bottom:.2rem"><?= e($t['title']) ?></h1><p class="muted small">Test kodi <b class="mono"><?= e(qb_code((int)$t['id'])) ?></b> · <?= count($items) ?> ta savol<?= $missing > 0 ? ' · ' . $missing . ' tasi bazadan olib tashlangan' : '' ?><?= $as ? ' · <b>muddat: ' . e(date('d.m.Y H:i', strtotime((string)$as['deadline']))) . '</b> — javoblar avtomatik saqlanadi, muddat tugasa saqlanganlari tekshiriladi' : '' ?></p></div>
  <a class="btn ghost" target="_blank" href="<?= e(url('student_practice_pdf', ['id' => $tid])) ?>"><?= icon('download', 16) ?>PDF yuklab olish</a>
</div>
<?php if (!$items): ?>
  <div class="card empty">Bu testning savollari bazadan olib tashlangan. <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $tid ?>"><button class="btn sm" name="action" value="delete">Testni o'chirish</button></form></div>
<?php else: ?>
<form method="post" id="qbSolve" data-key="qbp<?= $tid ?>"<?= $as ? ' data-autosave="' . e(url('student_practice_do')) . '"' : '' ?>><?= csrf_field() ?><input type="hidden" name="id" value="<?= $tid ?>">
  <div class="qb-sticky"><span>Javob berildi: <b id="qbDone">0</b> / <?= count($items) ?></span><button class="btn primary sm" name="action" value="submit" id="qbSubmit">Yakunlash va tekshirish</button></div>
  <?php foreach ($items as $it): $pos = (int)$it['pos']; ?>
  <div class="card qb-q" data-pos="<?= $pos ?>">
    <div class="qb-qn"><?= $pos ?></div>
    <img class="qb-qimg" loading="lazy" alt="<?= $pos ?>-savol" src="<?= e(url('qb_img', ['id' => $it['question_id'], 'v' => substr((string)$it['img'], 1, 8)])) ?>">
    <?php if ($it['kind'] === 'open'): ?>
      <label class="qb-open">Javobingiz<input name="a[<?= $pos ?>]" value="<?= e($it['given']) ?>" maxlength="80" autocomplete="off" inputmode="text"></label>
    <?php else: ?>
      <div class="qb-opts" role="radiogroup" aria-label="<?= $pos ?>-savol variantlari">
      <?php for ($k = 0; $k < ((int)$it['nopt'] === 6 ? 6 : 4); $k++): $L = chr(65 + $k); ?>
        <label class="qb-opt"><input type="radio" name="a[<?= $pos ?>]" value="<?= $L ?>" <?= $it['given'] === $L ? 'checked' : '' ?>><span><?= $L ?></span></label>
      <?php endfor; ?>
        <button type="button" class="btn sm ghost qb-clear" title="Javobni tozalash">tozalash</button>
      </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
  <div class="row gap wrap">
    <button class="btn primary" name="action" value="submit">Yakunlash va tekshirish</button>
    <?php if (!$as): ?><button class="btn danger-ghost" name="action" value="delete" formnovalidate onclick="return confirm('Bu mashq o\'chirilsinmi?')">Mashqni o'chirish</button><?php endif; ?>
  </div>
</form>
<?php endif; ?>
<?php page_footer(['assets/practice.js']);
