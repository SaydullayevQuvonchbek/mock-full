<?php
defined('APP_ROOT') || exit;
/**
 * Admin: o'zlashtirish (2.3) — qidiruv va filtrlar (guruh, bo'lim, holat, javoblar soni), saralash, bo'limlar kesimi, CSV;
 * bitta o'quvchi tafsiloti (bo'limlar, qiyinlik darajalari, mashq va topshiriqlar tarixi).
 */
qb_assign_tick();
$sid = is_string($_GET['sid'] ?? null) ? (int)$_GET['sid'] : 0;

if ($sid) {
    $s = row('SELECT * FROM students WHERE id=?', [$sid]);
    if (!$s) { flash('O\'quvchi topilmadi', 'err'); redirect('qb_mastery'); }
    $m = qb_mastery($sid);
    $mock = student_section_avg(student_history($sid));
    $lvM = qb_mastery_levels($sid);
    $wrongN = qb_wrong_count($sid);
    $tests = rows('SELECT t.*, a.closed_at FROM qb_tests t LEFT JOIN qb_assign a ON a.id=t.assign_id WHERE t.student_id=? ORDER BY t.id DESC LIMIT 60', [$sid]);
    $back = $_SESSION['mastery_back'] ?? url('qb_mastery', $s['group_name'] !== '' ? ['g' => $s['group_name']] : []);
    page_header('O\'zlashtirish — ' . $s['full_name']);
    ?>
<?= crumbs([['O\'zlashtirish', $back], $s['full_name']]) ?>
<h1><?= e($s['full_name']) ?> <span class="muted small">ID <?= e($s['code']) ?><?= $s['group_name'] ? ' · ' . e($s['group_name']) : '' ?></span></h1>
<?php include __DIR__ . '/_mastery_cards.php'; ?>
<div class="grid2 mastery">
  <div class="card">
    <h3>Qiyinlik darajalari bo'yicha</h3>
    <?php if (!$lvM): ?><p class="muted small">Darajasi belgilangan savollar bo'yicha javob hali yo'q.</p><?php else: ?>
    <div class="qb-secbars">
      <?php foreach ($lvM as $lv => [$n, $k]): $p = (int)round(100 * $k / $n); ?>
        <div class="qb-secbar"><span><?= qb_level_tag($lv) ?></span><div class="qb-track" role="img" aria-label="<?= $p ?>%"><i style="width:<?= $p ?>%" class="<?= pct_cls($p) ?>"></i></div><b><?= $p ?>% <span class="muted small"><?= $k ?>/<?= $n ?></span></b></div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
  <div class="card">
    <h3>Takrorlash kerak</h3>
    <p class="big-num"><?= $wrongN ?> <small>ta savol</small></p>
    <p class="small muted">Oxirgi urinishda xato javob berilgan yoki javobsiz qoldirilgan savollar. Mashq testlarida ular avtomatik qayta beriladi (testning yarmigacha); o'quvchi «Xatolarim ustida ishlash» bilan alohida ham ishlay oladi.</p>
  </div>
</div>
<h2 class="mt">Mashq va topshiriqlar</h2>
<?php if (!$tests): ?><div class="card empty">Hali mashq yoki topshiriq yo'q.</div><?php else: ?>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>Sana</th><th>Turi</th><th>Nomi</th><th class="num">Natija</th><th></th></tr></thead>
  <tbody><?php foreach ($tests as $t): $p = $t['status'] === 'done' && (int)$t['n'] > 0 ? (int)round(100 * (int)$t['correct'] / (int)$t['n']) : null; ?>
    <tr><td class="nowrap small"><?= e(date('d.m.Y H:i', strtotime((string)$t['created_at']))) ?></td>
      <td><?= $t['assign_id'] ? '<span class="tag blue">' . ($t['via'] === 'pap' ? 'sinf testi' : 'topshiriq') . '</span>' : '<span class="tag">mashq</span>' ?> <?= $t['via'] === 'bot' ? '<span class="muted small">bot</span>' : '' ?></td>
      <td><?= $t['assign_id'] ? '<a href="' . e(url('qb_assign', ['id' => $t['assign_id']])) . '">' . e($t['title']) . '</a>' : e($t['title']) ?></td>
      <td class="num"><?= $p !== null ? '<b>' . (int)$t['correct'] . '</b> / ' . (int)$t['n'] . ' <span class="pct ' . pct_cls($p) . '">' . $p . '%</span>' : ($t['status'] === 'missed' ? '<span class="tag red">topshirmadi</span>' : '<span class="tag amber">ochiq</span>') ?></td>
      <td class="right"><?php if ($t['assign_id'] && $t['status'] === 'done'): ?><a class="btn sm ghost" href="<?= e(url('qb_assign', ['id' => $t['assign_id'], 'tid' => $t['id']])) ?>">Javoblari</a><?php endif; ?></td></tr>
  <?php endforeach; ?></tbody>
</table></div>
<?php endif; ?>
    <?php
    page_footer();
    return;
}

/* ---------------- Filtrlar ---------------- */
$groups = array_column(rows('SELECT DISTINCT group_name FROM students WHERE group_name<>"" AND archived_at IS NULL ORDER BY group_name'), 'group_name');
$G = fn(string $k): string => is_string($_GET[$k] ?? null) ? $_GET[$k] : '';   // massiv yuborilsa — bo'sh
$F = [
    'q' => mb_substr(trim($G('q')), 0, 60),
    'g' => $G('g'),
    'sec' => (int)$G('sec'),
    'band' => in_array($G('band'), ['lo', 'mid', 'hi', 'none', 'data'], true) ? $G('band') : '',
    'min' => max(0, min(1000, (int)$G('min'))),
    'sort' => preg_match('/^(name|group|total|n|last|mA|mG|own|c\d{1,9})$/', $G('sort')) ? $G('sort') : 'name',
    'dir' => $G('dir') === 'desc' ? 'desc' : 'asc',
];
if ($F['g'] !== '' && $F['g'] !== '@none' && !in_array($F['g'], $groups, true)) $F['g'] = '';
$tree = qb_tree();
$secRow = null;
foreach ($tree as $t) if ((int)$t['id'] === $F['sec']) $secRow = $t;
if (!$secRow) $F['sec'] = 0;
$qs = array_filter($F, fn($v, $k) => !(($k === 'sort' && $v === 'name') || ($k === 'dir' && $v === 'asc') || $v === '' || $v === 0), ARRAY_FILTER_USE_BOTH);
$link = fn(array $x = []) => url('qb_mastery', array_filter(array_merge($qs, $x), fn($v) => $v !== '' && $v !== 0 && $v !== null));
$_SESSION['mastery_back'] = $link();

/* ---------------- Ustunlar: tanlangan bo'limning ichki bo'limlari (yoki asosiy bo'limlar) ---------------- */
$par = [];
foreach (rows('SELECT id, parent_id FROM qb_sections') as $r) $par[(int)$r['id']] = (int)($r['parent_id'] ?? 0);
foreach ($par as $id => $p) if ($p && !isset($par[$p])) $par[$id] = 0;   // ota bo'limi yo'q — asosiy
$cols = [];   // kalit => nom
if ($F['sec']) {
    if ((int)$secRow['own'] > 0) $cols['own'] = $secRow['name'] . ' (umumiy)';
    foreach ($tree as $t) if ((int)$t['parent_id'] === $F['sec'] && (int)$t['total'] > 0) $cols['c' . $t['id']] = $t['name'];
} else {
    foreach ($tree as $t) if ((int)$t['depth'] === 0 && (int)$t['total'] > 0) $cols['c' . $t['id']] = $t['name'];
}
$hasKids = [];
foreach ($tree as $t) if ((int)$t['parent_id']) $hasKids[(int)$t['parent_id']] = true;
$colMemo = [];
$colOf = function (int $secId) use (&$colMemo, $par, $F): ?string {   // bo'lim → ustun kaliti (doiradan tashqarida — null)
    if (array_key_exists($secId, $colMemo)) return $colMemo[$secId];
    $x = $secId; $prev = 0; $res = null;
    for ($g = 0; $g < 25 && isset($par[$x]); $g++) {
        if ($F['sec'] && $x === $F['sec']) { $res = $prev ? 'c' . $prev : 'own'; break; }
        if (!$F['sec'] && $par[$x] === 0) { $res = 'c' . $x; break; }
        if ($par[$x] === 0) break;
        $prev = $x; $x = $par[$x];
    }
    return $colMemo[$secId] = $res;
};

/* ---------------- O'quvchilar va natijalar ---------------- */
$w = ['s.archived_at IS NULL']; $p = [];
if ($F['g'] === '@none') $w[] = "s.group_name=''";
elseif ($F['g'] !== '') { $w[] = 's.group_name=?'; $p[] = $F['g']; }
if ($F['q'] !== '') { [$sw, $sp] = student_search_sql($F['q']); $w[] = $sw; $p = array_merge($p, $sp); }
$studs = rows('SELECT s.id, s.code, s.full_name, s.group_name FROM students s WHERE ' . implode(' AND ', $w) . ' ORDER BY s.full_name LIMIT 3000', $p);
$data = [];
foreach (array_chunk(array_map(fn($s) => (int)$s['id'], $studs), 500) as $chunk) {
    $in = implode(',', array_fill(0, count($chunk), '?'));
    foreach (rows("SELECT t.student_id, i.section_id, SUM(i.ok IS NOT NULL) n, SUM(i.ok=1) k, MAX(t.finished_at) last FROM qb_items i JOIN qb_tests t ON t.id=i.test_id
                   WHERE t.status='done' AND t.student_id IN ($in) GROUP BY t.student_id, i.section_id", $chunk) as $r) {
        $key = $colOf((int)$r['section_id']);
        if ($key === null || (int)$r['n'] === 0) continue;
        $d = &$data[(int)$r['student_id']];
        if ($d === null) $d = ['cols' => [], 'n' => 0, 'k' => 0, 'last' => ''];
        $d['cols'][$key] = $d['cols'][$key] ?? [0, 0];
        $d['cols'][$key][0] += (int)$r['n']; $d['cols'][$key][1] += (int)$r['k'];
        $d['n'] += (int)$r['n']; $d['k'] += (int)$r['k'];
        if ((string)$r['last'] > $d['last']) $d['last'] = (string)$r['last'];
        unset($d);
    }
}
$pctOf = fn(?array $nk) => $nk && $nk[0] > 0 ? (int)round(100 * $nk[1] / $nk[0]) : null;
$list = [];
foreach ($studs as $s) {
    $d = $data[(int)$s['id']] ?? ['cols' => [], 'n' => 0, 'k' => 0, 'last' => ''];
    $tp = $d['n'] > 0 ? (int)round(100 * $d['k'] / $d['n']) : null;
    if ($F['band'] === 'none' && $tp !== null) continue;
    if ($F['band'] === 'data' && $tp === null) continue;
    if (in_array($F['band'], ['lo', 'mid', 'hi'], true) && ($tp === null || pct_cls($tp) !== $F['band'])) continue;
    if ($F['min'] && $d['n'] < $F['min']) continue;
    $list[] = $s + ['d' => $d, 'pct' => $tp];
}
$mock = student_section_avg_many(array_map(fn($r) => (int)$r['id'], $list));
$mockPct = function (int $id, string $k) use ($mock) { $x = $mock[$id][$k] ?? null; return $x && (int)$x['total'] > 0 ? (int)$x['pct'] : null; };

/* ---------------- Saralash ---------------- */
$sortVal = function (array $r) use ($F, $mockPct, $pctOf) {
    switch ($F['sort']) {
        case 'name': return mb_strtolower((string)$r['full_name']);
        case 'group': return mb_strtolower((string)$r['group_name']) . ' ' . mb_strtolower((string)$r['full_name']);
        case 'total': return $r['pct'];
        case 'n': return $r['d']['n'] ?: null;
        case 'last': return $r['d']['last'] !== '' ? $r['d']['last'] : null;
        case 'mA': return $mockPct((int)$r['id'], 'A');
        case 'mG': return $mockPct((int)$r['id'], 'G');
        default: return $pctOf($r['d']['cols'][$F['sort']] ?? null);
    }
};
usort($list, function ($a, $b) use ($sortVal, $F) {
    $x = $sortVal($a); $y = $sortVal($b);
    if ($x === null && $y === null) return strcmp(mb_strtolower((string)$a['full_name']), mb_strtolower((string)$b['full_name']));
    if ($x === null) return 1;   // ma'lumoti yo'qlar har doim oxirida
    if ($y === null) return -1;
    $c = is_string($x) ? strcmp($x, (string)$y) : ($x <=> $y);
    if ($c === 0) return strcmp(mb_strtolower((string)$a['full_name']), mb_strtolower((string)$b['full_name']));
    return $F['dir'] === 'desc' ? -$c : $c;
});

/* ---------------- Jamlanma ---------------- */
$sumN = 0; $sumK = 0; $weak = 0; $noData = 0;
$colAgg = array_fill_keys(array_keys($cols), [0, 0, 0]);   // [n, k, zaif o'quvchilar]
foreach ($list as $r) {
    $sumN += $r['d']['n']; $sumK += $r['d']['k'];
    if ($r['pct'] === null) $noData++; elseif ($r['pct'] < 40) $weak++;
    foreach ($r['d']['cols'] as $k => $nk) {
        if (!isset($colAgg[$k])) continue;
        $colAgg[$k][0] += $nk[0]; $colAgg[$k][1] += $nk[1];
        if ($nk[0] >= 5 && 100 * $nk[1] / $nk[0] < 40) $colAgg[$k][2]++;
    }
}
$avg = $sumN ? (int)round(100 * $sumK / $sumN) : null;
$weakest = null;
foreach ($colAgg as $k => $a) if ($a[0] >= 10 && ($weakest === null || $a[1] / $a[0] < $colAgg[$weakest][1] / $colAgg[$weakest][0])) $weakest = $k;
$mockAgg = ['A' => [0, 0], 'G' => [0, 0]];
foreach ($list as $r) foreach (['A', 'G'] as $k) if (isset($mock[(int)$r['id']][$k])) { $mockAgg[$k][0] += (int)$mock[(int)$r['id']][$k]['total']; $mockAgg[$k][1] += (int)$mock[(int)$r['id']][$k]['ok']; }

/* ---------------- CSV ---------------- */
if (($_GET['export'] ?? '') === 'csv' && $G('export') === 'csv') {
    $head = ['ID', 'F.I.Sh', 'Guruh', 'MOCK Algebra %', 'MOCK Geometriya %'];
    foreach ($cols as $nm) { $head[] = $nm . ' %'; $head[] = $nm . ' (to\'g\'ri/jami)'; }
    array_push($head, $F['sec'] ? $secRow['name'] . ' jami %' : 'Bazada jami %', 'Javoblar', 'Oxirgi faollik');
    $out = [$head];
    foreach ($list as $r) {
        $row = [$r['code'], $r['full_name'], $r['group_name'], $mockPct((int)$r['id'], 'A') ?? '', $mockPct((int)$r['id'], 'G') ?? ''];
        foreach (array_keys($cols) as $k) { $nk = $r['d']['cols'][$k] ?? null; $row[] = $pctOf($nk) ?? ''; $row[] = $nk ? $nk[1] . '/' . $nk[0] : ''; }
        array_push($row, $r['pct'] ?? '', $r['d']['n'] ?: '', $r['d']['last'] !== '' ? date('d.m.Y H:i', strtotime($r['d']['last'])) : '');
        $out[] = $row;
    }
    session_write_close();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="ozlashtirish-' . date('Y-m-d') . '.csv"');
    $fh = fopen('php://output', 'w');
    fwrite($fh, "\xEF\xBB\xBF");
    foreach ($out as $r) fputcsv($fh, array_map('csv_safe', $r), ';', '"', '\\');
    fclose($fh);
    exit;
}

$cell = function (?array $nk, bool $strong = false) use ($pctOf): string {
    $p = $pctOf($nk);
    if ($p === null) return '<td class="num muted">—</td>';
    return '<td class="num' . ($strong ? ' tot' : '') . '"><span class="pct ' . pct_cls($p) . '">' . $p . '%</span> <span class="muted small">' . (int)$nk[1] . '/' . (int)$nk[0] . '</span></td>';
};
$th = function (string $key, string $label, string $cls = 'num', string $title = '') use ($F, $link): string {
    $on = $F['sort'] === $key;
    $pctCol = !in_array($key, ['name', 'group', 'n', 'last'], true);
    $dir = $on ? ($F['dir'] === 'asc' ? 'desc' : 'asc') : ($pctCol ? 'asc' : (in_array($key, ['n', 'last'], true) ? 'desc' : 'asc'));
    $arrow = $on ? ($F['dir'] === 'asc' ? ' ↑' : ' ↓') : '';
    return '<th class="' . $cls . ($on ? ' sorted' : '') . '"' . ($on ? ' aria-sort="' . ($F['dir'] === 'asc' ? 'ascending' : 'descending') . '"' : '') . '><a href="' . e($link(['sort' => $key, 'dir' => $dir])) . '"' . ($title !== '' ? ' title="' . e($title) . '"' : '') . '>' . e($label) . $arrow . '</a></th>';
};
$bandNames = ['' => 'Hammasi', 'lo' => 'Qayta ishlash kerak (40% dan past)', 'mid' => 'O\'rtacha (40–69%)', 'hi' => 'Yaxshi (70% va yuqori)', 'data' => 'Natijasi borlar', 'none' => 'Hali ishlamaganlar'];
$scopeName = $F['sec'] ? qb_section_path($F['sec']) : 'barcha bo\'limlar';
page_header('O\'zlashtirish');
?>
<div class="page-head">
  <div><h1>O'zlashtirish</h1>
    <p class="muted">O'quvchilarning bo'limlar bo'yicha to'g'ri javoblar ulushi: MOCK (Algebra, Geometriya) va savollar bazasi (mashq + topshiriqlar). Qidiring, filtrlang, ustun nomini bosib saralang; bo'lim nomini bossangiz ichki bo'limlari ochiladi.</p></div>
  <a class="btn ghost" href="<?= e($link(['export' => 'csv'])) ?>"><?= icon('download', 16) ?>CSV (Excel)</a>
</div>

<form method="get" class="card form m-filter" role="search">
  <input type="hidden" name="p" value="qb_mastery">
  <?php if ($F['sort'] !== 'name'): ?><input type="hidden" name="sort" value="<?= e($F['sort']) ?>"><?php endif; ?>
  <?php if ($F['dir'] !== 'asc'): ?><input type="hidden" name="dir" value="desc"><?php endif; ?>
  <label class="grow">Qidirish <input type="search" name="q" value="<?= e($F['q']) ?>" placeholder="Ism, ID yoki telefon" autocomplete="off"></label>
  <label>Guruh <select name="g"><option value="">Barcha guruhlar</option><?php foreach ($groups as $x): ?><option value="<?= e($x) ?>" <?= $x === $F['g'] ? 'selected' : '' ?>><?= e($x) ?></option><?php endforeach; ?><option value="@none" <?= $F['g'] === '@none' ? 'selected' : '' ?>>Guruhsiz</option></select></label>
  <label>Bo'lim <select name="sec"><option value="0">Barcha bo'limlar</option><?php foreach ($tree as $t): if ((int)$t['total'] === 0) continue; ?><option value="<?= $t['id'] ?>" <?= (int)$t['id'] === $F['sec'] ? 'selected' : '' ?>><?= str_repeat('— ', (int)$t['depth']) . e($t['name']) ?></option><?php endforeach; ?></select></label>
  <label>Holat <select name="band"><?php foreach ($bandNames as $k => $nm): ?><option value="<?= e($k) ?>" <?= $F['band'] === $k ? 'selected' : '' ?>><?= e($nm) ?></option><?php endforeach; ?></select></label>
  <label>Javoblar <select name="min"><?php foreach ([0 => 'istalgan', 10 => '10 tadan ko\'p', 20 => '20 tadan ko\'p', 50 => '50 tadan ko\'p', 100 => '100 tadan ko\'p'] as $k => $nm): ?><option value="<?= $k ?>" <?= $F['min'] === $k ? 'selected' : '' ?>><?= e($nm) ?></option><?php endforeach; ?></select></label>
  <div class="fb-actions"><button class="btn primary">Ko'rsatish</button><?php if ($qs): ?><a class="btn ghost" href="<?= e(url('qb_mastery')) ?>">Tozalash</a><?php endif; ?></div>
</form>

<div class="stats4">
  <div class="stat"><span><?= count($list) ?></span>O'quvchi<?= count($list) !== count($studs) ? ' <small class="muted">(' . count($studs) . ' dan)</small>' : '' ?></div>
  <div class="stat accent"><span><?= $avg !== null ? $avg . '%' : '—' ?></span>O'rtacha o'zlashtirish <small class="muted">(<?= e($scopeName) ?>)</small></div>
  <div class="stat"><span class="<?= $weak ? 'critical-t' : '' ?>"><?= $weak ?></span><a href="<?= e($link(['band' => 'lo'])) ?>">Qayta ishlash kerak</a> <small class="muted">(40% dan past)</small></div>
  <div class="stat"><span><?= $weakest !== null ? (int)round(100 * $colAgg[$weakest][1] / $colAgg[$weakest][0]) . '%' : '—' ?></span><?= $weakest !== null ? 'Eng qiyin: ' . e($cols[$weakest]) : 'Eng qiyin bo\'lim' ?></div>
</div>

<?php if ($cols && $sumN): ?>
<div class="card">
  <div class="card-head"><h3>Bo'limlar kesimida <span class="muted small">— <?= e($scopeName) ?>, ko'rsatilgan o'quvchilar bo'yicha</span></h3>
    <?php if ($F['sec']): $up = $par[$F['sec']] ?? 0; ?><a class="btn sm ghost" href="<?= e($link(['sec' => $up, 'sort' => 'name', 'dir' => 'asc'])) ?>">↑ <?= $up ? e(qb_section_path($up)) : 'Barcha bo\'limlar' ?></a><?php endif; ?></div>
  <div class="qb-secbars m-overview">
    <?php foreach (['A' => 'MOCK: Algebra', 'G' => 'MOCK: Geometriya'] as $k => $nm): if (!$mockAgg[$k][0]) continue; $pp = (int)round(100 * $mockAgg[$k][1] / $mockAgg[$k][0]); ?>
      <div class="qb-secbar"><span class="muted"><?= e($nm) ?></span><div class="qb-track" role="img" aria-label="<?= $pp ?>%"><i style="width:<?= $pp ?>%" class="<?= pct_cls($pp) ?>"></i></div><b><?= $pp ?>%</b></div>
    <?php endforeach; ?>
    <?php foreach ($cols as $k => $nm): $a = $colAgg[$k]; if (!$a[0]) continue; $pp = (int)round(100 * $a[1] / $a[0]); $cid = $k !== 'own' ? (int)substr($k, 1) : 0; ?>
      <div class="qb-secbar"><span><?php if ($cid && !empty($hasKids[$cid])): ?><a href="<?= e($link(['sec' => $cid, 'sort' => 'name', 'dir' => 'asc'])) ?>" title="Ichki bo'limlarini ko'rish"><?= e($nm) ?> ›</a><?php else: ?><?= e($nm) ?><?php endif; ?></span>
        <div class="qb-track" role="img" aria-label="<?= $pp ?>%"><i style="width:<?= $pp ?>%" class="<?= pct_cls($pp) ?>"></i></div>
        <b><?= $pp ?>% <span class="muted small"><?= $a[2] ? '· ' . $a[2] . ' ta o\'quvchi 40% dan past' : (int)$a[1] . '/' . (int)$a[0] ?></span></b></div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<?php if (!$studs): ?>
  <div class="card empty"><?= $F['q'] !== '' ? '«' . e($F['q']) . '» bo\'yicha o\'quvchi topilmadi.' : 'Bu guruhda o\'quvchi yo\'q.' ?></div>
<?php elseif (!$list): ?>
  <div class="card empty">Filtrga mos o'quvchi yo'q. <a href="<?= e($link(['band' => '', 'min' => 0])) ?>">Holat va javoblar filtrini olib tashlash</a></div>
<?php else: ?>
<div class="table-wrap"><table class="tbl mastery-tbl">
  <thead><tr>
    <?= $th('name', 'O\'quvchi', '') ?><?= $th('group', 'Guruh', '') ?>
    <?= $th('mA', 'MOCK: Algebra', 'num', SECTION_NAMES['A']) ?><?= $th('mG', 'MOCK: Geometriya', 'num', SECTION_NAMES['G']) ?>
    <?php foreach ($cols as $k => $nm): ?><?= $th($k, $nm) ?><?php endforeach; ?>
    <?= $th('total', $F['sec'] ? 'Jami' : 'Bazada jami') ?><?= $th('n', 'Javoblar', 'num', 'Yakunlangan mashq va topshiriqlardagi javoblar soni') ?><?= $th('last', 'Oxirgi faollik', '') ?>
  </tr></thead>
  <tbody>
  <?php foreach ($list as $r): $id = (int)$r['id']; $mk = function ($k) use ($mock, $id) { $x = $mock[$id][$k] ?? null; return $x && (int)$x['total'] > 0 ? [(int)$x['total'], (int)$x['ok']] : null; }; ?>
    <tr>
      <td><a href="<?= e(url('qb_mastery', ['sid' => $id])) ?>"><?= e($r['full_name']) ?></a> <span class="muted small mono"><?= e($r['code']) ?></span></td>
      <td class="small"><?= e($r['group_name']) ?></td>
      <?= $cell($mk('A')) ?><?= $cell($mk('G')) ?>
      <?php foreach (array_keys($cols) as $k): ?><?= $cell($r['d']['cols'][$k] ?? null) ?><?php endforeach; ?>
      <?= $cell($r['d']['n'] ? [$r['d']['n'], $r['d']['k']] : null, true) ?>
      <td class="num"><?= $r['d']['n'] ?: '<span class="muted">—</span>' ?></td>
      <td class="nowrap small muted"><?= $r['d']['last'] !== '' ? e(date('d.m.Y', strtotime($r['d']['last']))) : '—' ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<p class="small muted">Rang: <span class="pct hi">70%+</span> yaxshi · <span class="pct mid">40–69%</span> o'rtacha · <span class="pct lo">40% dan past</span> — qayta ishlash kerak. Kasr — to'g'ri / jami javob. «Javoblar» va «Oxirgi faollik» — tanlangan bo'lim doirasida.</p>
<?php endif; ?>
<?php page_footer();
