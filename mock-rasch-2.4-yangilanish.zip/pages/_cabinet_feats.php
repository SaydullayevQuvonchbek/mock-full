<?php
defined('APP_ROOT') || exit;
/** Shaxsiy kabinetda nimalar borligi (bosh sahifa va kirish sahifasi uchun umumiy ro'yxat) */
$feats = [
    ['chart', 'Natijalar va daraja', 'Har bir MOCK bo\'yicha ball, daraja (A+ … C), o\'rningiz va savollar tahlili. Sertifikat ham shu yerda.'],
    ['target', 'Bo\'limlar bo\'yicha o\'zlashtirish', 'Algebra va geometriyaning qaysi mavzusi kuchli, qaysi biri qayta ishlashni talab qilishini ko\'rasiz.'],
    ['tests', 'Mashq testlari', 'Savollar bazasidan test tuzasiz. Xato qilgan savollaringiz keyingi mashqlarda qayta beriladi.'],
    ['clock', 'Topshiriqlar', 'O\'qituvchi bergan topshiriqlar muddati bilan. Muddat tugagach, xatolaringiz va to\'g\'ri javoblar ochiladi.'],
    ['send', 'Telegram bot', 'Natija, topshiriq va eslatmalar telefoningizga keladi; mashqni botda ham yechasiz.'],
];
?>
<ul class="cab-feats">
  <?php foreach ($feats as [$ic, $t, $d]): ?>
    <li><span class="cf-ico"><?= icon($ic, 20) ?></span><div><b><?= e($t) ?></b><p><?= e($d) ?></p></div></li>
  <?php endforeach; ?>
</ul>
