<?php
defined('APP_ROOT') || exit;
/** O'quvchining o'z mashq testini PDF qilib berish (javoblar varaqasi bilan; javob kaliti hech qachon berilmaydi) */
$me = student();
$t = row('SELECT * FROM qb_tests WHERE id=? AND student_id=?', [(int)($_GET['id'] ?? 0), (int)$me['id']]);
if (!$t) { flash('Mashq testi topilmadi', 'err'); redirect('student_practice'); }
if (($t['via'] ?? '') === 'pap' && $t['status'] !== 'done') { flash('Sinf testi qog\'ozda yechiladi', 'warn'); redirect('student_practice'); }
$pdf = qb_test_pdf($t);   // test kodi (#id) har sahifada — botga javob yuborishda shu kod yoziladi
if ($pdf === null && !(int)val('SELECT COUNT(*) FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=?', [$t['id']])) { flash('Testda savol qolmagan', 'err'); redirect('student_practice'); }
if ($pdf === null) { flash('PDF yaratish hozir mumkin emas (serverda GD yo\'q). Testni sahifada yeching.', 'err'); redirect('student_practice_do', ['id' => $t['id']]); }
session_write_close();
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="mashq-' . (int)$t['id'] . '.pdf"');
header('Content-Length: ' . strlen($pdf));
header('Cache-Control: private, no-store');
echo $pdf;
exit;
