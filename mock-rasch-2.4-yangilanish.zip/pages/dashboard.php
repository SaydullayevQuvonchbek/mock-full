<?php
defined('APP_ROOT') || exit;
$nTests = (int)val('SELECT COUNT(*) FROM tests');
$nStud = (int)val('SELECT COUNT(*) FROM students WHERE archived_at IS NULL');
$nResp = (int)val('SELECT COUNT(*) FROM responses WHERE status="submitted"');
$nCert = (int)val('SELECT COUNT(*) FROM results WHERE ball >= 46');
$nRes = (int)val('SELECT COUNT(*) FROM results');
$tests = rows('SELECT t.*, (SELECT COUNT(*) FROM responses r WHERE r.test_id=t.id AND r.status="submitted") n,
               (SELECT AVG(ball) FROM results x WHERE x.test_id=t.id) avg_ball
               FROM tests t ORDER BY t.id DESC LIMIT 8');
$me = admin();
page_header('Bosh panel');
?>
<div class="page-head">
  <div>
    <div class="eyebrow"><?= e(date('d.m.Y')) ?></div>
    <h1>Xush kelibsiz<?= $me['name'] ? ', ' . e($me['name']) : '' ?></h1>
    <p class="muted" style="margin:0">MOCK testlari, javoblar va Rasch tahlili bir joyda.</p>
  </div>
  <a class="btn primary" href="<?= e(url('tests')) ?>#new"><?= icon('plus', 16) ?>Yangi test</a>
</div>
<div class="stats4">
  <div class="stat"><span><?= $nTests ?></span>Testlar</div>
  <div class="stat"><span><?= $nStud ?></span>O'quvchilar</div>
  <div class="stat"><span><?= $nResp ?></span>Topshirilgan varaqalar</div>
  <div class="stat accent"><span><?= $nRes ? round($nCert / $nRes * 100) : 0 ?>%</span>Sertifikat darajasi (≥ 46)<small><?= $nCert ?> / <?= $nRes ?> natija</small></div>
</div>
<div class="section-title"><h2>So'nggi testlar</h2><a class="small" href="<?= e(url('tests')) ?>">Barchasi →</a></div>
<?php if (!$tests): ?>
  <div class="card empty">Hali test yo'q. <a href="<?= e(url('tests')) ?>#new">Birinchi testni yarating</a>.</div>
<?php else: ?>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>Test</th><th>Sana</th><th class="num">Ishtirokchi</th><th class="num">O'rtacha ball</th><th>Holat</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($tests as $t): ?>
    <tr>
      <td><a href="<?= e(url('results', ['id' => $t['id']])) ?>"><?= e($t['title']) ?></a><div class="small muted"><?= e($t['subject']) ?></div></td>
      <td class="muted nowrap"><?= e($t['test_date']) ?></td>
      <td class="num"><?= (int)$t['n'] ?></td>
      <td class="num"><?= $t['avg_ball'] !== null ? fmt($t['avg_ball']) : '—' ?></td>
      <td>
        <?php if ($t['online']): ?><span class="tag blue">Onlayn</span><?php endif; ?>
        <?php if ($t['published']): ?><span class="tag green">E'lon qilingan</span><?php endif; ?>
        <?php if ($t['dirty'] && $t['n']): ?><span class="tag amber">Qayta hisoblanadi</span><?php endif; ?>
      </td>
      <td class="right"><a class="btn sm ghost" href="<?= e(url('test_edit', ['id' => $t['id']])) ?>">Ochish</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php endif; ?>
<div class="grid3 mt">
  <a class="card link-card" href="<?= e(url('students')) ?>"><h3><?= icon('users') ?>O'quvchilar</h3><p>ID va parollar, guruhlar, ro'yxatni qo'shish, kartochkalarni chop etish.</p></a>
  <a class="card link-card" href="<?= e(url('scan')) ?>"><h3><?= icon('scan') ?>Varaqalarni skanerlash</h3><p>Javoblar varaqasi rasmlari yoki PDF — ID va javoblar avtomatik o'qiladi.</p></a>
  <a class="card link-card" href="<?= e(url('rasch')) ?>"><h3><?= icon('theta') ?>Rasch modeli</h3><p>Model qanday ishlashi, 75 ball chegarasi va interaktiv misollar.</p></a>
</div>
<?php page_footer();
