<?php
defined('APP_ROOT') || exit;
$test = get_test_or_404();
$sid = (int)($_GET['sid'] ?? 0);
$forStudent = ($_GET['view'] ?? '') === 'student';   // chop etib o'quvchiga berish uchun — ichki ko'rsatkichlarsiz
page_header('Natija kartasi');
?>
<div class="row between center-v wrap gap no-print">
  <?= crumbs([['Testlar', url('tests')], ['#' . (int)$test['id'], url('test_edit', ['id' => $test['id']])], ['Natijalar', url('results', ['id' => $test['id']])], 'Natija kartasi']) ?>
  <div class="row gap center-v">
    <div class="seg">
      <a class="<?= $forStudent ? '' : 'active' ?>" href="<?= e(url('result_card', ['id' => $test['id'], 'sid' => $sid])) ?>">To'liq (admin)</a>
      <a class="<?= $forStudent ? 'active' : '' ?>" href="<?= e(url('result_card', ['id' => $test['id'], 'sid' => $sid, 'view' => 'student'])) ?>">O'quvchi uchun</a>
    </div>
    <button class="btn ghost" onclick="print()" title="Chop etish" aria-label="Chop etish"><?= icon('print', 16) ?><span class="hide-sm">Chop etish</span></button>
  </div>
</div>
<?php if (!$forStudent): ?><p class="small muted no-print">O'quvchiga chop etib berish uchun "O'quvchi uchun" ko'rinishini tanlang — unda θ, qiyinlik qiymatlari va hisoblash formulasi ko'rsatilmaydi.</p><?php endif; ?>
<?php render_result_card($test, $sid, $forStudent); ?>
<?php page_footer();
