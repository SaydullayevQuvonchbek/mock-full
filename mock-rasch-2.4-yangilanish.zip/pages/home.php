<?php
defined('APP_ROOT') || exit;
/** Ommaviy bosh sahifa (2.3): javoblar varaqasi motivi, shaxsiy kabinetga kirish, ochiq MOCK lar, darajalar shkalasi */
if (admin()) redirect('dashboard');
if (student()) redirect('student_home');
$openTests = rows('SELECT id, title, subject, test_date, online FROM tests WHERE reg_open=1 ORDER BY test_date IS NULL, test_date, id LIMIT 4');
$center = app_setting('center');
$months = ['', 'yan', 'fev', 'mar', 'apr', 'may', 'iyn', 'iyl', 'avg', 'sen', 'okt', 'noy', 'dek'];
// varaqadagi belgilangan javoblar (namuna) — 16 ta savol, 2 ustun
$marks = ['B', 'D', 'A', 'C', 'C', 'A', 'D', 'B', 'A', 'B', 'D', 'C', 'A', 'D', 'B', 'C'];
page_header('Bosh sahifa', ['main' => 'lp']);
?>
<section class="lp-hero">
  <div class="lp-hero-text">
    <h1>Imtihondan oldin&nbsp;— imtihonning o'zi</h1>
    <p class="lp-lead">MOCK imtihon milliy sertifikat formatida o'tadi: javoblar varaqasi, vaqt va 75 ballik baholash. Natijangiz, xatolaringiz va o'sishingiz shaxsiy kabinetingizda saqlanadi.</p>
    <div class="lp-cta">
      <a class="btn primary xl" href="<?= e(url('student_login')) ?>"><?= icon('user', 18) ?>Shaxsiy kabinetga kirish</a>
      <a class="btn xl" href="<?= e(url('register')) ?>">MOCK ga ro'yxatdan o'tish</a>
    </div>
    <p class="lp-note">Kabinetga ID raqamingiz yoki telefoningiz va parolingiz bilan kirasiz.</p>
  </div>

  <figure class="lp-sheet" aria-label="Javoblar varaqasi namunasi: 61,4 ball, B+ daraja">
    <div class="ls-head">
      <div class="ls-title"><b>JAVOBLAR VARAQASI</b><span>Matematika · MOCK</span></div>
      <div class="ls-id" aria-hidden="true"><span>ID</span><?php foreach (str_split('482107') as $d): ?><i><?= $d ?></i><?php endforeach; ?></div>
    </div>
    <ol class="ls-grid" aria-hidden="true">
      <?php foreach ($marks as $i => $mk): ?>
        <li><span class="qn"><?= $i + 1 ?></span><?php foreach (['A', 'B', 'C', 'D'] as $L): ?><i class="<?= $L === $mk ? 'f' : '' ?>" style="--d:<?= $i ?>"><?= $L ?></i><?php endforeach; ?></li>
      <?php endforeach; ?>
    </ol>
    <div class="ls-open" aria-hidden="true">
      <span>36</span><em>12</em><span>37</span><em>−3/4</em><span>38</span><em>7</em>
    </div>
    <div class="ls-foot">
      <div class="ls-score"><span>Natija</span><b>61,4</b><small>ball</small></div>
      <div class="ls-grade"><svg viewBox="0 0 100 64" aria-hidden="true"><path pathLength="1" d="M70 9C55 2 20 6 11 24c-8 17 9 33 38 34 27 1 46-10 45-26C93 15 74 6 54 6 39 6 27 10 22 14"/></svg><b>B+</b></div>
    </div>
  </figure>
</section>

<section class="lp-next" aria-labelledby="lpNext">
  <h2 id="lpNext"><?= $openTests ? 'Ro\'yxat ochiq' : 'Keyingi MOCK' ?></h2>
  <?php if ($openTests): ?>
    <div class="tickets">
      <?php foreach ($openTests as $t): $ts = $t['test_date'] ? strtotime((string)$t['test_date']) : 0; ?>
        <a class="ticket" href="<?= e(url('register', ['test' => $t['id']])) ?>">
          <span class="t-date"><?php if ($ts): ?><b><?= date('j', $ts) ?></b><small><?= $months[(int)date('n', $ts)] ?></small><?php else: ?><small>sana<br>keyinroq</small><?php endif; ?></span>
          <span class="t-body"><b><?= e($t['title']) ?></b><small><?= e($t['subject']) ?><?= $t['online'] ? ', onlayn' : '' ?></small></span>
          <span class="t-go">Ro'yxatdan o'tish</span>
        </a>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="ticket empty-ticket">
      <span class="t-body"><b>Hozir ro'yxati ochiq MOCK yo'q</b><small>Ma'lumotlaringizni oldindan qoldiring — keyingi MOCK e'lon qilinganda bir bosishda yozilasiz.</small></span>
      <a class="btn" href="<?= e(url('register')) ?>">Oldindan ro'yxatdan o'tish</a>
    </div>
  <?php endif; ?>
</section>

<section class="lp-cab" id="kabinet" aria-labelledby="lpCab">
  <div class="lp-login">
    <h2 id="lpCab">Shaxsiy kabinetga kirish</h2>
    <p class="muted">6 xonali ID raqamingiz yoki telefoningiz va parolingiz.</p>
    <form method="post" action="<?= e(url('student_login')) ?>" class="form">
      <?= csrf_field() ?>
      <label>ID yoki telefon <input name="ident" maxlength="20" required class="big-input" placeholder="123456" autocomplete="username" inputmode="text"></label>
      <label>Parol <input name="pass" type="password" required class="big-input" placeholder="••••••" autocomplete="current-password"></label>
      <button class="btn primary wide">Kirish</button>
    </form>
    <p class="lp-login-links"><a href="<?= e(url('student_reset')) ?>">Parolni unutdingizmi?</a><a href="<?= e(url('register')) ?>">Hali ro'yxatdan o'tmaganman</a></p>
  </div>
  <div class="lp-feats">
    <h2>Kabinetda nimalar bor</h2>
    <?php include __DIR__ . '/_cabinet_feats.php'; ?>
  </div>
</section>

<section class="lp-scale" aria-labelledby="lpScale">
  <div class="lp-scale-text">
    <h2 id="lpScale">Ball va daraja</h2>
    <p>Natija 75 ballik shkalada hisoblanadi. 46 balldan boshlab sertifikat darajasi beriladi — har 5 ball keyingi darajaga olib chiqadi.</p>
  </div>
  <?php
  // Shkala: 0–46 qismi qisqartirib ko'rsatiladi (uzilish belgisi bilan), 46–75 — haqiqiy nisbatda; aks holda darajalar juda tor bo'lib qoladi
  $scale = [[46, 50, 'g-c', 'C'], [50, 55, 'g-cp', 'C+'], [55, 60, 'g-b', 'B'], [60, 65, 'g-bp', 'B+'], [65, 70, 'g-a', 'A'], [70, 75, 'g-ap', 'A+']];
  $cut = 24;   // «sertifikatsiz» qismi kengligi, %
  $pos = fn(float $v) => $v <= 46 ? $cut * $v / 46 : $cut + (100 - $cut) * ($v - 46) / 29;
  ?>
  <div class="ruler" role="img" aria-label="Darajalar: C — 46 balldan, C+ — 50, B — 55, B+ — 60, A — 65, A+ — 70 balldan; 46 dan past — sertifikatsiz">
    <div class="ruler-bar">
      <span class="rseg rseg-none" style="width:<?= $cut ?>%"><b>46 dan past</b></span>
      <?php foreach ($scale as [$from, $to, $cls, $lbl]): ?><span class="rseg <?= e($cls) ?>" style="width:<?= round($pos($to) - $pos($from), 3) ?>%"><b><?= e($lbl) ?></b></span><?php endforeach; ?>
      <i class="ruler-break" style="left:<?= $cut ?>%" aria-hidden="true"></i>
    </div>
    <div class="ruler-ticks">
      <?php foreach ([0, 46, 50, 55, 60, 65, 70, 75] as $v): ?><span style="left:<?= round($pos($v), 3) ?>%"><?= $v ?></span><?php endforeach; ?>
    </div>
  </div>
</section>

<section class="lp-steps" aria-labelledby="lpSteps">
  <h2 id="lpSteps">Qanday o'tadi</h2>
  <ol>
    <li><b>Ro'yxatdan o'ting</b><p>MOCK ni tanlang, ma'lumotlaringizni kiriting va parol qo'ying — sizga shaxsiy ID beriladi.</p></li>
    <li><b>Imtihon kuni</b><p>Ismingiz yozilgan javoblar varaqasini to'ldirasiz yoki onlayn ishlaysiz. Xona va o'rningiz oldindan xabar qilinadi.</p></li>
    <li><b>Natija</b><p>Natija e'lon qilingach, kabinetingizda ball, daraja, bo'limlar tahlili va sertifikat paydo bo'ladi.</p></li>
  </ol>
</section>

<section class="lp-verify" aria-labelledby="lpVer">
  <div><h2 id="lpVer">Sertifikatni tekshirish</h2><p class="muted">Sertifikat raqamini kiriting yoki undagi QR kodni telefon kamerasi bilan skanerlang.</p></div>
  <form method="get" class="form lp-verify-form">
    <input type="hidden" name="p" value="verify">
    <label class="sr-only" for="lpCert">Sertifikat raqami</label>
    <input id="lpCert" name="n" required class="big-input" placeholder="M26-000123">
    <button class="btn">Tekshirish</button>
  </form>
</section>
<?php page_footer();
