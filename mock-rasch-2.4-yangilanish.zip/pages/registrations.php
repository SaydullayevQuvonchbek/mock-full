<?php
defined('APP_ROOT') || exit;
$test = get_test_or_404();
$tid = (int)$test['id'];
// Amaldan keyin shu sahifaga filtrlar saqlangan holda qaytish (formalar joriy manzilga yuboriladi, shuning uchun $_GET da filtrlar bor)
$back = function () use ($tid) {
    $keep = ['id' => $tid];
    foreach (['room', 'pr', 'q', 'fg', 'fc', 'o', 'un', 'ng', 'nc', 'ns'] as $k) $keep[$k] = (string)($_POST['f_' . $k] ?? $_GET[$k] ?? '');
    redirect('registrations', array_filter($keep, fn($v) => $v !== ''));
};

/** Shu test ro'yxatiga hali kiritilmagan o'quvchilar uchun WHERE va parametrlar (filtr: guruh, markaz, qidiruv) */
$unregSql = function (string $g, string $c, string $s) use ($tid): array {
    $w = ['s.archived_at IS NULL', 'NOT EXISTS (SELECT 1 FROM test_registrations r WHERE r.test_id=? AND r.student_id=s.id)']; $p = [$tid];
    if ($g === '@none') $w[] = "s.group_name=''";
    elseif ($g !== '') { $w[] = 's.group_name=?'; $p[] = $g; }
    if ($c === 'own') $w[] = 's.center_id IS NULL';
    elseif ($c !== '') { $w[] = 's.center_id=?'; $p[] = (int)$c; }
    if ($s !== '') { [$sw, $sp] = student_search_sql($s); $w[] = $sw; $p = array_merge($p, $sp); }
    return [implode(' AND ', $w), $p];
};

if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    $addIds = function (array $ids) use ($tid): int {
        $st = db()->prepare('INSERT IGNORE INTO test_registrations (test_id, student_id) VALUES (?,?)');
        $n = 0; foreach ($ids as $sid) { $st->execute([$tid, (int)$sid]); $n += $st->rowCount(); }
        return $n;
    };
    if ($act === 'remove') q('DELETE FROM test_registrations WHERE test_id=? AND student_id=?', [$tid, (int)$_POST['sid']]);
    if ($act === 'toggle') q('UPDATE tests SET reg_open=1-reg_open WHERE id=?', [$tid]);
    if ($act === 'add') {
        // Telefon orqali yoki markazga kelib ro'yxatdan o'tganlar: admin ID bo'yicha qo'shadi (ro'yxat yopiq bo'lsa ham)
        $ids = []; $miss = [];
        foreach (preg_split('/[\s,;]+/', (string)($_POST['codes'] ?? ''), -1, PREG_SPLIT_NO_EMPTY) as $code) {
            $sid = val('SELECT id FROM students WHERE code=? AND archived_at IS NULL', [preg_replace('/\D/', '', $code)]);
            if ($sid) $ids[] = $sid; else $miss[] = $code;
        }
        $n = $addIds($ids);
        flash("Qo'shildi: $n" . ($miss ? '. Topilmagan ID: ' . implode(', ', array_slice($miss, 0, 10)) : ''), $miss ? 'warn' : 'ok');
    }
    if ($act === 'add_group') {
        $g = trim((string)($_POST['group'] ?? ''));
        if ($g === '@all') { $ids = array_column(rows('SELECT id FROM students WHERE archived_at IS NULL'), 'id'); $from = "Barcha o'quvchilardan"; }
        elseif ($g === '@none') { $ids = array_column(rows("SELECT id FROM students WHERE group_name='' AND archived_at IS NULL"), 'id'); $from = 'Guruhsizlardan'; }
        else { $ids = array_column(rows('SELECT id FROM students WHERE group_name=? AND archived_at IS NULL', [$g]), 'id'); $from = "\"$g\" guruhidan"; }
        $n = $addIds($ids);
        flash("$from $n ta o'quvchi qo'shildi" . (count($ids) > $n ? ' (' . (count($ids) - $n) . ' tasi avval ro\'yxatda edi)' : ''));
    }
    if ($act === 'add_sel') {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
        if (!$ids) flash('O\'quvchi tanlanmagan', 'warn');
        else flash($addIds($ids) . " ta o'quvchi ro'yxatga qo'shildi");
    }
    if ($act === 'add_filter') {
        [$w, $p] = $unregSql((string)($_POST['f_ng'] ?? ''), (string)($_POST['f_nc'] ?? ''), trim((string)($_POST['f_ns'] ?? '')));
        $n = $addIds(array_column(rows("SELECT s.id FROM students s WHERE $w", $p), 'id'));
        flash("$n ta o'quvchi ro'yxatga qo'shildi");
    }
    // --- Xonalar ---
    if ($act === 'room_add') {
        $name = mb_substr(trim((string)($_POST['name'] ?? '')), 0, 60);
        $cap = max(1, min(500, (int)($_POST['capacity'] ?? 30)));
        $cnt = max(1, min(50, (int)($_POST['count'] ?? 1)));
        $sort = (int)val('SELECT COALESCE(MAX(sort),0) FROM test_rooms WHERE test_id=?', [$tid]);
        for ($i = 1; $i <= $cnt; $i++) {
            $nm = $cnt > 1 || $name === '' ? ($name !== '' ? "$name-$i" : ($sort + 1) . '-xona') : $name;
            q('INSERT INTO test_rooms (test_id, name, capacity, sort) VALUES (?,?,?,?)', [$tid, $nm, $cap, ++$sort]);
        }
        flash($cnt > 1 ? "$cnt ta xona qo'shildi" : 'Xona qo\'shildi');
    }
    if ($act === 'room_preset') {
        $n = center_rooms_apply($tid);
        flash($n ? "Markaz xonalaridan $n ta qo'shildi. Endi «Joylashtirish» ni bosing." : 'Markaz xonalari allaqachon qo\'shilgan', $n ? 'ok' : 'warn');
    }
    if ($act === 'room_edit') {
        $rid = (int)$_POST['rid'];
        $cap = max(1, min(500, (int)($_POST['capacity'] ?? 30)));
        $used = (int)val('SELECT MAX(seat) FROM test_registrations WHERE test_id=? AND room_id=?', [$tid, $rid]);
        if ($cap < $used) flash("Sig'imni $used dan kamaytirib bo'lmaydi — avval o'quvchilarni boshqa xonaga o'tkazing yoki qaytadan taqsimlang", 'err');
        else q('UPDATE test_rooms SET name=?, capacity=?, proctor=? WHERE id=? AND test_id=?', [mb_substr(trim((string)$_POST['name']), 0, 60) ?: 'Xona', $cap, mb_substr(trim((string)($_POST['proctor'] ?? '')), 0, 120), $rid, $tid]);
    }
    if ($act === 'room_del') {
        $rid = (int)$_POST['rid'];
        q('UPDATE test_registrations SET room_id=NULL, seat=NULL WHERE test_id=? AND room_id=?', [$tid, $rid]);
        q('DELETE FROM test_rooms WHERE id=? AND test_id=?', [$rid, $tid]);
        flash('Xona o\'chirildi, undagi o\'quvchilar xonasiz qoldi', 'warn');
    }
    if ($act === 'distribute') {
        $ord = in_array($_POST['order'] ?? '', ['name', 'school', 'group', 'time', 'random', 'mix'], true) ? $_POST['order'] : 'name';
        $seedIn = trim((string)($_POST['seed'] ?? ''));
        [$done, $left, $seed] = distribute_rooms($tid, ($_POST['mode'] ?? 'new') === 'all' ? 'all' : 'new', $ord, !empty($_POST['balance']), $seedIn !== '' ? (int)$seedIn : null);
        flash("$done ta o'quvchi xonalarga joylashtirildi" . (in_array($ord, ['random', 'mix'], true) ? " (seed: $seed — shu raqam bilan bir xil joylashuvni qayta olish mumkin)" : '') . ($left ? ". $left tasiga joy yetmadi — xona qo'shing yoki sig'imni oshiring" : ''), $left ? 'warn' : 'ok');
    }
    if ($act === 'notify_rooms') {
        if (!tg_ready() && !sms_ready()) flash('Xabar yuborish uchun Telegram bot yoki Eskiz SMS ulanmagan (Sozlamalar)', 'err');
        else {
            $n = room_notify_queue($tid, isset($_POST['resend']));
            if ($n['bot'] + $n['sms'] > 0) tg_tick(20);
            flash('Xona va o\'rin xabari navbatga qo\'yildi: Telegram ' . $n['bot'] . ', SMS ' . $n['sms'] . ($n['none'] ? '; yetkazib bo\'lmaydi (bot ham, telefon ham yo\'q): ' . $n['none'] : ''), ($n['bot'] + $n['sms']) ? 'ok' : 'warn');
        }
    }
    if ($act === 'move') {
        if (!move_to_room($tid, (int)$_POST['sid'], (int)$_POST['room'])) flash('Bu xonada bo\'sh o\'rin yo\'q', 'err');
    }
    // --- Belgilanganlar bilan ---
    if ($act === 'mass') {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
        $op = $_POST['op'] ?? '';
        if (!$ids) flash('O\'quvchi tanlanmagan', 'warn');
        else {
            $in = implode(',', array_fill(0, count($ids), '?'));
            if ($op === 'room') {
                $full = 0; foreach ($ids as $sid) if (!move_to_room($tid, $sid, (int)($_POST['to_room'] ?? 0))) $full++;
                flash(count($ids) - $full . ' ta o\'quvchi ko\'chirildi' . ($full ? ", $full tasiga joy yetmadi" : ''), $full ? 'warn' : 'ok');
            } elseif ($op === 'printed') {
                q("UPDATE test_registrations SET printed_at=NOW() WHERE test_id=? AND student_id IN ($in)", array_merge([$tid], $ids));
                flash(count($ids) . ' ta varaq "chop etilgan" deb belgilandi');
            } elseif ($op === 'unprinted') {
                q("UPDATE test_registrations SET printed_at=NULL WHERE test_id=? AND student_id IN ($in)", array_merge([$tid], $ids));
                flash(count($ids) . ' ta varaq qayta chop etish uchun belgilandi');
            } elseif ($op === 'remove') {
                q("DELETE FROM test_registrations WHERE test_id=? AND student_id IN ($in)", array_merge([$tid], $ids));
                flash(count($ids) . ' ta o\'quvchi ro\'yxatdan chiqarildi', 'warn');
            }
        }
    }
    $back();
}

$rooms = test_rooms($tid);
// Ro'yxat filtri — shu filtr chop etishga ham o'tadi (ro'yxatda nima ko'rinsa, o'sha chop etiladi, o'sha tartibda)
$fRoom = (string)($_GET['room'] ?? '');
$fPr = in_array($_GET['pr'] ?? '', ['new', 'done'], true) ? $_GET['pr'] : '';
$fQ = trim((string)($_GET['q'] ?? ''));
$fG = (string)($_GET['fg'] ?? '');
$fC = (string)($_GET['fc'] ?? '');
$fO = in_array($_GET['o'] ?? '', ['room', 'name', 'school', 'time'], true) ? $_GET['o'] : ($rooms ? 'room' : 'name');
$all = reg_students($tid, ['order' => $fO]);
$list = reg_students($tid, ['room' => $fRoom, 'only' => $fPr, 'q' => $fQ, 'group' => $fG, 'center' => $fC, 'order' => $fO]);
$filtered = $fRoom !== '' || $fPr !== '' || $fQ !== '' || $fG !== '' || $fC !== '';
// Ro'yxatdagilarning guruhlari (filtr uchun, soni bilan)
$regGroups = [];
foreach ($all as $s) $regGroups[$s['group_name']] = ($regGroups[$s['group_name']] ?? 0) + 1;
ksort($regGroups);
$resp = [];
foreach (rows('SELECT student_id, status FROM responses WHERE test_id=?', [$tid]) as $r) $resp[(int)$r['student_id']] = $r['status'];
$N = count($all);
$nPrinted = count(array_filter($all, fn($s) => $s['printed_at']));
$nPlaced = count(array_filter($all, fn($s) => $s['room_id']));
$seats = array_sum(array_map(fn($r) => (int)$r['capacity'], $rooms));
// Guruhlar: jami o'quvchi (n) va shu ro'yxatga hali kiritilmaganlar (free)
$gstat = rows('SELECT s.group_name g, COUNT(*) n, SUM(r.student_id IS NULL) free FROM students s
               LEFT JOIN test_registrations r ON r.test_id=? AND r.student_id=s.id WHERE s.archived_at IS NULL GROUP BY s.group_name ORDER BY s.group_name', [$tid]);
$nStudents = (int)array_sum(array_column($gstat, 'n'));
$freeAll = (int)array_sum(array_column($gstat, 'free'));
$groups = array_values(array_filter($gstat, fn($g) => $g['g'] !== ''));
$noGroup = current(array_filter($gstat, fn($g) => $g['g'] === '')) ?: null;
$gLabel = fn(int $free) => $free ? "(+$free)" : '✓';   // +N — qo'shiladiganlar soni, ✓ — hammasi ro'yxatda
$centers = centers_list();
// Ro'yxatga kiritilmaganlar bo'limi
$nf = ['g' => (string)($_GET['ng'] ?? ''), 'c' => (string)($_GET['nc'] ?? ''), 's' => trim((string)($_GET['ns'] ?? ''))];
[$uw, $up] = $unregSql($nf['g'], $nf['c'], $nf['s']);
$unTotal = (int)val("SELECT COUNT(*) FROM students s WHERE $uw", $up);
$unList = rows("SELECT s.id, s.code, s.full_name, s.group_name, s.center_id, s.school, s.grade_level, s.phone FROM students s WHERE $uw ORDER BY s.full_name LIMIT 500", $up);
$unFiltered = $nf['g'] !== '' || $nf['c'] !== '' || $nf['s'] !== '';
$unOpen = $unFiltered || !empty($_GET['un']) || ($N === 0 && $freeAll > 0);
$link = app_base_url() . 'index.php?' . http_build_query(['p' => 'register', 'test' => $tid]);
$sheetUrl = fn(array $p) => url('sheet', ['id' => $tid, 'group' => '@reg'] + $p);
// Joriy filtr bo'yicha varaqlar (ro'yxatdagi tartibda)
$filterSheetUrl = $sheetUrl(array_filter(['room' => $fRoom, 'only' => $fPr, 'q' => $fQ, 'fg' => $fG, 'fc' => $fC, 'order' => $fO], fn($v) => $v !== ''));

page_header('Ro\'yxat — ' . $test['title']);
test_tabs($test, 'registrations');
?>
<div class="stats4 reg-kpi">
  <div class="stat"><span><?= $N ?></span>Ro'yxatda</div>
  <div class="stat"><span><?= $rooms ? "$nPlaced / $N" : '—' ?></span>Xonaga joylashgan</div>
  <div class="stat"><span><?= $rooms ? $seats : '—' ?></span>Jami o'rin<?= $rooms && $seats < $N ? ' <b class="warn-txt">· yetmaydi</b>' : '' ?></div>
  <div class="stat"><span><?= $nPrinted ?> / <?= $N ?></span>Varaq chop etilgan</div>
</div>

<div class="reg-flow">
  <!-- 1. Ro'yxat -->
  <section class="card reg-step <?= $N ? 'ok' : 'now' ?>">
    <div class="rs-h"><span class="rs-n">1</span><div><h2>Ro'yxat</h2><p class="small muted"><?= $N ? "<b>$N</b> kishi ro'yxatda" : 'Hali hech kim yo\'q' ?><?= $test['reg_open'] ? ' · onlayn ro\'yxat <b>ochiq</b>' : '' ?></p></div></div>
    <?php if ($nStudents && $freeAll): ?>
    <form method="post" class="row gap filter add-row" onsubmit="return this.group.value!=='@all' || confirm('Barcha faol o\'quvchilar (<?= $freeAll ?> ta) shu MOCK ro\'yxatiga qo\'shilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="add_group">
      <select name="group" aria-label="Guruh" class="grow">
        <?php foreach ($groups as $g): if (!(int)$g['free']) continue; ?><option value="<?= e($g['g']) ?>"><?= e($g['g']) ?> — +<?= (int)$g['free'] ?> kishi</option><?php endforeach; ?>
        <?php if ($noGroup && (int)$noGroup['free']): ?><option value="@none">Guruhsizlar — +<?= (int)$noGroup['free'] ?></option><?php endif; ?>
        <option value="@all">Barcha o'quvchilar — +<?= $freeAll ?></option>
      </select>
      <button class="btn primary">Qo'shish</button></form>
    <?php elseif ($nStudents): ?><p class="small muted">Barcha faol o'quvchilar ro'yxatda ✓</p>
    <?php else: ?><p class="small muted">Bazada o'quvchi yo'q — <a href="<?= e(url('students')) ?>">O'quvchilar</a> sahifasida qo'shing.</p><?php endif; ?>
    <details class="rs-more"><summary>ID bo'yicha yoki tanlab qo'shish</summary>
      <form method="post" class="form"><?= csrf_field() ?><input type="hidden" name="action" value="add">
        <label>ID lar <textarea name="codes" rows="2" class="mono" placeholder="545742, 929446 …"></textarea></label>
        <button class="btn sm">Qo'shish</button></form>
      <?php if ($freeAll): ?><p class="small"><a href="#unreg" onclick="document.getElementById('unreg').open=true">Ro'yxatga kiritilmaganlardan belgilab qo'shish (<?= $freeAll ?>) ↓</a></p><?php endif; ?>
    </details>
    <details class="rs-more"><summary>Onlayn ro'yxatdan o'tish (havola) — <?= $test['reg_open'] ? 'ochiq' : 'yopiq' ?></summary>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><button class="btn sm <?= $test['reg_open'] ? 'ghost' : '' ?>"><?= $test['reg_open'] ? 'Ro\'yxatni yopish' : 'Ro\'yxatni ochish' ?></button></form>
      <p class="small muted">Ochiq bo'lsa, o'quvchilar shu havola orqali o'zi yoziladi:</p>
      <input class="mono small copy-in" readonly value="<?= e($link) ?>" onclick="this.select()" aria-label="Ro'yxatdan o'tish havolasi">
    </details>
  </section>

  <!-- 2. Xonalar -->
  <section class="card reg-step <?= $rooms ? ($seats >= $N ? 'ok' : 'warn') : ($N ? 'now' : '') ?>">
    <div class="rs-h"><span class="rs-n">2</span><div><h2>Xonalar</h2><p class="small muted"><?= $rooms ? count($rooms) . ' ta xona · ' . $seats . ' o\'rin' . ($seats < $N ? ' — <b class="warn-txt">' . ($N - $seats) . ' o\'rin yetmaydi</b>' : '') : 'Xonalar kiritilmagan (bitta xonada o\'tsa — shart emas)' ?></p></div></div>
    <?php if ($rooms): ?>
      <div class="room-rows">
        <?php foreach ($rooms as $r): $full = (int)$r['used'] >= (int)$r['capacity']; ?>
          <div class="room-row">
            <form method="post" class="room-edit filter"><?= csrf_field() ?><input type="hidden" name="action" value="room_edit"><input type="hidden" name="rid" value="<?= (int)$r['id'] ?>">
              <input name="name" value="<?= e($r['name']) ?>" maxlength="60" aria-label="Xona nomi">
              <input name="capacity" type="number" min="1" max="500" value="<?= (int)$r['capacity'] ?>" class="num-in" aria-label="Sig'im" title="Sig'im">
              <input name="proctor" value="<?= e($r['proctor']) ?>" maxlength="120" placeholder="Nazoratchi" aria-label="Nazoratchi" title="Nazoratchi (xona ro'yxatida va o'quvchi kabinetida ko'rinadi)">
              <button class="btn sm ghost" title="Saqlash"><?= icon('check', 14) ?></button>
            </form>
            <span class="room-used <?= $full ? 'warn-txt' : '' ?>" title="Band o'rinlar"><?= (int)$r['used'] ?>/<?= (int)$r['capacity'] ?></span>
            <form method="post" onsubmit="return confirm('Xona o\'chirilsinmi? Undagi o\'quvchilar xonasiz qoladi.')"><?= csrf_field() ?><input type="hidden" name="action" value="room_del"><input type="hidden" name="rid" value="<?= (int)$r['id'] ?>"><button class="btn sm danger-ghost" title="O'chirish">×</button></form>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <?php $cr = center_rooms(); $crNew = array_filter($cr, function ($c) use ($rooms) { foreach ($rooms as $r) if (mb_strtolower($r['name']) === mb_strtolower($c['name'])) return false; return true; }); ?>
    <?php if ($crNew): ?>
      <form method="post" class="mt"><?= csrf_field() ?><input type="hidden" name="action" value="room_preset">
        <button class="btn <?= $rooms ? '' : 'primary' ?> wide">Markaz xonalarini qo'shish — <?= count($crNew) ?> ta, <?= array_sum(array_map(fn($c) => (int)$c['capacity'], $crNew)) ?> o'rin</button></form>
    <?php elseif (!$cr): ?>
      <p class="small muted mt">Markaz xonalarini bir marta <a href="<?= e(url('settings')) ?>#xonalar">Sozlamalar → Xonalar va sig'im</a> da kiriting — keyin har MOCK ga bir bosishda qo'shiladi.</p>
    <?php endif; ?>
    <details class="rs-more" <?= !$rooms && !$cr ? 'open' : '' ?>><summary>Boshqa xona qo'shish</summary>
      <form method="post" class="form room-add"><?= csrf_field() ?><input type="hidden" name="action" value="room_add">
        <div class="grid3">
          <label>Nomi <input name="name" maxlength="60" placeholder="12-xona"></label>
          <label>Sig'im <input name="capacity" type="number" min="1" max="500" value="30"></label>
          <label>Soni <input name="count" type="number" min="1" max="50" value="1" title="Bir nechta bir xil xona qo'shish"></label>
        </div>
        <button class="btn sm">Qo'shish</button>
      </form>
    </details>
  </section>

  <!-- 3. Joylashtirish -->
  <section class="card reg-step <?= !$rooms ? 'off' : ($nPlaced === $N && $N ? 'ok' : ($N ? 'now' : '')) ?>">
    <div class="rs-h"><span class="rs-n">3</span><div><h2>Xonalarga joylashtirish</h2><p class="small muted"><?= !$rooms ? 'Avval xona qo\'shing' : ($N ? "Joylashgan: <b>$nPlaced / $N</b>" . ($nPlaced < $N ? ' · xonasiz: <b>' . ($N - $nPlaced) . '</b>' : ' ✓') : 'Ro\'yxat bo\'sh') ?></p></div></div>
    <?php if ($rooms && $N): ?>
    <form method="post" class="form dist-form"><?= csrf_field() ?><input type="hidden" name="action" value="distribute"><input type="hidden" name="balance" value="1">
      <label>Qanday o'tqazilsin
        <select name="order"><option value="mix">Aralash — bir guruh/maktab yonma-yon o'tirmaydi (tavsiya)</option><option value="name">Alifbo bo'yicha</option><option value="random">Tasodifiy</option><option value="group">Guruh bo'yicha</option><option value="school">Maktab / sinf bo'yicha</option><option value="time">Ro'yxatdan o'tish vaqti bo'yicha</option></select></label>
      <?php if ($nPlaced > 0): ?>
        <label class="check"><input type="radio" name="mode" value="new" checked> Faqat xonasizlarni joylash<?= $nPlaced < $N ? ' (' . ($N - $nPlaced) . ')' : '' ?></label>
        <label class="check"><input type="radio" name="mode" value="all"> Hammasini qaytadan joylash</label>
      <?php else: ?><input type="hidden" name="mode" value="new"><?php endif; ?>
      <details class="rs-more"><summary>Qo'shimcha</summary>
        <label>Seed <input name="seed" inputmode="numeric" maxlength="9" placeholder="bo'sh — yangi tasodifiy" title="Tasodifiy/aralash tartib uchun: bir xil raqam — bir xil joylashuv"></label>
        <p class="small muted">Xonalar teng to'ldiriladi (masalan 100 kishi, 3 xona: 34/33/33). Keyin istalgan o'quvchini pastdagi ro'yxatda boshqa xonaga o'tkazish mumkin.</p>
      </details>
      <button class="btn primary wide" onclick="var m=this.form.querySelector('input[name=mode]:checked'); return !m || m.value!=='all' || confirm('Barcha o\'rinlar qaytadan taqsimlanadi. Chop etilgan varaqlardagi xona/o\'rin eskiradi. Davom etasizmi?')">Joylashtirish</button>
    </form>
    <?php endif; ?>
  </section>

  <!-- 4. Tasdiqlash: chop etish va xabar -->
  <section class="card reg-step <?= $N && $nPrinted === $N ? 'ok' : ($N && (!$rooms || $nPlaced === $N) ? 'now' : '') ?>">
    <div class="rs-h"><span class="rs-n">4</span><div><h2>Tasdiqlash: varaqlar va xabar</h2><p class="small muted">Varaqda ism, ID<?= $rooms ? ', xona va o\'rin' : '' ?> yoziladi. Chop etilganlar belgilanadi.</p></div></div>
    <?php if ($N): ?>
    <div class="rs-actions">
      <?php if ($rooms): ?>
        <a class="btn primary" target="_blank" href="<?= e($sheetUrl(['order' => 'room', 'sep' => 1])) ?>" title="Xona → o'rin tartibida; har xona oldidan ajratuvchi varaq"><?= icon('print', 16) ?>Javoblar varaqalari — xonalar bo'yicha</a>
      <?php endif; ?>
      <a class="btn <?= $rooms ? '' : 'primary' ?>" target="_blank" href="<?= e($sheetUrl(['only' => 'new'] + ($rooms ? ['order' => 'room', 'sep' => 1] : []))) ?>"><?= icon('print', 16) ?>Faqat yangilar (<?= $N - $nPrinted ?>)</a>
      <?php if (!$rooms): ?><a class="btn" target="_blank" href="<?= e($sheetUrl([])) ?>">Hammasi (<?= $N ?>)</a><?php endif; ?>
    </div>
    <?php if ($rooms): ?>
      <div class="rs-rooms">
        <?php foreach ($rooms as $r): if (!(int)$r['used']) continue; ?>
          <a class="rs-room-chip" target="_blank" href="<?= e($sheetUrl(['room' => (int)$r['id'], 'order' => 'room', 'sep' => 1])) ?>" title="Faqat shu xonaning varaqlari"><?= icon('print', 13) ?><?= e($r['name']) ?> <b><?= (int)$r['used'] ?></b></a>
        <?php endforeach; ?>
      </div>
      <p class="small"><a target="_blank" href="<?= e(url('room_list', ['id' => $tid])) ?>">Davomat ro'yxatlari</a> · <a target="_blank" href="<?= e(url('room_door', ['id' => $tid])) ?>">Eshik ro'yxatlari</a> · <a target="_blank" href="<?= e(url('room_door', ['id' => $tid, 'mode' => 'all'])) ?>">Kirishdagi umumiy ro'yxat</a></p>
    <?php endif; ?>
    <?php if ($rooms && $nPlaced > 0): $np = room_notify_plan($tid, false); $canSend = tg_ready() || sms_ready(); $toSend = count($np['bot']) + count($np['sms']); ?>
      <div class="rs-notify">
        <b>O'quvchilarga xona va o'rin xabari</b>
        <?php if (!$canSend): ?>
          <p class="small muted">Telegram bot yoki Eskiz SMS ulangach yuboriladi. <a href="<?= e(url('settings')) ?>#xabarlar">Sozlamalar →</a></p>
        <?php else: ?>
          <p class="small" style="margin:.2rem 0">Olgan: <b><?= $np['done'] ?></b> · yuboriladi: <b><?= count($np['bot']) ?></b> Telegram + <b><?= count($np['sms']) ?></b> SMS<?php if ($np['none']): ?> · <span class="warn-txt">yetkazib bo'lmaydi: <b><?= count($np['none']) ?></b></span><?php endif; ?></p>
          <div class="row gap wrap">
            <form method="post" onsubmit="return confirm('<?= $toSend ?> ta o\'quvchiga xona va o\'rin yuborilsinmi?<?= count($np['sms']) ? ' (SMS pullik: ' . count($np['sms']) . ' ta)' : '' ?>')"><?= csrf_field() ?><input type="hidden" name="action" value="notify_rooms"><button class="btn sm primary" <?= $toSend ? '' : 'disabled' ?>>Tasdiqlash va yuborish (<?= $toSend ?>)</button></form>
            <form method="post" onsubmit="return confirm('Hammasiga (avval olganlarga ham) qayta yuborilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="notify_rooms"><input type="hidden" name="resend" value="1"><button class="btn sm ghost">Hammasiga qayta</button></form>
          </div>
        <?php endif; ?>
      </div>
    <?php endif; ?>
    <?php else: ?><p class="small muted">Ro'yxat bo'sh.</p><?php endif; ?>
  </section>
</div>

<details class="card" id="unreg" <?= $unOpen ? 'open' : '' ?>>
  <summary><h2 style="display:inline">Ro'yxatga kiritilmagan o'quvchilar <span class="muted">(<?= $freeAll ?>)</span></h2></summary>
  <p class="small muted mt">Bazada bor, lekin shu MOCK ro'yxatida yo'q o'quvchilar (masalan, admin qo'shgan, lekin testga biriktirmagan). Belgilab qo'shing yoki filtrga mos hammasini bir bosishda qo'shing.</p>
  <?php if (!$nStudents): ?>
    <p class="empty">Bazada hali o'quvchi yo'q — avval <a href="<?= e(url('students')) ?>">"O'quvchilar"</a> sahifasida qo'shing.</p>
  <?php elseif (!$freeAll): ?>
    <p class="empty">Barcha o'quvchilar shu MOCK ro'yxatida.</p>
  <?php else: ?>
  <form method="get" class="row gap wrap center-v filter filter-row">
    <input type="hidden" name="p" value="registrations"><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="un" value="1">
    <input name="ns" value="<?= e($nf['s']) ?>" placeholder="Ism, ID, telefon yoki maktab" aria-label="Qidirish">
    <select name="ng" aria-label="Guruh"><option value="">Barcha guruhlar</option><?php foreach ($groups as $g): ?><option value="<?= e($g['g']) ?>" <?= $nf['g'] === $g['g'] ? 'selected' : '' ?>><?= e($g['g']) ?></option><?php endforeach; ?><?php if ($noGroup): ?><option value="@none" <?= $nf['g'] === '@none' ? 'selected' : '' ?>>Guruhsizlar</option><?php endif; ?></select>
    <?php if ($centers): ?><select name="nc"><option value="">Barcha markazlar</option><option value="own" <?= $nf['c'] === 'own' ? 'selected' : '' ?>>O'z markazimiz</option><?php foreach ($centers as $cid => $cn): ?><option value="<?= (int)$cid ?>" <?= $nf['c'] === (string)$cid ? 'selected' : '' ?>><?= e($cn) ?></option><?php endforeach; ?></select><?php endif; ?>
    <button class="btn sm">Filtr</button>
    <?php if ($unFiltered): ?><a class="small keep-scroll" href="<?= e(url('registrations', ['id' => $tid, 'un' => 1])) ?>">Tozalash</a><?php endif; ?>
  </form>
  <?php if ($unList): ?>
  <form method="post">
    <?= csrf_field() ?><input type="hidden" name="f_un" value="1"><input type="hidden" name="f_ng" value="<?= e($nf['g']) ?>"><input type="hidden" name="f_nc" value="<?= e($nf['c']) ?>"><input type="hidden" name="f_ns" value="<?= e($nf['s']) ?>">
    <div class="mass-bar card soft mt">
      <label class="check"><input type="checkbox" id="unAll"> Barchasi</label>
      <button class="btn sm primary" name="action" value="add_sel">Tanlanganlarni qo'shish</button>
      <span class="muted small" id="unCount">0 ta tanlangan</span>
      <button class="btn sm" style="margin-left:auto" name="action" value="add_filter" onclick="return confirm('<?= $unFiltered ? 'Filtrga mos' : 'Ro\'yxatga kiritilmagan' ?> <?= $unTotal ?> ta o\'quvchi shu MOCK ro\'yxatiga qo\'shilsinmi?')"><?= $unFiltered ? 'Filtrdagi' : 'Hammasini' ?> qo'shish (<?= $unTotal ?>)</button>
    </div>
    <div class="table-wrap"><table class="tbl compact-tbl">
      <thead><tr><th></th><th>ID</th><th>F.I.Sh</th><th>Guruh</th><th>Telefon</th></tr></thead>
      <tbody>
      <?php foreach ($unList as $s): ?>
        <tr>
          <td><input type="checkbox" name="ids[]" value="<?= (int)$s['id'] ?>" class="unchk" aria-label="Belgilash"></td>
          <td class="mono"><?= e($s['code']) ?></td>
          <td><?= e($s['full_name']) ?><?php if ($s['school'] || $s['grade_level']): ?><div class="small muted"><?= e(trim($s['school'] . ' · ' . $s['grade_level'], ' ·')) ?></div><?php endif; ?></td>
          <td class="small"><?= e($s['group_name'] ?: '—') ?><?php if ($s['center_id']): ?><div class="muted"><?= e($centers[(int)$s['center_id']] ?? '') ?></div><?php endif; ?></td>
          <td class="nowrap small"><?= e($s['phone'] ? fmt_phone($s['phone']) : '—') ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php if ($unTotal > count($unList)): ?><p class="small muted">Birinchi <?= count($unList) ?> tasi ko'rsatildi (jami <?= $unTotal ?>) — filtrdan foydalaning yoki "<?= $unFiltered ? 'Filtrdagi' : 'Hammasini' ?> qo'shish" tugmasini bosing.</p><?php endif; ?>
  </form>
  <?php else: ?>
    <p class="empty">Filtrga mos o'quvchi yo'q.</p>
  <?php endif; ?>
  <?php endif; ?>
</details>

<div class="reg-list" id="regList">
  <div>
    <div class="row between center-v wrap gap">
      <h2 style="margin:0">Ro'yxatdagilar <span class="muted" id="regCount">(<?= count($list) ?><?= $filtered ? " / $N" : '' ?>)</span></h2>
      <a class="btn sm ghost" href="<?= e(url('export', ['what' => 'registrations', 'id' => $tid])) ?>"><?= icon('download', 14) ?>Excel</a>
    </div>
    <form method="get" class="row gap wrap center-v filter filter-row reg-filter mt" id="regFilter">
      <input type="hidden" name="p" value="registrations"><input type="hidden" name="id" value="<?= $tid ?>">
      <input type="search" name="q" value="<?= e($fQ) ?>" placeholder="Ism, ID, telefon yoki maktab" autocomplete="off" aria-label="Qidirish">
      <?php if (count($regGroups) > 1 || ($regGroups && !isset($regGroups['']))): ?><select name="fg" aria-label="Guruh"><option value="">Barcha guruhlar</option><?php foreach ($regGroups as $g => $n): ?><option value="<?= $g === '' ? '@none' : e($g) ?>" <?= $fG === ($g === '' ? '@none' : (string)$g) ? 'selected' : '' ?>><?= $g === '' ? 'Guruhsizlar' : e($g) ?> (<?= $n ?>)</option><?php endforeach; ?></select><?php endif; ?>
      <?php if ($centers): ?><select name="fc"><option value="">Barcha markazlar</option><option value="own" <?= $fC === 'own' ? 'selected' : '' ?>>O'z markazimiz</option><?php foreach ($centers as $cid => $cn): ?><option value="<?= (int)$cid ?>" <?= $fC === (string)$cid ? 'selected' : '' ?>><?= e($cn) ?></option><?php endforeach; ?></select><?php endif; ?>
      <?php if ($rooms): ?><select name="room" aria-label="Xona"><option value="">Barcha xonalar</option><?php foreach ($rooms as $r): ?><option value="<?= (int)$r['id'] ?>" <?= $fRoom === (string)$r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?><option value="none" <?= $fRoom === 'none' ? 'selected' : '' ?>>Xonasizlar</option></select><?php endif; ?>
      <select name="pr" aria-label="Varaq holati"><option value="">Varaq: hammasi</option><option value="new" <?= $fPr === 'new' ? 'selected' : '' ?>>chop etilmagan</option><option value="done" <?= $fPr === 'done' ? 'selected' : '' ?>>chop etilgan</option></select>
      <select name="o" title="Ro'yxat va varaqlar shu tartibda chiqadi"><?php foreach (array_filter(['room' => $rooms ? 'Tartib: xona va o\'rin' : null, 'name' => 'Tartib: alifbo', 'school' => 'Tartib: maktab / sinf', 'time' => 'Tartib: qo\'shilgan vaqt']) as $k => $lbl): ?><option value="<?= $k ?>" <?= $fO === $k ? 'selected' : '' ?>><?= $lbl ?></option><?php endforeach; ?></select>
      <button class="btn sm">Qidirish</button>
      <span id="regClear"><?php if ($filtered): ?><a class="small" href="<?= e(url('registrations', ['id' => $tid] + ($fO !== ($rooms ? 'room' : 'name') ? ['o' => $fO] : []))) ?>">× Filtrni tozalash</a><?php endif; ?></span>
    </form>

    <div id="regResults">
    <form method="post" id="regMass" class="reg-bar-wrap">
      <?= csrf_field() ?><input type="hidden" name="action" value="mass">
      <div class="mass-bar card soft reg-bar">
        <label class="check"><input type="checkbox" id="checkAll"<?= $list ? '' : ' disabled' ?>> Barchasi</label>
        <span class="small" id="selCount"><b>0</b> ta belgilangan</span>
        <button type="button" class="btn sm primary" id="printSel" disabled data-url="<?= e($sheetUrl(['order' => $fO])) ?>" data-all-url="<?= e($filterSheetUrl) ?>"><?= icon('print', 14) ?>Belgilanganlarni chop etish</button>
        <?php if ($list): ?><a class="btn sm" target="_blank" href="<?= e($filterSheetUrl) ?>"><?= icon('print', 14) ?><?= $filtered ? 'Filtrdagilarni' : 'Hammasini' ?> chop etish (<?= count($list) ?>)</a><?php endif; ?>
        <span class="bar-ops">
        <select name="op" id="regOp" aria-label="Belgilanganlar bilan amal">
          <?php if ($rooms): ?><option value="room">Xonaga o'tkazish</option><?php endif; ?>
          <option value="printed">"Chop etilgan" deb belgilash</option>
          <option value="unprinted">Qayta chop etishga belgilash</option>
          <option value="remove">Ro'yxatdan chiqarish</option>
        </select>
        <?php if ($rooms): ?><select name="to_room" class="op-room" aria-label="Qaysi xonaga"><?php foreach ($rooms as $r): ?><option value="<?= (int)$r['id'] ?>"><?= e($r['name']) ?></option><?php endforeach; ?><option value="0">— xonasiz —</option></select><?php endif; ?>
        <button class="btn sm" id="massDo" disabled onclick="return document.getElementById('regOp').value!=='remove' || confirm('Belgilanganlar ro\'yxatdan chiqarilsinmi?')">Bajarish</button>
        </span>
      </div>
    </form>
    <p class="small muted reg-hint">Qatorni bosib belgilang. <b>Shift</b> bosib turib ikkinchi qatorni bossangiz — oradagilarning hammasi belgilanadi.</p>
    <div class="table-wrap"><table class="tbl reg-tbl">
      <thead><tr><th></th><th>ID</th><th>F.I.Sh</th><th>Telefon</th><?php if ($rooms): ?><th>Xona · o'rin</th><?php endif; ?><th>Varaq</th><th>Holat</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($list as $s): $sid = (int)$s['id']; $rs = $resp[$sid] ?? null; $sub = implode(' · ', array_filter([$s['group_name'], $s['school'], $s['grade_level']], fn($v) => $v !== '')); ?>
        <tr>
          <td><input type="checkbox" name="ids[]" value="<?= $sid ?>" class="rowchk" form="regMass" aria-label="Belgilash"></td>
          <td class="mono"><?= e($s['code']) ?></td>
          <td><?= e($s['full_name']) ?><?php if ($sub !== ''): ?><div class="small muted"><?= e($sub) ?></div><?php endif; ?></td>
          <td class="nowrap small"><?= e($s['phone'] ? fmt_phone($s['phone']) : '—') ?></td>
          <?php if ($rooms): ?>
          <td class="nowrap">
            <form method="post" class="inline room-cell filter"><?= csrf_field() ?><input type="hidden" name="action" value="move"><input type="hidden" name="sid" value="<?= $sid ?>">
              <select name="room" onchange="this.form.submit()" title="Boshqa xonaga o'tkazish"><option value="0">—</option><?php foreach ($rooms as $r): ?><option value="<?= (int)$r['id'] ?>" <?= (int)$s['room_id'] === (int)$r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?></select>
              <?php if ($s['seat']): ?><b class="seat">· <?= (int)$s['seat'] ?></b><?php if ($s['notified_at']): ?> <span class="tag green" title="Xona/o'rin haqida xabar yuborilgan: <?= e($s['notified_at']) ?>">✉</span><?php endif; ?><?php endif; ?>
            </form></td>
          <?php endif; ?>
          <td class="nowrap small"><?= $s['printed_at'] ? '<span class="tag green" title="' . e($s['printed_at']) . '">✓ ' . e(date('d.m', strtotime($s['printed_at']))) . '</span>' : '<span class="tag">yangi</span>' ?></td>
          <td><?= $rs === 'submitted' ? '<span class="tag green">topshirdi</span>' : ($rs ? '<span class="tag amber">jarayonda</span>' : '<span class="tag">kutilmoqda</span>') ?></td>
          <td class="right nowrap">
            <a class="btn sm ghost" target="_blank" title="Shu o'quvchining varag'ini chop etish" href="<?= e($sheetUrl(['sid' => $sid])) ?>"><?= icon('print', 14) ?></a>
            <form method="post" class="inline" onsubmit="return confirm('Ro\'yxatdan chiqarilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="remove"><input type="hidden" name="sid" value="<?= $sid ?>"><button class="btn sm danger-ghost">×</button></form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$list): ?><tr><td colspan="8" class="empty"><?= $N ? 'Filtrga mos o\'quvchi yo\'q' : 'Hali hech kim ro\'yxatdan o\'tmagan' ?></td></tr><?php endif; ?>
      </tbody>
    </table></div>
    </div>
  </div>

</div>
<script>
(function(){
  // Ro'yxatdagilar: belgilash (qatorni bosish, Shift bilan oraliq), belgilanganlarni chop etish.
  // Filtr sahifani qayta yuklamaydi — faqat jadval almashtiriladi, shuning uchun hodisalar hujjat darajasida ushlanadi.
  const $ = s => document.querySelector(s);
  const boxes = () => [...document.querySelectorAll('.rowchk')];
  let last = null;
  const upd = () => {
    const bx = boxes(), n = bx.filter(b => b.checked).length, all = $('#checkAll'), pb = $('#printSel'), db = $('#massDo'), cnt = $('#selCount');
    bx.forEach(b => b.closest('tr').classList.toggle('sel', b.checked));
    if (cnt) cnt.innerHTML = '<b>' + n + '</b> ta belgilangan';
    if (pb) { pb.disabled = n === 0; pb.lastChild.textContent = n ? 'Belgilanganlarni chop etish (' + n + ')' : 'Belgilanganlarni chop etish'; }
    if (db) db.disabled = n === 0;
    if (all) { all.checked = n > 0 && n === bx.length; all.indeterminate = n > 0 && n < bx.length; }
  };
  const roomOp = () => { const op = $('#regOp'), rs = $('.op-room'); if (op && rs) rs.hidden = op.value !== 'room'; };
  const setRange = (to, state) => {
    const bx = boxes(), a = bx.indexOf(last), b = bx.indexOf(to);
    if (a < 0 || b < 0) return;
    bx.slice(Math.min(a, b), Math.max(a, b) + 1).forEach(x => x.checked = state);
  };
  document.addEventListener('change', e => {
    if (e.target.id === 'checkAll') { boxes().forEach(b => b.checked = e.target.checked); upd(); }
    if (e.target.id === 'regOp') roomOp();
  });
  document.addEventListener('click', e => {
    const t = e.target;
    if (t.classList && t.classList.contains('rowchk')) {          // katakchaning o'zi (Shift bilan — oraliq)
      if (e.shiftKey && last) setRange(t, t.checked);
      last = t; upd(); return;
    }
    const pb = t.closest && t.closest('#printSel');
    if (pb) {
      const bx = boxes(), ids = bx.filter(b => b.checked).map(b => b.value);
      if (!ids.length) return;
      // Hammasi belgilangan bo'lsa — filtr bo'yicha (manzil qisqa qoladi), aks holda belgilangan ID lar bo'yicha
      window.open(ids.length === bx.length ? pb.dataset.allUrl : pb.dataset.url + '&sids=' + ids.join(','), '_blank');
      return;
    }
    const tr = t.closest && t.closest('.reg-tbl tbody tr');       // qatorning bo'sh joyi
    if (!tr || t.closest('input, select, button, a, label, form')) return;
    const cb = tr.querySelector('.rowchk'); if (!cb) return;
    if (e.shiftKey && last) { window.getSelection && window.getSelection().removeAllRanges(); setRange(cb, !cb.checked); }
    else cb.checked = !cb.checked;
    last = cb; upd();
  });

  // --- Jonli filtr: sahifa yangilanmaydi va joyidan siljimaydi ---
  const ff = $('#regFilter');
  let ctl = null, timer = null;
  const formUrl = () => {
    const q = new URLSearchParams();
    for (const [k, v] of new FormData(ff)) if (String(v).trim() !== '') q.set(k, String(v).trim());
    return 'index.php?' + q.toString();
  };
  async function load(url) {
    if (ctl) ctl.abort();
    ctl = new AbortController();
    const box = $('#regResults'); box.classList.add('is-loading');
    try {
      const html = await fetch(url, { signal: ctl.signal, credentials: 'same-origin' }).then(r => { if (!r.ok) throw new Error(r.status); return r.text(); });
      const doc = new DOMParser().parseFromString(html, 'text/html');
      if (!doc.querySelector('#regResults')) throw new Error('javob noto\'g\'ri');   // masalan, sessiya tugagan
      ['#regResults', '#regCount', '#regClear'].forEach(sel => { const n = doc.querySelector(sel), o = $(sel); if (n && o) o.replaceWith(document.importNode(n, true)); });
      history.replaceState(null, '', url);
      last = null; roomOp(); upd();
    } catch (err) {
      if (err.name !== 'AbortError') location.href = url;           // xato bo'lsa — oddiy usulda ochamiz
    } finally {
      const b = $('#regResults'); if (b) b.classList.remove('is-loading');
    }
  }
  if (ff) {
    ff.addEventListener('submit', e => { e.preventDefault(); clearTimeout(timer); load(formUrl()); });
    ff.addEventListener('change', e => { if (e.target.tagName === 'SELECT') load(formUrl()); });
    ff.q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => load(formUrl()), 350); });
    document.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('#regClear a');
      if (!a) return;
      e.preventDefault();
      ff.q.value = '';
      ff.querySelectorAll('select').forEach(s => { if (s.name !== 'o') s.value = ''; });
      load(formUrl());
    });
  }

  // --- Amal bajarilgach (sahifa qayta yuklanadi) avvalgi joyga qaytish ---
  const KEY = 'regScroll:' + <?= $tid ?>;
  const save = () => { try { sessionStorage.setItem(KEY, JSON.stringify({ y: window.scrollY, t: Date.now() })); } catch (e) {} };
  document.addEventListener('submit', e => { if (e.target !== ff) save(); }, true);
  document.addEventListener('change', e => { if (e.target.closest && e.target.closest('form.room-cell')) save(); }, true);   // xona tanlovi o'zi yuboradi
  document.addEventListener('click', e => { if (e.target.closest && e.target.closest('a.keep-scroll')) save(); }, true);
  try {
    const v = JSON.parse(sessionStorage.getItem(KEY) || 'null');
    sessionStorage.removeItem(KEY);
    if (v && Date.now() - v.t < 20000 && v.y > 200) {
      // Tepadagi xabarni ko'rinadigan joyga — pastki burchakka chiqaramiz (avval ko'chiramiz, keyin scroll — sahifa siljimasligi uchun)
      const msgs = [...document.querySelectorAll('main > .alert')];
      if (msgs.length) {
        const wrap = document.createElement('div'); wrap.className = 'flash-toast';
        msgs.forEach(m => wrap.appendChild(m));
        document.body.appendChild(wrap);
        setTimeout(() => wrap.classList.add('hide'), 4500);
        setTimeout(() => wrap.remove(), 5200);
        wrap.addEventListener('click', () => wrap.remove());
      }
      window.scrollTo(0, v.y);
    }
  } catch (e) {}

  roomOp(); upd();
})();
(function(){
  // Ro'yxatga kiritilmaganlar bo'limi: belgilash
  const all = document.getElementById('unAll'), cnt = document.getElementById('unCount');
  if (!all) return;
  const boxes = () => [...document.querySelectorAll('.unchk')];
  const upd = () => { cnt.textContent = boxes().filter(b => b.checked).length + ' ta tanlangan'; };
  all.addEventListener('change', () => { boxes().forEach(b => b.checked = all.checked); upd(); });
  boxes().forEach(b => b.addEventListener('change', upd));
})();
</script>
<?php page_footer();
