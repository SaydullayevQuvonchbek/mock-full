<?php
defined('APP_ROOT') || exit;
/**
 * PDF (yoki rasm) dan savollarni qirqib bo'limga yuklash. Qirqish brauzerda bajariladi (pdf.js), serverga tayyor PNG rasmlar yuboriladi.
 * 2.4: bo'lim darajasi avtomatik, bet oralig'i, savol raqami bo'yicha bo'lish, sahifada tekshirish (bosib belgilash, chizib qo'shish).
 */
$sid = (int)($_GET['s'] ?? 0);
$sec = $sid ? row('SELECT * FROM qb_sections WHERE id=?', [$sid]) : null;
$tree = qb_tree();
if (!$sec) {
    if (!$tree) { flash('Avval bo\'lim yarating', 'warn'); redirect('qb'); }
    $sid = (int)$tree[0]['id'];
    $sec = row('SELECT * FROM qb_sections WHERE id=?', [$sid]);
}
$have = (int)val('SELECT COUNT(*) FROM qb_questions WHERE section_id=?', [$sid]);
$secLv = [];
$secCnt = [];
foreach ($tree as $s) { $secLv[(int)$s['id']] = (int)$s['level']; $secCnt[(int)$s['id']] = (int)$s['own']; }
$lvSec = (int)$sec['level'];
page_header('PDF dan yuklash — ' . $sec['name']);
?>
<div class="page-head">
  <div>
    <?= crumbs([['Savollar bazasi', url('qb')], [$sec['name'], url('qb_questions', ['s' => $sid])], 'PDF dan yuklash']) ?>
    <h1>PDF dan savol yuklash</h1>
    <p class="muted">Faylni tanlang — savollar avtomatik qirqiladi, sahifaning o'zida tekshirib, yuklaysiz. Hammasi brauzeringizda bajariladi, faqat tayyor rasmlar serverga yuboriladi.</p>
  </div>
</div>

<div class="card qb-imp">
  <div class="grid2">
    <div class="form">
      <label>Bo'lim
        <select id="qbSec"><?php foreach ($tree as $s): ?><option value="<?= $s['id'] ?>" <?= (int)$s['id'] === $sid ? 'selected' : '' ?>><?= str_repeat('— ', $s['depth']) . e($s['name']) ?></option><?php endforeach; ?></select>
        <span class="small muted" id="qbHave">Hozir bu bo'limda <?= $have ?> ta savol bor — yangilari oxiriga qo'shiladi.</span></label>
      <div class="qb-lvfixed" id="qbLvFixed" <?= $lvSec ? '' : 'hidden' ?>>Qiyinlik: <span id="qbLvTag"><?= qb_section_level_tag($lvSec) ?></span> <span class="small muted">— bo'lim darajasi, barcha savollarga qo'yiladi</span></div>
      <label id="qbLvPick" <?= $lvSec ? 'hidden' : '' ?>>Qiyinlik darajasi <span class="small muted">— bo'lim «aralash»: shu yuklanadiganlarga</span>
        <select id="qbLevel"><option value="">— tanlang —</option><?php foreach (QB_LEVELS as $k => $nm): ?><option value="<?= $k ?>"><?= e($nm) ?></option><?php endforeach; ?></select></label>
      <label>Fayl (PDF, PNG yoki JPG)
        <input type="file" id="qbFile" accept="application/pdf,.pdf,image/png,image/jpeg" multiple></label>
      <div class="qb-range" id="qbRange" hidden>
        <label>Betlar<span class="row gap center-v"><input type="number" id="qbFrom" min="1" value="1" aria-label="Qaysi betdan"><span>–</span><input type="number" id="qbTo" min="1" value="1" aria-label="Qaysi betgacha"></span></label>
        <span class="small muted" id="qbPages"></span>
      </div>
      <div class="grid2">
        <label>Savol turi
          <select id="qbKind"><option value="mc4">Test: A, B, C, D</option><option value="mc6">Test: A–F (6 variant)</option><option value="open">Ochiq javobli</option></select></label>
        <label>Javoblar kaliti <span class="muted small">(ixtiyoriy)</span>
          <input id="qbKey" placeholder="ACDBBADC… yoki 1:A 2:C 3:12" autocomplete="off" spellcheck="false"></label>
      </div>
    </div>
    <div class="form">
      <div class="qb-how small">
        <b>Qanday qirqiladi</b>
        <ol>
          <li>PDF da savol raqamlari («7.», «12)») bo'lsa — har savol o'z raqamidan keyingisigacha olinadi; bo'lmasa — savollar orasidagi bo'sh joy bo'yicha.</li>
          <li>Ikki ustunli betlar o'zi aniqlanadi; bet sarlavhasi va bet raqami tashlab ketiladi.</li>
          <li>Natijani <b>sahifaning o'zida</b> ko'rasiz: noto'g'ri bo'lakni bosib o'chirasiz, kerakli joyni sichqoncha bilan chizib qo'shasiz.</li>
        </ol>
      </div>
      <details class="qb-adv" id="qbAdv">
        <summary>Qo'shimcha sozlamalar</summary>
        <fieldset><legend>Usul</legend>
          <label class="check"><input type="radio" name="qbMode" value="auto" checked> Avtomatik — savol raqami va bo'sh joy bo'yicha</label>
          <label class="check"><input type="radio" name="qbMode" value="page"> Har bir bet — bitta savol</label>
          <label class="check"><input type="radio" name="qbMode" value="manual"> Faqat qo'lda — betda chizib qirqaman</label>
        </fieldset>
        <div class="grid2 qb-iopts">
          <label>Ustunlar<select id="qbCols"><option value="0">Avtomatik</option><option value="1">1 ustun</option><option value="2">2 ustun (chap, keyin o'ng)</option></select></label>
          <label>Savollar orasidagi bo'sh joy, px<input type="number" id="qbGap" min="4" max="120" placeholder="avtomatik"></label>
          <label>Yuqori chet, %<input type="number" id="qbTop" value="0" min="0" max="30"></label>
          <label>Pastki chet, %<input type="number" id="qbBot" value="0" min="0" max="30"></label>
        </div>
        <label class="check"><input type="checkbox" id="qbNumSplit" checked> Savol raqami bo'yicha bo'lish <span class="muted small">(PDF matnida raqamlar bo'lsa)</span></label>
        <label class="check"><input type="checkbox" id="qbStrip" checked> Savol raqamini rasmdan olib tashlash <span class="muted small">(o'quvchiga saytning o'z tartib raqami ko'rinadi)</span></label>
        <p class="small muted">«Bo'sh joy» — raqamsiz (skaner qilingan) betlar uchun; bo'sh qoldirilsa o'zi aniqlanadi. Kichik son — savol bo'laklarga bo'linadi, katta — ikki savol qo'shilib qoladi.</p>
      </details>
    </div>
  </div>
  <div class="row gap wrap center-v">
    <button type="button" class="btn primary" id="qbGo" disabled><?= icon('scan', 16) ?>Qirqish</button>
    <span id="qbStatus" class="muted small" role="status"></span>
  </div>
</div>

<div class="card qb-view" id="qbView" hidden>
  <div class="card-head"><h3>Sahifada tekshirish</h3>
    <div class="row gap center-v wrap">
      <button type="button" class="btn sm ghost qb-draw-btn" id="qbDraw" aria-pressed="false" title="Sensorli ekranda: yoqilsa — barmoq bilan chiziladi, o'chirilsa — bet suriladi">✏️ Chizish</button>
      <button type="button" class="btn sm" id="qbPrev" aria-label="Oldingi bet">←</button>
      <select id="qbPageSel" class="sel-sm" aria-label="Bet"></select>
      <button type="button" class="btn sm" id="qbNext" aria-label="Keyingi bet">→</button>
    </div></div>
  <p class="small muted qb-legend"><span class="qb-key on"></span> yuklanadi · <span class="qb-key off"></span> yuklanmaydi · <span class="qb-key note"></span> savol boshi topilmadi — oldingi savol davomi bo'lsa, ro'yxatda «↑ oldingisiga qo'shish» ni bosing. <b>Bosing</b> — belgini almashtiradi; <b>bo'sh joyda chizing</b> — yangi savol qo'shiladi.</p>
  <div class="qb-viewer" id="qbViewer"><canvas id="qbCanvas"></canvas><div class="qb-ov" id="qbOv"></div><div id="qbSel" class="qb-selbox" hidden></div></div>
</div>

<div class="card" id="qbPieces" hidden>
  <div class="card-head"><h3>Qirqilgan savollar: <span id="qbCount">0</span> <span class="muted small" id="qbSelCount"></span></h3>
    <div class="row gap center-v wrap">
      <button type="button" class="btn sm ghost" id="qbAll">Hammasini belgilash</button>
      <button type="button" class="btn sm ghost" id="qbNone">Belgini olib tashlash</button>
      <button type="button" class="btn primary" id="qbUpload"><?= icon('upload', 16) ?>Tanlanganlarni yuklash</button></div></div>
  <progress id="qbProg" value="0" max="1" hidden style="width:100%"></progress>
  <div id="qbMsg" class="small" role="status"></div>
  <div class="qb-grid" id="qbGrid"></div>
</div>
<script>window.QB = <?= json_encode(['api' => url('qb_api'), 'list' => url('qb_questions', ['s' => '__S__']), 'pdfjs' => 'assets/pdfjs/pdf.min.js?v=3.11.174', 'worker' => 'assets/pdfjs/pdf.worker.min.js?v=3.11.174',
    'levels' => QB_LEVELS, 'secLevels' => (object)$secLv, 'secCounts' => (object)$secCnt], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;</script>
<?php page_footer(['assets/qb_strip.js', 'assets/qb_import.js']);
