<?php
defined('APP_ROOT') || exit;
/** Bo'limdagi savollar: rasm, turi, javob kaliti; tezkor kalit kiritish, ko'chirish, o'chirish */
$sid = (int)($_GET['s'] ?? $_POST['s'] ?? 0);
$sec = $sid ? row('SELECT * FROM qb_sections WHERE id=?', [$sid]) : null;
if (!$sec) { flash('Bo\'lim topilmadi', 'err'); redirect('qb'); }

$own = fn() => rows('SELECT * FROM qb_questions WHERE section_id=? ORDER BY sort, id', [$sid]);
$lvIn = is_string($_GET['lv'] ?? null) ? $_GET['lv'] : (is_string($_POST['lvf'] ?? null) ? $_POST['lvf'] : '');
$lvf = in_array($lvIn, ['0', '1', '2', '3'], true) ? (int)$lvIn : null;   // daraja filtri
/** O'quvchilar javoblari bo'yicha: [question_id => [javoblar, to'g'ri]] (yakunlangan mashq va topshiriqlar) */
$qstats = function (array $list): array {
    $st = [];
    $ids = array_map(fn($r) => (int)$r['id'], $list);
    foreach (array_chunk($ids, 500) as $ch) {
        $in = implode(',', array_fill(0, count($ch), '?'));
        foreach (rows("SELECT i.question_id, SUM(i.ok IS NOT NULL) n, SUM(i.ok=1) k FROM qb_items i JOIN qb_tests t ON t.id=i.test_id WHERE t.status='done' AND i.question_id IN ($in) GROUP BY i.question_id", $ch) as $r)
            $st[(int)$r['question_id']] = [(int)$r['n'], (int)$r['k']];
    }
    return $st;
};

if (is_post()) {
    csrf_check();
    $a = (string)($_POST['action'] ?? '');
    if (!empty($_POST['mv']) && preg_match('/^([ud])(\d+)$/', (string)$_POST['mv'], $mv)) $a = 'move_' . $mv[1];
    $list = $own();
    $byId = [];
    foreach ($list as $r) $byId[(int)$r['id']] = $r;
    $sel = array_values(array_filter(array_map('intval', (array)($_POST['sel'] ?? [])), fn($i) => isset($byId[$i])));

    // joriy sahifadagi tahrirlarni saqlash (↑/↓ bosilganda ham tahrirlar yo'qolmasin)
    $saveEdits = function () use ($byId) {
        $n = 0; $bad = 0;
        foreach ($byId as $id => $r) {
            if (!isset($_POST['kind'][$id])) continue;
            $kind = $_POST['kind'][$id] === 'open' ? 'open' : 'mc';
            $nopt = (int)($_POST['nopt'][$id] ?? 4) === 6 ? 6 : 4;
            $ans = qb_clean_answer($kind, $nopt, (string)($_POST['ans'][$id] ?? ''));
            if ($ans === null) { $bad++; $ans = ''; }
            $label = mb_substr(trim((string)($_POST['label'][$id] ?? '')), 0, 40);
            $lvl = isset($_POST['lv'][$id]) ? (int)$_POST['lv'][$id] : (int)$r['level'];
            if (!isset(QB_LEVELS[$lvl])) $lvl = 0;
            if ($kind !== $r['kind'] || $nopt !== (int)$r['nopt'] || $ans !== (string)$r['answer'] || $label !== (string)$r['label'] || $lvl !== (int)$r['level']) {
                q('UPDATE qb_questions SET kind=?, nopt=?, answer=?, label=?, level=? WHERE id=?', [$kind, $nopt, $ans, $label, $lvl, $id]);
                $n++;
            }
        }
        return [$n, $bad];
    };
    if ($a === 'save') {
        [$n, $bad] = $saveEdits();
        flash($n . ' ta savol yangilandi' . ($bad ? ' · ' . $bad . ' ta noto\'g\'ri javob (A–D/A–F bo\'lishi kerak) bo\'sh qoldirildi' : ''), $bad ? 'warn' : 'ok');
    } elseif ($a === 'quick') {
        $key = qb_parse_key((string)($_POST['key'] ?? ''));
        $n = 0; $bad = [];
        foreach ($list as $i => $r) {
            if (!isset($key[$i + 1])) continue;
            $v = qb_clean_answer((string)$r['kind'], (int)$r['nopt'], (string)$key[$i + 1]);
            if ($v === null) { $bad[] = $i + 1; continue; }
            q('UPDATE qb_questions SET answer=? WHERE id=?', [$v, $r['id']]);
            $n++;
        }
        $extra = max(0, count($key) ? max(array_keys($key)) - count($list) : 0);
        flash($n . ' ta javob kiritildi' . ($bad ? ' · noto\'g\'ri: ' . implode(', ', array_slice($bad, 0, 12)) . '-savol' : '') . ($extra ? ' · kalitda ' . $extra . ' ta ortiqcha javob bor (savollar soni ' . count($list) . ')' : ''), ($bad || $extra) ? 'warn' : 'ok');
    } elseif ($a === 'delete') {
        foreach ($sel as $id) qb_delete_question($id);
        flash(count($sel) . ' ta savol o\'chirildi');
    } elseif ($a === 'move') {
        $to = (int)($_POST['to'] ?? 0);
        if (!$sel) flash('Savollarni belgilang', 'err');
        elseif (!$to || !row('SELECT 1 FROM qb_sections WHERE id=?', [$to])) flash('Qaysi bo\'limga ko\'chirish kerakligini tanlang', 'err');
        else {
            $sort = (int)val('SELECT COALESCE(MAX(sort),0) FROM qb_questions WHERE section_id=?', [$to]);
            foreach ($sel as $id) q('UPDATE qb_questions SET section_id=?, sort=? WHERE id=?', [$to, ++$sort, $id]);
            flash(count($sel) . ' ta savol ko\'chirildi: ' . qb_section_path($to));
        }
    } elseif ($a === 'setkind') {
        $v = (string)($_POST['kindset'] ?? '');
        if (!$sel || !in_array($v, ['mc4', 'mc6', 'open'], true)) flash('Savollarni belgilab, turini tanlang', 'err');
        else {
            foreach ($sel as $id) q('UPDATE qb_questions SET kind=?, nopt=?, answer="" WHERE id=?', [$v === 'open' ? 'open' : 'mc', $v === 'mc6' ? 6 : 4, $id]);
            flash(count($sel) . ' ta savol turi o\'zgartirildi (javoblari tozalandi — kalitni qayta kiriting)', 'warn');
        }
    } elseif ($a === 'setlevel') {
        $v = (int)($_POST['lvset'] ?? -1);
        if (!$sel || ($v !== 0 && !isset(QB_LEVELS[$v]))) flash('Savollarni belgilab, darajani tanlang', 'err');
        else {
            $saveEdits();   // sahifadagi boshqa tahrirlar yo'qolmasin
            foreach ($sel as $id) q('UPDATE qb_questions SET level=? WHERE id=?', [$v, $id]);
            flash(count($sel) . ' ta savolga daraja qo\'yildi: ' . qb_level_name($v));
        }
    } elseif ($a === 'fromsec' && (int)$sec['level'] > 0) {   // 2.4: darajasi belgilanmaganlarga — bo'lim darajasi
        $n = q('UPDATE qb_questions SET level=? WHERE section_id=? AND level=0', [(int)$sec['level'], $sid])->rowCount();
        flash($n . ' ta savolga bo\'lim darajasi qo\'yildi: ' . qb_level_name((int)$sec['level']));
    } elseif ($a === 'autolevel') {   // darajasi belgilanmaganlarga — o'quvchilar natijasiga qarab
        $none = array_values(array_filter($list, fn($r) => (int)$r['level'] === 0));
        $st = $qstats($none);
        $set = [1 => 0, 2 => 0, 3 => 0]; $few = 0;
        foreach ($none as $r) {
            [$n, $k] = $st[(int)$r['id']] ?? [0, 0];
            $lv = qb_level_from_stats($n, $k);
            if (!$lv) { $few++; continue; }
            q('UPDATE qb_questions SET level=? WHERE id=? AND level=0', [$lv, $r['id']]);
            $set[$lv]++;
        }
        $tot = array_sum($set);
        flash(($tot ? $tot . ' ta savolga daraja qo\'yildi (oson ' . $set[1] . ', o\'rta ' . $set[2] . ', qiyin ' . $set[3] . ')' : 'Daraja qo\'yilmadi')
            . ($few ? ' · ' . $few . ' tasida ma\'lumot yetarli emas (kamida 8 ta javob kerak) — ularni o\'zingiz belgilang' : ''), $tot ? 'ok' : 'warn');
    } elseif ($a === 'move_u' || $a === 'move_d') {
        $saveEdits();
        $ids = array_keys($byId);
        $i = array_search((int)$mv[2], $ids, true);
        $j = $a === 'move_u' ? $i - 1 : $i + 1;
        if ($i !== false && isset($ids[$j])) { [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]]; foreach ($ids as $k => $qid) q('UPDATE qb_questions SET sort=? WHERE id=?', [$k + 1, $qid]); }
    }
    redirect('qb_questions', ['s' => $sid, 'pg' => max(1, (int)($_POST['pg'] ?? 1))] + ($lvf !== null ? ['lv' => $lvf] : []));
}

$all = $own();
$lvCnt = [0 => 0, 1 => 0, 2 => 0, 3 => 0];
foreach ($all as $r) $lvCnt[isset($lvCnt[(int)$r['level']]) ? (int)$r['level'] : 0]++;
$shown = $lvf === null ? $all : array_filter($all, fn($r) => (int)$r['level'] === $lvf);   // kalitlar — umumiy tartib raqamlari saqlanadi
$PER = 80;
$pages = max(1, (int)ceil(count($shown) / $PER));
$pg = max(1, min($pages, (int)($_GET['pg'] ?? 1)));
$list = array_slice($shown, ($pg - 1) * $PER, $PER, true);   // kalitlar — umumiy tartib raqamlari (0 dan)
$stats = $qstats($list);
$qp = fn(array $x = []) => url('qb_questions', array_merge(['s' => $sid], $lvf !== null ? ['lv' => $lvf] : [], $x));
$children = rows('SELECT id, name FROM qb_sections WHERE parent_id=? ORDER BY sort, name', [$sid]);
$ready = 0;
foreach ($all as $r) if ((string)$r['answer'] !== '') $ready++;
$allSecs = qb_tree();
page_header('Savollar — ' . $sec['name']);
?>
<div class="page-head">
  <div>
    <?= crumbs([['Savollar bazasi', url('qb')], qb_section_path($sid)]) ?>
    <h1><?= e($sec['name']) ?></h1>
    <p class="muted"><?= count($all) ?> ta savol, kalitli: <b><?= $ready ?></b><?= count($all) > $ready ? ' · <span class="critical-t">' . (count($all) - $ready) . ' tasida kalit yo\'q</span>' : '' ?> · bo'lim darajasi: <?= qb_section_level_tag((int)$sec['level']) ?> <a class="small" href="<?= e(url('qb')) ?>#s<?= $sid ?>" title="Bo'limlar ro'yxatida «⋯» orqali o'zgartiriladi">o'zgartirish</a></p>
    <?php if ($all): ?>
    <nav class="lv-filter" aria-label="Daraja bo'yicha filtr">
      <a class="chip<?= $lvf === null ? ' on' : '' ?>" href="<?= e(url('qb_questions', ['s' => $sid])) ?>">Hammasi <b><?= count($all) ?></b></a>
      <?php foreach (QB_LEVELS as $k => $nm): ?><a class="chip c<?= $k ?><?= $lvf === $k ? ' on' : '' ?>" href="<?= e(url('qb_questions', ['s' => $sid, 'lv' => $k])) ?>"><?= e($nm) ?> <b><?= $lvCnt[$k] ?></b></a><?php endforeach; ?>
      <?php if ($lvCnt[0]): ?><a class="chip c0<?= $lvf === 0 ? ' on' : '' ?>" href="<?= e(url('qb_questions', ['s' => $sid, 'lv' => 0])) ?>">Darajasiz <b><?= $lvCnt[0] ?></b></a><?php endif; ?>
    </nav>
    <?php endif; ?>
  </div>
  <div class="row gap wrap">
    <a class="btn primary" href="<?= e(url('qb_import', ['s' => $sid])) ?>"><?= icon('upload', 16) ?>PDF dan yuklash</a>
    <?php if ($all): ?><a class="btn" target="_blank" href="<?= e(url('qb_pdf', ['s' => $sid, 'key' => 1])) ?>"><?= icon('download', 16) ?>PDF (kalit bilan)</a>
    <a class="btn ghost" target="_blank" href="<?= e(url('qb_pdf', ['s' => $sid])) ?>">PDF (kalitsiz)</a>
    <button type="button" class="btn ghost" id="qbFixBtn" data-api="<?= e(url('qb_api')) ?>" title="Rasmlardagi «7.», «12)» kabi savol raqamlarini topib olib tashlaydi — saqlashdan oldin ko'rsatadi">✂ Savol raqamlarini olib tashlash</button><?php endif; ?>
  </div>
</div>

<?php if ($lvCnt[0] && $all): ?>
<div class="alert warn"><?= icon('alert') ?><span><b><?= $lvCnt[0] ?> ta savolning qiyinlik darajasi belgilanmagan.</b> Topshiriqni daraja bo'yicha tuzganda ular olinmaydi. Har savol yonidagi «Daraja» ustunida tanlang, belgilab «Darajani qo'yish» bilan bir yo'la qo'ying yoki o'quvchilar natijasiga qarab avtomatik taklif qiling.</span>
  <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="s" value="<?= $sid ?>"><input type="hidden" name="pg" value="<?= $pg ?>"><?php if ($lvf !== null): ?><input type="hidden" name="lvf" value="<?= $lvf ?>"><?php endif; ?>
    <?php if ((int)$sec['level'] > 0): ?><button class="btn sm" name="action" value="fromsec">Bo'lim darajasini qo'yish (<?= e(qb_level_name((int)$sec['level'])) ?>)</button><?php endif; ?>
    <button class="btn sm" name="action" value="autolevel" title="Kamida 8 marta yechilgan savollar: 70%+ to'g'ri — oson, 40–69% — o'rta, pastroq — qiyin. Qo'lda qo'yilgan darajalar o'zgarmaydi.">Natijalar bo'yicha taklif qilish</button></form></div>
<?php endif; ?>

<?php if ($children): ?><p class="small">Ichki bo'limlar: <?php foreach ($children as $c): ?><a class="tag blue" href="<?= e(url('qb_questions', ['s' => $c['id']])) ?>"><?= e($c['name']) ?></a><?php endforeach; ?></p><?php endif; ?>

<?php if (!$all): ?>
  <div class="card empty">Bu bo'limda hali savol yo'q. <a href="<?= e(url('qb_import', ['s' => $sid])) ?>">PDF dan yuklash →</a></div>
<?php else: ?>

<?php if ($lvf === null): ?>
<div class="card">
  <form method="post" class="form row gap wrap qb-quick"><?= csrf_field() ?><input type="hidden" name="s" value="<?= $sid ?>"><input type="hidden" name="pg" value="<?= $pg ?>"><input type="hidden" name="action" value="quick"><?php if ($lvf !== null): ?><input type="hidden" name="lvf" value="<?= $lvf ?>"><?php endif; ?>
    <label style="flex:1 1 320px">Tezkor kalit kiritish <span class="muted small">— savollar tartibida: <code>ACDBBAD…</code> yoki <code>1:A 2:C 3:12 4:0.5;1/2</code></span>
      <input name="key" placeholder="ACDBBADC…" autocomplete="off" spellcheck="false"></label>
    <label>&nbsp;<button class="btn primary">Kalitni qo'llash</button></label>
  </form>
</div>
<?php endif; ?>

<div class="card" id="qbFix" hidden>
  <div class="card-head"><h3>Savol raqamlarini olib tashlash</h3><button type="button" class="btn primary" id="qbFixSave" hidden>Saqlash</button></div>
  <p id="qbFixMsg" class="small" role="status"></p>
  <div id="qbFixGrid" class="qb-fix-grid"></div>
</div>

<?php if ($pages > 1): ?><p class="small qb-pages">Sahifa: <?php for ($i = 1; $i <= $pages; $i++): ?><a class="tag <?= $i === $pg ? 'blue' : '' ?>" href="<?= e($qp(['pg' => $i])) ?>"><?= $i ?> (<?= ($i - 1) * $PER + 1 ?>–<?= min(count($shown), $i * $PER) ?>)</a><?php endfor; ?></p><?php endif; ?>
<?php if ($lvf !== null): ?><p class="small muted">Faqat «<?= e(qb_level_name($lvf)) ?>» savollar ko'rsatilmoqda (<?= count($shown) ?> ta). Raqamlar — bo'limdagi umumiy tartib raqami. <a href="<?= e(url('qb_questions', ['s' => $sid])) ?>">Hammasini ko'rsatish</a></p><?php endif; ?>
<?php if (!$shown): ?><div class="card empty">Bu darajada savol yo'q.</div><?php endif; ?>
<form method="post" class="card qb-list" <?= $shown ? '' : 'hidden' ?>><?= csrf_field() ?><input type="hidden" name="s" value="<?= $sid ?>"><input type="hidden" name="pg" value="<?= $pg ?>"><?php if ($lvf !== null): ?><input type="hidden" name="lvf" value="<?= $lvf ?>"><?php endif; ?>
  <button type="submit" name="action" value="save" class="qb-defbtn" tabindex="-1" aria-hidden="true">Saqlash</button>
  <div class="table-wrap"><table class="tbl qb-qtbl">
    <thead><tr><th style="width:2rem"><input type="checkbox" aria-label="Hammasini belgilash" onclick="document.querySelectorAll('.qsel').forEach(c=>c.checked=this.checked)"></th><th class="num">№</th><th>Savol</th><th>Turi</th><th>Javob</th><th>Daraja</th><th class="num" title="Yakunlangan mashq va topshiriqlarda to'g'ri javob berganlar ulushi">Natija</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($list as $i => $r): $id = (int)$r['id']; ?>
      <tr class="<?= (string)$r['answer'] === '' ? 'qb-nokey' : '' ?>">
        <td><input class="qsel" type="checkbox" name="sel[]" value="<?= $id ?>" aria-label="Belgilash"></td>
        <td class="num"><b><?= $i + 1 ?></b></td>
        <?php $iu = url('qb_img', ['id' => $id, 'v' => substr((string)$r['img'], 1, 8)]); ?>
        <td><a href="<?= e($iu) ?>" target="_blank"><img class="qb-thumb" alt="Savol <?= $i + 1 ?>" data-id="<?= $id ?>" data-no="<?= $i + 1 ?>" src="<?= e($iu) ?>"></a>
          <input class="qb-label" name="label[<?= $id ?>]" value="<?= e($r['label']) ?>" maxlength="40" placeholder="izoh (ixtiyoriy)" aria-label="Izoh"></td>
        <td class="nowrap">
          <select name="kind[<?= $id ?>]" aria-label="Savol turi" onchange="this.closest('tr').querySelector('.nopt').style.display = this.value==='open' ? 'none' : ''">
            <option value="mc" <?= $r['kind'] === 'mc' ? 'selected' : '' ?>>Test</option><option value="open" <?= $r['kind'] === 'open' ? 'selected' : '' ?>>Ochiq</option></select>
          <select class="nopt" name="nopt[<?= $id ?>]" aria-label="Variantlar soni" style="<?= $r['kind'] === 'open' ? 'display:none' : '' ?>"><option value="4" <?= (int)$r['nopt'] === 4 ? 'selected' : '' ?>>A–D</option><option value="6" <?= (int)$r['nopt'] === 6 ? 'selected' : '' ?>>A–F</option></select>
        </td>
        <td><input class="qb-ans mono" name="ans[<?= $id ?>]" value="<?= e($r['answer']) ?>" maxlength="80" aria-label="Javob" autocomplete="off" placeholder="<?= $r['kind'] === 'open' ? 'javob; variant' : 'A' ?>"></td>
        <td><select class="lv-sel lvs<?= (int)$r['level'] ?>" name="lv[<?= $id ?>]" aria-label="Qiyinlik darajasi" onchange="this.className='lv-sel lvs'+this.value"><option value="0"<?= (int)$r['level'] === 0 ? ' selected' : '' ?>>—</option><?php foreach (QB_LEVELS as $k => $nm): ?><option value="<?= $k ?>"<?= (int)$r['level'] === $k ? ' selected' : '' ?>><?= e($nm) ?></option><?php endforeach; ?></select></td>
        <?php [$sn, $sk] = $stats[$id] ?? [0, 0]; $sp = $sn ? (int)round(100 * $sk / $sn) : null; ?>
        <td class="num nowrap"><?= $sp !== null ? '<span class="pct ' . pct_cls($sp) . '" title="' . $sk . ' / ' . $sn . ' to\'g\'ri">' . $sp . '%</span> <span class="muted small">' . $sn . ' ta</span>' : '<span class="muted small">—</span>' ?></td>
        <td class="nowrap"><?php if ($lvf === null): ?><button class="btn sm ghost" name="mv" value="u<?= $id ?>" title="Yuqoriga">↑</button><button class="btn sm ghost" name="mv" value="d<?= $id ?>" title="Pastga">↓</button><?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <div class="qb-bar row gap wrap center-v">
    <button class="btn primary" name="action" value="save">Saqlash</button>
    <span class="muted small">Belgilanganlar bilan:</span>
    <select name="to" aria-label="Ko'chirish"><option value="0">Ko'chirish…</option><?php foreach ($allSecs as $s): if ((int)$s['id'] === $sid) continue; ?><option value="<?= $s['id'] ?>"><?= str_repeat('— ', $s['depth']) . e($s['name']) ?></option><?php endforeach; ?></select>
    <button class="btn" name="action" value="move">Ko'chirish</button>
    <select name="kindset" aria-label="Turi"><option value="">Turini o'zgartirish…</option><option value="mc4">Test A–D</option><option value="mc6">Test A–F</option><option value="open">Ochiq javobli</option></select>
    <button class="btn" name="action" value="setkind">Qo'llash</button>
    <select name="lvset" aria-label="Daraja"><option value="-1">Darajani o'zgartirish…</option><?php foreach (QB_LEVELS as $k => $nm): ?><option value="<?= $k ?>"><?= e($nm) ?></option><?php endforeach; ?><option value="0">Belgilanmagan</option></select>
    <button class="btn" name="action" value="setlevel">Darajani qo'yish</button>
    <button class="btn danger-ghost" name="action" value="delete" onclick="return confirm('Belgilangan savollar o\'chirilsinmi?')">O'chirish</button>
  </div>
</form>
<?php endif; ?>
<?php page_footer($all ? ['assets/qb_strip.js', 'assets/qb_fix.js'] : []);
