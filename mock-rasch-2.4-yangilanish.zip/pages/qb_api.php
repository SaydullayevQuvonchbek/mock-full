<?php
defined('APP_ROOT') || exit;
/** Admin uchun JSON API: PDF dan qirqilgan rasmni qabul qilish (qb_import.js) */
if (!is_post()) json_out(['ok' => false, 'error' => 'POST kerak'], 405);
$tok = $_SERVER['HTTP_X_CSRF'] ?? ($_POST['_csrf'] ?? '');
if (!hash_equals(csrf_token(), (string)$tok)) json_out(['ok' => false, 'error' => 'Xavfsizlik tokeni eskirgan. Sahifani yangilang.'], 400);
$a = (string)($_POST['action'] ?? '');
if ($a === 'upload') {
    $f = $_FILES['img'] ?? null;
    if (!$f || ($f['error'] ?? 1) !== UPLOAD_ERR_OK) json_out(['ok' => false, 'error' => 'Rasm yuklanmadi (kod ' . (int)($f['error'] ?? -1) . ')'], 400);
    $kind = ($_POST['kind'] ?? 'mc') === 'open' ? 'open' : 'mc';
    $nopt = (int)($_POST['nopt'] ?? 4) === 6 ? 6 : 4;
    $level = (int)($_POST['level'] ?? 0);   // 2.3: qiyinlik darajasi (1 oson, 2 o'rta, 3 qiyin)
    [$id, $err] = qb_add_image((int)($_POST['section_id'] ?? 0), $f['tmp_name'], (string)($_POST['label'] ?? ''), (string)($_POST['src'] ?? ''), $kind, $nopt, isset(QB_LEVELS[$level]) ? $level : 0);
    if (!$id) json_out(['ok' => false, 'error' => $err], 400);
    $ans = qb_clean_answer($kind, $nopt, (string)($_POST['answer'] ?? ''));
    if ($ans !== null && $ans !== '') q('UPDATE qb_questions SET answer=? WHERE id=?', [$ans, $id]);
    json_out(['ok' => true, 'id' => $id, 'answer' => $ans ?? '']);
}
if ($a === 'replace') {   // savol rasmini almashtirish (raqamni olib tashlash)
    $f = $_FILES['img'] ?? null;
    if (!$f || ($f['error'] ?? 1) !== UPLOAD_ERR_OK) json_out(['ok' => false, 'error' => 'Rasm yuklanmadi'], 400);
    [$ok, $err] = qb_replace_image((int)($_POST['id'] ?? 0), $f['tmp_name']);
    json_out($ok ? ['ok' => true] : ['ok' => false, 'error' => $err], $ok ? 200 : 400);
}
json_out(['ok' => false, 'error' => 'Noma\'lum amal'], 400);
