<?php
defined('APP_ROOT') || exit;
$me = student();
$test = test_by_id((int)($_GET['id'] ?? 0));
if (!$test || !$test['published']) { flash('Natija hali e\'lon qilinmagan', 'warn'); redirect('student_home'); }
page_header('Natijam — ' . $test['title']);
?>
<div class="row between center-v wrap gap no-print">
  <?= crumbs([['Mening sahifam', url('student_home')], $test['title']]) ?>
  <button class="btn ghost" onclick="print()" title="Chop etish" aria-label="Chop etish"><?= icon('print', 16) ?><span class="hide-sm">Chop etish</span></button>
</div>
<?php render_result_card($test, (int)$me['id'], true); ?>
<?php page_footer();
