<?php
defined('APP_ROOT') || exit;
/**
 * Telegram bot: Bot API chaqiruvlari, ulash (ID + parol), xabarlar navbati, vaqtli ishlar.
 * Faqat Telegram Bot API ishlatiladi (bepul). Baholash kodiga tegmaydi — javoblar mavjud `responses` jadvaliga yoziladi.
 * PHP 7.4 bilan mos.
 */

/* ---------------- Sozlamalar (meta jadvalidan, keshsiz) ---------------- */

function tg_meta(string $k, string $default = ''): string
{
    $v = val('SELECT v FROM meta WHERE k=?', ['set_tg_' . $k]);
    return $v === null ? $default : (string)$v;
}

function tg_meta_set(string $k, string $v): void
{
    q('REPLACE INTO meta (k, v) VALUES (?, ?)', ['set_tg_' . $k, mb_substr($v, 0, 255)]);
}

function tg_token(): string { return tg_meta('token'); }
function tg_ready(): bool { return tg_token() !== ''; }

/** config.php da 'tg_api' berilsa (sinov uchun) shu manzil ishlatiladi */
function tg_api_base(): string
{
    global $CONFIG;
    return rtrim((string)($CONFIG['tg_api'] ?? 'https://api.telegram.org'), '/');
}

/** Saytning ochiq manzili (https://…): botdagi havolalar va webhook uchun */
function tg_site_url(): string
{
    return rtrim(trim(app_setting('public_url')), '/');
}

/* ---------------- Bot API ---------------- */

/**
 * Bot API chaqiruvi. Qaytaradi: ['ok'=>bool, 'result'=>mixed, 'code'=>int, 'desc'=>string, 'retry'=>int]
 * Fayl (CURLFile) bo'lsa multipart, aks holda JSON yuboriladi.
 */
function tg_call(string $method, array $params = [], ?string $token = null, int $timeout = 25): array
{
    $token = $token ?? tg_token();
    if ($token === '') return ['ok' => false, 'result' => null, 'code' => 0, 'desc' => 'Bot tokeni kiritilmagan', 'retry' => 0];
    if (!function_exists('curl_init')) return ['ok' => false, 'result' => null, 'code' => 0, 'desc' => 'PHP curl kengaytmasi yoqilmagan', 'retry' => 0];

    $multipart = false;
    foreach ($params as $v) if ($v instanceof CURLFile) { $multipart = true; break; }
    $ch = curl_init(tg_api_base() . '/bot' . $token . '/' . $method);
    if ($multipart) {
        foreach ($params as $k => $v) if (is_array($v)) $params[$k] = json_encode($v, JSON_UNESCAPED_UNICODE);
        $body = $params;
        $hdr = [];
    } else {
        $body = json_encode($params, JSON_UNESCAPED_UNICODE);
        $hdr = ['Content-Type: application/json'];
    }
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body, CURLOPT_HTTPHEADER => $hdr,
        CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => $timeout,
    ]);
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if (PHP_VERSION_ID < 80000) curl_close($ch);   // PHP 8+ da keraksiz, 8.5 da eskirgan
    if ($raw === false) return ['ok' => false, 'result' => null, 'code' => 0, 'desc' => 'Tarmoq xatosi: ' . $err, 'retry' => 0];
    $j = json_decode((string)$raw, true);
    if (!is_array($j)) return ['ok' => false, 'result' => null, 'code' => $http, 'desc' => 'Telegram javobi tushunarsiz (HTTP ' . $http . ')', 'retry' => 0];
    return [
        'ok' => !empty($j['ok']), 'result' => $j['result'] ?? null, 'code' => (int)($j['error_code'] ?? $http),
        'desc' => (string)($j['description'] ?? ''), 'retry' => (int)($j['parameters']['retry_after'] ?? 0),
    ];
}

function tg_h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function tg_send(int $chat, string $html, ?array $markup = null): array
{
    $p = ['chat_id' => $chat, 'text' => $html, 'parse_mode' => 'HTML', 'disable_web_page_preview' => true];
    if ($markup) $p['reply_markup'] = $markup;
    return tg_call('sendMessage', $p);
}

/** Bitta url tugmali klaviatura */
/** Javob kiritish usullari: botning o'zida yoki saytda (bir martalik havola orqali) */
function tg_ans_kb(array $t): array
{
    return ['inline_keyboard' => [
        [['text' => "🤖 Javoblarni shu botda kiritish", 'callback_data' => 'ans:' . (int)$t['id']]],
        [['text' => "🌐 Saytda kiritish", 'callback_data' => 'go:' . (int)$t['id']]],
    ]];
}

function tg_kb_url(string $text, string $url): array { return ['inline_keyboard' => [[['text' => $text, 'url' => $url]]]]; }
function tg_kb_cb(string $text, string $data): array { return ['inline_keyboard' => [[['text' => $text, 'callback_data' => $data]]]]; }

function tg_log(string $dir, ?int $chat, string $kind, bool $ok, string $info = ''): void
{
    try {
        q('INSERT INTO tg_log (dir, chat_id, kind, ok, info) VALUES (?,?,?,?,?)', [$dir, $chat, mb_substr($kind, 0, 16), $ok ? 1 : 0, mb_substr($info, 0, 255)]);
    } catch (Throwable $e) { /* jurnal xatosi asosiy ishni to'xtatmasin */ }
}

/** Savollar kitobini yuborish. Bir marta yuklangach Telegram `file_id` bilan qayta yuboriladi (tez, bepul). */
function tg_send_pdf(int $chat, array $test, string $captionHtml, ?array $markup = null): array
{
    $name = basename((string)$test['pdf_file']);
    $path = APP_ROOT . '/uploads/' . $name;
    if (!preg_match('/^test_\d+_[a-f0-9]{12}\.pdf$/', $name) || !is_file($path)) return tg_send($chat, $captionHtml, $markup);

    $base = ['chat_id' => $chat, 'caption' => $captionHtml, 'parse_mode' => 'HTML'];
    if ($markup) $base['reply_markup'] = $markup;
    if ($test['tg_file_id'] !== '' && $test['tg_file_for'] === $name) {
        $r = tg_call('sendDocument', $base + ['document' => $test['tg_file_id']]);
        if ($r['ok'] || !in_array($r['code'], [400], true)) return $r;   // 400 — file_id yaroqsiz bo'lsa qayta yuklaymiz
    }
    $fn = preg_replace('/[^\p{L}\p{N}._ -]+/u', '', (string)$test['title']);
    $fn = trim($fn) !== '' ? trim($fn) : 'savollar';
    $r = tg_call('sendDocument', $base + ['document' => new CURLFile($path, 'application/pdf', $fn . '.pdf')], null, 120);
    if ($r['ok'] && !empty($r['result']['document']['file_id'])) {
        q('UPDATE tests SET tg_file_id=?, tg_file_for=? WHERE id=?', [(string)$r['result']['document']['file_id'], $name, $test['id']]);
    }
    return $r;
}

/* ---------------- Auditoriya ---------------- */

/** Testga yuboriladigan (Telegramga ulangan) o'quvchilar */
function tg_audience(array $t): array
{
    $aud = (string)($t['tg_audience'] ?? 'reg');
    if ($aud === 'all') {
        return rows('SELECT id, tg_chat_id FROM students WHERE tg_chat_id IS NOT NULL AND archived_at IS NULL');
    }
    if ($aud === 'group') {
        return rows('SELECT id, tg_chat_id FROM students WHERE tg_chat_id IS NOT NULL AND archived_at IS NULL AND group_name=?', [(string)$t['tg_group']]);
    }
    return rows('SELECT s.id, s.tg_chat_id FROM students s JOIN test_registrations r ON r.student_id=s.id AND r.test_id=? WHERE s.tg_chat_id IS NOT NULL AND s.archived_at IS NULL', [$t['id']]);
}

function tg_in_audience(array $t, int $sid): bool
{
    foreach (tg_audience($t) as $s) if ((int)$s['id'] === $sid) return true;
    return false;
}

/** Foydalanuvchiga hozir/yaqinda mo'ljallangan Telegram testlari */
function tg_student_tests(int $sid): array
{
    $out = [];
    foreach (rows('SELECT * FROM tests WHERE tg_enabled=1 AND online=1 AND (online_end IS NULL OR online_end > NOW()) ORDER BY online_start, id') as $t) {
        $t['key'] = [];
        if (tg_in_audience($t, $sid)) $out[] = $t;
    }
    return $out;
}

/* ---------------- Bir martalik kirish havolasi ---------------- */

/** Havola yasaydi (15 daqiqa, bir marta). Sayt manzili yoki limit bo'lmasa null. */
function tg_make_link(int $studentId, int $testId, string $go): ?string
{
    $base = tg_site_url();
    if ($base === '') return null;
    if ((int)val('SELECT COUNT(*) FROM tg_tokens WHERE student_id=? AND used_at IS NULL AND expires_at>NOW()', [$studentId]) >= 5) return null;
    $tok = bin2hex(random_bytes(16));
    q('INSERT INTO tg_tokens (token_hash, student_id, test_id, go, expires_at) VALUES (?,?,?,?,DATE_ADD(NOW(), INTERVAL 15 MINUTE))',
        [hash('sha256', $tok), $studentId, $testId, in_array($go, ['result', 'qb', 'home'], true) ? $go : 'test']);
    return $base . '/index.php?p=tg_login&t=' . $tok;
}

/* ---------------- Matnlar ---------------- */

function tg_dt(?string $v): string
{
    return $v ? date('d.m.Y H:i', strtotime($v)) : '';
}

function tg_text_start(array $t): string
{
    $s = "📘 <b>" . tg_h($t['title']) . "</b>\n\nSavollar kitobi biriktirilgan.\n";
    $s .= "⏱ Davomiyligi: <b>" . (int)$t['duration_min'] . " daqiqa</b>\n";
    if (!empty($t['online_end'])) $s .= "🕒 Eng kechi tugash: <b>" . tg_dt($t['online_end']) . "</b>\n";
    $s .= "\nJavoblarni kiritish uchun pastdagi tugmani bosing. Vaqt tugagach test avtomatik yopiladi. Fayl faqat shaxsiy foydalanish uchun — tarqatmang.";
    return $s;
}

function tg_text_welcome(array $st): string
{
    $s = "✅ <b>Ulandi!</b> Xush kelibsiz, <b>" . tg_h($st['full_name'] ?: 'o‘quvchi') . "</b> (ID " . tg_h((string)$st['code']) . ").\n\nBu bot orqali:\n📝 mashq testlari yechasiz (bo‘lim tanlab, botda yoki PDF da)\n📋 o‘qituvchi topshiriqlarini bajarasiz\n📈 bo‘limlar bo‘yicha o‘zlashtirishingizni ko‘rasiz\n📊 MOCK natijalaringizni olasiz\n🌐 saytdagi kabinetga parolsiz kirasiz";
    $tests = tg_student_tests((int)$st['id']);
    if ($tests) {
        $s .= "\n\n<b>Sizga mo‘ljallangan MOCK:</b>";
        foreach ($tests as $t) $s .= "\n• " . tg_h($t['title']) . ($t['online_start'] ? ' — ' . tg_dt($t['online_start']) : '');
    }
    return $s . "\n\nPastdagi tugmalardan boshlang 👇";
}

function tg_text_help(): string
{
    return "Bu bot orqali onlayn MOCK topshirasiz, savol ishlaysiz va topshiriqlarni bajarasiz.\n\n"
        . "📝 /mashq — mashq testi: bo‘lim tanlab savol ishlash\n"
        . "📋 /topshiriq — o‘qituvchi yuborgan topshiriqlar (muddatli, avtomatik tekshiriladi)\n"
        . "📄 PDF da yechsangiz — javoblarni test kodi bilan bitta xabarda yuboring: <code>#123 ABCD…</code>\n"
        . "📈 /ozlashtirish — bo‘limlar bo‘yicha o‘zlashtirishim\n"
        . "📊 /natija — e’lon qilingan MOCK natijalarim\n"
        . "🗓 /mening — menga mo‘ljallangan MOCK lar\n"
        . "🌐 /kabinet — saytdagi kabinetga parolsiz kirish havolasi (botdagi hamma narsa saytda ham bor)\n"
        . "/start — ulanish · /menu — tugmalar menyusi · /uzish — ulanishni uzish\n\n"
        . "Ulanish uchun 6 xonali ID va parolingizni bitta xabarda yuboring, masalan: <code>123456 parolim</code>";
}

function tg_grade_label(string $g): string { return $g === 'NB' ? 'Sertifikatsiz' : $g; }

/** Doimiy menyu tugmalari (o'quvchi uchun) */
const TG_MENU = ['📝 Mashq testi' => '/mashq', '📋 Topshiriqlar' => '/topshiriq', '📈 O‘zlashtirish' => '/ozlashtirish',
                 '📊 Natijalarim' => '/natija', '🗓 MOCKlarim' => '/mening', '🌐 Kabinetga kirish' => '/kabinet', 'ℹ️ Yordam' => '/help'];

function tg_menu_kb(): array
{
    $b = array_map(fn($t) => ['text' => $t], array_keys(TG_MENU));
    return ['keyboard' => array_chunk($b, 2), 'resize_keyboard' => true, 'is_persistent' => true];
}

/** Bot buyruqlari ro'yxati (Telegram menyusidagi «/» tugmasi uchun) */
function tg_set_commands(): array
{
    return tg_call('setMyCommands', ['commands' => [
        ['command' => 'menu', 'description' => 'Asosiy menyu'],
        ['command' => 'mashq', 'description' => 'Mashq testi — savol ishlash'],
        ['command' => 'topshiriq', 'description' => 'Topshiriqlarim'],
        ['command' => 'ozlashtirish', 'description' => 'Bo‘limlar bo‘yicha o‘zlashtirishim'],
        ['command' => 'natija', 'description' => 'MOCK natijalarim'],
        ['command' => 'mening', 'description' => 'MOCK larim'],
        ['command' => 'kabinet', 'description' => 'Saytdagi kabinetga kirish'],
        ['command' => 'help', 'description' => 'Yordam'],
        ['command' => 'uzish', 'description' => 'Telegram ulanishini uzish'],
    ]]);
}

/* ---------------- Kiruvchi yangilanishlar ---------------- */

function tg_handle_update(array $u): void
{
    if (isset($u['callback_query'])) { tg_handle_callback($u['callback_query']); return; }
    $m = $u['message'] ?? null;
    if (!$m || ($m['chat']['type'] ?? '') !== 'private') return;
    $chat = (int)$m['chat']['id'];
    $text = trim((string)($m['text'] ?? ''));
    $from = $m['from'] ?? [];
    tg_log('in', $chat, 'msg', true, preg_match('/^\/\w+/', $text, $mm) ? $mm[0] : 'text');
    if ($text === '') { tg_send($chat, 'Matn yuboring. /help — yordam.'); return; }

    $st = row('SELECT * FROM students WHERE tg_chat_id=?', [$chat]);
    if ($st && $st['archived_at'] !== null) { tg_send($chat, 'Hisobingiz arxivlangan. Savollar bo‘lsa o‘quv markaziga murojaat qiling.', ['remove_keyboard' => true]); return; }
    $cmd = '';
    if ($text[0] === '/') $cmd = strtolower(preg_replace('/@.*$/', '', strtok($text, " \n")));
    elseif (array_key_exists($text, TG_MENU)) $cmd = TG_MENU[$text];   // menyu tugmasi
    $aliases = ['/tasks' => '/topshiriq', '/topshiriqlar' => '/topshiriq', '/progress' => '/ozlashtirish', '/o‘zlashtirish' => '/ozlashtirish', '/menyu' => '/menu'];
    if (isset($aliases[$cmd])) $cmd = $aliases[$cmd];

    if ($cmd === '/start') {
        $arg = trim((string)preg_replace('/^\/start(@\S+)?/i', '', $text));
        if ($arg !== '') { tg_start_token($chat, $from, $arg); return; }   // kabinetdagi «Telegramni ulash» havolasi
        q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, $st ? '' : 'id', '']);
        if ($st) tg_send($chat, "Siz allaqachon ulangansiz: <b>" . tg_h($st['full_name']) . "</b> (ID " . tg_h($st['code']) . ").\n\nPastdagi tugmalardan foydalaning.", tg_menu_kb());
        else tg_send($chat, "Assalomu alaykum! 👋\nMOCK ga ulanish uchun <b>6 xonali ID</b> raqamingizni yuboring (yoki ID va parolni birga: <code>123456 parolim</code>).\n\nID va vaqtinchalik parol o‘quv markazidan beriladi; o‘zingiz parol belgilagan bo‘lsangiz — shuni yuboring.\nSayt kabinetingizdagi «Telegramni ulash» tugmasi orqali ham ulanishingiz mumkin.");
        return;
    }
    if ($cmd === '/help') { tg_send($chat, tg_text_help(), $st ? tg_menu_kb() : null); return; }
    if ($cmd === '/menu') { q('DELETE FROM tg_state WHERE chat_id=? AND step IN ("qb","qbkeys","qbsec","qbcnt","ans")', [$chat]); tg_send($chat, $st ? 'Menyu 👇' : 'Avval ulaning: /start', $st ? tg_menu_kb() : null); return; }
    $parKids = !$st ? rows('SELECT id, full_name FROM students WHERE parent_tg_chat=?', [$chat]) : [];
    if ($parKids && ($cmd === '/uzish' || $cmd === '/unlink')) {
        q('UPDATE students SET parent_tg_chat=NULL, parent_tg_at=NULL WHERE parent_tg_chat=?', [$chat]);
        tg_send($chat, 'Ulanish uzildi. Natijalar endi bu yerga yuborilmaydi.');
        return;
    }
    if ($parKids && ($cmd === '/natija' || $cmd === '/result')) {
        $any = false;
        foreach ($parKids as $k) {
            $rs = rows('SELECT t.id, t.title, res.ball, res.grade, res.rank_no FROM results res JOIN tests t ON t.id=res.test_id WHERE res.student_id=? AND t.published=1 ORDER BY t.id DESC LIMIT 3', [$k['id']]);
            foreach ($rs as $r) { $any = true; tg_send($chat, "👤 <b>" . tg_h($k['full_name']) . "</b>\n" . tg_text_result($r)); }
        }
        if (!$any) tg_send($chat, 'E’lon qilingan natija hali yo‘q.');
        return;
    }
    if ($parKids && $cmd === '') { tg_send($chat, 'Bu yerga farzandingiz MOCK natijalari keladi. /natija — so‘nggi natijalar, /uzish — ulanishni uzish.'); return; }
    if ($cmd === '/uzish' || $cmd === '/unlink') {
        if ($st) { q('UPDATE students SET tg_chat_id=NULL, tg_username="", tg_linked_at=NULL WHERE id=?', [$st['id']]); q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); tg_send($chat, "Ulanish uzildi. Qayta ulanish uchun /start.", ['remove_keyboard' => true]); }
        else tg_send($chat, 'Siz ulanmagansiz. /start');
        return;
    }
    if ($cmd === '/mening' || $cmd === '/my') {
        if (!$st) { tg_send($chat, 'Avval ulaning: /start'); return; }
        $tests = tg_student_tests((int)$st['id']);
        if (!$tests) { tg_send($chat, 'Hozircha sizga mo‘ljallangan MOCK yo‘q.'); return; }
        $s = "<b>Sizning MOCK larigiz:</b>";
        foreach ($tests as $t) $s .= "\n• " . tg_h($t['title']) . ($t['online_start'] ? "\n  Boshlanish: " . tg_dt($t['online_start']) : '') . "\n  Davomiyligi: " . (int)$t['duration_min'] . ' daqiqa';
        tg_send($chat, $s);
        return;
    }
    if ($cmd === '/natija' || $cmd === '/result') {
        if (!$st) { tg_send($chat, 'Avval ulaning: /start'); return; }
        $rs = rows('SELECT t.id, t.title, res.ball, res.grade, res.rank_no FROM results res JOIN tests t ON t.id=res.test_id WHERE res.student_id=? AND t.published=1 ORDER BY t.id DESC LIMIT 5', [$st['id']]);
        if (!$rs) { tg_send($chat, 'E’lon qilingan natija hali yo‘q.'); return; }
        foreach ($rs as $r) tg_send($chat, tg_text_result($r), tg_kb_cb('📊 Batafsil natija', 'res:' . (int)$r['id']));
        return;
    }
    if ($cmd === '/mashq' || $cmd === '/practice') {
        if (!$st) { tg_send($chat, 'Avval ulaning: /start'); return; }
        tg_qb_menu($chat, $st);
        return;
    }
    if ($cmd === '/topshiriq') {
        if (!$st) { tg_send($chat, 'Avval ulaning: /start'); return; }
        tg_asg_list($chat, $st);
        return;
    }
    if ($cmd === '/kabinet' || $cmd === '/sayt') {
        if (!$st) { tg_send($chat, 'Avval ulaning: /start'); return; }
        $link = tg_make_link((int)$st['id'], 0, 'home');
        if ($link === null) { tg_send($chat, tg_site_url() === '' ? 'Sayt manzili sozlanmagan — o‘quv markaziga xabar bering.' : 'Avvalgi havolalar hali amalda — 15 daqiqadan keyin qayta urinib ko‘ring yoki ID va parol bilan kiring.'); return; }
        tg_send($chat, "🌐 <b>Shaxsiy kabinet</b>\nBu havola parolsiz kiritadi: 15 daqiqa amal qiladi va bir marta ishlaydi. Boshqalarga yubormang.\n\nKabinetda: topshiriqlar, mashq testlari (PDF bilan), o‘zlashtirish, MOCK natijalari, profil.\nKeyinroq o‘zingiz kirish: " . tg_h(tg_site_url()) . " → «Kirish» (ID yoki telefon + parol).", tg_kb_url('🌐 Kabinetni ochish', $link));
        return;
    }
    if ($cmd === '/ozlashtirish') {
        if (!$st) { tg_send($chat, 'Avval ulaning: /start'); return; }
        tg_send($chat, tg_mastery_text($st));
        return;
    }
    if ($cmd !== '') { tg_send($chat, tg_text_help()); return; }

    // Ulanish: "123456 parol" yoki ikki bosqichda (ID, so'ng parol)
    $state = row('SELECT * FROM tg_state WHERE chat_id=?', [$chat]) ?: ['step' => '', 'data' => '', 'msg_id' => 0];
    if (in_array($state['step'], ['qb', 'qbkeys', 'qbsec', 'qbcnt'], true) && !empty($state['updated_at']) && time() - strtotime((string)$state['updated_at']) > 6 * 3600) {   // eski rejim oddiy xabarlarni «yutmasin»
        q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); $state = ['step' => '', 'data' => '', 'msg_id' => 0];
    }
    if ($st && preg_match('/^(#[Aa]?\d{1,9})(?!\d)/', $text, $mm)) {   // «#123 ABCD…» / «#A12 ABCD…» — PDF test javoblari
        $kt = qb_code_resolve($mm[1], (int)$st['id']);
        if (!$kt) { tg_send($chat, '<b>' . tg_h(strtoupper($mm[1])) . '</b> kodli test sizda topilmadi. Kodni PDF dagi «TEST KODI» yozuvidan tekshiring.'); return; }
        if (tg_qb_keys($chat, $st, $kt, $text)) return;
    }
    if ($st && $state['step'] === 'qbkeys' && ctype_digit((string)$state['data']) && tg_qb_keys($chat, $st, (int)$state['data'], $text)) return;
    if ($st && $state['step'] === 'ans' && tg_ans_text($chat, $st, $state, $text)) return;
    if ($st && $state['step'] === 'qb' && tg_qb_text($chat, $st, $state, $text)) return;
    if ($st && in_array($state['step'], ['qbsec', 'qbcnt'], true) && tg_qb_pick_text($chat, $st, $state, $text)) return;   // yozib yuborilgan raqam
    $code = $pass = '';
    if (!$st && $state['step'] === 'pass' && preg_match('/^\d{6}$/', (string)$state['data']) && preg_match('/^\S{4,64}$/u', $text) && !preg_match('/^\d{6}$/', $text)) { $code = $state['data']; $pass = $text; }
    elseif (preg_match('/^(\d{6})[\s,;:\/]+(\S{4,64})$/u', $text, $mm)) { $code = $mm[1]; $pass = $mm[2]; }
    elseif (!$st && preg_match('/^\d{6}$/', $text)) { q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'pass', $text]); tg_send($chat, 'Endi <b>parolingizni</b> yuboring (xabar yuborilgach o‘chiriladi).'); return; }
    else { tg_send($chat, $st ? "Bu buyruqni tushunmadim 🙂\nPastdagi tugmalardan foydalaning yoki /help ni bosing.\n\nPDF javoblarini yuborayotgan bo‘lsangiz, xabarni test kodi bilan boshlang: <code>#123 ABCD…</code>" : "ID raqamingizni (6 xona) yuboring yoki /start.", $st ? tg_menu_kb() : null); return; }

    tg_try_link($chat, $from, $code, $pass, (int)($m['message_id'] ?? 0));
}

function tg_try_link(int $chat, array $from, string $code, string $pass, int $msgId): void
{
    $since = date('Y-m-d H:i:s', time() - 900);
    $byChat = (int)val('SELECT COUNT(*) FROM login_attempts WHERE kind="tg" AND ident=? AND created_at>?', [(string)$chat, $since]);
    $byCode = (int)val('SELECT COUNT(*) FROM login_attempts WHERE kind="tgc" AND ident=? AND created_at>?', [$code, $since]);
    if ($byChat >= 5 || $byCode >= 20) {
        tg_send($chat, 'Juda ko‘p noto‘g‘ri urinish. 15 daqiqadan keyin qayta urinib ko‘ring.');
        return;
    }
    $s = row('SELECT * FROM students WHERE code=?', [$code]);
    if ($msgId) tg_call('deleteMessage', ['chat_id' => $chat, 'message_id' => $msgId]);   // parol chatda qolmasin (imkon bo'lsa)
    if (!$s || !student_pass_check($s, $pass) || $s['archived_at'] !== null) {
        q('INSERT INTO login_attempts (kind, ident, ip) VALUES ("tg",?,"tg")', [(string)$chat]);
        q('INSERT INTO login_attempts (kind, ident, ip) VALUES ("tgc",?,"tg")', [$code]);
        q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'id', '']);
        usleep(300000);
        tg_send($chat, "ID yoki parol noto‘g‘ri. Qayta yuboring: <code>123456 parolim</code>\n\nParolni unutgan bo‘lsangiz — saytdagi «Parolni unutdingizmi?» havolasidan tiklang.");
        return;
    }
    q('DELETE FROM login_attempts WHERE kind IN ("tg","tgc") AND ident IN (?,?)', [(string)$chat, $code]);
    tg_link_student($chat, $from, $s);
}

/** Chatni o'quvchiga bog'laydi (boshqa chatdan o'tkazish va eski chatga ogohlantirish bilan) */
function tg_link_student(int $chat, array $from, array $s): void
{
    $oldChat = $s['tg_chat_id'] !== null ? (int)$s['tg_chat_id'] : 0;
    q('UPDATE students SET tg_chat_id=NULL, tg_username="", tg_linked_at=NULL WHERE tg_chat_id=?', [$chat]);   // bu chat boshqa o'quvchiga ulangan bo'lsa
    q('UPDATE students SET tg_chat_id=?, tg_username=?, tg_linked_at=NOW() WHERE id=?', [$chat, mb_substr((string)($from['username'] ?? ''), 0, 64), $s['id']]);
    q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
    if ($oldChat && $oldChat !== $chat) tg_send($oldChat, 'Sizning hisobingiz boshqa Telegram profilga ulandi. Bu chatga endi xabar kelmaydi.');
    tg_log('in', $chat, 'link', true, 'student ' . $s['id']);
    tg_send($chat, tg_text_welcome($s), tg_menu_kb());
}

/** `/start <token>`: kabinetdan yoki ota-ona uchun yaratilgan bir martalik havola */
function tg_start_token(int $chat, array $from, string $arg): void
{
    $since = date('Y-m-d H:i:s', time() - 900);
    if ((int)val('SELECT COUNT(*) FROM login_attempts WHERE kind="tgt" AND ident=? AND created_at>?', [(string)$chat, $since]) >= 8) {
        tg_send($chat, 'Juda ko‘p noto‘g‘ri urinish. 15 daqiqadan keyin qayta urinib ko‘ring.');
        return;
    }
    $l = preg_match('/^[A-Za-z0-9_-]{16,64}$/', $arg) ? row('SELECT * FROM tg_links WHERE token_hash=? AND used_at IS NULL AND expires_at>NOW()', [hash('sha256', $arg)]) : null;
    $s = $l ? row('SELECT * FROM students WHERE id=? AND archived_at IS NULL', [$l['student_id']]) : null;
    if (!$l || !$s) {
        q('INSERT INTO login_attempts (kind, ident, ip) VALUES ("tgt",?,"tg")', [(string)$chat]);
        tg_send($chat, "Havola eskirgan yoki noto‘g‘ri. Saytdagi kabinetingizdan «Telegramni ulash» tugmasi orqali yangi havola oling, yoki ID va parolingizni yuboring: <code>123456 parolim</code>");
        return;
    }
    q('UPDATE tg_links SET used_at=NOW() WHERE token_hash=?', [$l['token_hash']]);
    if ($l['who'] === 'par') {
        q('UPDATE students SET parent_tg_chat=?, parent_tg_at=NOW() WHERE id=?', [$chat, $s['id']]);
        tg_log('in', $chat, 'plink', true, 'student ' . $s['id']);
        tg_send($chat, "✅ Ulandi. Siz <b>" . tg_h($s['full_name'] ?: 'o‘quvchi') . "</b> ning ota-onasi sifatida ulandingiz.\nMOCK natijalari shu yerga keladi.\n\n/natija — so‘nggi natijalar, /uzish — ulanishni uzish.");
        return;
    }
    tg_link_student($chat, $from, $s);
}

function tg_text_result(array $r): string
{
    return "📊 <b>" . tg_h($r['title']) . "</b> natijasi\n\nBall: <b>" . fmt($r['ball']) . "</b>\nDaraja: <b>" . tg_h(tg_grade_label((string)$r['grade'])) . "</b>\nO‘rin: <b>" . (int)$r['rank_no'] . "</b>";
}

function tg_handle_callback(array $cb): void
{
    $id = (string)($cb['id'] ?? '');
    $chat = (int)($cb['message']['chat']['id'] ?? $cb['from']['id'] ?? 0);
    $data = (string)($cb['data'] ?? '');
    $ans = function (string $text = '', bool $alert = false) use ($id) {
        tg_call('answerCallbackQuery', array_filter(['callback_query_id' => $id, 'text' => $text, 'show_alert' => $alert], fn($v) => $v !== '' && $v !== false));
    };
    tg_log('in', $chat, 'cb', true, mb_substr($data, 0, 40));
    $st = $chat ? row('SELECT * FROM students WHERE tg_chat_id=? AND archived_at IS NULL', [$chat]) : null;
    if (!$st) { $ans('Avval /start orqali ID va parol bilan ulaning', true); return; }
    if (strncmp($data, 'ans:', 4) === 0) { tg_ans_cb($chat, $st, $data, $ans); return; }
    if (strncmp($data, 'qb', 2) === 0) { tg_qb_cb($chat, $st, $data, $ans, (int)($cb['message']['message_id'] ?? 0)); return; }
    if (preg_match('/^join:(\d+)$/', $data, $mm)) {
        $test = test_by_id((int)$mm[1]);
        if (!$test || !$test['tg_enabled']) { $ans('Test topilmadi', true); return; }
        q('INSERT IGNORE INTO test_registrations (test_id, student_id) VALUES (?,?)', [$test['id'], $st['id']]);
        $ans('✅ Ro‘yxatga yozildingiz!', true);
        $mid = (int)($cb['message']['message_id'] ?? 0);
        if ($mid) tg_call('editMessageReplyMarkup', ['chat_id' => $chat, 'message_id' => $mid]);
        return;
    }
    if (!preg_match('/^(go|res):(\d+)$/', $data, $mm)) { $ans(); return; }
    $test = test_by_id((int)$mm[2]);
    if (!$test) { $ans('Test topilmadi', true); return; }
    $sid = (int)$st['id'];

    if ($mm[1] === 'go') {
        $resp = row('SELECT * FROM responses WHERE test_id=? AND student_id=?', [$test['id'], $sid]);
        if (!$test['tg_enabled'] || !$test['online']) { $ans('Bu test Telegram orqali o‘tkazilmaydi', true); return; }
        if ($resp && $resp['status'] === 'submitted') { $ans('Siz bu testni topshirgansiz. Natija e’lon qilinganda yuboriladi.', true); return; }
        $alive = $resp && $resp['status'] === 'in_progress' && time() <= online_deadline($test, $resp) + 60;
        if (!$alive) {
            if (!tg_in_audience($test, $sid) && !$resp) { $ans('Siz bu MOCK ro‘yxatida yo‘qsiz. Markaz bilan bog‘laning.', true); return; }
            if (!online_open($test)) { $ans(empty($test['online_start']) || time() >= strtotime((string)$test['online_start']) ? 'Test vaqti tugagan' : 'Test hali boshlanmagan', true); return; }
        }
        $link = tg_make_link($sid, (int)$test['id'], 'test');
        $label = '✍️ Javoblarni kiritish';
    } else {
        $has = val('SELECT 1 FROM results WHERE test_id=? AND student_id=?', [$test['id'], $sid]);
        if (!$test['published'] || !$has) { $ans('Natija hali e’lon qilinmagan', true); return; }
        $link = tg_make_link($sid, (int)$test['id'], 'result');
        $label = '📊 Natijani ochish';
    }
    if ($link === null) {
        $ans(tg_site_url() === '' ? 'Sayt manzili sozlanmagan — markazga xabar bering' : 'Avvalgi havolalar hali amalda — bir oz kuting', true);
        return;
    }
    $ans();
    tg_send($chat, "Havola 15 daqiqa amal qiladi va faqat bir marta ishlaydi. Boshqalarga yubormang.", tg_kb_url($label, $link));
}

/* ---------------- Navbat ---------------- */

function tg_enqueue(string $kind, int $testId, int $sid, int $chat, ?array $payload = null, ?string $sendAt = null, string $channel = 'tg', string $phone = ''): bool
{
    $st = q('INSERT IGNORE INTO tg_queue (kind, test_id, student_id, chat_id, payload, send_at, channel, phone) VALUES (?,?,?,?,?,?,?,?)',
        [$kind, $testId, $sid, $chat, $payload ? json_encode($payload, JSON_UNESCAPED_UNICODE) : null, $sendAt ?: date('Y-m-d H:i:s'), $channel === 'sms' ? 'sms' : 'tg', $phone]);
    return $st->rowCount() > 0;
}

/** Navbatni qulf bilan bo'shatish (sahifalardan chaqirish uchun; cron bilan bir vaqtda ikki marta yuborilmasin) */
function tg_drain_now(int $budgetSec = 8, int $max = 200): array
{
    if (!tg_lock()) return ['busy' => true];
    try { return tg_drain($budgetSec, $max); } finally { tg_unlock(); }
}

/** Bitta navbat vazifasini yuboradi. Qaytaradi tg_call formatidagi natija (+ 'skip' => sabab) */
function tg_run_job(array $j): array
{
    // Yuborish paytida chat qayta aniqlanadi: o'quvchi arxivlangan / botni uzgan / boshqa chatga ulangan bo'lsa eski chatga ketmasin
    if ((int)$j['student_id'] > 0 && ($j['channel'] ?? 'tg') === 'tg') {
        $stu = row('SELECT tg_chat_id, parent_tg_chat, archived_at FROM students WHERE id=?', [(int)$j['student_id']]);
        if (!$stu) return ['ok' => true, 'skip' => 'o‘quvchi o‘chirilgan'];
        if ($stu['archived_at'] !== null) return ['ok' => true, 'skip' => 'arxivlangan'];
        $cur = in_array($j['kind'], ['ptg', 'p1', 'p2'], true) ? $stu['parent_tg_chat'] : $stu['tg_chat_id'];
        if ($cur === null || (int)$cur === 0) return ['ok' => true, 'skip' => 'bot ulanmagan'];
        $j['chat_id'] = (int)$cur;
    }
    if (in_array($j['kind'], ['asg', 'asgr', 'asgd', 'asgn'], true)) return tg_asg_job($j);   // topshiriqlar (inc/tg_practice.php)
    $test = $j['test_id'] ? test_by_id((int)$j['test_id']) : null;
    $chat = (int)$j['chat_id'];
    $p = json_decode((string)$j['payload'], true) ?: [];
    if (in_array($j['kind'], ['room', 'p1', 'p2', 'ptg', 'temp'], true)) return msg_run_job($j);   // xona / ota-ona xabarlari (inc/msg_jobs.php)
    if ($j['kind'] === 'start') {
        if (!$test || !$test['tg_enabled'] || !online_open($test)) return ['ok' => true, 'skip' => 'test yopiq'];
        $done = val('SELECT 1 FROM responses WHERE test_id=? AND student_id=? AND status="submitted"', [$test['id'], $j['student_id']]);
        if ($done) return ['ok' => true, 'skip' => 'topshirgan'];
        $stu = row('SELECT code, full_name FROM students WHERE id=?', [$j['student_id']]);
        $cap = tg_text_start($test) . ($stu ? "\n\n👤 Bu nusxa: <b>" . tg_h($stu['full_name'] ?: 'o‘quvchi') . "</b> (ID " . tg_h($stu['code']) . ")" : '');
        $kb = tg_ans_kb($test);
        return !empty($test['pdf_file']) ? tg_send_pdf($chat, $test, $cap, $kb) : tg_send($chat, $cap, $kb);
    }
    if ($j['kind'] === 'closed') {
        if (!$test) return ['ok' => true, 'skip' => 'test o‘chirilgan'];
        $s = "⏹ <b>" . tg_h($test['title'] ?? 'Test') . "</b> yakunlandi.\nJavoblaringiz qabul qilindi: <b>" . (int)($p['answered'] ?? 0) . " / " . (int)($p['total'] ?? 0) . "</b> ta savolga javob berilgan.\n\nNatijalar e’lon qilinganda shu yerga yuboriladi.";
        return tg_send($chat, $s);
    }
    if ($j['kind'] === 'result') {
        $r = row('SELECT t.id, t.title, t.published, res.ball, res.grade, res.rank_no FROM results res JOIN tests t ON t.id=res.test_id WHERE res.test_id=? AND res.student_id=?', [$j['test_id'], $j['student_id']]);
        if (!$r || !$r['published']) return ['ok' => true, 'skip' => 'natija yo‘q'];
        return tg_send($chat, tg_text_result($r), tg_kb_cb('📊 Batafsil natija', 'res:' . (int)$r['id']));
    }
    if ($j['kind'] === 'invite') {
        if (!$test || !$test['tg_enabled'] || (!empty($test['online_end']) && time() > strtotime((string)$test['online_end']))) return ['ok' => true, 'skip' => 'test yopiq'];
        $s = "📣 <b>" . tg_h($test['title']) . "</b>\n";
        if (!empty($test['online_start'])) $s .= "📅 Boshlanish: <b>" . tg_dt($test['online_start']) . "</b>\n";
        $s .= "⏱ Davomiyligi: <b>" . (int)$test['duration_min'] . " daqiqa</b>\n\nSavollar kitobi boshlanish vaqtida shu botga keladi. Qog'oz va qalam tayyorlab turing.";
        $reg = val('SELECT 1 FROM test_registrations WHERE test_id=? AND student_id=?', [$test['id'], $j['student_id']]);
        return tg_send($chat, $s . ($reg ? "\n\n✅ Siz ro'yxatdasiz." : ''), $reg ? null : tg_kb_cb('✅ Qatnashaman', 'join:' . (int)$test['id']));
    }
    if ($j['kind'] === 'rem1d' || $j['kind'] === 'rem1h') {
        if (!$test || !$test['tg_enabled'] || empty($test['online_start']) || time() >= strtotime((string)$test['online_start'])) return ['ok' => true, 'skip' => 'boshlangan'];
        if (val('SELECT 1 FROM responses WHERE test_id=? AND student_id=? AND status="submitted"', [$test['id'], $j['student_id']])) return ['ok' => true, 'skip' => 'topshirgan'];
        $s = $j['kind'] === 'rem1d'
            ? "📅 Eslatma: <b>" . tg_h($test['title']) . "</b> ertaga — <b>" . tg_dt($test['online_start']) . "</b> da boshlanadi.\nQog'oz, qalam tayyorlang. Javoblarni oxirgi daqiqalarga qoldirmay, yechgan sari kiritib boring."
            : "⏰ <b>" . tg_h($test['title']) . "</b> tez orada — <b>" . tg_dt($test['online_start']) . "</b> da boshlanadi. Savollar kitobi shu yerga keladi.";
        return tg_send($chat, $s);
    }
    if ($j['kind'] === 'rem30' || $j['kind'] === 'rem10' || $j['kind'] === 'nudge') {
        if (!$test || !$test['online']) return ['ok' => true, 'skip' => 'test yopiq'];
        $r = row('SELECT * FROM responses WHERE test_id=? AND student_id=?', [$test['id'], $j['student_id']]);
        if ($r && $r['status'] === 'submitted') return ['ok' => true, 'skip' => 'topshirgan'];
        $dl = $r ? online_deadline($test, $r) : (!empty($test['online_end']) ? strtotime((string)$test['online_end']) : 0);
        $mins = $dl ? (int)ceil(($dl - time()) / 60) : 0;
        if ($dl && $mins <= 0) return ['ok' => true, 'skip' => 'muddat o‘tgan'];
        $items = test_items($test);
        $done = $r ? tg_ans_counts($items, json_decode($r['answers'] ?: '{}', true) ?: []) : 0;
        $s = "⏳ <b>" . tg_h($test['title']) . "</b>: tugashiga ~<b>$mins daqiqa</b> qoldi.\n"
            . ($r ? "Belgilangan: <b>$done / " . count($items) . "</b>." . ($done === 0 ? " ⚠️ Hali birorta javob kiritmadingiz!" : '')
                  : "⚠️ Siz testni hali boshlamadingiz!");
        return tg_send($chat, $s, tg_ans_kb($test));
    }
    if ($j['kind'] === 'extend') {
        if (!$test) return ['ok' => true, 'skip' => 'test yo‘q'];
        if (val('SELECT 1 FROM responses WHERE test_id=? AND student_id=? AND status="submitted"', [$test['id'], $j['student_id']])) return ['ok' => true, 'skip' => 'topshirgan'];
        return tg_send($chat, "🕒 <b>" . tg_h($test['title']) . "</b> muddati uzaytirildi. Yangi tugash vaqti: <b>" . tg_h((string)($p['end'] ?? '')) . "</b>.", tg_ans_kb($test));
    }
    return ['ok' => true, 'skip' => 'noma’lum tur'];
}

/** Navbatni vaqt byudjeti ichida bo'shatadi (Telegram ~30 xabar/s chegarasi: xabarlar orasida ~40 ms) */
function tg_drain(int $budgetSec = 40, int $max = 600): array
{
    $t0 = microtime(true); $sent = 0; $fail = 0; $skipped = 0;
    while ($sent + $fail + $skipped < $max && microtime(true) - $t0 < $budgetSec) {
        $j = row('SELECT * FROM tg_queue WHERE sent_at IS NULL AND attempts<3 AND send_at<=NOW() ORDER BY send_at, id LIMIT 1');
        if (!$j) break;
        q('UPDATE tg_queue SET attempts=attempts+1 WHERE id=?', [$j['id']]);
        try { $r = tg_run_job($j); }
        catch (Throwable $e) { $r = ['ok' => false, 'code' => 0, 'desc' => 'Ichki xato: ' . $e->getMessage(), 'retry' => 0]; }
        if (!empty($r['ok'])) {
            q('UPDATE tg_queue SET sent_at=NOW(), error=? WHERE id=?', [isset($r['skip']) ? 'o‘tkazildi: ' . $r['skip'] : '', $j['id']]);
            isset($r['skip']) ? $skipped++ : $sent++;
            tg_log('out', (int)$j['chat_id'], $j['kind'], true, isset($r['skip']) ? $r['skip'] : '');
        } elseif ((int)$r['code'] === 429) {
            $wait = max(1, (int)$r['retry']);
            q('UPDATE tg_queue SET attempts=attempts-1, send_at=DATE_ADD(NOW(), INTERVAL ? SECOND) WHERE id=?', [$wait, $j['id']]);
            if ($wait > 3) break;   // umumiy chegaraga yetdik — keyingi chaqiruvda davom etamiz
            sleep($wait);
            continue;
        } else {
            $final = in_array((int)$r['code'], [400, 403], true);
            $err = mb_substr(($r['code'] ? '[' . $r['code'] . '] ' : '') . $r['desc'], 0, 255);
            q('UPDATE tg_queue SET error=?, attempts=?, send_at=DATE_ADD(NOW(), INTERVAL 60 SECOND) WHERE id=?', [$err, $final ? 3 : (int)$j['attempts'] + 1, $j['id']]);
            $fail++;
            tg_log('out', (int)$j['chat_id'], $j['kind'], false, $err);
        }
        usleep(40000);
    }
    return ['sent' => $sent, 'failed' => $fail, 'skipped' => $skipped];
}

/* ---------------- Vaqtli ishlar ---------------- */

function tg_lock(): bool { return (int)val('SELECT GET_LOCK("mock_tg_tick", 0)') === 1; }
function tg_unlock(): void { try { q('SELECT RELEASE_LOCK("mock_tg_tick")')->fetchAll(); } catch (Throwable $e) {} }

/**
 * Vaqtli ishlarni bajaradi (cron har daqiqa, webhook va admin tugmasi ham chaqiradi):
 *  1) boshlanish vaqti kelgan testlar uchun PDF yuborishni navbatga qo'yadi;
 *  2) vaqti o'tgan `in_progress` javoblarni yopadi va o'quvchiga xabar qo'yadi;
 *  3) e'lon qilingan natijalarni yuborishni navbatga qo'yadi;
 *  4) navbatni bo'shatadi.
 * Qaytaradi: hisobot massivi yoki ['busy'=>true].
 */
function tg_tick(int $budgetSec = 40): array
{
    if (!tg_ready() && !sms_ready()) return ['off' => true];   // bot ham, SMS ham ulanmagan
    if (!tg_lock()) return ['busy' => true];
    $rep = ['queued_start' => 0, 'closed' => 0, 'queued_result' => 0];
    try {
        @set_time_limit($budgetSec + 20);
        $tests = tg_ready() ? rows('SELECT id FROM tests WHERE tg_enabled=1') : [];   // test jarayoni faqat bot bilan
        foreach ($tests as $tr) {
            $t = test_by_id((int)$tr['id']);
            if (!$t) continue;
            // 1) boshlanish
            if ($t['online'] && !empty($t['online_start']) && online_open($t)) {
                foreach (tg_audience($t) as $s) {
                    if (tg_enqueue('start', (int)$t['id'], (int)$s['id'], (int)$s['tg_chat_id'])) $rep['queued_start']++;
                }
            }
            // 1b) eslatmalar: boshlanishdan 1 kun va 1 soat oldin; tugashiga 30 va 10 daqiqa qolganda
            $now = time();
            $stT = !empty($t['online_start']) ? strtotime($t['online_start']) : 0;
            if ($stT && $now < $stT) {
                $d = $stT - $now;
                $k = $d <= 3600 ? 'rem1h' : ($d >= 72000 && $d <= 86400 ? 'rem1d' : '');
                if ($k !== '') foreach (tg_audience($t) as $s) tg_enqueue($k, (int)$t['id'], (int)$s['id'], (int)$s['tg_chat_id']);
            }
            $enT = !empty($t['online_end']) ? strtotime($t['online_end']) : 0;
            if ($enT && online_open($t)) {
                $e = $enT - $now;
                $k = $e <= 600 ? 'rem10' : ($e <= 1800 ? 'rem30' : '');
                if ($k !== '') foreach (tg_audience($t) as $s) {
                    if (val('SELECT 1 FROM responses WHERE test_id=? AND student_id=? AND status="submitted"', [$t['id'], $s['id']])) continue;
                    tg_enqueue($k, (int)$t['id'], (int)$s['id'], (int)$s['tg_chat_id']);
                }
            }
            // 2) muddati o'tganlarni yopish
            $total = count(test_items($t));
            foreach (rows('SELECT * FROM responses WHERE test_id=? AND status="in_progress"', [$t['id']]) as $r) {
                if (time() <= online_deadline($t, $r) + 60) continue;
                $up = q('UPDATE responses SET status="submitted", submitted_at=NOW() WHERE id=? AND status="in_progress"', [$r['id']]);
                if (!$up->rowCount()) continue;
                q('UPDATE tests SET dirty=1 WHERE id=?', [$t['id']]);
                $rep['closed']++;
                $chat = val('SELECT tg_chat_id FROM students WHERE id=?', [$r['student_id']]);
                if ($chat) {
                    $ans = json_decode((string)$r['answers'] ?: '{}', true) ?: [];
                    $filled = count(array_filter($ans, fn($v) => trim((string)$v) !== ''));
                    tg_enqueue('closed', (int)$t['id'], (int)$r['student_id'], (int)$chat, ['answered' => $filled, 'total' => $total]);
                }
            }
            // 3) natija e'lon qilindi
            if ($t['published'] && empty($t['tg_result_at'])) {
                $nResp = (int)val('SELECT COUNT(*) FROM responses WHERE test_id=? AND status="submitted"', [$t['id']]);
                if ($t['dirty'] && $nResp > 0 && count($t['key']) > 0) { compute_test((int)$t['id']); }
                if ((int)val('SELECT COUNT(*) FROM results WHERE test_id=?', [$t['id']]) > 0) {
                    foreach (rows('SELECT s.id, s.tg_chat_id FROM results res JOIN students s ON s.id=res.student_id WHERE res.test_id=? AND s.tg_chat_id IS NOT NULL', [$t['id']]) as $s) {
                        if (tg_enqueue('result', (int)$t['id'], (int)$s['id'], (int)$s['tg_chat_id'])) $rep['queued_result']++;
                    }
                    q('UPDATE tests SET tg_result_at=NOW() WHERE id=?', [$t['id']]);
                }
            }
        }
        qb_assign_tick();   // topshiriqlar: muddat, eslatma, natija
        $rep += tg_drain($budgetSec);
        if (tg_ready()) tg_alert_failures();
        if (random_int(1, 40) === 1) tg_cleanup();
    } finally {
        tg_unlock();
    }
    return $rep;
}

/** Yuborilmagan xabarlar bo'lsa adminga (ko'pi bilan 10 daqiqada bir marta) xabar */
function tg_alert_failures(): void
{
    $chat = (int)tg_meta('admin_chat');
    if (!$chat) return;
    $n = (int)val('SELECT COUNT(*) FROM tg_queue WHERE sent_at IS NULL AND attempts>=3 AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)');
    if ($n === 0 || time() - (int)tg_meta('last_alert', '0') < 600 || $n === (int)tg_meta('last_alert_n', '0')) return;
    tg_meta_set('last_alert', (string)time());
    tg_meta_set('last_alert_n', (string)$n);
    tg_send($chat, "⚠️ <b>" . $n . "</b> ta xabar yuborilmadi (so‘nggi 24 soat). Ko‘pincha o‘quvchi botni bloklagan. Tafsilot: Sozlamalar → Telegram.");
}

function tg_cleanup(): void
{
    q('DELETE FROM tg_tokens WHERE expires_at < DATE_SUB(NOW(), INTERVAL 1 DAY)');
    q('DELETE FROM tg_links WHERE expires_at < DATE_SUB(NOW(), INTERVAL 1 DAY)');
    q('DELETE FROM tg_log WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)');
    q('DELETE FROM tg_state WHERE updated_at < DATE_SUB(NOW(), INTERVAL 7 DAY)');
    q('DELETE FROM tg_queue WHERE sent_at IS NOT NULL AND sent_at < DATE_SUB(NOW(), INTERVAL 60 DAY)');
}

/* ---------------- Admin yordamchilari ---------------- */

function tg_stats(): array
{
    return [
        'linked' => (int)val('SELECT COUNT(*) FROM students WHERE tg_chat_id IS NOT NULL AND archived_at IS NULL'),
        'pending' => (int)val('SELECT COUNT(*) FROM tg_queue WHERE sent_at IS NULL AND attempts<3'),
        'sent' => (int)val('SELECT COUNT(*) FROM tg_queue WHERE sent_at IS NOT NULL AND error=""'),
        'failed' => (int)val('SELECT COUNT(*) FROM tg_queue WHERE sent_at IS NULL AND attempts>=3'),
    ];
}

/** Webhook o'rnatadi (HTTPS manzil kerak — Telegram talabi) */
function tg_set_webhook(): array
{
    $base = tg_site_url();
    if ($base === '') return ['ok' => false, 'desc' => 'Avval «Markaz» kartasida sayt manzilini (https://…) kiriting'];
    if (!preg_match('#^https://#i', $base) && !isset($GLOBALS['CONFIG']['tg_api'])) return ['ok' => false, 'desc' => 'Telegram faqat HTTPS manzilga yuboradi. Sayt manzili https:// bilan boshlansin'];
    $secret = tg_meta('secret');
    if ($secret === '') { $secret = bin2hex(random_bytes(24)); tg_meta_set('secret', $secret); }
    $r = tg_call('setWebhook', ['url' => $base . '/bot.php', 'secret_token' => $secret, 'allowed_updates' => ['message', 'callback_query'], 'max_connections' => 10]);
    if (!empty($r['ok'])) tg_set_commands();   // «/» menyusi
    return $r;
}
