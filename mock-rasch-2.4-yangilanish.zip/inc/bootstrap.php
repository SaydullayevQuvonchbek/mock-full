<?php
/**
 * MOCK Rasch platformasi — umumiy yuklovchi fayl.
 * Sessiya, konfiguratsiya, PDO ulanish va yordamchi funksiyalar.
 */
declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));
define('APP_NAME', 'MOCK Rasch');
define('APP_VERSION', '2.4');

mb_internal_encoding('UTF-8');
date_default_timezone_set('Asia/Tashkent');

require_once __DIR__ . '/compat.php';   // PHP 7.4 uchun (str_starts_with va h.k.)
require_once __DIR__ . '/security.php';
if (!defined('NO_SESSION')) start_secure_session();   // bot.php / cron.php sessiyasiz ishlaydi
security_headers();

$configFile = APP_ROOT . '/config.php';
if (!is_file($configFile)) {
    header('Location: install.php');
    exit;
}
$CONFIG = require $configFile;

require_once __DIR__ . '/migrate.php';
require_once __DIR__ . '/format.php';
require_once __DIR__ . '/rasch.php';
require_once __DIR__ . '/scoring.php';
require_once __DIR__ . '/charts.php';
require_once __DIR__ . '/report.php';
require_once __DIR__ . '/certs.php';
require_once __DIR__ . '/rooms.php';
require_once __DIR__ . '/telegram.php';
require_once __DIR__ . '/tg_admin.php';
require_once __DIR__ . '/tg_answers.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/sms.php';
require_once __DIR__ . '/tg_gateway.php';
require_once __DIR__ . '/notify.php';
require_once __DIR__ . '/msg_admin.php';
require_once __DIR__ . '/msg_jobs.php';
require_once __DIR__ . '/student_area.php';
require_once __DIR__ . '/qb.php';
require_once __DIR__ . '/qb_assign.php';
require_once __DIR__ . '/tg_practice.php';

function db(): PDO
{
    static $pdo = null;
    global $CONFIG;
    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
            $CONFIG['db_host'], (int)($CONFIG['db_port'] ?? 3306), $CONFIG['db_name']);
        $pdo = new PDO($dsn, $CONFIG['db_user'], $CONFIG['db_pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        // MySQL vaqtini PHP vaqt zonasiga tenglash (server UTC bo'lsa NOW() 5 soat orqada qolib, navbat va muddatlar buziladi)
        try { $pdo->exec("SET time_zone = '" . date('P') . "'"); } catch (Throwable $e) { /* huquq bo'lmasa — o'tkazib yuboramiz */ }
        ensure_schema($pdo);
    }
    return $pdo;
}

/** Sozlama: avval bazadagi `meta` jadvalidan, bo'lmasa config.php dan */
function app_setting(string $k, string $default = ''): string
{
    static $cache = null;
    global $CONFIG;
    if ($cache === null) {
        $cache = [];
        try { foreach (rows("SELECT k, v FROM meta WHERE k LIKE 'set_%'") as $r) $cache[substr($r['k'], 4)] = $r['v']; } catch (Throwable $e) {}
    }
    return (string)($cache[$k] ?? $CONFIG[$k] ?? $default);
}

function set_app_setting(string $k, string $v): void
{
    q('REPLACE INTO meta (k, v) VALUES (?, ?)', ['set_' . $k, mb_substr($v, 0, 255)]);
}

/** Bazani joriy versiyaga moslash (bir sessiyada bir marta tekshiriladi) */
function ensure_schema(PDO $pdo): void
{
    if (($_SESSION['schema_v'] ?? 0) >= DB_SCHEMA_VERSION) return;
    migrate($pdo);
    $_SESSION['schema_v'] = DB_SCHEMA_VERSION;
}

function q(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function row(string $sql, array $params = []): ?array
{
    $r = q($sql, $params)->fetch();
    return $r === false ? null : $r;
}

function rows(string $sql, array $params = []): array
{
    return q($sql, $params)->fetchAll();
}

function val(string $sql, array $params = [])
{
    $r = q($sql, $params)->fetchColumn();
    return $r === false ? null : $r;
}

function e($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $page, array $params = []): string
{
    $params = array_merge(['p' => $page], $params);
    return 'index.php?' . http_build_query($params);
}

function redirect(string $page, array $params = []): void
{
    header('Location: ' . url($page, $params));
    exit;
}

function flash(string $msg, string $type = 'ok'): void
{
    $_SESSION['flash'][] = ['msg' => $msg, 'type' => $type];
}

function take_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    $t = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF'] ?? '');
    if (!hash_equals(csrf_token(), (string)$t)) {
        http_response_code(400);
        exit('Xavfsizlik tokeni noto\'g\'ri. Sahifani yangilab qayta urinib ko\'ring.');
    }
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

/* ---------------- Autentifikatsiya ---------------- */

function admin(): ?array
{
    return $_SESSION['admin'] ?? null;
}

function require_admin(): void
{
    $a = admin();
    if (!$a) redirect('login');
    // Administrator o'chirilgan yoki paroli o'zgargan bo'lsa, eski sessiya darhol yopiladi
    static $checked = false;
    if (!$checked) {
        $checked = true;
        $h = val('SELECT pass_hash FROM users WHERE id=?', [(int)$a['id']]);
        if (!$h || !hash_equals(admin_session_sig((string)$h), (string)($a['sig'] ?? ''))) {
            unset($_SESSION['admin']);
            flash('Sessiya tugadi. Qayta kiring.', 'warn');
            redirect('login');
        }
    }
}

/** Sessiyaga bog'lanadigan imzo: parol o'zgarsa boshqa qurilmalardagi sessiyalar ham tugaydi */
function admin_session_sig(string $passHash): string
{
    return hash('sha256', 'moc-admin|' . $passHash);
}

/** Test PDF faylini diskdan o'chirish (nomi faqat kutilgan formatda bo'lsa) */
function remove_test_pdf(array $test): void
{
    $f = basename((string)($test['pdf_file'] ?? ''));
    if ($f !== '' && preg_match('/^test_\d+_[a-f0-9]{12}\.pdf$/', $f) && is_file(APP_ROOT . '/uploads/' . $f)) @unlink(APP_ROOT . '/uploads/' . $f);
}

function student(): ?array
{
    return $_SESSION['student'] ?? null;
}

function require_student(): void
{
    if (!student()) {
        redirect('student_login');
    }
    student_session_guard();   // parol o'zgargan bo'lsa chiqaradi; vaqtinchalik parol bo'lsa almashtirishga yo'naltiradi
}

function json_out($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/* ---------------- Formatlash ---------------- */

function fmt($n, int $d = 1): string
{
    if ($n === null || $n === '') return '—';
    return number_format((float)$n, $d, '.', ' ');
}

function grade_badge(?string $g): string
{
    if ($g === null || $g === '') return '<span class="badge g-none">—</span>';
    $cls = [
        'A+' => 'g-ap', 'A' => 'g-a', 'B+' => 'g-bp', 'B' => 'g-b', 'C+' => 'g-cp', 'C' => 'g-c',
    ][$g] ?? 'g-none';
    $label = $g === 'NB' ? 'Sertifikatsiz' : $g;
    return '<span class="badge ' . $cls . '">' . e($label) . '</span>';
}

function gen_student_code(): string
{
    for ($i = 0; $i < 200; $i++) {
        $code = (string)random_int(100000, 999999);
        if (!val('SELECT 1 FROM students WHERE code=?', [$code])) return $code;
    }
    throw new RuntimeException('Kod yaratib bo\'lmadi');
}

/** Vaqtinchalik parol (eski nomi saqlangan: chaqiruvchilar o'zgarmasligi uchun). inc/auth.php */
function gen_pin(): string
{
    return gen_temp_pass();
}

/** F.I.Sh qismlaridan to'liq ism */
function compose_name(string $last, string $first, string $middle = ''): string
{
    return trim(preg_replace('/\s+/u', ' ', "$last $first $middle"));
}

/** "Familiya Ism Otasining ismi" matnini qismlarga ajratish */
function split_name(string $full): array
{
    $p = preg_split('/\s+/u', trim($full), 3);
    return [$p[0] ?? '', $p[1] ?? '', $p[2] ?? ''];
}

/** Telefonni +998XXXXXXXXX ko'rinishiga keltirish; noto'g'ri bo'lsa '' */
function norm_phone(string $s): string
{
    $d = preg_replace('/\D/', '', $s);
    if (strlen($d) === 9) $d = '998' . $d;
    if (strlen($d) === 12 && str_starts_with($d, '998') && preg_match('/^998(33|50|55|61|62|65|66|67|69|70|71|72|73|74|75|76|77|78|79|88|90|91|93|94|95|97|98|99)\d{7}$/', $d)) {
        return '+' . $d;
    }
    return '';
}

function fmt_phone(string $p): string
{
    $d = preg_replace('/\D/', '', $p);
    if (strlen($d) !== 12) return $p;
    return '+' . substr($d, 0, 3) . ' ' . substr($d, 3, 2) . ' ' . substr($d, 5, 3) . ' ' . substr($d, 8, 2) . ' ' . substr($d, 10, 2);
}

/** O'quvchini kodi bo'yicha topadi yoki (ism berilsa) yaratadi. */
function find_or_create_student(string $code, string $name = '', string $group = '', ?int $centerId = null): ?array
{
    $code = preg_replace('/\D/', '', $code);
    if ($code !== '') {
        $s = row('SELECT * FROM students WHERE code=?', [$code]);
        if ($s) {
            if ($name !== '' && trim($s['full_name']) === '') {
                [$l, $f, $m] = split_name($name);
                q('UPDATE students SET full_name=?, last_name=?, first_name=?, middle_name=? WHERE id=?', [compose_name($l, $f, $m), $l, $f, $m, $s['id']]);
                $s['full_name'] = compose_name($l, $f, $m);
            }
            return $s;
        }
    }
    if ($code === '' && $name === '') return null;
    if ($code === '' || strlen($code) !== 6) $code = gen_student_code();
    [$l, $f, $m] = split_name($name);
    if ($group !== '') q('INSERT IGNORE INTO study_groups (name) VALUES (?)', [$group]);
    q('INSERT INTO students (code, full_name, last_name, first_name, middle_name, group_name, pin, center_id) VALUES (?,?,?,?,?,?,?,?)',
        [$code, compose_name($l, $f, $m), $l, $f, $m, $group, gen_pin(), $centerId]);
    return row('SELECT * FROM students WHERE code=?', [$code]);
}

function groups_list(): array
{
    return array_column(rows('SELECT name FROM study_groups ORDER BY name'), 'name');
}

/** 2.2: «Hamkor markazlar» bo'limi olib tashlandi — ro'yxat bo'sh (markaz tanlash maydonlari ko'rinmaydi; bazadagi ma'lumot saqlanadi) */
function centers_list(): array
{
    if (!defined('CENTERS_ON')) return [];
    $out = [];
    foreach (rows('SELECT id, name FROM centers ORDER BY name') as $c) $out[(int)$c['id']] = $c['name'];
    return $out;
}

function test_by_id(int $id): ?array
{
    $t = row('SELECT * FROM tests WHERE id=?', [$id]);
    if ($t) {
        $t['key'] = json_decode($t['key_json'] ?: '{}', true) ?: [];
        $t['stats'] = json_decode($t['stats_json'] ?: '{}', true) ?: [];
    }
    return $t;
}

function save_response(int $testId, int $studentId, array $answers, string $source, string $status = 'submitted'): void
{
    $json = json_encode($answers, JSON_UNESCAPED_UNICODE);
    $exists = val('SELECT id FROM responses WHERE test_id=? AND student_id=?', [$testId, $studentId]);
    if ($exists) {
        q('UPDATE responses SET answers=?, source=?, status=?, submitted_at=IF(?="submitted", NOW(), submitted_at) WHERE id=?',
            [$json, $source, $status, $status, $exists]);
    } else {
        q('INSERT INTO responses (test_id, student_id, answers, source, status, started_at, submitted_at) VALUES (?,?,?,?,?,NOW(),IF(?="submitted",NOW(),NULL))',
            [$testId, $studentId, $json, $source, $status, $status]);
    }
    q('UPDATE tests SET dirty=1 WHERE id=?', [$testId]);
}

/** Onlayn test uchun o'quvchining yakuniy muddati (unix vaqt) */
function online_deadline(array $test, array $resp): int
{
    $start = strtotime($resp['started_at'] ?? 'now');
    $dl = $start + (int)$test['duration_min'] * 60;
    if (!empty($test['online_end'])) $dl = min($dl, strtotime($test['online_end']));
    return $dl;
}

/** Test hozir onlayn topshirish uchun ochiqmi */
function online_open(array $test): bool
{
    if (!$test['online']) return false;
    $now = time();
    if (!empty($test['online_start']) && $now < strtotime($test['online_start'])) return false;
    if (!empty($test['online_end']) && $now > strtotime($test['online_end'])) return false;
    return true;
}
