<?php
// Qisqa manzil: sayt.uz/kabinet/ → o'quvchining shaxsiy kabineti (kirmagan bo'lsa — kirish sahifasi)
$base = rtrim(str_replace('\\', '/', dirname(dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/kabinet/index.php')))), '/');
header('Location: ' . $base . '/index.php?p=kabinet', true, 302);
exit;
