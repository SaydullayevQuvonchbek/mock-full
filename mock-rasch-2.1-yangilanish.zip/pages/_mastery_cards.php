<?php
defined('APP_ROOT') || exit;
/**
 * O'zlashtirish kartalari (o'quvchi kabineti, mashq sahifasi va admin tafsiloti uchun umumiy).
 * Kutiladi: $m = qb_mastery(sid), $mock = student_section_avg(student_history(sid)).
 */
$mockAny = false;
foreach ($mock as $x) if ((int)$x['total'] > 0) $mockAny = true;
?>
<div class="grid2 mastery">
  <div class="card">
    <h3>MOCK bo'limlari</h3>
    <?php if (!$mockAny): ?><p class="muted small">E'lon qilingan MOCK natijasi hali yo'q.</p><?php else: ?>
    <div class="qb-secbars">
      <?php foreach ($mock as $x): if ((int)$x['total'] === 0) continue; $p = (int)$x['pct']; ?>
        <div class="qb-secbar"><span><?= e($x['name']) ?></span><div class="qb-track" role="img" aria-label="<?= $p ?>%"><i style="width:<?= $p ?>%" class="<?= pct_cls($p) ?>"></i></div><b><?= $p ?>%</b></div>
      <?php endforeach; ?>
    </div>
    <p class="small muted mt">Barcha e'lon qilingan MOCK lar bo'yicha to'g'ri javoblar ulushi.</p>
    <?php endif; ?>
  </div>
  <div class="card">
    <h3>Savollar bazasi bo'limlari</h3>
    <?php if (!$m): ?><p class="muted small">Hali yakunlangan mashq yoki topshiriq yo'q.</p><?php else: ?>
    <div class="qb-secbars">
      <?php foreach ($m as $x): $p = (int)$x['pct']; ?>
        <div class="qb-secbar<?= $x['depth'] ? ' sub' : '' ?>"><span style="padding-left: <?= $x['depth'] * 1.1 ?>rem"><?= $x['depth'] ? '· ' : '' ?><?= e($x['name']) ?></span><div class="qb-track" role="img" aria-label="<?= $p ?>%"><i style="width:<?= $p ?>%" class="<?= pct_cls($p) ?>"></i></div><b><?= $p ?>% <span class="muted small"><?= (int)$x['k'] ?>/<?= (int)$x['n'] ?></span></b></div>
      <?php endforeach; ?>
    </div>
    <p class="small muted mt">Mashq testlari va topshiriqlardagi javoblar asosida.</p>
    <?php endif; ?>
  </div>
</div>
