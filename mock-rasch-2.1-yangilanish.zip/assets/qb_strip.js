/* Savol rasmidan boshidagi savol raqamini ("7.", "12)", "(3)") olib tashlash.
   Ikki usul:
   1) "Osilgan" raqam — raqam alohida chap ustunda, matn o'ngroqdan boshlanadi, pastki qatorlarda o'sha ustun bo'sh.
      Rasmning o'zidan aniqlanadi (skaner, PNG, PDF — hammasida ishlaydi): chap ustun qirqib tashlanadi.
   2) Qator ichidagi raqam ("7. Hisoblang..." keyingi qator chap chetdan) — faqat PDF matn qatlami aytgan joy oq bilan bo'yaladi.
   Ishonch bo'lmasa rasmga tegilmaydi. */
(function () {
  'use strict';
  const INK = 215;

  function ink(d, k) { return d[k + 3] > 40 && (d[k] * 3 + d[k + 1] * 6 + d[k + 2]) / 10 < INK; }

  function profile(ctx, x, y, w, h) {
    const d = ctx.getImageData(x, y, w, h).data;
    const rows = new Uint32Array(h), cols = new Uint32Array(w);
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) if (ink(d, (j * w + i) * 4)) { rows[j]++; cols[i]++; }
    return { rows, cols };
  }

  /** Yozuv chegarasi bo'yicha qayta qirqish (pad piksel bo'sh joy qoldirib) */
  function trim(c, pad) {
    const ctx = c.getContext('2d', { willReadFrequently: true });
    const p = profile(ctx, 0, 0, c.width, c.height);
    let x0 = -1, x1 = -1, y0 = -1, y1 = -1;
    for (let i = 0; i < p.cols.length; i++) if (p.cols[i]) { if (x0 < 0) x0 = i; x1 = i; }
    for (let j = 0; j < p.rows.length; j++) if (p.rows[j]) { if (y0 < 0) y0 = j; y1 = j; }
    if (x0 < 0) return c;
    const sx = Math.max(0, x0 - pad), sy = Math.max(0, y0 - pad);
    const w = Math.min(c.width, x1 + pad + 1) - sx, h = Math.min(c.height, y1 + pad + 1) - sy;
    const o = document.createElement('canvas'); o.width = w; o.height = h;
    const oc = o.getContext('2d', { willReadFrequently: true });
    oc.fillStyle = '#fff'; oc.fillRect(0, 0, w, h); oc.drawImage(c, sx, sy, w, h, 0, 0, w, h);
    return o;
  }

  /** Birinchi qator chegarasi: [y0, y1] (kamida 3 piksel bo'sh qator bilan ajralgan) */
  function firstLine(rows) {
    let y0 = -1, y1 = -1, blank = 0;
    for (let j = 0; j < rows.length; j++) {
      if (rows[j]) { if (y0 < 0) y0 = j; y1 = j; blank = 0; }
      else if (y0 >= 0 && ++blank >= 3) break;
    }
    return y0 < 0 ? null : [y0, y1];
  }

  /** Ustun profilidagi yozuv bo'laklari (kichik oraliqlar birlashtiriladi) */
  function runs(cols, merge) {
    const out = []; let s = -1, e = -1;
    for (let i = 0; i < cols.length; i++) {
      if (cols[i]) { if (s < 0) s = i; else if (i - e - 1 > merge) { out.push([s, e]); s = i; } e = i; }
    }
    if (s >= 0) out.push([s, e]);
    return out;
  }

  /**
   * c: oq fonli canvas (qirqilgan savol). hint: PDF matn qatlamidan raqam joyi {x0,y0,x1,y1,num} (canvas koordinatalarida) yoki null.
   * Qaytaradi: {canvas, changed, how, num}
   */
  function strip(c, hint, pad) {
    pad = pad == null ? 9 : pad;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    const W = c.width, H = c.height;
    const all = profile(ctx, 0, 0, W, H);
    const fl = firstLine(all.rows);
    if (!fl) return { canvas: c, changed: false };
    const lineH = fl[1] - fl[0] + 1;
    if (lineH < 6 || lineH > H * 0.8) return { canvas: c, changed: false };   // birinchi "qator" — chizma bo'lishi mumkin
    const band = profile(ctx, 0, fl[0], W, lineH).cols;
    const r = runs(band, Math.max(1, Math.round(lineH * 0.12)));
    // raqam ortidagi nuqta/qavs alohida bo'lak bo'lib qolishi mumkin ("1" + "." qalin shriftda) — tor bo'laklarni qo'shamiz
    while (r.length >= 3 && r[1][1] - r[1][0] + 1 <= lineH * 0.4 && r[1][0] - r[0][1] - 1 <= lineH * 0.35 && r[1][1] - r[0][0] + 1 <= lineH * 2.4) {
      r.splice(0, 2, [r[0][0], r[1][1]]);
    }
    if (r.length >= 2) {
      const [bx0, bx1] = r[0], nx = r[1][0];
      const bw = bx1 - bx0 + 1, gap = nx - bx1 - 1;
      // 1) osilgan raqam: tor bo'lak, keyin keng bo'sh joy, pastda shu ustun bo'sh
      if (bw >= lineH * 0.2 && bw <= lineH * 2.4 && gap >= lineH * 0.45) {
        const below = fl[1] + 1 < H ? profile(ctx, 0, fl[1] + 1, Math.min(W, nx), H - fl[1] - 1).cols : new Uint32Array(0);
        let emptyBelow = true;
        for (let i = 0; i <= Math.min(bx1 + Math.floor(gap / 2), below.length - 1); i++) if (below[i]) { emptyBelow = false; break; }
        const hintOk = !hint || (hint.x0 <= bx1 + 2 && hint.x1 >= bx0 - 2);
        if (emptyBelow && hintOk) {
          const cut = Math.max(0, nx - 2);
          const o = document.createElement('canvas'); o.width = W - cut; o.height = H;
          const oc = o.getContext('2d', { willReadFrequently: true });
          oc.fillStyle = '#fff'; oc.fillRect(0, 0, o.width, H); oc.drawImage(c, cut, 0, W - cut, H, 0, 0, W - cut, H);
          return { canvas: trim(o, pad), changed: true, how: 'ustun', num: hint ? hint.num : null };
        }
      }
    }
    // 2) qator ichidagi raqam — faqat PDF matn qatlami ko'rsatsa
    if (hint && hint.y0 <= fl[1] && hint.y1 >= fl[0] - lineH * 0.3 && hint.x0 < (r.length ? r[0][1] + lineH : W)) {
      const o = document.createElement('canvas'); o.width = W; o.height = H;
      const oc = o.getContext('2d', { willReadFrequently: true });
      oc.drawImage(c, 0, 0);
      oc.fillStyle = '#fff';
      oc.fillRect(Math.max(0, hint.x0 - 2), Math.max(0, Math.min(hint.y0, fl[0]) - 1), hint.x1 - hint.x0 + 4, Math.max(hint.y1, fl[1]) - Math.min(hint.y0, fl[0]) + 3);
      return { canvas: trim(o, pad), changed: true, how: 'matn', num: hint.num };
    }
    return { canvas: c, changed: false };
  }

  /* ---------- PDF matn qatlamidan raqamlar ---------- */
  const NUM_ONLY = /^\s*\(?(\d{1,3})\s*[.)]\s*$|^\s*\((\d{1,3})\)\s*$/;
  const NUM_PREFIX = /^(\s*\(?(\d{1,3})\s*[.)]\s+)\S/;

  /** pdf.js sahifasidan raqam ko'rinishidagi matn bo'laklari (canvas koordinatalarida) */
  async function pageNumbers(page, vp, lib) {
    const out = [];
    let tc;
    try { tc = await page.getTextContent(); } catch (e) { return out; }
    for (const it of tc.items) {
      const s = it.str || '';
      let m = s.match(NUM_ONLY), frac = 1, num;
      if (m) num = +(m[1] || m[2]);
      else if ((m = s.match(NUM_PREFIX))) { num = +m[2]; frac = m[1].trimEnd().length / s.length; }
      else continue;
      const t = lib.Util.transform(vp.transform, it.transform);
      const fh = Math.hypot(t[2], t[3]) || 10;
      const w = (it.width || 0) * vp.scale * frac;
      if (w <= 0) continue;
      out.push({ x0: t[4], x1: t[4] + w, y0: t[5] - fh * 0.85, y1: t[5] + fh * 0.2, num });
    }
    return out;
  }

  /** Qirqish to'rtburchagi uchun eng mos raqam (yuqori chap burchakda) — canvas koordinatasini bo'lakka o'tkazib */
  function hintFor(nums, rect) {
    let best = null;
    for (const n of nums) {
      if (n.x0 < rect.x - 2 || n.x1 > rect.x + rect.w + 2 || n.y1 < rect.y || n.y0 > rect.y + rect.h) continue;
      if (!best || n.y0 < best.y0 - 2 || (Math.abs(n.y0 - best.y0) <= 2 && n.x0 < best.x0)) best = n;
    }
    if (!best) return null;
    return { x0: best.x0 - rect.x, x1: best.x1 - rect.x, y0: best.y0 - rect.y, y1: best.y1 - rect.y, num: best.num };
  }

  window.QBStrip = { strip, pageNumbers, hintFor, trim };
})();
