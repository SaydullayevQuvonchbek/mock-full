/* Mashq testini yechish: hisoblagich, qoralama (localStorage) va yakunlashdan oldin ogohlantirish */
(function () {
  'use strict';
  const f = document.getElementById('qbSolve');
  if (!f) return;
  const key = f.dataset.key;
  const total = f.querySelectorAll('.qb-q').length;
  const done = document.getElementById('qbDone');
  const store = {
    get() { try { return JSON.parse(localStorage.getItem(key) || '{}') || {}; } catch (e) { return {}; } },
    set(v) { try { localStorage.setItem(key, JSON.stringify(v)); } catch (e) { /* xotira yo'q — e'tiborsiz */ } },
    del() { try { localStorage.removeItem(key); } catch (e) { /* e'tiborsiz */ } },
  };
  function answered() {
    let n = 0;
    f.querySelectorAll('.qb-q').forEach(q => {
      const r = q.querySelector('input[type=radio]:checked'), t = q.querySelector('.qb-open input');
      if (r || (t && t.value.trim() !== '')) n++;
    });
    return n;
  }
  function refresh() {
    done.textContent = answered();
    const d = {};
    f.querySelectorAll('.qb-q').forEach(q => {
      const pos = q.dataset.pos, r = q.querySelector('input[type=radio]:checked'), t = q.querySelector('.qb-open input');
      const v = r ? r.value : (t ? t.value : '');
      if (v) d[pos] = v;
    });
    store.set(d);
    if (f.dataset.autosave) autosave();
  }
  // topshiriqlarda javoblar serverga ham saqlanadi (muddat tugasa, saqlanganlari tekshiriladi)
  let timer = null, busy = false, again = false;
  function autosave() {
    clearTimeout(timer);
    timer = setTimeout(async function send() {
      if (busy) { again = true; return; }
      busy = true;
      try {
        const fd = new FormData(f); fd.set('action', 'save');
        f.querySelectorAll('.qb-q').forEach(q => { if (!q.querySelector('input[type=radio]:checked') && !q.querySelector('.qb-open input')) fd.append('a[' + q.dataset.pos + ']', ''); });   // tozalangan javob
        const r = await fetch(f.dataset.autosave, { method: 'POST', body: fd, credentials: 'same-origin' });
        const j = await r.json().catch(() => null);
        if (j && j.closed) { store.del(); location.reload(); return; }
      } catch (e) { /* tarmoq — keyingi o'zgarishda qayta urinadi */ }
      busy = false;
      if (again) { again = false; send(); }
    }, 1200);
  }
  // qoralamani tiklash (server qiymati yo'q bo'lsa)
  const d = store.get();
  f.querySelectorAll('.qb-q').forEach(q => {
    const pos = q.dataset.pos;
    if (d[pos] == null) return;
    const t = q.querySelector('.qb-open input');
    if (t && !t.value) t.value = d[pos];
    const radios = q.querySelectorAll('input[type=radio]');
    if (radios.length && ![...radios].some(r => r.checked)) radios.forEach(r => { if (r.value === d[pos]) r.checked = true; });
  });
  f.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.matches('input')) e.preventDefault(); });   // tasodifan yakunlab yubormaslik
  f.addEventListener('change', refresh);
  f.addEventListener('input', refresh);
  f.querySelectorAll('.qb-clear').forEach(b => b.addEventListener('click', () => {
    b.closest('.qb-q').querySelectorAll('input[type=radio]').forEach(r => { r.checked = false; });
    refresh();
  }));
  f.addEventListener('submit', e => {
    const act = (e.submitter && e.submitter.value) || 'submit';
    if (act !== 'submit') return;
    const left = total - answered();
    if (left > 0 && !confirm(left + ' ta savolga javob bermadingiz. Baribir yakunlaysizmi?')) { e.preventDefault(); return; }
    store.del();
  });
  refresh();
})();
