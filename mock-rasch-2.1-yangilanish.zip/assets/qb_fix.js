/* Savollar sahifasi: mavjud savol rasmlaridan savol raqamini olib tashlash (oldindan ko'rish → tasdiqlash → saqlash) */
(function () {
  'use strict';
  const btn = document.getElementById('qbFixBtn');
  if (!btn || !window.QBStrip) return;
  const box = document.getElementById('qbFix'), grid = document.getElementById('qbFixGrid'), msg = document.getElementById('qbFixMsg'), save = document.getElementById('qbFixSave');
  const csrf = document.querySelector('meta[name=csrf]').content;
  const api = btn.dataset.api;
  let found = [];

  const loadImg = url => new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('rasm ochilmadi')); im.src = url; });
  const toBlob = c => new Promise(r => c.toBlob(r, 'image/png'));

  btn.addEventListener('click', async () => {
    btn.disabled = true; found.forEach(f => URL.revokeObjectURL(f.url)); found = []; grid.innerHTML = ''; box.hidden = false; save.hidden = true;
    const imgs = [...document.querySelectorAll('img.qb-thumb[data-id]')];
    let done = 0;
    for (const im0 of imgs) {
      msg.textContent = 'Tekshirilmoqda: ' + (++done) + ' / ' + imgs.length;
      try {
        const im = await loadImg(im0.src);
        const c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight;
        const x = c.getContext('2d', { willReadFrequently: true }); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0);
        const r = window.QBStrip.strip(c, null, 9);
        if (!r.changed) continue;
        const blob = await toBlob(r.canvas);
        found.push({ id: im0.dataset.id, no: im0.dataset.no, blob, url: URL.createObjectURL(blob), old: im0.src, sel: true });
      } catch (e) { /* bu rasmni o'tkazib yuboramiz */ }
    }
    btn.disabled = false;
    if (!found.length) { msg.textContent = 'Bu sahifadagi savollarda alohida ustunda turgan raqam topilmadi — o\'zgartirish kerak emas.'; return; }
    msg.textContent = found.length + ' ta savolda raqam topildi. Tekshiring: chapda — hozirgi, o\'ngda — raqamsiz. Keraksizining belgisini olib tashlang.';
    found.forEach(f => {
      const d = document.createElement('div'); d.className = 'qb-fix-item';
      d.innerHTML = '<label class="check"><input type="checkbox" checked> <b>' + f.no + '-savol</b></label><div class="qb-fix-pair"><img alt="hozirgi" src="' + f.old + '"><span aria-hidden="true">→</span><img alt="raqamsiz" src="' + f.url + '"></div>';
      d.querySelector('input').onchange = e => { f.sel = e.target.checked; d.classList.toggle('off', !f.sel); };
      grid.appendChild(d);
    });
    save.hidden = false; save.textContent = 'Saqlash (' + found.length + ')';
  });

  save.addEventListener('click', async () => {
    const sel = found.filter(f => f.sel);
    if (!sel.length) { msg.textContent = 'Hech narsa belgilanmagan.'; return; }
    save.disabled = true; let ok = 0, err = '';
    for (const f of sel) {
      const fd = new FormData(); fd.append('action', 'replace'); fd.append('id', f.id); fd.append('img', f.blob, 'q.png');
      try {
        const r = await fetch(api, { method: 'POST', body: fd, headers: { 'X-CSRF': csrf }, credentials: 'same-origin' });
        let j = null; try { j = await r.json(); } catch (e) { /* sessiya tugagan */ }
        if (j && j.ok) ok++; else { err = j ? j.error : 'Sessiya tugagan bo\'lishi mumkin'; break; }
      } catch (e) { err = 'Tarmoq xatosi'; break; }
      msg.textContent = 'Saqlanmoqda: ' + ok + ' / ' + sel.length;
    }
    if (err) { msg.textContent = ok + ' ta saqlandi, xato: ' + err; save.disabled = false; return; }
    location.reload();
  });
})();
