<?php
defined('APP_ROOT') || exit;
/**
 * Telegram bot: /mashq — savollar bazasidan tasodifiy mashq testi (rasmli savollar, tugmali javoblar).
 * Yakunda faqat nechta to'g'ri topilgani (umumiy va bo'limlar bo'yicha) yuboriladi. PHP 7.4 bilan mos.
 * Holat: tg_state(step='qb', data='<test>:<pos>') — ochiq savolga matn bilan javob uchun.
 */

function tg_qb_state(int $chat, string $data): void
{
    q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'qb', $data]);
}

/** /mashq — bo'lim tanlash menyusi */
function tg_qb_menu(int $chat, array $st): void
{
    $tree = array_values(array_filter(qb_tree(), function ($s) { return $s['ready_total'] > 0; }));
    if (!$tree) { tg_send($chat, 'Hozircha mashq savollari qo‘shilmagan.'); return; }
    $kb = [];
    $open = row('SELECT id, n FROM qb_tests WHERE student_id=? AND status="open" AND via="bot" ORDER BY id DESC LIMIT 1', [$st['id']]);
    if ($open) $kb[] = [['text' => '▶️ Davom ettirish (' . (int)$open['n'] . ' ta savol)', 'callback_data' => 'qbr:' . (int)$open['id']]];
    $kb[] = [['text' => '🎲 Barcha bo‘limlar', 'callback_data' => 'qbs:0']];
    foreach (array_slice($tree, 0, 24) as $s) {
        $kb[] = [['text' => str_repeat('· ', (int)$s['depth']) . mb_strimwidth((string)$s['name'], 0, 40, '…') . ' (' . (int)$s['ready_total'] . ')', 'callback_data' => 'qbs:' . (int)$s['id']]];
    }
    tg_send($chat, "📚 <b>Mashq testi</b>\nBo‘limni tanlang — tasodifiy savollar beriladi. Yakunda nechta to‘g‘ri topganingiz ko‘rsatiladi.", ['inline_keyboard' => $kb]);
}

function tg_qb_own_test(int $tid, int $sid): ?array
{
    return row('SELECT * FROM qb_tests WHERE id=? AND student_id=? AND status="open"', [$tid, $sid]);
}

/** Savol xabaridagi tugmalarni olib tashlaydi (javob berilgach) */
function tg_qb_clear_kb(int $chat, int $msgId): void
{
    if ($msgId) tg_call('editMessageReplyMarkup', ['chat_id' => $chat, 'message_id' => $msgId, 'reply_markup' => ['inline_keyboard' => []]]);
}

/** «qb…» tugmalari */
function tg_qb_cb(int $chat, array $st, string $data, callable $cb, int $msgId = 0): void
{
    $sid = (int)$st['id'];
    if (!preg_match('/^qb([a-zA-Z]):(\d+)(?::(\d+))?(?::([A-F]))?$/', $data, $m)) { $cb(); return; }
    $act = $m[1]; $a = (int)$m[2]; $b = isset($m[3]) ? (int)$m[3] : 0; $L = $m[4] ?? '';
    qb_assign_tick();   // muddati o'tgan topshiriq javob qabul qilmasin

    if ($act === 'x') { $cb(); tg_asg_review($chat, $st, $a); return; }       // xatolarni ko'rish
    if ($act === 'w') {                                   // saytda yechish — bir martalik havola
        $own = row('SELECT id FROM qb_tests WHERE id=? AND student_id=?', [$a, $sid]);
        if (!$own) { $cb('Topilmadi', true); return; }
        $link = tg_make_link($sid, $a, 'qb');
        if ($link === null) { $cb(tg_site_url() === '' ? 'Sayt manzili sozlanmagan — markazga xabar bering' : 'Avvalgi havolalar hali amalda — bir oz kuting', true); return; }
        $cb();
        tg_send($chat, 'Havola 15 daqiqa amal qiladi va bir marta ishlaydi.', tg_kb_url('🌐 Saytda ochish', $link));
        return;
    }

    if ($act === 's') {                                   // bo'lim tanlandi → savollar soni
        $pool = qb_pool_size($a ? [$a] : []);
        if ($pool < 1) { $cb('Bu bo‘limda tayyor savol yo‘q', true); return; }
        $cb();
        $row = [];
        foreach ([5, 10, 20, 30, 45] as $n) if ($n <= $pool) $row[] = ['text' => (string)$n, 'callback_data' => 'qbn:' . $a . ':' . $n];
        if (!$row || ($pool <= 60 && !in_array($pool, [5, 10, 20, 30, 45], true))) $row[] = ['text' => 'Hammasi (' . min(60, $pool) . ')', 'callback_data' => 'qbn:' . $a . ':' . min(60, $pool)];
        tg_send($chat, 'Nechta savol bo‘lsin? (bazada ' . $pool . ' ta tayyor savol bor)', ['inline_keyboard' => array_chunk($row, 3)]);
        return;
    }
    if ($act === 'n') {                                   // test tuzish
        $open = (int)val('SELECT COUNT(*) FROM qb_tests WHERE student_id=? AND status="open" AND assign_id IS NULL', [$sid]);
        $today = (int)val('SELECT COUNT(*) FROM qb_tests WHERE student_id=? AND assign_id IS NULL AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)', [$sid]);
        if ($open >= 8) { $cb('Yakunlanmagan mashqlaringiz ko‘p. Avval ularni yakunlang (saytdagi «Mashq testlari»).', true); return; }
        if ($today >= 40) { $cb('Bugungi mashq limiti tugadi. Ertaga davom eting.', true); return; }
        [$tid, $err] = qb_build_test($sid, $a ? [$a] : [], max(1, $b), 'bot');
        if (!$tid) { $cb($err, true); return; }
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_send($chat, '🎯 Mashq tayyor: <b>' . (int)val('SELECT n FROM qb_tests WHERE id=?', [$tid]) . ' ta savol</b>. Har bir savol rasm bilan keladi — tugma bosing' . "\n" . '(ochiq savolda javobni matn bilan yuboring).');
        tg_qb_next($chat, $st, (int)$tid, 0);
        return;
    }
    $t = tg_qb_own_test($a, $sid);
    if (!$t) { $cb('Bu test topilmadi yoki yakunlangan (topshiriq muddati tugagan bo‘lishi mumkin)', true); return; }
    $tid = (int)$t['id'];

    if ($act === 'a') {                                   // javob (tugma)
        $it = row('SELECT i.given, q.kind, q.nopt FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND i.pos=?', [$tid, $b]);
        if (!$it || $it['kind'] === 'open' || $L === '' || ord($L) - 64 > ((int)$it['nopt'] === 6 ? 6 : 4)) { $cb('Bu savolga matn bilan javob bering', true); return; }
        if ((string)$it['given'] !== '' && (string)$it['given'] !== '-') { $cb('Bu savolga javob berilgan'); return; }
        q('UPDATE qb_items SET given=? WHERE test_id=? AND pos=?', [$L, $tid, $b]);
        $cb($b . '-savol → ' . $L);
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, $b);
        return;
    }
    if ($act === 'k') {                                   // o'tkazish
        $up = q('UPDATE qb_items SET given="-" WHERE test_id=? AND pos=? AND given=""', [$tid, $b]);
        if (!$up->rowCount()) { $cb('Bu savol allaqachon o‘tkazilgan yoki javob berilgan'); tg_qb_clear_kb($chat, $msgId); return; }   // qayta bosish keyingi savolni ikki marta yubormasin
        $cb('O‘tkazildi');
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, $b);
        return;
    }
    if ($act === 'f') {                                   // yakunlashni so'rash
        $cb();
        $n = (int)$t['n'];
        $done = (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given NOT IN ("","-")', [$tid]);
        tg_send($chat, "Mashqni yakunlaysizmi?\nJavob berilgan: <b>$done / $n</b>." . ($done < $n ? "\n⚠️ Javobsiz savollar noto‘g‘ri hisoblanadi." : ''), ['inline_keyboard' => [
            [['text' => '✅ Ha, yakunlash', 'callback_data' => 'qbF:' . $tid]],
            [['text' => '↩️ Davom etaman', 'callback_data' => 'qbr:' . $tid]],
        ]]);
        return;
    }
    if ($act === 'F') {                                   // yakunlash
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_finish($chat, $tid);
        return;
    }
    if ($act === 'q') {                                   // o'tkazilganlarni qayta yechish
        q('UPDATE qb_items SET given="" WHERE test_id=? AND given="-"', [$tid]);
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, 0);
        return;
    }
    if ($act === 'r') {                                   // davom ettirish
        $cb();
        tg_qb_clear_kb($chat, $msgId);
        tg_qb_next($chat, $st, $tid, 0);
        return;
    }
    $cb();
}

/** Keyingi javobsiz savolni yuboradi (bo'lmasa — yakunlash taklifi) */
function tg_qb_next(int $chat, array $st, int $tid, int $afterPos): void
{
    $t = tg_qb_own_test($tid, (int)$st['id']);
    if (!$t) { tg_send($chat, 'Bu mashq topilmadi yoki yakunlangan. /mashq'); return; }
    $left = array_map('intval', array_column(rows('SELECT pos FROM qb_items WHERE test_id=? AND given="" ORDER BY pos', [$tid]), 'pos'));
    $pos = null;
    foreach ($left as $p) if ($p > $afterPos) { $pos = $p; break; }
    if ($pos === null && $left) $pos = $left[0];
    if ($pos === null) {
        $n = (int)$t['n'];
        $done = (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given NOT IN ("","-")', [$tid]);
        $skipped = (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given="-"', [$tid]);
        $kb = [[['text' => '✅ Yakunlash', 'callback_data' => 'qbF:' . $tid]]];
        if ($skipped) $kb[] = [['text' => '↩️ O‘tkazilganlarni yechish (' . $skipped . ')', 'callback_data' => 'qbq:' . $tid]];
        q('DELETE FROM tg_state WHERE chat_id=? AND step="qb"', [$chat]);
        tg_send($chat, "Barcha savollarga o‘tdingiz.\nJavob berilgan: <b>$done / $n</b>." . ($skipped ? "\nO‘tkazilgan: <b>$skipped</b>." : ''), ['inline_keyboard' => $kb]);
        return;
    }
    tg_qb_send_question($chat, $st, $t, $pos);
}

function tg_qb_send_question(int $chat, array $st, array $t, int $pos): void
{
    $tid = (int)$t['id'];
    $it = row('SELECT i.pos, i.section_name, q.id, q.img, q.kind, q.nopt FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND i.pos=?', [$tid, $pos]);
    $path = $it ? qb_dir() . '/' . basename((string)$it['img']) : '';
    if (!$it || !is_file($path)) {                         // savol bazadan olib tashlangan — o'tkazib yuboramiz
        q('UPDATE qb_items SET given="-" WHERE test_id=? AND pos=?', [$tid, $pos]);
        tg_qb_next($chat, $st, $tid, $pos);
        return;
    }
    $cap = '<b>Savol ' . $pos . ' / ' . (int)$t['n'] . '</b> · ' . tg_h($it['section_name']);
    $kb = [];
    if ($it['kind'] === 'open') {
        $cap .= "\n\n✍️ Javobni matn bilan yuboring (kasr: <code>1/2</code>, o‘nlik: <code>0.5</code>).";
    } else {
        $row = [];
        for ($k = 0; $k < ((int)$it['nopt'] === 6 ? 6 : 4); $k++) { $L = chr(65 + $k); $row[] = ['text' => $L, 'callback_data' => 'qba:' . $tid . ':' . $pos . ':' . $L]; }
        $kb[] = $row;
    }
    $kb[] = [['text' => '⏭ O‘tkazish', 'callback_data' => 'qbk:' . $tid . ':' . $pos], ['text' => '🏁 Yakunlash', 'callback_data' => 'qbf:' . $tid]];
    tg_qb_state($chat, $tid . ':' . $pos);
    $base = ['chat_id' => $chat, 'caption' => $cap, 'parse_mode' => 'HTML', 'reply_markup' => ['inline_keyboard' => $kb]];
    $r = tg_call('sendPhoto', $base + ['photo' => new CURLFile($path, 'image/png', 'savol.png')], null, 60);
    if (!$r['ok'] && $r['code'] === 400) {                 // juda cho'zinchoq rasm kabi hollarda — fayl sifatida
        $r = tg_call('sendDocument', $base + ['document' => new CURLFile($path, 'image/png', 'savol-' . $pos . '.png')], null, 60);
    }
    if (!$r['ok']) tg_send($chat, 'Savolni yuborib bo‘lmadi. Birozdan keyin /mashq orqali davom eting.');
}

/** Ochiq savolga (yoki harf bilan) matnli javob. true — qabul qilindi */
function tg_qb_text(int $chat, array $st, array $state, string $text): bool
{
    if (!preg_match('/^(\d+):(\d+)$/', (string)$state['data'], $m)) return false;
    $tid = (int)$m[1]; $pos = (int)$m[2];
    $t = tg_qb_own_test($tid, (int)$st['id']);
    if (!$t) { q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); return false; }
    $it = row('SELECT i.given, q.kind, q.nopt FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND i.pos=?', [$tid, $pos]);
    if (!$it) return false;
    $val = trim($text);
    if ($it['kind'] === 'open') {
        if (mb_strlen($val) > 40) { tg_send($chat, 'Javob juda uzun (40 belgigacha). Eng sodda ko‘rinishda yozing.'); return true; }
    } else {
        $val = strtoupper($val);
        $max = (int)$it['nopt'] === 6 ? 'F' : 'D';
        if (!preg_match('/^[A-F]$/', $val) || $val > $max) { tg_send($chat, 'Bu savolga tugmalar bilan javob bering (A–' . $max . ').'); return true; }
    }
    q('UPDATE qb_items SET given=? WHERE test_id=? AND pos=?', [$val, $tid, $pos]);
    tg_send($chat, '✔️ ' . $pos . '-savol: <code>' . tg_h($val) . '</code>');
    tg_qb_next($chat, $st, $tid, $pos);
    return true;
}

/** Mashqni yakunlaydi va faqat sonlarni yuboradi */
function tg_qb_finish(int $chat, int $tid): void
{
    qb_finish($tid, []);
    q('DELETE FROM tg_state WHERE chat_id=? AND step="qb"', [$chat]);
    $r = qb_result($tid);
    $pct = $r['total'] > 0 ? round(100 * $r['ok'] / $r['total']) : 0;
    $asg = !empty($r['test']['assign_id']) ? row('SELECT * FROM qb_assign WHERE id=?', [(int)$r['test']['assign_id']]) : null;
    $s = "🏁 <b>" . ($asg ? 'Topshiriq topshirildi' : 'Mashq yakunlandi') . "</b>\n\nTo‘g‘ri javoblar: <b>" . $r['ok'] . ' / ' . $r['total'] . "</b> ($pct%)";
    if (count($r['sections']) > 1) {
        $s .= "\n\n<b>Bo‘limlar bo‘yicha:</b>";
        foreach ($r['sections'] as $x) $s .= "\n• " . tg_h($x['name']) . ': ' . $x['ok'] . ' / ' . $x['total'];
    }
    if ($asg && (int)$asg['review'] && $asg['closed_at'] === null) $s .= "\n\nXatolaringiz va to‘g‘ri javoblar muddat tugagach (<b>" . tg_dt($asg['deadline']) . "</b>) yuboriladi.";
    tg_send($chat, $s . "\n\nYana mashq qilish: /mashq", null);
}

/* ---------------- 2.1: topshiriqlar, o'zlashtirish, menyu ---------------- */

/** Topshiriq xabari tugmalari (botda / saytda yechish) */
function tg_asg_kb(int $tid): array
{
    return ['inline_keyboard' => [
        [['text' => '▶️ Botda yechish', 'callback_data' => 'qbr:' . $tid]],
        [['text' => '🌐 Saytda yechish', 'callback_data' => 'qbw:' . $tid]],
    ]];
}

/** Navbat: asg (yangi topshiriq), asgr/asgn (eslatma), asgd (muddat tugadi — natija) */
function tg_asg_job(array $j): array
{
    $a = row('SELECT * FROM qb_assign WHERE id=?', [(int)$j['test_id']]);
    if (!$a) return ['ok' => true, 'skip' => 'topshiriq o‘chirilgan'];
    $t = qb_assign_test((int)$a['id'], (int)$j['student_id']);
    if (!$t) return ['ok' => true, 'skip' => 'o‘quvchiga biriktirilmagan'];
    $chat = (int)$j['chat_id'];
    $dl = tg_dt($a['deadline']);
    if ($j['kind'] === 'asg') {
        if ($t['status'] !== 'open') return ['ok' => true, 'skip' => 'topshirgan'];
        $s = "📋 <b>Yangi topshiriq</b>\n\n<b>" . tg_h($a['title']) . "</b>\nSavollar: <b>" . (int)$t['n'] . " ta</b>\nMuddat: <b>$dl</b> gacha"
           . ((int)$a['review'] ? "\n\nMuddat tugagach qaysi savollarda xato qilganingiz va to‘g‘ri javoblar ko‘rsatiladi." : '')
           . "\n\nBotda yoki saytda yechishingiz mumkin — javoblar bitta joyga saqlanadi.";
        return tg_send($chat, $s, tg_asg_kb((int)$t['id']));
    }
    if ($j['kind'] === 'asgr' || $j['kind'] === 'asgn') {
        if ($t['status'] !== 'open' || $a['closed_at'] !== null) return ['ok' => true, 'skip' => 'topshirgan'];
        $done = (int)val('SELECT COUNT(*) FROM qb_items WHERE test_id=? AND given NOT IN ("","-")', [$t['id']]);
        $s = "⏰ <b>" . tg_h($a['title']) . "</b>\nMuddat: <b>$dl</b>" . ($j['kind'] === 'asgr' ? ' — 1 soatdan kam qoldi!' : '')
           . "\nJavob berilgan: <b>$done / " . (int)$t['n'] . "</b>" . ($done === 0 ? "\n⚠️ Hali boshlamadingiz." : '');
        return tg_send($chat, $s, tg_asg_kb((int)$t['id']));
    }
    if ($j['kind'] === 'asgd') {
        $t = row('SELECT * FROM qb_tests WHERE id=?', [$t['id']]);
        if (!$t || $t['status'] !== 'done') return ['ok' => true, 'skip' => 'yakunlanmagan'];
        $r = qb_result((int)$t['id']);
        $pct = $r['total'] > 0 ? round(100 * $r['ok'] / $r['total']) : 0;
        $s = "🏁 <b>" . tg_h($a['title']) . "</b> — muddat tugadi\n\nNatijangiz: <b>" . $r['ok'] . ' / ' . $r['total'] . "</b> ($pct%)";
        if (count($r['sections']) > 1) foreach ($r['sections'] as $x) $s .= "\n• " . tg_h($x['name']) . ': ' . $x['ok'] . ' / ' . $x['total'];
        $kb = (int)$a['review'] && $r['ok'] < $r['total'] ? tg_kb_cb('🔍 Xatolarimni ko‘rish', 'qbx:' . (int)$t['id']) : null;
        return tg_send($chat, $s, $kb);
    }
    return ['ok' => true, 'skip' => 'noma’lum tur'];
}

/** «📋 Topshiriqlar»: ochiq va yaqinda yopilgan topshiriqlar */
function tg_asg_list(int $chat, array $st): void
{
    qb_assign_tick();
    $list = rows('SELECT t.*, a.deadline, a.closed_at, a.review FROM qb_tests t JOIN qb_assign a ON a.id=t.assign_id WHERE t.student_id=? AND (t.status="open" OR a.closed_at IS NULL OR a.closed_at > DATE_SUB(NOW(), INTERVAL 14 DAY)) ORDER BY t.status="open" DESC, a.deadline LIMIT 10', [$st['id']]);
    if (!$list) { tg_send($chat, '📋 Hozircha topshiriq yo‘q. Mashq qilish: /mashq'); return; }
    foreach ($list as $t) {
        $s = "📋 <b>" . tg_h($t['title']) . "</b>\n" . (int)$t['n'] . ' ta savol · muddat: <b>' . tg_dt($t['deadline']) . '</b>';
        if ($t['status'] === 'open') { tg_send($chat, $s, tg_asg_kb((int)$t['id'])); continue; }
        $s .= "\nNatija: <b>" . (int)$t['correct'] . ' / ' . (int)$t['n'] . '</b>';
        $kb = null;
        if ((int)$t['review'] && $t['closed_at'] !== null) $kb = tg_kb_cb('🔍 Xatolarimni ko‘rish', 'qbx:' . (int)$t['id']);
        elseif ((int)$t['review']) $s .= "\nXatolar muddat tugagach ko‘rsatiladi.";
        tg_send($chat, $s, $kb);
    }
}

/** Muddatdan keyin: xato savollar (rasm + sizning javob + to'g'ri javob) */
function tg_asg_review(int $chat, array $st, int $tid): void
{
    $t = row('SELECT * FROM qb_tests WHERE id=? AND student_id=?', [$tid, $st['id']]);
    if (!$t || !qb_review_allowed($t)) { tg_send($chat, 'Xatolar topshiriq muddati tugagach ko‘rsatiladi.'); return; }
    $items = qb_review_items($tid);
    $lines = [];
    $wrong = [];
    foreach ($items as $it) {
        if ($it['ok'] === null) continue;
        $g = $it['given'] !== '' && $it['given'] !== '-' ? $it['given'] : '—';
        if ((int)$it['ok'] === 1) $lines[] = (int)$it['pos'] . '. ✅ ' . tg_h($g);
        else { $lines[] = (int)$it['pos'] . '. ❌ ' . tg_h($g) . ' → <b>' . tg_h(qb_answer_show($it['kind'], $it['answer'])) . '</b>'; $wrong[] = $it; }
    }
    tg_send($chat, "🔍 <b>" . tg_h($t['title']) . "</b>\n\n" . implode("\n", $lines));
    foreach (array_slice($wrong, 0, 10) as $it) {
        $path = qb_dir() . '/' . basename((string)$it['img']);
        if (!$it['img'] || !is_file($path)) continue;
        $cap = '<b>' . (int)$it['pos'] . '-savol</b> · ' . tg_h($it['section_name']) . "\nSizning javob: <b>" . tg_h($it['given'] !== '' && $it['given'] !== '-' ? $it['given'] : '—') . "</b>\nTo‘g‘ri javob: <b>" . tg_h(qb_answer_show($it['kind'], $it['answer'])) . '</b>';
        $r = tg_call('sendPhoto', ['chat_id' => $chat, 'caption' => $cap, 'parse_mode' => 'HTML', 'photo' => new CURLFile($path, 'image/png', 'savol.png')], null, 60);
        if (!$r['ok'] && $r['code'] === 400) tg_call('sendDocument', ['chat_id' => $chat, 'caption' => $cap, 'parse_mode' => 'HTML', 'document' => new CURLFile($path, 'image/png', 'savol-' . (int)$it['pos'] . '.png')], null, 60);
    }
    if (count($wrong) > 10) tg_send($chat, 'Qolgan ' . (count($wrong) - 10) . ' ta xato savolni saytdagi «Topshiriq va mashq» bo‘limida ko‘ring.');
}

/** «📈 O'zlashtirish» matni */
function tg_mastery_text(array $st): string
{
    $sid = (int)$st['id'];
    $bar = function (int $p): string { $n = (int)round($p / 10); return str_repeat('▰', $n) . str_repeat('▱', 10 - $n); };
    $s = "📈 <b>O‘zlashtirishim</b>";
    $mock = student_section_avg(student_history($sid));
    $any = false;
    foreach ($mock as $x) if ((int)$x['total'] > 0) { if (!$any) $s .= "\n\n<b>MOCK bo‘limlari:</b>"; $any = true; $s .= "\n" . $bar((int)$x['pct']) . ' ' . (int)$x['pct'] . '% — ' . tg_h($x['name']); }
    $m = qb_mastery($sid);
    if ($m) {
        $s .= "\n\n<b>Savollar bazasi bo‘limlari:</b>";
        foreach (array_slice($m, 0, 25) as $x) $s .= "\n" . str_repeat('  ', (int)$x['depth']) . ($x['depth'] ? '· ' : '') . $bar((int)$x['pct']) . ' ' . (int)$x['pct'] . '% — ' . tg_h($x['name']) . ' <i>(' . (int)$x['k'] . '/' . (int)$x['n'] . ')</i>';
        $weak = array_values(array_filter($m, fn($x) => $x['pct'] < 50 && $x['n'] >= 3));
        if ($weak) $s .= "\n\n💡 Ko‘proq ishlash kerak: " . implode(', ', array_map(fn($x) => tg_h($x['name']), array_slice($weak, 0, 3))) . '. /mashq';
    }
    if (!$any && !$m) $s .= "\n\nHali ma’lumot yo‘q — mashq qiling (/mashq) yoki MOCK natijasini kuting.";
    return $s;
}
