/* Savollar bazasi: PDF/rasm dan savollarni qirqish va yuklash (hammasi brauzerda; serverga tayyor PNG ketadi) */
(function () {
  'use strict';
  const cfg = window.QB;
  const csrf = document.querySelector('meta[name=csrf]').content;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const toBlob = (c, type) => new Promise(r => c.toBlob(r, type || 'image/png'));

  let pieces = [];          // {blob,url,w,h,label,src,sel,lv}  lv: null — umumiy daraja (yuqoridagi tanlov)
  const LV = cfg.levels || { 1: 'Oson', 2: "O'rta", 3: 'Qiyin' };
  const batchLevel = () => +($('qbLevel') && $('qbLevel').value) || 0;
  const pieceLevel = p => p.lv || batchLevel();
  let pdfLoading = null;
  let manual = null;        // {pdf|img, n, cur, name}
  let busy = false;

  /* ---------- pdf.js ---------- */
  function loadPdfJs() {
    if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
    if (pdfLoading) return pdfLoading;
    pdfLoading = new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = cfg.pdfjs;
      s.onload = () => { window.pdfjsLib.GlobalWorkerOptions.workerSrc = cfg.worker; res(window.pdfjsLib); };
      s.onerror = () => rej(new Error('PDF o\'quvchi yuklanmadi. PNG/JPG rasm yuklab ko\'ring.'));
      document.head.appendChild(s);
    });
    return pdfLoading;
  }

  /* ---------- kalit matnini tahlil qilish (server bilan bir xil qoida) ---------- */
  function parseKey(s) {
    s = (s || '').trim();
    const out = {};
    if (!s) return out;
    const compact = s.replace(/[\s,]+/g, '');
    if (/^[A-Fa-f]+$/.test(compact)) { compact.toUpperCase().split('').forEach((c, i) => { out[i + 1] = c; }); return out; }
    if (/^(?:\d{1,3}[A-Fa-f])+$/.test(compact)) { compact.replace(/(\d{1,3})([A-Fa-f])/g, (_, n, c) => { out[+n] = c.toUpperCase(); return ''; }); return out; }
    let pos = 0;
    s.split(/\s+/).filter(Boolean).forEach(tok => {
      const m = tok.match(/^(\d{1,3})[:=)](.+)$/);
      let v;
      if (m) { pos = +m[1]; v = m[2]; } else { pos++; v = tok; }
      out[pos] = v;
    });
    return out;
  }

  /* ---------- sahifani rasmga aylantirish ---------- */
  function newCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h));
    const x = c.getContext('2d', { willReadFrequently: true });
    x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
    return c;
  }

  async function renderPdfPage(pdf, n, target) {
    const page = await pdf.getPage(n);
    const v0 = page.getViewport({ scale: 1 });
    const scale = Math.max(1, Math.min(2, 1800 / v0.width));
    const vp = page.getViewport({ scale });
    const c = target || newCanvas(vp.width, vp.height);
    if (target) { c.width = Math.round(vp.width); c.height = Math.round(vp.height); }
    const x = c.getContext('2d', { willReadFrequently: true });
    x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
    await page.render({ canvasContext: x, viewport: vp }).promise;
    c.qbNums = window.QBStrip ? await window.QBStrip.pageNumbers(page, vp, window.pdfjsLib) : [];   // savol raqamlari joyi (matn qatlami)
    return c;
  }

  function loadImage(file) {
    return new Promise((res, rej) => {
      const url = URL.createObjectURL(file);
      const im = new Image();
      im.onload = () => {
        const w = Math.min(im.naturalWidth, 2400), k = w / im.naturalWidth;
        const c = newCanvas(w, im.naturalHeight * k);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url); res(c);
      };
      im.onerror = () => { URL.revokeObjectURL(url); rej(new Error(file.name + ' — rasm ochilmadi')); };
      im.src = url;
    });
  }

  /* ---------- tahlil: qora piksellar profili ---------- */
  function inkProfile(canvas, box) {
    const d = canvas.getContext('2d', { willReadFrequently: true }).getImageData(box.x, box.y, box.w, box.h).data;
    const rows = new Uint32Array(box.h), cols = new Uint32Array(box.w);
    for (let j = 0; j < box.h; j++) {
      for (let i = 0; i < box.w; i++) {
        const k = (j * box.w + i) * 4;
        if (d[k + 3] > 40 && (d[k] * 3 + d[k + 1] * 6 + d[k + 2]) / 10 < 215) { rows[j]++; cols[i]++; }
      }
    }
    return { rows, cols };
  }

  /** Qator profilidan bo'sh oraliqlar bo'yicha bloklar: [{y0,y1}] */
  function splitRows(rows, gapMin, minH) {
    const out = [];
    let start = -1, gap = 0, last = -1;
    for (let j = 0; j < rows.length; j++) {
      if (rows[j] > 0) { if (start < 0) start = j; last = j; gap = 0; }
      else if (start >= 0) { gap++; if (gap >= gapMin) { out.push({ y0: start, y1: last }); start = -1; gap = 0; } }
    }
    if (start >= 0) out.push({ y0: start, y1: last });
    return out.filter(b => b.y1 - b.y0 + 1 >= minH);
  }

  /** Ikki ustunli sahifada ustunlar orasidagi bo'sh yo'lak (markazga yaqin): x yoki 0 */
  function findColGap(cols) {
    const w = cols.length, lo = Math.floor(w * 0.3), hi = Math.floor(w * 0.7);
    let best = 0, bestStart = 0, run = 0, runStart = 0;
    for (let i = lo; i <= hi; i++) {
      if (cols[i] === 0) { if (!run) runStart = i; run++; if (run > best) { best = run; bestStart = runStart; } } else run = 0;
    }
    return best >= 8 ? Math.round(bestStart + best / 2) : 0;
  }

  /** Berilgan to'rtburchak ichidagi yozuv chegarasi bo'yicha qirqib, PNG qiladi */
  async function cropPiece(canvas, rect, pad, label, src) {
    const prof = inkProfile(canvas, rect);
    let x0 = -1, x1 = -1, y0 = -1, y1 = -1;
    for (let i = 0; i < prof.cols.length; i++) if (prof.cols[i] > 0) { if (x0 < 0) x0 = i; x1 = i; }
    for (let j = 0; j < prof.rows.length; j++) if (prof.rows[j] > 0) { if (y0 < 0) y0 = j; y1 = j; }
    if (x0 < 0) return null;
    const sx = Math.max(0, rect.x + x0 - pad), sy = Math.max(0, rect.y + y0 - pad);
    const ex = Math.min(canvas.width, rect.x + x1 + pad + 1), ey = Math.min(canvas.height, rect.y + y1 + pad + 1);
    const w = ex - sx, h = ey - sy;
    if (w < 20 || h < 14) return null;
    let c = newCanvas(w, h);
    c.getContext('2d').drawImage(canvas, sx, sy, w, h, 0, 0, w, h);
    if (opts().strip && window.QBStrip) {
      const hint = canvas.qbNums ? window.QBStrip.hintFor(canvas.qbNums, { x: sx, y: sy, w, h }) : null;
      const r = window.QBStrip.strip(c, hint, pad);
      if (r.changed) {
        const orig = await makePiece(c, label, src);
        const p = await makePiece(r.canvas, label + (r.num ? ' №' + r.num : ''), src);
        p.orig = orig; p.num = r.num || null;
        return p;
      }
    }
    return makePiece(c, label, src);
  }

  async function makePiece(c, label, src) {
    let blob = await toBlob(c);
    if (blob.size > 3.8 * 1024 * 1024) {           // juda katta — sifatni biroz tushiramiz
      const k = 0.7, d = newCanvas(c.width * k, c.height * k);
      d.getContext('2d').drawImage(c, 0, 0, d.width, d.height);
      blob = await toBlob(d); c = d;
    }
    return { blob, url: URL.createObjectURL(blob), w: c.width, h: c.height, label, src, sel: true, lv: null };
  }

  /* ---------- sozlamalar ---------- */
  function opts() {
    return {
      mode: (document.querySelector('input[name=qbMode]:checked') || {}).value || 'auto',
      cols: +$('qbCols').value, gap: Math.max(4, +$('qbGap').value || 26),
      top: Math.max(0, Math.min(30, +$('qbTop').value || 0)), bot: Math.max(0, Math.min(30, +$('qbBot').value || 0)),
      strip: !$('qbStrip') || $('qbStrip').checked,
    };
  }

  async function pagePieces(canvas, label, src, o) {
    const h0 = Math.floor(canvas.height * o.top / 100);
    const box = { x: 0, y: h0, w: canvas.width, h: Math.max(10, Math.floor(canvas.height * (1 - (o.top + o.bot) / 100))) };
    box.h = Math.min(box.h, canvas.height - box.y);
    const out = [];
    if (o.mode === 'page') {
      const p = await cropPiece(canvas, box, 10, label, src);
      if (p) out.push(p);
      return out;
    }
    let colsDef = [{ x: 0, w: canvas.width }];
    if (o.cols === 2) {
      const sx = findColGap(inkProfile(canvas, box).cols);
      if (sx) colsDef = [{ x: 0, w: sx }, { x: sx, w: canvas.width - sx }];
    }
    let n = 0;
    for (const col of colsDef) {
      const b = { x: col.x, y: box.y, w: col.w, h: box.h };
      const ranges = splitRows(inkProfile(canvas, b).rows, o.gap, 10);
      for (const r of ranges) {
        const p = await cropPiece(canvas, { x: b.x, y: b.y + r.y0, w: b.w, h: r.y1 - r.y0 + 1 }, 9, label + '-' + (++n), src);
        if (p) out.push(p);
      }
    }
    return out;
  }

  /* ---------- asosiy oqim ---------- */
  function setStatus(t) { $('qbStatus').textContent = t || ''; }

  async function run() {
    if (busy) return;
    const files = [...$('qbFile').files];
    if (!files.length) return;
    const o = opts();
    busy = true; $('qbGo').disabled = true;
    clearPieces(); $('qbManual').hidden = true; manual = null;
    try {
      if (o.mode === 'manual') {
        const f = files[0];
        if (isPdf(f)) { const lib = await loadPdfJs(); const pdf = await lib.getDocument({ data: await f.arrayBuffer(), isEvalSupported: false }).promise; manual = { pdf, n: pdf.numPages, cur: 1, name: f.name }; }
        else manual = { img: await loadImage(f), n: 1, cur: 1, name: f.name };
        $('qbManual').hidden = false;
        await showManualPage();
        $('qbPieces').hidden = false; renderPieces();
        setStatus('Sahifalarda savollarni chizib belgilang.');
        return;
      }
      for (const f of files) {
        if (isPdf(f)) {
          const lib = await loadPdfJs();
          const pdf = await lib.getDocument({ data: await f.arrayBuffer(), isEvalSupported: false }).promise;
          for (let n = 1; n <= pdf.numPages; n++) {
            setStatus(f.name + ': ' + n + '/' + pdf.numPages + '-bet…');
            const c = await renderPdfPage(pdf, n);
            pieces.push(...await pagePieces(c, 's' + n, f.name + ' ' + n + '-bet', o));
            c.width = c.height = 1;               // xotirani bo'shatish
            if (n % 3 === 0) renderPieces();
          }
        } else {
          setStatus(f.name + '…');
          const c = await loadImage(f);
          pieces.push(...await pagePieces(c, f.name.replace(/\.[^.]+$/, '').slice(0, 20), f.name, o));
        }
      }
      setStatus(pieces.length ? 'Tayyor: ' + pieces.length + ' ta savol topildi. Tekshiring va yuklang.' : 'Savol topilmadi. "Bo\'sh joy" ni kamaytirib yoki "Qo\'lda" rejimida urinib ko\'ring.');
      $('qbPieces').hidden = !pieces.length; renderPieces();
    } catch (e) {
      setStatus('Xato: ' + e.message);
    } finally { busy = false; $('qbGo').disabled = false; }
  }

  function isPdf(f) { return f.type === 'application/pdf' || /\.pdf$/i.test(f.name); }

  function freePiece(p) { URL.revokeObjectURL(p.url); if (p.orig) URL.revokeObjectURL(p.orig.url); }
  function clearPieces() { pieces.forEach(freePiece); pieces = []; renderPieces(); $('qbMsg').textContent = ''; }

  /* ---------- ro'yxat ---------- */
  function renderPieces() {
    $('qbCount').textContent = pieces.length;
    const g = $('qbGrid');
    g.innerHTML = '';
    const bl = batchLevel();
    pieces.forEach((p, i) => {
      const d = document.createElement('div');
      const lv = pieceLevel(p);
      d.className = 'qb-piece' + (p.sel ? '' : ' off') + (lv ? ' plv' + lv : ' plv0');
      const lvSel = '<select class="qb-plv" aria-label="Qiyinlik darajasi" title="Shu savolning qiyinlik darajasi">' +
        '<option value="">' + (bl ? 'Umumiy: ' + esc(LV[bl]) : 'Daraja?') + '</option>' +
        Object.keys(LV).map(k => '<option value="' + k + '"' + (+p.lv === +k ? ' selected' : '') + '>' + esc(LV[k]) + '</option>').join('') + '</select> ';
      d.innerHTML = '<div class="qb-ph"><label class="check"><input type="checkbox" ' + (p.sel ? 'checked' : '') + '> <b>' + (i + 1) + '</b> <span class="muted small">' + esc(p.label) + '</span></label>' +
        '<span class="nowrap">' + lvSel + (p.orig ? '<button type="button" class="btn sm ghost" data-a="orig" title="' + (p.showOrig ? 'Raqamni olib tashlash' : 'Raqam bilan, asl holida yuklash') + '">' + (p.showOrig ? '✂ raqamsiz' : '↺ asl holi') + '</button> ' : '') +
        '<button type="button" class="btn sm ghost" data-a="merge" ' + (i === pieces.length - 1 ? 'disabled' : '') + ' title="Keyingi bo\'lak bilan bitta savol qilish">↓ birlashtirish</button> ' +
        '<button type="button" class="btn sm ghost" data-a="del" title="Olib tashlash" aria-label="Olib tashlash">✕</button></span></div>' +
        '<img alt="Savol ' + (i + 1) + '" src="' + p.url + '">';
      d.querySelector('input').onchange = e => { p.sel = e.target.checked; d.classList.toggle('off', !p.sel); };
      d.querySelector('.qb-plv').onchange = e => { p.lv = +e.target.value || null; renderPieces(); };
      d.querySelector('[data-a=del]').onclick = () => { freePiece(p); pieces.splice(i, 1); renderPieces(); };
      const ob = d.querySelector('[data-a=orig]');
      if (ob) ob.onclick = () => {   // raqamsiz ⇄ asl holi
        const o = p.orig;
        ['blob', 'url', 'w', 'h'].forEach(k => { const t = p[k]; p[k] = o[k]; o[k] = t; });
        p.showOrig = !p.showOrig; renderPieces();
      };
      d.querySelector('[data-a=merge]').onclick = () => mergeWithNext(i);
      g.appendChild(d);
    });
  }

  function blobImage(p) {
    return new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = p.url; });
  }

  async function mergeWithNext(i) {
    const a = pieces[i], b = pieces[i + 1];
    if (!a || !b) return;
    const [ia, ib] = await Promise.all([blobImage(a), blobImage(b)]);
    const gap = 12, c = newCanvas(Math.max(a.w, b.w), a.h + gap + b.h);
    const x = c.getContext('2d');
    x.drawImage(ia, 0, 0); x.drawImage(ib, 0, a.h + gap);
    const m = await makePiece(c, a.label + '+', a.src);
    m.sel = a.sel || b.sel; m.lv = a.lv || b.lv || null;
    freePiece(a); freePiece(b);
    pieces.splice(i, 2, m);
    renderPieces();
  }

  /* ---------- qo'lda qirqish ---------- */
  async function showManualPage() {
    const m = manual; if (!m) return;
    $('qbPageNo').textContent = m.cur + ' / ' + m.n + '-bet';
    $('qbPrev').disabled = m.cur <= 1; $('qbNext').disabled = m.cur >= m.n;
    const cv = $('qbCanvas');
    if (m.pdf) await renderPdfPage(m.pdf, m.cur, cv);
    else { cv.width = m.img.width; cv.height = m.img.height; cv.qbNums = null; cv.getContext('2d', { willReadFrequently: true }).drawImage(m.img, 0, 0); }
    $('qbSel').hidden = true;
  }

  (function setupViewer() {
    const cv = $('qbCanvas'), box = $('qbSel');
    let start = null;
    const pt = e => { const r = cv.getBoundingClientRect(); return { x: Math.max(0, Math.min(cv.width, (e.clientX - r.left) * cv.width / r.width)), y: Math.max(0, Math.min(cv.height, (e.clientY - r.top) * cv.height / r.height)), px: e.clientX - r.left, py: e.clientY - r.top }; };
    cv.addEventListener('pointerdown', e => { start = pt(e); cv.setPointerCapture(e.pointerId); box.hidden = false; e.preventDefault(); });
    cv.addEventListener('pointermove', e => {
      if (!start) return;
      const p = pt(e);
      box.style.left = Math.min(start.px, p.px) + 'px'; box.style.top = Math.min(start.py, p.py) + 'px';
      box.style.width = Math.abs(p.px - start.px) + 'px'; box.style.height = Math.abs(p.py - start.py) + 'px';
    });
    cv.addEventListener('pointerup', async e => {
      if (!start) return;
      const p = pt(e), s = start; start = null; box.hidden = true;
      const rect = { x: Math.floor(Math.min(s.x, p.x)), y: Math.floor(Math.min(s.y, p.y)), w: Math.ceil(Math.abs(p.x - s.x)), h: Math.ceil(Math.abs(p.y - s.y)) };
      if (rect.w < 24 || rect.h < 16) return;
      const piece = await cropPiece(cv, rect, 9, 's' + manual.cur + '-' + (pieces.filter(q => q.label.indexOf('s' + manual.cur + '-') === 0).length + 1), manual.name + ' ' + manual.cur + '-bet');
      if (piece) { pieces.push(piece); $('qbPieces').hidden = false; renderPieces(); setStatus(pieces.length + ' ta savol qo\'shildi.'); }
      else setStatus('Tanlangan joyda yozuv topilmadi.');
    });
    $('qbPrev').onclick = () => { if (manual && manual.cur > 1) { manual.cur--; showManualPage(); } };
    $('qbNext').onclick = () => { if (manual && manual.cur < manual.n) { manual.cur++; showManualPage(); } };
  })();

  /* ---------- yuklash ---------- */
  async function upload() {
    if (busy) return;
    const sel = pieces.filter(p => p.sel);
    if (!sel.length) { $('qbMsg').textContent = 'Yuklash uchun kamida bitta savolni belgilang.'; return; }
    const noLv = sel.filter(p => !pieceLevel(p)).length;
    if (noLv) {   // daraja majburiy: topshiriqlar daraja bo'yicha tuziladi
      $('qbMsg').textContent = 'Qiyinlik darajasini tanlang: yuqoridagi «Qiyinlik darajasi» (hammasiga) yoki har bir savoldagi tanlov orqali. Darajasi yo\'q savollar: ' + noLv + ' ta.';
      $('qbLevel').classList.add('lv-need'); $('qbLevel').focus();
      return;
    }
    const kindSel = $('qbKind').value, kind = kindSel === 'open' ? 'open' : 'mc', nopt = kindSel === 'mc6' ? 6 : 4;
    const key = parseKey($('qbKey').value);
    const keyN = Object.keys(key).length;
    busy = true; $('qbUpload').disabled = true;
    const prog = $('qbProg'); prog.hidden = false; prog.max = sel.length; prog.value = 0;
    let ok = 0, fail = 0, noKey = 0, lastErr = '';
    for (let i = 0; i < sel.length; i++) {
      const p = sel[i];
      const fd = new FormData();
      fd.append('action', 'upload'); fd.append('section_id', $('qbSec').value);
      fd.append('kind', kind); fd.append('nopt', nopt); fd.append('label', p.label); fd.append('src', p.src); fd.append('level', pieceLevel(p));
      if (!p.keyed) { p.keyed = true; p.ans = key[i + 1] != null ? key[i + 1] : ''; }   // kalit bir marta, birinchi urinishda biriktiriladi (qayta urinishda siljimasin)
      if (p.ans) fd.append('answer', p.ans); else noKey++;
      fd.append('img', p.blob, 'q.png');
      try {
        const r = await fetch(cfg.api, { method: 'POST', body: fd, headers: { 'X-CSRF': csrf }, credentials: 'same-origin' });
        const t = await r.text(); let j = null;
        try { j = JSON.parse(t); } catch (e) { /* HTML — sessiya tugagan bo'lishi mumkin */ }
        if (j && j.ok) { ok++; p.done = true; } else { fail++; lastErr = j ? j.error : 'Sessiya tugagan bo\'lishi mumkin — sahifani yangilab, qayta kiring'; if (!j) break; }
      } catch (e) { fail++; lastErr = 'Tarmoq xatosi'; break; }
      prog.value = i + 1;
      $('qbMsg').textContent = 'Yuklanmoqda: ' + (i + 1) + ' / ' + sel.length;
    }
    if (keyN) $('qbKey').value = '';   // kalit ishlatildi — qayta yuklashda boshqa savolga tushib qolmasin
    // yuklanganlarni ro'yxatdan olib tashlaymiz
    pieces = pieces.filter(p => !p.done);
    renderPieces();
    const secId = $('qbSec').value;
    let msg = ok + ' ta savol yuklandi' + (fail ? ', ' + fail + ' tasi yuklanmadi (' + lastErr + ')' : '') + '. ';
    if (keyN && keyN !== sel.length) msg += 'Eslatma: kalitda ' + keyN + ' ta javob, yuklangan savollar ' + sel.length + ' ta. ';
    const out = $('qbMsg'); out.textContent = msg;
    if (ok) { const a = document.createElement('a'); a.className = 'btn sm primary'; a.href = cfg.list.replace('__S__', secId); a.textContent = 'Savollarni ko\'rish va kalitni kiritish →'; out.appendChild(a); }
    busy = false; $('qbUpload').disabled = false; prog.hidden = true;
  }

  /* ---------- hodisalar ---------- */
  $('qbFile').addEventListener('change', () => { $('qbGo').disabled = !$('qbFile').files.length; setStatus(''); });
  $('qbGo').addEventListener('click', run);
  $('qbUpload').addEventListener('click', upload);
  $('qbAll').onclick = () => { pieces.forEach(p => { p.sel = true; }); renderPieces(); };
  $('qbNone').onclick = () => { pieces.forEach(p => { p.sel = false; }); renderPieces(); };
  $('qbLevel').addEventListener('change', () => { $('qbLevel').classList.toggle('lv-need', !batchLevel()); renderPieces(); });
  $('qbSec').addEventListener('change', () => { try { history.replaceState(null, '', location.pathname + '?p=qb_import&s=' + $('qbSec').value); } catch (e) { /* e'tiborsiz */ } });
  document.querySelectorAll('input[name=qbMode]').forEach(r => r.addEventListener('change', () => {
    const auto = opts().mode === 'auto';
    ['qbCols', 'qbGap'].forEach(id => { $(id).disabled = !auto; });
  }));
})();
