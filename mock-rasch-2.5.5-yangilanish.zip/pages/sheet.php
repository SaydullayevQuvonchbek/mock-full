<?php
defined('APP_ROOT') || exit;
require_once APP_ROOT . '/inc/sheet_layout.php';
require_once APP_ROOT . '/inc/sheet_svg.php';   // 2.5.4: varaq chizmasi — PDF bilan umumiy
$test = get_test_or_404();
$L = sheet_layout($test);
global $CONFIG;
$group = $_GET['group'] ?? null;
$regMode = $group === '@reg';
// Chop etilgandan keyin varaqlarni "chop etilgan" deb belgilash (brauzerning afterprint hodisasidan yoki tugmadan)
if (is_post() && ($_POST['action'] ?? '') === 'mark_printed') {
    csrf_check();
    $ids = array_values(array_filter(array_map('intval', explode(',', (string)($_POST['sids'] ?? '')))));
    if ($ids) q('UPDATE test_registrations SET printed_at=NOW() WHERE test_id=? AND student_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', array_merge([$test['id']], $ids));
    json_out(['ok' => true, 'n' => count($ids)]);
}
$students = [];
$regOpt = ['only' => (string)($_GET['only'] ?? ''), 'room' => (string)($_GET['room'] ?? ''), 'sid' => (int)($_GET['sid'] ?? 0), 'order' => (string)($_GET['order'] ?? 'room'),
    // "Ro'yxat" sahifasidagi filtr va belgilanganlar
    'sids' => (string)($_GET['sids'] ?? ''), 'group' => (string)($_GET['fg'] ?? ''), 'center' => (string)($_GET['fc'] ?? ''), 'q' => trim((string)($_GET['q'] ?? '')),
    'via' => (string)($_GET['fv'] ?? ''), 'day' => (string)($_GET['fd'] ?? ''),   // 2.5.4: qayerdan / qachon yozilgan
    'pay' => in_array($_GET['fp'] ?? '', ['paid', 'free', 'waived'], true) ? (string)$_GET['fp'] : ''];   // 2.5.5: to'lov filtri (band — hech qachon varaqsiz)
$regHow = $regOpt['sids'] !== '' ? 'belgilanganlar' : (($regOpt['room'] . $regOpt['group'] . $regOpt['center'] . $regOpt['q'] . $regOpt['via'] . $regOpt['day'] . $regOpt['pay']) !== '' || $regOpt['only'] === 'done' ? 'filtr bo\'yicha' : '');
if ($regOpt['only'] === 'new') $regHow = trim($regHow . ($regHow !== '' ? ', ' : '') . 'hali chop etilmaganlar');
if ($group !== null && $group !== '') {
    $students = $group === '*' ? rows('SELECT * FROM students WHERE archived_at IS NULL ORDER BY group_name, full_name')
        : ($regMode ? reg_students((int)$test['id'], $regOpt)
        : rows('SELECT * FROM students WHERE group_name=? AND archived_at IS NULL ORDER BY full_name', [$group]));
}
$hasRooms = $regMode && (bool)val('SELECT 1 FROM test_rooms WHERE test_id=? LIMIT 1', [$test['id']]);
$copies = max(1, min(200, (int)($_GET['copies'] ?? 1)));
$pages = $students ?: array_fill(0, $copies, null);
$groups = array_column(rows('SELECT DISTINCT group_name FROM students WHERE group_name<>"" ORDER BY 1'), 'group_name');

page_header('Javoblar varaqasi', ['bare' => true, 'body' => 'print-page sheet-page']);
?>
<div class="no-print toolbar">
  <button class="btn primary" onclick="print()">🖨 Chop etish</button>
  <details class="print-help">
    <summary>Xira chiqyaptimi?</summary>
    <div class="print-help-body">
      <p><b>Varaqning o'zi tiniq (vektor)</b> — xiralik printer sozlamasidan. Chrome o'z oynasidan chop etganda printerning <i>standart</i> sozlamalarini oladi, siz printer xususiyatlarida tanlagan sifat va toner zichligini emas. PDF orqali tiniq chiqishining sababi shu.</p>
      <ol>
        <li><b>Tezkor yo'l:</b> <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>P</kbd> bosing — Windows'ning chop etish oynasi ochiladi. Printerni tanlab <b>Xususiyatlar</b> (Свойства / Properties) → sifat: eng yuqori (600 yoki 1200 dpi), <b>toner tejash</b> (Экономия тонера / EconoMode) — o'chiq.</li>
        <li><b>Chrome oynasida:</b> "Yana sozlamalar" (Дополнительные настройки) → <b>Sifat</b>: eng katta dpi; Masshtab: standart (100%); Chekkalar: yo'q.</li>
        <li><b>Bir marta sozlab qo'yish:</b> Windows → Printerlar va skanerlar → printeringiz → <b>Printer xususiyatlari</b> → "Qo'shimcha" (Дополнительно / Advanced) → <b>Chop etish standartlari</b> (Значения по умолчанию / Printing Defaults) — shu yerda sifat va toner tejashni o'zgartiring. Chrome aynan shu sozlamani oladi.</li>
      </ol>
      <p class="muted">Yoki chop etish oynasida printer o'rniga "PDF sifatida saqlash" ni tanlab, PDF faylni chop eting.</p>
    </div>
  </details>
  <form method="get" class="row gap inline">
    <input type="hidden" name="p" value="sheet"><input type="hidden" name="id" value="<?= (int)$test['id'] ?>">
    <label>Bo'sh nusxa: <input type="number" name="copies" value="<?= $copies ?>" min="1" max="200" style="width:70px"></label>
    <label>yoki shaxsiy varaqalar (ism + ID bo'yalgan):
      <select name="group"><option value="">—</option><option value="*" <?= $group === '*' ? 'selected' : '' ?>>Barcha o'quvchilar</option><option value="@reg" <?= $group === '@reg' ? 'selected' : '' ?>>Shu MOCK ro'yxatidagilar</option>
        <?php foreach ($groups as $g): ?><option <?= $g === $group ? 'selected' : '' ?>><?= e($g) ?></option><?php endforeach; ?></select></label>
    <button class="btn">Ko'rsatish</button>
  </form>
  <span class="muted small">Chop etishda: A4, masshtab 100%, "Fon grafikasi" yoqilgan, chekkalar — yo'q.</span>
  <?php if ($regMode): ?>
    <div class="print-status" id="printStatus" data-sids="<?= e(implode(',', array_map(fn($x) => (int)$x['id'], $students))) ?>">
      <?php if ($students): ?>
        <b><?= count($students) ?> ta varaq</b><?= $regHow !== '' ? ' (' . e($regHow) . ')' : '' ?>.
        <button type="button" class="btn sm" id="markPrinted">Chop etildi deb belgilash</button>
        <a class="small" href="<?= e(url('registrations', ['id' => $test['id']])) ?>">← Ro'yxatga qaytish</a>
      <?php else: ?>
        <b>Chop etiladigan varaq yo'q</b> — <?= $regOpt['only'] === 'new' ? 'barcha varaqlar allaqachon chop etilgan.' : ($regHow !== '' ? 'filtrga mos o\'quvchi yo\'q.' : 'ro\'yxat bo\'sh.') ?> <a href="<?= e(url('registrations', ['id' => $test['id']])) ?>">Ro'yxatga qaytish</a>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>
<?php
// Xonalar bo'yicha chop etishda har xona oldidan ajratuvchi varaq (paketlarni xonalarga tarqatish oson bo'lsin)
$sep = $regMode && $hasRooms && $regOpt['order'] === 'room' && !empty($_GET['sep']);
$byRoom = [];
if ($sep) foreach ($students as $x) $byRoom[(string)($x['room_id'] ?? '')][] = $x;
$curRoom = null;
?>
<?php if (!($regMode && !$students)) foreach ($pages as $st): ?>
  <?php if ($sep && $st && (string)($st['room_id'] ?? '') !== $curRoom): $curRoom = (string)($st['room_id'] ?? ''); $grp = $byRoom[$curRoom] ?? []; ?>
  <div class="sheet-wrap room-sep">
    <div class="room-sep-in">
      <div class="rs-test"><?= e($test['title']) ?> · <?= e(app_setting('center')) ?></div>
      <div class="rs-room"><?= $curRoom !== '' ? e($st['room_name']) : 'Xonasiz' ?></div>
      <div class="rs-meta"><b><?= count($grp) ?> ta</b> javoblar varaqasi<?= $curRoom !== '' && ($st['proctor'] ?? '') !== '' ? ' · nazoratchi: <b>' . e($st['proctor']) . '</b>' : '' ?></div>
      <div class="rs-grid <?= count($grp) > 70 ? 'c3' : '' ?>">
        <?php foreach ($grp as $x): ?><div><b><?= $x['seat'] !== null ? (int)$x['seat'] : '—' ?></b> <?= e($x['full_name']) ?> <span class="mono"><?= e($x['code']) ?></span></div><?php endforeach; ?>
      </div>
      <div class="rs-note">Bu ajratuvchi varaq — skanerlanmaydi. Keyingi varaqlar o'rin tartibida.</div>
    </div>
  </div>
  <?php endif; ?>
  <div class="sheet-wrap"><?= sheet_svg($test, $L, $st, app_setting('center')) ?></div>
<?php endforeach; ?>
<?php if ($regMode && $students): ?>
<script>
(function(){
  const box = document.getElementById('printStatus'), btn = document.getElementById('markPrinted');
  const csrf = document.querySelector('meta[name=csrf]').content;
  let marked = false;
  async function mark(){
    if (marked) return; marked = true;
    const fd = new FormData(); fd.append('_csrf', csrf); fd.append('action', 'mark_printed'); fd.append('sids', box.dataset.sids);
    try {
      const r = await fetch(location.href, { method: 'POST', body: fd }).then(r => r.json());
      box.innerHTML = '<b>✓ ' + r.n + ' ta varaq "chop etilgan" deb belgilandi.</b> Keyingi safar "Faqat yangilar" ular chiqmaydi.';
    } catch (e) { marked = false; }
  }
  btn.addEventListener('click', mark);
  // Chop etish oynasi yopilgach so'raymiz (bekor qilingan bo'lishi ham mumkin)
  window.addEventListener('afterprint', () => { if (!marked && confirm('Varaqalar chop etildimi? Ular "chop etilgan" deb belgilansinmi?')) mark(); });
})();
</script>
<?php endif; ?>
<?php page_footer();
