<?php
defined('APP_ROOT') || exit;
require_once APP_ROOT . '/inc/students_lib.php';   // 2.5.2: guruh katagi, guruhga biriktirish (assets/students.js + stu_api)
require_once APP_ROOT . '/inc/room_pack.php';      // 2.5.4: xonalar bo'yicha yuklab olish (PDF, ZIP, Excel)
$test = get_test_or_404();
$tid = (int)$test['id'];
// Amaldan keyin shu sahifaga filtrlar saqlangan holda qaytish (formalar joriy manzilga yuboriladi, shuning uchun $_GET da filtrlar bor)
$back = function () use ($tid) {
    $keep = ['id' => $tid];
    foreach (['tab', 'room', 'pr', 'q', 'fg', 'fc', 'fp', 'fv', 'fd', 'o', 'un', 'ng', 'nc', 'ns'] as $k) $keep[$k] = (string)($_POST['f_' . $k] ?? $_GET[$k] ?? '');
    redirect('registrations', array_filter($keep, fn($v) => $v !== ''));
};

/** Shu test ro'yxatiga hali kiritilmagan o'quvchilar uchun WHERE va parametrlar (filtr: guruh, markaz, qidiruv) */
$unregSql = function (string $g, string $c, string $s) use ($tid): array {
    $w = ['s.archived_at IS NULL', 'NOT EXISTS (SELECT 1 FROM test_registrations r WHERE r.test_id=? AND r.student_id=s.id)']; $p = [$tid];
    if ($g === '@none') $w[] = "s.group_name=''";
    elseif ($g !== '') { $w[] = 's.group_name=?'; $p[] = $g; }
    if ($c === 'own') $w[] = 's.center_id IS NULL';
    elseif ($c !== '') { $w[] = 's.center_id=?'; $p[] = (int)$c; }
    if ($s !== '') { [$sw, $sp] = student_search_sql($s); $w[] = $sw; $p = array_merge($p, $sp); }
    return [implode(' AND ', $w), $p];
};

if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    $fin = can_finance();
    // 2.5: qo'shish — yagona qoida (mock_register): pullik MOCK da admin tanlagan to'lov usuli bilan
    $payMode = (string)($_POST['pay'] ?? 'auto');
    if (!in_array($payMode, $fin ? ['auto', 'unpaid', 'cash', 'waive'] : ['auto', 'unpaid'], true)) $payMode = 'auto';
    $payNote = '';
    $addIds = function (array $ids) use ($tid, $payMode, &$payNote): int {
        $c = ['paid' => 0, 'unpaid' => 0, 'waived' => 0];
        $n = 0;
        foreach ($ids as $sid) {
            try { $r = mock_register((int)$sid, $tid, 'admin', ['pay' => $payMode, 'force' => true]); }
            catch (Throwable $ex) { error_log('[MOCK reg-add] ' . $ex->getMessage()); continue; }   // bittasidagi xato qolganlarini to'xtatmasin
            if (!$r['ok'] || $r['status'] === 'exists') continue;
            $n++;
            if (isset($c[$r['status']])) $c[$r['status']]++;
        }
        $payNote = ($c['paid'] ? ", to'langan: " . $c['paid'] : '') . ($c['unpaid'] ? ", band (to'lov kutilmoqda): " . $c['unpaid'] : '') . ($c['waived'] ? ', imtiyoz: ' . $c['waived'] : '');
        return $n;
    };
    if ($act === 'remove') {
        $r = mock_cancel((int)$_POST['sid'], $tid, 'admin', ['refund' => !($fin && !empty($_POST['norefund']))]);
        if (!$r['ok']) flash($r['error'], 'err');
        elseif ($r['refund'] > 0) flash('Ro\'yxatdan chiqarildi, ' . som($r['refund']) . ' hamyoniga qaytarildi', 'warn');
    }
    if ($act === 'pay' && $fin) {
        if (($_POST['op'] ?? '') === 'uncash') {   // 2.5.4: xato qo'yilgan naqd belgisini bekor qilish
            $r = mock_admin_uncash((int)$_POST['sid'], $tid);
            flash($r['ok'] ? 'Naqd to\'lov belgisi bekor qilindi' . ($r['status'] === 'unpaid' ? ' — o\'quvchi yana «band» (to\'lov kutilmoqda)' : '') : $r['error'], $r['ok'] ? 'warn' : 'err');
        } else {
            $r = mock_admin_pay((int)$_POST['sid'], $tid, (string)($_POST['op'] ?? ''), (string)($_POST['note'] ?? ''), null, isset($_POST['expect']) && $_POST['expect'] !== '' ? (int)$_POST['expect'] : null);
            $who = $r['ok'] ? (string)val('SELECT full_name FROM students WHERE id=?', [(int)$_POST['sid']]) : '';
            flash($r['ok'] ? (['paid' => !empty($r['cash']) ? 'Naqd to\'lov yozildi' : 'To\'lov yozildi', 'waived' => 'Imtiyoz berildi (bepul)', 'unpaid' => 'To\'lov talab qilindi — o\'quvchi to\'lagach qatnashadi'][$r['status']] ?? 'Saqlandi') . ($who !== '' ? ': ' . $who : '')
                . (!empty($r['seat']['room']) && !empty($r['seat']['new']) ? ' · ' . $r['seat']['room'] . ', ' . (int)$r['seat']['seat'] . '-o\'rin' : '') : $r['error'], $r['ok'] ? 'ok' : 'err');
        }
    }
    if ($act === 'room_printed') {   // 2.5.4: xona varaqlari chop etildi (PDF yuklab olib chop etilganda)
        $n = q('UPDATE test_registrations SET printed_at=NOW() WHERE test_id=? AND room_id=? AND pay_status<>"unpaid" AND printed_at IS NULL', [$tid, (int)$_POST['rid']])->rowCount();
        flash($n . ' ta varaq "chop etilgan" deb belgilandi');
    }
    if ($act === 'toggle') {
        q('UPDATE tests SET reg_open=1-reg_open WHERE id=?', [$tid]);
        if ((int)$test['reg_open'] === 1) {   // yopildi — to'lanmagan bandlar bekor
            $nx = mock_expire_unpaid($tid);
            if ($nx) flash('Ro\'yxat yopildi: ' . $nx . ' ta to\'lanmagan band bekor qilindi', 'warn');
        }
    }
    if ($act === 'add') {
        // Telefon orqali yoki markazga kelib ro'yxatdan o'tganlar: admin ID bo'yicha qo'shadi (ro'yxat yopiq bo'lsa ham)
        $ids = []; $miss = [];
        foreach (preg_split('/[\s,;]+/', (string)($_POST['codes'] ?? ''), -1, PREG_SPLIT_NO_EMPTY) as $code) {
            $sid = val('SELECT id FROM students WHERE code=? AND archived_at IS NULL', [preg_replace('/\D/', '', $code)]);
            if ($sid) $ids[] = $sid; else $miss[] = $code;
        }
        $n = $addIds($ids);
        flash("Qo'shildi: $n" . $payNote . ($miss ? '. Topilmagan ID: ' . implode(', ', array_slice($miss, 0, 10)) : ''), $miss ? 'warn' : 'ok');
    }
    if ($act === 'add_group') {
        $g = trim((string)($_POST['group'] ?? ''));
        if ($g === '') { flash('Guruh tanlanmagan', 'warn'); $back(); }
        if ($g === '@all') { $ids = array_column(rows('SELECT id FROM students WHERE archived_at IS NULL'), 'id'); $from = "Barcha o'quvchilardan"; }
        elseif ($g === '@none') { $ids = array_column(rows("SELECT id FROM students WHERE group_name='' AND archived_at IS NULL"), 'id'); $from = 'Guruhsizlardan'; }
        else { $ids = array_column(rows('SELECT id FROM students WHERE group_name=? AND archived_at IS NULL', [$g]), 'id'); $from = "\"$g\" guruhidan"; }
        $n = $addIds($ids);
        flash("$from $n ta o'quvchi qo'shildi" . $payNote . (count($ids) > $n ? ' (' . (count($ids) - $n) . ' tasi avval ro\'yxatda edi)' : ''));
    }
    if ($act === 'add_sel') {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
        if (!$ids) flash('O\'quvchi tanlanmagan', 'warn');
        else { $n = $addIds($ids); flash($n . " ta o'quvchi ro'yxatga qo'shildi" . $payNote); }
    }
    if ($act === 'add_filter') {
        [$w, $p] = $unregSql((string)($_POST['f_ng'] ?? ''), (string)($_POST['f_nc'] ?? ''), trim((string)($_POST['f_ns'] ?? '')));
        $n = $addIds(array_column(rows("SELECT s.id FROM students s WHERE $w", $p), 'id'));
        flash("$n ta o'quvchi ro'yxatga qo'shildi" . $payNote);
    }
    // --- Xonalar ---
    if ($act === 'room_add') {
        $name = mb_substr(trim((string)($_POST['name'] ?? '')), 0, 60);
        $cap = max(1, min(500, (int)($_POST['capacity'] ?? 30)));
        $cnt = max(1, min(50, (int)($_POST['count'] ?? 1)));
        $sort = (int)val('SELECT COALESCE(MAX(sort),0) FROM test_rooms WHERE test_id=?', [$tid]);
        for ($i = 1; $i <= $cnt; $i++) {
            $nm = $cnt > 1 || $name === '' ? ($name !== '' ? "$name-$i" : ($sort + 1) . '-xona') : $name;
            q('INSERT INTO test_rooms (test_id, name, capacity, sort) VALUES (?,?,?,?)', [$tid, $nm, $cap, ++$sort]);
        }
        flash($cnt > 1 ? "$cnt ta xona qo'shildi" : 'Xona qo\'shildi');
    }
    if ($act === 'room_preset') {
        $n = center_rooms_apply($tid);
        flash($n ? "Markaz xonalaridan $n ta qo'shildi. Endi «Joylashtirish» ni bosing." : 'Markaz xonalari allaqachon qo\'shilgan', $n ? 'ok' : 'warn');
    }
    if ($act === 'room_edit') {
        $rid = (int)$_POST['rid'];
        $cap = max(1, min(500, (int)($_POST['capacity'] ?? 30)));
        $used = (int)val('SELECT MAX(seat) FROM test_registrations WHERE test_id=? AND room_id=?', [$tid, $rid]);
        if ($cap < $used) flash("Sig'imni $used dan kamaytirib bo'lmaydi — avval o'quvchilarni boshqa xonaga o'tkazing yoki qaytadan taqsimlang", 'err');
        else q('UPDATE test_rooms SET name=?, capacity=?, proctor=? WHERE id=? AND test_id=?', [mb_substr(trim((string)$_POST['name']), 0, 60) ?: 'Xona', $cap, mb_substr(trim((string)($_POST['proctor'] ?? '')), 0, 120), $rid, $tid]);
    }
    if ($act === 'room_del') {
        $rid = (int)$_POST['rid'];
        q('UPDATE test_registrations SET room_id=NULL, seat=NULL WHERE test_id=? AND room_id=?', [$tid, $rid]);
        q('DELETE FROM test_rooms WHERE id=? AND test_id=?', [$rid, $tid]);
        flash('Xona o\'chirildi, undagi o\'quvchilar xonasiz qoldi', 'warn');
    }
    if ($act === 'distribute') {
        $ord = in_array($_POST['order'] ?? '', ['name', 'school', 'group', 'time', 'random', 'mix'], true) ? $_POST['order'] : 'name';
        $seedIn = trim((string)($_POST['seed'] ?? ''));
        [$done, $left, $seed] = distribute_rooms($tid, ($_POST['mode'] ?? 'new') === 'all' ? 'all' : 'new', $ord, !empty($_POST['balance']), $seedIn !== '' ? (int)$seedIn : null);
        flash("$done ta o'quvchi xonalarga joylashtirildi" . (in_array($ord, ['random', 'mix'], true) ? " (seed: $seed — shu raqam bilan bir xil joylashuvni qayta olish mumkin)" : '') . ($left ? ". $left tasiga joy yetmadi — xona qo'shing yoki sig'imni oshiring" : ''), $left ? 'warn' : 'ok');
    }
    if ($act === 'notify_rooms') {
        if (!tg_ready() && !sms_ready()) flash('Xabar yuborish uchun Telegram bot yoki Eskiz SMS ulanmagan (Sozlamalar)', 'err');
        else {
            $n = room_notify_queue($tid, isset($_POST['resend']));
            if ($n['bot'] + $n['sms'] > 0) tg_tick(20);
            flash('Xona va o\'rin xabari navbatga qo\'yildi: Telegram ' . $n['bot'] . ', SMS ' . $n['sms'] . ($n['none'] ? '; yetkazib bo\'lmaydi (bot ham, telefon ham yo\'q): ' . $n['none'] : ''), ($n['bot'] + $n['sms']) ? 'ok' : 'warn');
        }
    }
    if ($act === 'move') {
        $sid = (int)$_POST['sid']; $to = (int)($_POST['room'] ?? 0);
        $ps = val('SELECT pay_status FROM test_registrations WHERE test_id=? AND student_id=?', [$tid, $sid]);
        if ($ps === null) flash('O\'quvchi bu MOCK ro\'yxatida yo\'q', 'err');
        elseif ($to && $ps === 'unpaid') flash('To\'lov kutilmoqda — o\'rin to\'lovdan keyin beriladi', 'err');   // 2.5.5: band — xonaga joylanmaydi
        elseif (!move_to_room($tid, $sid, $to)) flash('Bu xonada bo\'sh o\'rin yo\'q', 'err');
        else {   // 2.5.5: qatordagi xona tugmasi — natija qisqa xabar bilan
            $g = row('SELECT s.full_name, r.name, g.seat FROM test_registrations g JOIN students s ON s.id=g.student_id LEFT JOIN test_rooms r ON r.id=g.room_id WHERE g.test_id=? AND g.student_id=?', [$tid, $sid]);
            if ($g) flash($g['full_name'] . ' — ' . ($g['name'] !== null ? $g['name'] . ', ' . (int)$g['seat'] . '-o\'rin' : 'xonasiz'));
        }
    }
    // --- Belgilanganlar bilan ---
    if ($act === 'mass') {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
        $op = $_POST['op'] ?? '';
        if (!$ids) flash('O\'quvchi tanlanmagan', 'warn');
        else {
            $in = implode(',', array_fill(0, count($ids), '?'));
            if ($op === 'room') {
                $to = (int)($_POST['to_room'] ?? 0);
                // 2.5.5: band (to'lanmagan) — xonaga joylanmaydi (to'lagach o'zi joylanadi); xonasizga o'tkazish mumkin
                $band = $to ? array_map('intval', array_column(rows("SELECT student_id FROM test_registrations WHERE test_id=? AND pay_status='unpaid' AND student_id IN ($in)", array_merge([$tid], $ids)), 'student_id')) : [];
                $full = 0; $moved = 0;
                foreach ($ids as $sid) { if (in_array($sid, $band, true)) continue; if (move_to_room($tid, $sid, $to)) $moved++; else $full++; }
                flash($moved . ' ta o\'quvchi ko\'chirildi' . ($full ? ", $full tasiga joy yetmadi" : '') . ($band ? ', ' . count($band) . ' tasi band (to\'lanmagan) — to\'lagach joylanadi' : ''), $full || $band ? 'warn' : 'ok');
            } elseif ($op === 'printed') {
                q("UPDATE test_registrations SET printed_at=NOW() WHERE test_id=? AND student_id IN ($in)", array_merge([$tid], $ids));
                flash(count($ids) . ' ta varaq "chop etilgan" deb belgilandi');
            } elseif ($op === 'unprinted') {
                q("UPDATE test_registrations SET printed_at=NULL WHERE test_id=? AND student_id IN ($in)", array_merge([$tid], $ids));
                flash(count($ids) . ' ta varaq qayta chop etish uchun belgilandi');
            } elseif ($op === 'remove' || ($op === 'remove_keep' && $fin)) {
                $n = 0; $sum = 0;
                foreach ($ids as $sid) { $r = mock_cancel($sid, $tid, 'admin', ['refund' => $op === 'remove']); if ($r['ok']) { $n++; $sum += (int)$r['refund']; } }
                flash($n . ' ta o\'quvchi ro\'yxatdan chiqarildi' . ($sum ? ', hamyonlariga qaytarildi: ' . som($sum) : ''), 'warn');
            } elseif (in_array($op, ['cash', 'wallet', 'waive', 'unpaid'], true) && $fin) {
                $ok = 0; $errs = [];
                foreach ($ids as $sid) {
                    try { $r = mock_admin_pay($sid, $tid, $op); } catch (Throwable $ex) { error_log('[MOCK reg-pay] ' . $ex->getMessage()); $r = ['ok' => false, 'error' => 'ichki xato']; }
                    if ($r['ok']) $ok++; else $errs[$r['error']] = ($errs[$r['error']] ?? 0) + 1;
                }
                $msg = $ok . ' ta: ' . ['cash' => 'naqd to\'lov yozildi', 'wallet' => 'hamyondan yechildi', 'waive' => 'imtiyoz berildi', 'unpaid' => 'to\'lov talab qilindi'][$op];
                foreach (array_slice($errs, 0, 3, true) as $er => $k) $msg .= '; ' . $k . ' tasi — ' . $er;
                flash($msg, $errs ? 'warn' : 'ok');
            }
        }
    }
    $back();
}

$rooms = test_rooms($tid);
// Ro'yxat filtri — shu filtr chop etishga ham o'tadi (ro'yxatda nima ko'rinsa, o'sha chop etiladi, o'sha tartibda)
$fRoom = (string)($_GET['room'] ?? '');
$fPr = in_array($_GET['pr'] ?? '', ['new', 'done'], true) ? $_GET['pr'] : '';
$fQ = trim((string)($_GET['q'] ?? ''));
$fG = (string)($_GET['fg'] ?? '');
$fC = (string)($_GET['fc'] ?? '');
$fO = in_array($_GET['o'] ?? '', ['room', 'name', 'school', 'time'], true) ? $_GET['o'] : ($rooms ? 'room' : 'name');
$fP = isset(REG_PAY_LABEL[$_GET['fp'] ?? '']) ? (string)$_GET['fp'] : '';
$fV = in_array($_GET['fv'] ?? '', ['self', 'bot', 'web', 'admin'], true) ? (string)$_GET['fv'] : '';   // 2.5.4: qayerdan yozilgan
$fD = (string)($_GET['fd'] ?? '');                                                                       // 2.5.4: qachon
if (!in_array($fD, ['today', 'old'], true) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fD)) $fD = '';
wallet_tick(true);
$price = mock_price($test);
$fin = can_finance();
$allPay = reg_students($tid, ['order' => $fO, 'pay' => 'all']);
$all = array_values(array_filter($allPay, fn($s) => $s['pay_status'] !== 'unpaid'));   // joy, varaq, xabar — to'lanmagan bandlarsiz
$list = reg_students($tid, ['room' => $fRoom, 'only' => $fPr, 'q' => $fQ, 'group' => $fG, 'center' => $fC, 'order' => $fO, 'pay' => $fP !== '' ? $fP : 'all', 'via' => $fV, 'day' => $fD]);
$filtered = $fRoom !== '' || $fPr !== '' || $fQ !== '' || $fG !== '' || $fC !== '' || $fP !== '' || $fV !== '' || $fD !== '';
$payCnt = ['free' => 0, 'paid' => 0, 'unpaid' => 0, 'waived' => 0];
$income = 0;
$cashN = 0; $cashSum = 0;
$viaCnt = ['bot' => 0, 'web' => 0, 'admin' => 0]; $dayCnt = [];   // 2.5.4: qayerdan va qachon yozilgan
foreach ($allPay as $s) {
    $payCnt[$s['pay_status']] = ($payCnt[$s['pay_status']] ?? 0) + 1;
    if ($s['pay_status'] === 'paid') { $income += (int)$s['paid_amount']; if ($s['pay_method'] === 'cash') { $cashN++; $cashSum += (int)$s['paid_amount']; } }
    $v = (string)$s['via'];
    $viaCnt[$v === 'bot' ? 'bot' : (in_array($v, ['web', 'register'], true) ? 'web' : 'admin')]++;
    $d = substr((string)$s['reg_at'], 0, 10);
    $dayCnt[$d] = ($dayCnt[$d] ?? 0) + 1;
}
krsort($dayCnt);
$today = date('Y-m-d');
$nToday = (int)($dayCnt[$today] ?? 0);
$showPay = $price > 0 || $payCnt['paid'] + $payCnt['unpaid'] + $payCnt['waived'] > 0;
$nExpiring = $test['reg_open'] ? mock_unpaid_count($tid, true) : 0;
// Ro'yxatdagilarning guruhlari (filtr uchun, soni bilan)
$regGroups = [];
foreach ($allPay as $s) $regGroups[$s['group_name']] = ($regGroups[$s['group_name']] ?? 0) + 1;
ksort($regGroups);
$regNone = (int)($regGroups[''] ?? 0);   // 2.5.2: ro'yxatdagi guruhsizlar — «Guruhsiz: N» belgisi
// «Guruhsiz: N» belgisi: bosilsa — shu filtr yoqiladi/o'chadi (boshqa filtrlar saqlanadi)
$noneChipUrl = url('registrations', ['id' => $tid] + array_filter(['room' => $fRoom, 'pr' => $fPr, 'q' => $fQ, 'fc' => $fC, 'fp' => $fP, 'fv' => $fV, 'fd' => $fD, 'o' => $fO !== ($rooms ? 'room' : 'name') ? $fO : ''], fn($v) => $v !== '') + ($fG === '@none' ? [] : ['fg' => '@none'])) . '#regList';
$resp = [];
foreach (rows('SELECT student_id, status FROM responses WHERE test_id=?', [$tid]) as $r) $resp[(int)$r['student_id']] = $r['status'];
$N = count($all);
$nPrinted = count(array_filter($all, fn($s) => $s['printed_at']));
$nPlaced = count(array_filter($all, fn($s) => $s['room_id']));
$seats = array_sum(array_map(fn($r) => (int)$r['capacity'], $rooms));
// Guruhlar: jami o'quvchi (n) va shu ro'yxatga hali kiritilmaganlar (free)
$gstat = rows('SELECT s.group_name g, COUNT(*) n, SUM(r.student_id IS NULL) free FROM students s
               LEFT JOIN test_registrations r ON r.test_id=? AND r.student_id=s.id WHERE s.archived_at IS NULL GROUP BY s.group_name ORDER BY s.group_name', [$tid]);
$nStudents = (int)array_sum(array_column($gstat, 'n'));
$freeAll = (int)array_sum(array_column($gstat, 'free'));
$groups = array_values(array_filter($gstat, fn($g) => $g['g'] !== ''));
$noGroup = current(array_filter($gstat, fn($g) => $g['g'] === '')) ?: null;
$gLabel = fn(int $free) => $free ? "(+$free)" : '✓';   // +N — qo'shiladiganlar soni, ✓ — hammasi ro'yxatda
$centers = centers_list();
// Ro'yxatga kiritilmaganlar bo'limi
$nf = ['g' => (string)($_GET['ng'] ?? ''), 'c' => (string)($_GET['nc'] ?? ''), 's' => trim((string)($_GET['ns'] ?? ''))];
[$uw, $up] = $unregSql($nf['g'], $nf['c'], $nf['s']);
$unTotal = (int)val("SELECT COUNT(*) FROM students s WHERE $uw", $up);
$unList = rows("SELECT s.id, s.code, s.full_name, s.group_name, s.center_id, s.school, s.grade_level, s.phone FROM students s WHERE $uw ORDER BY s.full_name LIMIT 500", $up);
$unFiltered = $nf['g'] !== '' || $nf['c'] !== '' || $nf['s'] !== '';
$link = app_base_url() . 'index.php?' . http_build_query(['p' => 'register', 'test' => $tid]);
$sheetUrl = fn(array $p) => url('sheet', ['id' => $tid, 'group' => '@reg'] + $p);
// Joriy filtr bo'yicha varaqlar (ro'yxatdagi tartibda)
$filterSheetUrl = $sheetUrl(array_filter(['room' => $fRoom, 'only' => $fPr, 'q' => $fQ, 'fg' => $fG, 'fc' => $fC, 'fv' => $fV, 'fd' => $fD, 'order' => $fO,
    'fp' => in_array($fP, ['paid', 'free', 'waived'], true) ? $fP : ''], fn($v) => $v !== ''));   // 2.5.5: to'lov filtri ham (band — varaqsiz)

// Pullik MOCK: qo'shish formalaridagi to'lov tanlovi
$paySel = function () use ($price, $fin): string {
    if ($price <= 0) return '';
    $o = ['auto' => 'To\'lov: hamyondan', 'unpaid' => 'To\'lov: band', ] + ($fin ? ['cash' => 'To\'lov: naqd olindi', 'waive' => 'To\'lov: imtiyoz'] : []);
    $h = '<select name="pay" aria-label="To\'lov" title="Pullik MOCK (' . e(som($price)) . '). Hamyondan — balans yetsa yechiladi, yetmasa band qilinadi; band — to\'lov kutiladi; naqd — kirim va yechim yoziladi; imtiyoz — bepul">';
    foreach ($o as $k => $v) $h .= '<option value="' . $k . '">' . e($v) . '</option>';
    return $h . '</select>';
};
$nAllPay = count($allPay);
// 2.5.5: sahifa bo'limlarga ajratildi — «Ro'yxat» (filtr aynan ro'yxat ustida), «Qo'shish», «Xonalar», «Chop etish va xabar».
// Tepada — bitta qatorli xulosa (bosilsa — ro'yxat shu bo'yicha filtrlanadi yoki kerakli bo'lim ochiladi).
$TABS = ['list' => 'Ro\'yxat', 'add' => 'Qo\'shish', 'rooms' => 'Xonalar', 'print' => 'Chop etish<span class="tl-x"> va xabar</span>'];   // telefonda — «Chop etish»
$tab = (string)($_GET['tab'] ?? '');
// «Qo'shish» o'zi ochiladi faqat ro'yxat butunlay bo'sh bo'lsa (2.5.4: «band»lar ham ro'yxatda — bazadagilar ro'yxatdagidek ko'rinmasin)
if (!isset($TABS[$tab])) $tab = $unFiltered || !empty($_GET['un']) || $nAllPay === 0 ? 'add' : 'list';
$tabUrl = fn(string $t, array $p = []) => url('registrations', ['id' => $tid] + ($t !== 'list' ? ['tab' => $t] : []) + $p);
$np = $rooms && $nPlaced > 0 ? room_notify_plan($tid, false) : null;
$canSend = tg_ready() || sms_ready();
$autoSeat = seat_auto_on() && !(int)$test['online'];   // 2.5.2: to'lov tasdiqlanganda o'rin avtomatik
$nNoRoom = $N - $nPlaced;
$nNotified = count(array_filter($all, fn($s) => $s['room_id'] && $s['notified_at']));   // «Xabar olgan» — xonadagilardan (arxivdagilarsiz)
$nPrintable = count(array_filter($list, fn($s) => $s['pay_status'] !== 'unpaid'));        // ro'yxatda ko'ringanlardan varaq chiqadiganlar
$hasResp = (bool)$resp;
$defO = $rooms ? 'room' : 'name';
// joriy filtrlar (havolalar uchun) va ro'yxat ustidagi belgilar (× — shu filtrni olib tashlash)
$curF = array_filter(['q' => $fQ, 'fp' => $fP, 'fg' => $fG, 'room' => $fRoom, 'fv' => $fV, 'fd' => $fD, 'fc' => $fC, 'pr' => $fPr, 'o' => $fO !== $defO ? $fO : ''], fn($v) => $v !== '');
$actF = [];
if ($fQ !== '') $actF['q'] = '«' . $fQ . '»';
if ($fP !== '') $actF['fp'] = REG_PAY_LABEL[$fP] ?? $fP;
if ($fG !== '' && $fG !== '@none') $actF['fg'] = $fG;   // guruhsizlar — «Guruhsiz: N» belgisining o'zi
if ($fRoom !== '') { $actF['room'] = 'Xonasizlar'; foreach ($rooms as $r) if ((string)$r['id'] === $fRoom) $actF['room'] = (string)$r['name']; }
if ($fV !== '') $actF['fv'] = ['self' => 'O\'zi yozilgan', 'bot' => 'Bot orqali', 'web' => 'Sayt orqali', 'admin' => 'Admin qo\'shgan'][$fV];
if ($fD !== '') $actF['fd'] = $fD === 'today' ? 'Bugun yozilgan' : ($fD === 'old' ? 'Bugungacha yozilgan' : date('d.m.Y', strtotime($fD)) . ' kuni yozilgan');
if ($fC !== '') $actF['fc'] = $fC === 'own' ? 'O\'z markazimiz' : (string)($centers[(int)$fC] ?? 'Markaz');
if ($fPr !== '') $actF['pr'] = $fPr === 'new' ? 'Varaq chop etilmagan' : 'Varaq chop etilgan';
$nMore = (int)($fV !== '') + (int)($fD !== '') + (int)($fC !== '') + (int)($fPr !== '') + (int)($fO !== $defO);   // «Yana filtrlar» ostidagi tanlanganlar
$moreOpen = $nMore > 0;
$sumF = fn(array $f) => e($tabUrl('list', $f));
// xonalar — qatordagi xona tugmasi uchun (bo'sh o'rinlar bilan)
$roomsJs = array_map(fn($r) => [(int)$r['id'], (string)$r['name'], max(0, (int)$r['capacity'] - (int)$r['used'])], $rooms);
page_header('Ro\'yxat — ' . $test['title']);
test_tabs($test, 'registrations');
?>
<div class="reg-sum" id="regKpi" data-live>
  <div class="sum-main">
    <a class="sum-it" href="<?= $sumF([]) ?>" data-f="" title="Ro'yxatdagilarning hammasi"><b><?= $nAllPay ?></b> ro'yxatda</a>
    <?php if ($showPay): ?>
    <a class="sum-it ok" href="<?= $sumF(['fp' => 'paid']) ?>" data-f="fp=paid" data-fl="<?= e(REG_PAY_LABEL['paid']) ?>"><b><?= $payCnt['paid'] ?></b> to'lagan<?= $cashN ? '<small>naqd ' . $cashN . '</small>' : '' ?></a>
    <a class="sum-it<?= $payCnt['unpaid'] ? ' warn' : '' ?>" href="<?= $sumF(['fp' => 'unpaid']) ?>" data-f="fp=unpaid" data-fl="<?= e(REG_PAY_LABEL['unpaid']) ?>" title="To'lov kutilmoqda: xonaga joylanmaydi, varaq va xabar olmaydi<?= $test['online'] ? ', onlayn testni boshlay olmaydi' : '' ?>"><b><?= $payCnt['unpaid'] ?></b> band</a>
    <?php if ($payCnt['waived']): ?><a class="sum-it" href="<?= $sumF(['fp' => 'waived']) ?>" data-f="fp=waived" data-fl="<?= e(REG_PAY_LABEL['waived']) ?>"><b><?= $payCnt['waived'] ?></b> imtiyoz</a><?php endif; ?>
    <?php if ($payCnt['free'] && $price > 0): ?><a class="sum-it" href="<?= $sumF(['fp' => 'free']) ?>" data-f="fp=free" data-fl="<?= e(REG_PAY_LABEL['free']) ?>" title="Narx qo'yilishidan oldin yozilganlar — qatnasha oladi"><b><?= $payCnt['free'] ?></b> bepul yozilgan</a><?php endif; ?>
    <span class="sum-it money"><b><?= e(som($income)) ?></b> tushum<?= $cashSum ? '<small>naqd ' . e(som($cashSum)) . '</small>' : '' ?></span>
    <?php endif; ?>
  </div>
  <div class="sum-side">
    <?php if ($rooms): ?><a href="<?= e($tabUrl('rooms')) ?>" data-tab="rooms"<?= $N && $nNoRoom > 0 ? ' class="warn-txt"' : '' ?>>Xonada <b><?= $nPlaced ?>/<?= $N ?></b></a><?php endif; ?>
    <a href="<?= e($tabUrl('print')) ?>" data-tab="print">Chop etilgan <b><?= $nPrinted ?>/<?= $N ?></b></a>
    <?php if ($np && $canSend): ?><a href="<?= e($tabUrl('print')) ?>" data-tab="print">Xabar olgan <b><?= $nNotified ?>/<?= $nPlaced ?></b></a><?php endif; ?>
    <span class="muted"><?= $showPay ? 'Narxi ' . e(mock_price_label($test)) . ' · ' : '' ?>onlayn ro'yxat <?= $test['reg_open'] ? 'ochiq' : 'yopiq' ?></span>
  </div>
</div>

<nav class="reg-tabs" id="regTabs" aria-label="Ro'yxat bo'limlari" data-live>
  <?php foreach ($TABS as $k => $lbl):
    // nishon: son + izoh (telefonda izoh yashiriladi — faqat son qoladi)
    [$bn, $bl] = $k === 'list' ? [$nAllPay, ''] : ($k === 'rooms' ? ($rooms && $N && $nNoRoom > 0 ? [$nNoRoom, 'xonasiz'] : [0, '']) : ($k === 'print' && $N > $nPrinted ? [$N - $nPrinted, 'chop etilmagan'] : [0, ''])); ?>
    <a href="<?= e($tabUrl($k)) ?>" data-tab="<?= $k ?>" class="<?= $tab === $k ? 'on' : '' ?>"<?= $tab === $k ? ' aria-current="page"' : '' ?>><span><?= $k === 'add' ? '+ ' : '' ?><?= $lbl ?></span><?= $bn || $k === 'list' ? ' <span class="cnt' . ($k !== 'list' ? ' warn' : '') . '"' . ($bl !== '' ? ' title="' . $bn . ' ' . $bl . '"' : '') . '>' . (int)$bn . ($bl !== '' ? '<span class="cnt-l"> ' . $bl . '</span>' : '') . '</span>' : '' ?></a>
  <?php endforeach; ?>
</nav>

<!-- ============ Ro'yxat ============ -->
<section class="reg-pane" id="regList" data-pane="list"<?= $tab !== 'list' ? ' hidden' : '' ?>>
<?php if (!$nAllPay): ?>
  <div class="card empty">
    <p>Bu MOCK ro'yxatida hali hech kim yo'q.<?= $test['reg_open'] ? ' Onlayn ro\'yxat ochiq — o\'quvchilar bot yoki havola orqali o\'zi yozilishi mumkin.' : '' ?></p>
    <a class="btn primary" href="<?= e($tabUrl('add')) ?>" data-tab="add">+ O'quvchi qo'shish</a>
  </div>
<?php else: ?>
  <form method="get" class="reg-filter filter" id="regFilter">
    <input type="hidden" name="p" value="registrations"><input type="hidden" name="id" value="<?= $tid ?>">
    <div class="rf-row">
      <input type="search" name="q" value="<?= e($fQ) ?>" placeholder="Ism, ID, telefon yoki maktab" autocomplete="off" aria-label="Qidirish">
      <?php if ($showPay): /* 2.5.5: naqd/xonaga o'tkazishdan keyin sonlari yangilanadi (data-live) */ ?><span id="regFpWrap" class="fg-wrap" data-live><select name="fp" aria-label="To'lov"><option value="">To'lov: hammasi</option><?php foreach (REG_PAY_LABEL as $k => $lbl): if (!$payCnt[$k] && $fP !== $k) continue; ?><option value="<?= $k ?>" <?= $fP === $k ? 'selected' : '' ?>><?= e($lbl) ?> (<?= $payCnt[$k] ?>)</option><?php endforeach; ?></select></span><?php endif; ?>
      <span id="regFgWrap" class="fg-wrap"><?php if (count($regGroups) > 1 || ($regGroups && !isset($regGroups['']))): ?><select name="fg" aria-label="Guruh"><option value="">Guruh: hammasi</option><?php foreach ($regGroups as $g => $n): ?><option value="<?= $g === '' ? '@none' : e($g) ?>" <?= $fG === ($g === '' ? '@none' : (string)$g) ? 'selected' : '' ?>><?= $g === '' ? 'Guruhsizlar' : e($g) ?> (<?= $n ?>)</option><?php endforeach; ?></select><?php elseif ($fG !== ''): ?><input type="hidden" name="fg" value="<?= e($fG) ?>"><?php endif; ?></span>
      <?php if ($rooms): ?><select name="room" aria-label="Xona"><option value="">Xona: hammasi</option><?php foreach ($rooms as $r): ?><option value="<?= (int)$r['id'] ?>" <?= $fRoom === (string)$r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?><option value="none" <?= $fRoom === 'none' ? 'selected' : '' ?>>Xonasizlar</option></select><?php endif; ?>
      <button type="button" class="btn sm ghost rf-more-btn" aria-expanded="<?= $moreOpen ? 'true' : 'false' ?>" aria-controls="rfMore" hidden title="Qayerdan va qachon yozilgan, varaq holati, tartib">Yana filtrlar<?= $nMore ? ' (' . $nMore . ')' : '' ?></button>
      <button class="btn sm rf-go">Qidirish</button>
    </div>
    <div class="rf-row rf-more" id="rfMore">
      <select name="fv" aria-label="Qayerdan yozilgan"><option value="">Qayerdan: hammasi</option><?php foreach (['self' => 'O\'zi yozilgan (bot, sayt)', 'bot' => 'Bot orqali', 'web' => 'Sayt orqali', 'admin' => 'Admin qo\'shgan'] as $k => $lbl): $n = $k === 'self' ? $viaCnt['bot'] + $viaCnt['web'] : $viaCnt[$k]; if (!$n && $fV !== $k) continue; ?><option value="<?= $k ?>" <?= $fV === $k ? 'selected' : '' ?>><?= $lbl ?> (<?= $n ?>)</option><?php endforeach; ?></select>
      <select name="fd" aria-label="Qachon yozilgan"><option value="">Qachon: istalgan</option><option value="today" <?= $fD === 'today' ? 'selected' : '' ?>>Bugun (<?= $nToday ?>)</option><option value="old" <?= $fD === 'old' ? 'selected' : '' ?>>Bugungacha (<?= $nAllPay - $nToday ?>)</option><?php foreach (array_slice($dayCnt, 0, 14, true) as $d => $n): ?><option value="<?= e($d) ?>" <?= $fD === $d ? 'selected' : '' ?>><?= e(date('d.m.Y', strtotime($d))) ?> (<?= $n ?>)</option><?php endforeach; ?></select>
      <?php if ($centers): ?><select name="fc" aria-label="Markaz"><option value="">Markaz: hammasi</option><option value="own" <?= $fC === 'own' ? 'selected' : '' ?>>O'z markazimiz</option><?php foreach ($centers as $cid => $cn): ?><option value="<?= (int)$cid ?>" <?= $fC === (string)$cid ? 'selected' : '' ?>><?= e($cn) ?></option><?php endforeach; ?></select><?php endif; ?>
      <select name="pr" aria-label="Varaq holati"><option value="">Varaq: hammasi</option><option value="new" <?= $fPr === 'new' ? 'selected' : '' ?>>chop etilmagan</option><option value="done" <?= $fPr === 'done' ? 'selected' : '' ?>>chop etilgan</option></select>
      <select name="o" aria-label="Tartib" title="Ro'yxat va varaqlar shu tartibda chiqadi"><?php foreach (array_filter(['room' => $rooms ? 'Tartib: xona va o\'rin' : null, 'name' => 'Tartib: alifbo', 'school' => 'Tartib: maktab / sinf', 'time' => 'Tartib: qo\'shilgan vaqt']) as $k => $lbl): ?><option value="<?= $k ?>" <?= $fO === $k ? 'selected' : '' ?>><?= $lbl ?></option><?php endforeach; ?></select>
    </div>
  </form>

  <div class="rgl-head" id="regHead" data-live>
    <div class="rgl-info">
      <b id="regCount"><?= count($list) ?><?= $filtered ? ' / ' . $nAllPay : '' ?> ta</b>
      <?php foreach ($actF as $k => $lbl): ?><a class="fchip" href="<?= e(url('registrations', ['id' => $tid] + array_diff_key($curF, [$k => 1]))) ?>" data-clear="<?= $k ?>" title="Filtrni olib tashlash"><?= e($lbl) ?> <span aria-hidden="true">×</span></a><?php endforeach; ?>
      <span id="regChips"><?php if ($regNone || $fG === '@none'): ?><a class="gx-chip<?= $fG === '@none' ? ' on' : '' ?>" href="<?= e($noneChipUrl) ?>" data-fg="<?= $fG === '@none' ? '' : '@none' ?>" title="<?= $fG === '@none' ? 'Filtrni olib tashlash' : 'Faqat guruhga biriktirilmaganlarni ko\'rsatish' ?>">Guruhsiz: <b><?= $regNone ?></b><?= $fG === '@none' ? ' <span aria-hidden="true">×</span>' : '' ?></a><?php endif; ?></span>
      <?php if (count($actF) + ($fG === '@none' ? 1 : 0) > 1): ?><a class="fchip clear" href="<?= e(url('registrations', ['id' => $tid] + ($fO !== $defO ? ['o' => $fO] : []))) ?>" data-clear="*">Hammasini tozalash</a><?php endif; ?>
    </div>
    <div class="rgl-acts">
      <a class="btn sm ghost" href="<?= e(url('export', ['what' => 'registrations', 'id' => $tid])) ?>"><?= icon('download', 14) ?>Excel</a>
      <?php if ($nPrintable): ?><a class="btn sm" target="_blank" href="<?= e($filterSheetUrl) ?>" title="Ro'yxatda ko'rinib turganlarning javoblar varaqalari (shu tartibda; band — to'lanmaganlarga varaq chiqmaydi)"><?= icon('print', 14) ?>Varaqlarni chop etish (<?= $nPrintable ?>)</a><?php endif; ?>
    </div>
  </div>

  <div id="regResults" data-live>
    <div class="table-wrap"><table class="tbl reg-tbl">
      <thead><tr>
        <th class="chk"><input type="checkbox" id="checkAll" aria-label="Hammasini belgilash" title="Hammasini belgilash. Qatorni bosib ham belgilash mumkin; Shift bilan — oraliq"<?= $list ? '' : ' disabled' ?>></th>
        <?php if ($rooms): ?><th>Xona · o'rin</th><?php endif; ?>
        <th>F.I.Sh</th><th>ID</th><th>Telefon</th>
        <?php if ($showPay): ?><th>To'lov</th><?php endif; ?>
        <th>Varaq</th>
        <?php if ($hasResp): ?><th>Test</th><?php endif; ?>
        <th class="right"><span class="sr-only">Amallar</span></th>
      </tr></thead>
      <tbody>
      <?php foreach ($list as $s): $sid = (int)$s['id']; $rs = $resp[$sid] ?? null; $ps = (string)$s['pay_status']; $cash = $ps === 'paid' && (string)$s['pay_method'] === 'cash';
        $sub = school_grade($s); $regAt = strtotime((string)$s['reg_at']); ?>
        <tr data-sid="<?= $sid ?>">
          <td class="chk"><input type="checkbox" name="ids[]" value="<?= $sid ?>" class="rowchk" form="regMass" aria-label="Belgilash"></td>
          <?php if ($rooms): ?>
          <td class="nowrap rgl-seat"><?php if ($s['room_id']): ?><button type="button" class="rchip" data-sid="<?= $sid ?>" data-room="<?= (int)$s['room_id'] ?>" title="Boshqa xonaga o'tkazish"><?= e($s['room_name']) ?> · <b class="seat"><?= (int)$s['seat'] ?></b></button><?php if ($s['notified_at']): ?><span class="ntf" title="Xona va o'rin xabari yuborilgan: <?= e($s['notified_at']) ?>">✉</span><?php endif; ?>
            <?php elseif ($ps !== 'unpaid'): ?><button type="button" class="rchip none" data-sid="<?= $sid ?>" data-room="0" title="Xonaga joylash">xonasiz</button>
            <?php else: ?><span class="muted" title="To'lov kutilmoqda — o'rin to'lovdan keyin">—</span><?php endif; ?></td>
          <?php endif; ?>
          <td class="rgl-name"><span class="nm"><?= e($s['full_name']) ?></span>
            <div class="small muted reg-sub"><?= group_chip($sid, (string)$s['group_name']) ?><?= $sub !== '' ? '<span>' . e($sub) . '</span>' : '' ?><span class="reg-src" title="Ro'yxatga qo'shilgan: <?= e(date('d.m.Y H:i', $regAt)) ?>"><?= e(REG_VIA_LABEL[(string)$s['via']] ?? (string)$s['via']) ?> · <?= e(date('d.m H:i', $regAt)) ?></span></div></td>
          <td class="mono small"><?= e($s['code']) ?></td>
          <td class="nowrap small"><?= e($s['phone'] ? fmt_phone($s['phone']) : '—') ?></td>
          <?php if ($showPay): ?>
          <td class="nowrap small pay-cell">
            <span class="tag <?= REG_PAY_TAG[$ps] ?? '' ?>" title="<?= e(($ps === 'paid' ? som((int)$s['paid_amount']) . ($s['paid_at'] ? ', ' . date('d.m.Y H:i', strtotime((string)$s['paid_at'])) : '') . ($cash ? ', naqd' : ', hamyondan') : ($ps === 'unpaid' ? 'To\'lov kutilmoqda · balansi: ' . som((int)$s['balance']) : (REG_PAY_LABEL[$ps] ?? $ps)))) ?>"><?= e($ps === 'unpaid' ? 'Band' : (REG_PAY_LABEL[$ps] ?? $ps)) ?><?= $cash ? ' · naqd' : '' ?></span>
            <?php if ($fin && $price > 0 && in_array($ps, ['unpaid', 'free'], true)): /* 2.5.4: naqd to'lovni shu joyida belgilash */ ?><button type="button" class="btn sm cash-btn" data-sid="<?= $sid ?>" data-sum="<?= e(som($price)) ?>" data-price="<?= $price ?>" data-name="<?= e($s['full_name']) ?>" title="O'quvchi naqd to'ladi — shu yerda belgilash (<?= e(som($price)) ?>)">Naqd</button><?php endif; ?>
          </td>
          <?php endif; ?>
          <td class="nowrap small"><?= $s['printed_at'] ? '<span class="tag green" title="Chop etilgan: ' . e($s['printed_at']) . '">✓ ' . e(date('d.m', strtotime($s['printed_at']))) . '</span>' : '<span class="muted" title="Varaq hali chop etilmagan">—</span>' ?></td>
          <?php if ($hasResp): ?><td class="nowrap small"><?= $rs === 'submitted' ? '<span class="tag green">topshirdi</span>' : ($rs ? '<span class="tag amber">jarayonda</span>' : '<span class="muted">—</span>') ?></td><?php endif; ?>
          <td class="right nowrap">
            <details class="pay-menu row-menu"><summary class="btn sm ghost" title="Amallar" aria-label="Amallar">⋯</summary>
              <div class="pay-menu-list">
                <a class="btn sm ghost" target="_blank" href="<?= e($sheetUrl(['sid' => $sid])) ?>"><?= icon('print', 14) ?>Varag'ini chop etish</a>
                <?php if ($fin && $cash && !isset($resp[$sid])): ?>
                <form method="post" onsubmit="return confirm(<?= e(json_encode('«' . $s['full_name'] . '» uchun naqd to\'lov belgisi bekor qilinsinmi? (xato belgilangan bo\'lsa) O\'quvchi yana «band» bo\'ladi.', JSON_UNESCAPED_UNICODE)) ?>)"><?= csrf_field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="op" value="uncash"><input type="hidden" name="sid" value="<?= $sid ?>"><button class="btn sm ghost">↶ Naqd belgisini bekor qilish</button></form>
                <?php endif; ?>
                <?php if ($fin && in_array($ps, ['unpaid', 'free'], true) && ($price > 0 || $ps === 'unpaid')): ?>
                  <?php if ($price > 0): ?>
                  <form method="post" onsubmit="return confirm(<?= e(json_encode('Naqd ' . som($price) . ' qabul qilindi deb yozilsinmi?', JSON_UNESCAPED_UNICODE)) ?>)"><?= csrf_field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="op" value="cash"><input type="hidden" name="sid" value="<?= $sid ?>"><input type="hidden" name="expect" value="<?= $price ?>"><button class="btn sm ghost">Naqd to'landi (<?= e(som($price)) ?>)</button></form>
                  <?php if ((int)$s['balance'] >= $price): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="op" value="wallet"><input type="hidden" name="sid" value="<?= $sid ?>"><button class="btn sm ghost">Hamyondan yechish (balansi <?= e(som((int)$s['balance'])) ?>)</button></form><?php endif; ?>
                  <?php if ($ps === 'free'): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="op" value="unpaid"><input type="hidden" name="sid" value="<?= $sid ?>"><button class="btn sm ghost">To'lov talab qilish</button></form><?php endif; ?>
                  <?php endif; ?>
                  <form method="post" class="row gap"><?= csrf_field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="op" value="waive"><input type="hidden" name="sid" value="<?= $sid ?>"><input name="note" placeholder="izoh" maxlength="120" aria-label="Imtiyoz izohi"><button class="btn sm ghost">Imtiyoz</button></form>
                <?php endif; ?>
                <form method="post" onsubmit="return confirm(<?= e(json_encode('«' . $s['full_name'] . '» ro\'yxatdan chiqarilsinmi?' . ($ps === 'paid' && (int)$s['paid_amount'] > 0 ? ' To\'lagan ' . som((int)$s['paid_amount']) . ' hamyoniga qaytariladi.' : ''), JSON_UNESCAPED_UNICODE)) ?>)"><?= csrf_field() ?><input type="hidden" name="action" value="remove"><input type="hidden" name="sid" value="<?= $sid ?>"><button class="btn sm danger-ghost">Ro'yxatdan chiqarish</button></form>
              </div>
            </details>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$list): ?><tr><td colspan="9" class="empty">Filtrga mos o'quvchi yo'q</td></tr><?php endif; ?>
      </tbody>
    </table></div>

    <form method="post" id="regMass" class="sel-bar"><?= csrf_field() ?><input type="hidden" name="action" value="mass">
      <span class="sb-n" id="selCount"><b>0</b> ta belgilangan</span>
      <button type="button" class="btn sm" id="printSel" disabled data-url="<?= e($sheetUrl(['order' => $fO])) ?>" data-all-url="<?= e($filterSheetUrl) ?>"><?= icon('print', 14) ?>Chop etish</button>
      <button type="button" class="btn sm" id="regGrpBtn" disabled title="Belgilangan o'quvchilarni guruhga biriktirish"><?= icon('users', 14) ?>Guruhga</button>
      <span class="bar-ops">
        <select name="op" id="regOp" aria-label="Belgilanganlar bilan amal" required>
          <option value="" selected disabled>Amalni tanlang…</option>
          <?php if ($showPay && $fin && $price > 0): ?><option value="cash">To'lov: naqd olindi</option><?php endif; ?>
          <?php if ($rooms): ?><option value="room">Xonaga o'tkazish</option><?php endif; ?>
          <option value="printed">"Chop etilgan" deb belgilash</option>
          <option value="unprinted">Qayta chop etishga belgilash</option>
          <?php if ($showPay && $fin): ?>
          <?php if ($price > 0): ?><option value="wallet">To'lov: hamyondan</option><option value="unpaid">To'lov talab qilish</option><?php endif; ?>
          <option value="waive">To'lov: imtiyoz</option>
          <?php endif; ?>
          <option value="remove">Ro'yxatdan chiqarish<?= $showPay ? ' (pul qaytadi)' : '' ?></option>
          <?php if ($showPay && $fin): ?><option value="remove_keep">Chiqarish — pul qaytmaydi</option><?php endif; ?>
        </select>
        <?php if ($rooms): ?><select name="to_room" class="op-room" aria-label="Qaysi xonaga"><?php foreach ($rooms as $r): ?><option value="<?= (int)$r['id'] ?>"><?= e($r['name']) ?></option><?php endforeach; ?><option value="0">— xonasiz —</option></select><?php endif; ?>
        <button class="btn sm primary" id="massDo" disabled onclick="var v=document.getElementById('regOp').value; return (v!=='remove' && v!=='remove_keep' && v!=='cash') || confirm(v==='cash' ? 'Belgilanganlar naqd to\'lagan deb yozilsinmi? (kirim va yechim yoziladi)' : 'Belgilanganlar ro\'yxatdan chiqarilsinmi?' + (v==='remove_keep' ? ' To\'lov QAYTARILMAYDI.' : ''))">Bajarish</button>
      </span>
      <button type="button" class="btn sm ghost sb-x" id="selClear" aria-label="Belgilashni bekor qilish" title="Belgilashni bekor qilish">✕</button>
    </form>
  </div>
<?php endif; ?>
</section>

<!-- ============ Qo'shish ============ -->
<section class="reg-pane" id="regAdd" data-pane="add"<?= $tab !== 'add' ? ' hidden' : '' ?>>
  <div class="pane-grid">
    <div class="card pane-card">
      <h3>Guruhdan qo'shish</h3>
      <?php if ($nStudents && $freeAll): ?>
      <?php /* 2.5.4: guruh oldindan tanlanmaydi; har qanday guruhni qo'shishdan oldin soni bilan so'raladi */ ?>
      <form method="post" class="row gap filter add-row" onsubmit="var o=this.group.selectedOptions[0]; return !!(o && o.value) && confirm(o.dataset.ask)"><?= csrf_field() ?><input type="hidden" name="action" value="add_group">
        <select name="group" aria-label="Guruh" class="grow" required>
          <option value="" selected disabled>Guruhni tanlang…</option>
          <?php foreach ($groups as $g): if (!(int)$g['free']) continue; ?><option value="<?= e($g['g']) ?>" data-ask="<?= e('«' . $g['g'] . '» guruhidan ' . (int)$g['free'] . ' ta o\'quvchi shu MOCK ro\'yxatiga qo\'shilsinmi?') ?>"><?= e($g['g']) ?> — +<?= (int)$g['free'] ?> kishi</option><?php endforeach; ?>
          <?php if ($noGroup && (int)$noGroup['free']): ?><option value="@none" data-ask="<?= e('Guruhsiz ' . (int)$noGroup['free'] . ' ta o\'quvchi (bot va saytda ro\'yxatdan o\'tganlar shu yerda) shu MOCK ro\'yxatiga qo\'shilsinmi?') ?>">Guruhsizlar — +<?= (int)$noGroup['free'] ?></option><?php endif; ?>
          <option value="@all" data-ask="<?= e('DIQQAT: bazadagi BARCHA faol o\'quvchilar (' . $freeAll . ' ta) shu MOCK ro\'yxatiga qo\'shilsinmi?') ?>">Barcha o'quvchilar — +<?= $freeAll ?></option>
        </select>
        <?= $paySel() ?>
        <button class="btn primary">Qo'shish</button></form>
      <?php elseif ($nStudents): ?><p class="small muted">Barcha faol o'quvchilar ro'yxatda ✓</p>
      <?php else: ?><p class="small muted">Bazada o'quvchi yo'q — <a href="<?= e(url('students')) ?>">O'quvchilar</a> sahifasida qo'shing.</p><?php endif; ?>
      <div class="pane-sub">
        <h3>ID bo'yicha</h3>
        <p class="small muted">Telefon orqali yoki markazga kelib yozilganlar (ro'yxat yopiq bo'lsa ham qo'shiladi).</p>
        <form method="post" class="form"><?= csrf_field() ?><input type="hidden" name="action" value="add">
          <textarea name="codes" rows="2" class="mono" placeholder="545742, 929446 …" aria-label="ID lar"></textarea>
          <div class="row gap wrap center-v mt"><?= $paySel() ?><button class="btn sm">Qo'shish</button></div></form>
      </div>
    </div>
    <div class="card pane-card">
      <h3>Onlayn ro'yxat — <?= $test['reg_open'] ? 'ochiq' : 'yopiq' ?></h3>
      <p class="small muted"><?= $test['reg_open'] ? 'O\'quvchilar bot yoki shu havola orqali o\'zi yoziladi.' : 'Ochilsa, o\'quvchilar bot yoki shu havola orqali o\'zi yoziladi.' ?></p>
      <input class="mono small copy-in" readonly value="<?= e($link) ?>" onclick="this.select()" aria-label="Ro'yxatdan o'tish havolasi">
      <form method="post" class="mt"<?= $nExpiring ? ' onsubmit="return confirm(' . e(json_encode('Ro\'yxat yopilsa, to\'lanmagan ' . $nExpiring . ' ta band bekor bo\'ladi (kutilayotgan cheki borlar chek ko\'rib chiqilguncha qoladi). Davom etasizmi?', JSON_UNESCAPED_UNICODE)) . ')"' : '' ?>><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><button class="btn sm <?= $test['reg_open'] ? 'ghost' : 'primary' ?>"><?= $test['reg_open'] ? 'Ro\'yxatni yopish' : 'Ro\'yxatni ochish' ?></button></form>
    </div>
  </div>

  <div class="card" id="unreg">
    <h3>Ro'yxatga kiritilmagan o'quvchilar <span class="muted">(<?= $freeAll ?>)</span></h3>
    <p class="small muted">Bazada bor, lekin shu MOCK ro'yxatida yo'q o'quvchilar. Belgilab qo'shing yoki filtrga mos hammasini bir bosishda qo'shing.</p>
    <?php if (!$nStudents): ?>
      <p class="empty">Bazada hali o'quvchi yo'q — avval <a href="<?= e(url('students')) ?>">"O'quvchilar"</a> sahifasida qo'shing.</p>
    <?php elseif (!$freeAll): ?>
      <p class="empty">Barcha o'quvchilar shu MOCK ro'yxatida.</p>
    <?php else: ?>
    <form method="get" class="row gap wrap center-v filter filter-row">
      <input type="hidden" name="p" value="registrations"><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="tab" value="add"><input type="hidden" name="un" value="1">
      <input name="ns" value="<?= e($nf['s']) ?>" placeholder="Ism, ID, telefon yoki maktab" aria-label="Qidirish">
      <select name="ng" aria-label="Guruh"><option value="">Barcha guruhlar</option><?php foreach ($groups as $g): ?><option value="<?= e($g['g']) ?>" <?= $nf['g'] === $g['g'] ? 'selected' : '' ?>><?= e($g['g']) ?></option><?php endforeach; ?><?php if ($noGroup): ?><option value="@none" <?= $nf['g'] === '@none' ? 'selected' : '' ?>>Guruhsizlar</option><?php endif; ?></select>
      <?php if ($centers): ?><select name="nc" aria-label="Markaz"><option value="">Barcha markazlar</option><option value="own" <?= $nf['c'] === 'own' ? 'selected' : '' ?>>O'z markazimiz</option><?php foreach ($centers as $cid => $cn): ?><option value="<?= (int)$cid ?>" <?= $nf['c'] === (string)$cid ? 'selected' : '' ?>><?= e($cn) ?></option><?php endforeach; ?></select><?php endif; ?>
      <button class="btn sm">Filtr</button>
      <?php if ($unFiltered): ?><a class="small keep-scroll" href="<?= e($tabUrl('add', ['un' => 1])) ?>">Tozalash</a><?php endif; ?>
    </form>
    <?php if ($unList): ?>
    <form method="post">
      <?= csrf_field() ?><input type="hidden" name="f_un" value="1"><input type="hidden" name="f_ng" value="<?= e($nf['g']) ?>"><input type="hidden" name="f_nc" value="<?= e($nf['c']) ?>"><input type="hidden" name="f_ns" value="<?= e($nf['s']) ?>">
      <div class="mass-bar card soft mt">
        <label class="check"><input type="checkbox" id="unAll"> Barchasi</label>
        <?= $paySel() ?>
        <button class="btn sm primary" name="action" value="add_sel">Tanlanganlarni qo'shish</button>
        <span class="muted small" id="unCount">0 ta tanlangan</span>
        <button class="btn sm" style="margin-left:auto" name="action" value="add_filter" onclick="return confirm('<?= $unFiltered ? 'Filtrga mos' : 'Ro\'yxatga kiritilmagan' ?> <?= $unTotal ?> ta o\'quvchi shu MOCK ro\'yxatiga qo\'shilsinmi?')"><?= $unFiltered ? 'Filtrdagi' : 'Hammasini' ?> qo'shish (<?= $unTotal ?>)</button>
      </div>
      <div class="table-wrap"><table class="tbl compact-tbl">
        <thead><tr><th></th><th>ID</th><th>F.I.Sh</th><th>Guruh</th><th>Telefon</th></tr></thead>
        <tbody>
        <?php foreach ($unList as $s): ?>
          <tr>
            <td><input type="checkbox" name="ids[]" value="<?= (int)$s['id'] ?>" class="unchk" aria-label="Belgilash"></td>
            <td class="mono"><?= e($s['code']) ?></td>
            <td><?= e($s['full_name']) ?><?php if ($s['school'] || $s['grade_level']): ?><div class="small muted"><?= e(school_grade($s)) ?></div><?php endif; ?></td>
            <td class="small"><?= e($s['group_name'] ?: '—') ?><?php if ($s['center_id']): ?><div class="muted"><?= e($centers[(int)$s['center_id']] ?? '') ?></div><?php endif; ?></td>
            <td class="nowrap small"><?= e($s['phone'] ? fmt_phone($s['phone']) : '—') ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
      <?php if ($unTotal > count($unList)): ?><p class="small muted">Birinchi <?= count($unList) ?> tasi ko'rsatildi (jami <?= $unTotal ?>) — filtrdan foydalaning yoki "<?= $unFiltered ? 'Filtrdagi' : 'Hammasini' ?> qo'shish" tugmasini bosing.</p><?php endif; ?>
    </form>
    <?php else: ?>
      <p class="empty">Filtrga mos o'quvchi yo'q.</p>
    <?php endif; ?>
    <?php endif; ?>
  </div>
</section>

<!-- ============ Xonalar ============ -->
<section class="reg-pane" id="regRooms" data-pane="rooms"<?= $tab !== 'rooms' ? ' hidden' : '' ?>>
  <div class="pane-grid">
    <div class="card pane-card" id="roomsBox" data-live>
      <h3>Xonalar</h3>
      <p class="small muted"><?= $rooms ? count($rooms) . ' ta xona · ' . $seats . ' o\'rin' . ($seats < $N ? ' — <b class="warn-txt">' . ($N - $seats) . ' o\'rin yetmaydi</b>' : '') . ($autoSeat ? ' · to\'lov tasdiqlanganda o\'rin avtomatik beriladi' : '') : ($autoSeat ? 'Xonalar kiritilmagan — qo\'shsangiz, to\'lov tasdiqlanganda o\'rin avtomatik beriladi va o\'quvchiga botda yuboriladi.' : 'Xonalar kiritilmagan (bitta xonada o\'tsa — shart emas).') ?></p>
      <?php if ($rooms): ?>
        <div class="room-rows">
          <?php foreach ($rooms as $r): $full = (int)$r['used'] >= (int)$r['capacity']; ?>
            <div class="room-row">
              <form method="post" class="room-edit filter"><?= csrf_field() ?><input type="hidden" name="action" value="room_edit"><input type="hidden" name="rid" value="<?= (int)$r['id'] ?>">
                <input name="name" value="<?= e($r['name']) ?>" maxlength="60" aria-label="Xona nomi">
                <input name="capacity" type="number" min="1" max="500" value="<?= (int)$r['capacity'] ?>" class="num-in" aria-label="Sig'im" title="Sig'im">
                <input name="proctor" value="<?= e($r['proctor']) ?>" maxlength="120" placeholder="Nazoratchi" aria-label="Nazoratchi" title="Nazoratchi (xona ro'yxatida va o'quvchi kabinetida ko'rinadi)">
                <button class="btn sm ghost" title="Saqlash"><?= icon('check', 14) ?></button>
              </form>
              <span class="room-used <?= $full ? 'warn-txt' : '' ?>" title="Band o'rinlar"><?= (int)$r['used'] ?>/<?= (int)$r['capacity'] ?></span>
              <form method="post" onsubmit="return confirm('Xona o\'chirilsinmi? Undagi o\'quvchilar xonasiz qoladi.')"><?= csrf_field() ?><input type="hidden" name="action" value="room_del"><input type="hidden" name="rid" value="<?= (int)$r['id'] ?>"><button class="btn sm danger-ghost" title="O'chirish">×</button></form>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <?php $cr = center_rooms(); $crNew = array_filter($cr, function ($c) use ($rooms) { foreach ($rooms as $r) if (mb_strtolower($r['name']) === mb_strtolower($c['name'])) return false; return true; }); ?>
      <?php if ($crNew): ?>
        <form method="post" class="mt"><?= csrf_field() ?><input type="hidden" name="action" value="room_preset">
          <button class="btn <?= $rooms ? '' : 'primary' ?> wide">Markaz xonalarini qo'shish — <?= count($crNew) ?> ta, <?= array_sum(array_map(fn($c) => (int)$c['capacity'], $crNew)) ?> o'rin</button></form>
      <?php elseif (!$cr): ?>
        <p class="small muted mt">Markaz xonalarini bir marta <a href="<?= e(url('settings')) ?>#xonalar">Sozlamalar → Xonalar va sig'im</a> da kiriting — keyin har MOCK ga bir bosishda qo'shiladi.</p>
      <?php endif; ?>
      <details class="rs-more" <?= !$rooms && !$cr ? 'open' : '' ?>><summary>Boshqa xona qo'shish</summary>
        <form method="post" class="form room-add"><?= csrf_field() ?><input type="hidden" name="action" value="room_add">
          <div class="grid3">
            <label>Nomi <input name="name" maxlength="60" placeholder="12-xona"></label>
            <label>Sig'im <input name="capacity" type="number" min="1" max="500" value="30"></label>
            <label>Soni <input name="count" type="number" min="1" max="50" value="1" title="Bir nechta bir xil xona qo'shish"></label>
          </div>
          <button class="btn sm">Qo'shish</button>
        </form>
      </details>
    </div>
    <div class="card pane-card" id="distBox" data-live>
      <h3>Xonalarga joylashtirish</h3>
      <p class="small muted"><?= !$rooms ? 'Avval xona qo\'shing.' : ($N ? "Joylashgan: <b>$nPlaced / $N</b>" . ($nNoRoom > 0 ? ' · xonasiz: <b>' . $nNoRoom . '</b>' : ' ✓') : 'Ro\'yxat bo\'sh.') ?><?= $payCnt['unpaid'] ? ' Band (to\'lanmagan) ' . $payCnt['unpaid'] . ' ta — to\'lagach joylanadi.' : '' ?></p>
      <?php if ($rooms && $N): ?>
      <form method="post" class="form dist-form"><?= csrf_field() ?><input type="hidden" name="action" value="distribute"><input type="hidden" name="balance" value="1">
        <label>Qanday o'tqazilsin
          <select name="order"><option value="mix">Aralash — bir guruh/maktab yonma-yon o'tirmaydi (tavsiya)</option><option value="name">Alifbo bo'yicha</option><option value="random">Tasodifiy</option><option value="group">Guruh bo'yicha</option><option value="school">Maktab / sinf bo'yicha</option><option value="time">Ro'yxatdan o'tish vaqti bo'yicha</option></select></label>
        <?php if ($nPlaced > 0): ?>
          <label class="check"><input type="radio" name="mode" value="new" checked> Faqat xonasizlarni joylash<?= $nNoRoom > 0 ? ' (' . $nNoRoom . ')' : '' ?></label>
          <label class="check"><input type="radio" name="mode" value="all"> Hammasini qaytadan joylash</label>
        <?php else: ?><input type="hidden" name="mode" value="new"><?php endif; ?>
        <details class="rs-more"><summary>Qo'shimcha</summary>
          <label>Seed <input name="seed" inputmode="numeric" maxlength="9" placeholder="bo'sh — yangi tasodifiy" title="Tasodifiy/aralash tartib uchun: bir xil raqam — bir xil joylashuv"></label>
          <p class="small muted">Xonalar teng to'ldiriladi (masalan 100 kishi, 3 xona: 34/33/33). Keyin istalgan o'quvchini ro'yxatda xona tugmasini bosib boshqa xonaga o'tkazish mumkin.</p>
        </details>
        <button class="btn primary wide" onclick="var m=this.form.querySelector('input[name=mode]:checked'); return !m || m.value!=='all' || confirm('Barcha o\'rinlar qaytadan taqsimlanadi. Chop etilgan varaqlardagi va o\'quvchilarga yuborilgan xona/o\'rin eskiradi — keyin «Chop etish va xabar» bo\'limida yangisini yuboring. Davom etasizmi?')">Joylashtirish</button>
      </form>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- ============ Chop etish va xabar ============ -->
<section class="reg-pane" id="regPrint" data-pane="print"<?= $tab !== 'print' ? ' hidden' : '' ?>>
  <div class="card pane-card" id="printBox" data-live>
    <h3>Javoblar varaqalari</h3>
    <p class="small muted"><?= $N ? 'Varaqda ism, ID' . ($rooms ? ', xona va o\'rin' : '') . ' yoziladi. Chop etilgan: <b>' . $nPrinted . ' / ' . $N . '</b>.' : 'Ro\'yxat bo\'sh — chop etiladigan varaq yo\'q.' ?><?= $payCnt['unpaid'] ? ' Band (to\'lanmagan)larga varaq chiqmaydi.' : '' ?></p>
    <?php if ($N): ?>
    <div class="rs-actions">
      <?php if ($rooms): ?>
        <a class="btn primary" target="_blank" href="<?= e($sheetUrl(['order' => 'room', 'sep' => 1])) ?>" title="Xona → o'rin tartibida; har xona oldidan ajratuvchi varaq"><?= icon('print', 16) ?>Hammasi — xonalar bo'yicha (<?= $N ?>)</a>
      <?php endif; ?>
      <a class="btn <?= $rooms ? '' : 'primary' ?>" target="_blank" href="<?= e($sheetUrl(['only' => 'new'] + ($rooms ? ['order' => 'room', 'sep' => 1] : []))) ?>"><?= icon('print', 16) ?>Faqat chop etilmaganlar (<?= $N - $nPrinted ?>)</a>
      <?php if (!$rooms): ?><a class="btn" target="_blank" href="<?= e($sheetUrl([])) ?>"><?= icon('print', 16) ?>Hammasi (<?= $N ?>)</a>
        <a class="btn ghost" href="<?= e(url('room_pack', ['id' => $tid, 'fmt' => 'pdf', 'room' => 'all', 'what' => 'sheets'])) ?>" title="Barcha varaqlar bitta PDF faylda (printerga yoki boshqa kompyuterga)"><?= icon('download', 16) ?>PDF yuklab olish</a><?php endif; ?>
    </div>
    <?php endif; ?>
  </div>

  <?php if ($rooms && $N): /* 2.5.4: xonalar bo'yicha — har xona alohida chop etish va yuklab olish (PDF), hammasi — ZIP / Excel */
    $rpUrl = fn(array $p) => url('room_pack', ['id' => $tid] + $p);
    $rpPr = []; foreach ($all as $x) if ($x['room_id'] && $x['printed_at']) $rpPr[(int)$x['room_id']] = ($rpPr[(int)$x['room_id']] ?? 0) + 1; ?>
  <div class="card pane-card rp-box" id="rpBox" data-live>
    <div class="rp-head">
      <div><h3>Xonalar bo'yicha</h3><p class="small muted" style="margin:0">Har xona — alohida chop etish yoki bitta PDF fayl (eshik va davomat ro'yxati, javoblar varaqalari o'rin tartibida).</p></div>
      <span class="rp-dl">
        <select id="rpWhat" aria-label="PDF ga nima kirsin" title="Yuklab olinadigan PDF tarkibi"><?php foreach (ROOM_PACK_WHAT as $k => $lbl): ?><option value="<?= $k ?>"><?= e($lbl) ?></option><?php endforeach; ?></select>
        <a class="btn sm" data-rp href="<?= e($rpUrl(['fmt' => 'zip'])) ?>" title="Har xona — alohida PDF fayl, hammasi bitta ZIP arxivda"><?= icon('download', 14) ?>Hamma xonalar (ZIP)</a>
        <a class="btn sm ghost" href="<?= e($rpUrl(['fmt' => 'xlsx'])) ?>" title="Excel: har xona — alohida varaq"><?= icon('download', 14) ?>Excel</a>
      </span>
    </div>
    <div class="table-wrap"><table class="tbl compact-tbl rp-tbl">
      <thead><tr><th>Xona</th><th class="num">Kishi</th><th class="num">Chop etilgan</th><th>Chop etish</th><th>Yuklab olish</th></tr></thead>
      <tbody>
      <?php foreach ($rooms as $r): $u = (int)$r['used']; $rid = (int)$r['id']; $pr = (int)($rpPr[$rid] ?? 0); ?>
        <tr>
          <td><b><?= e($r['name']) ?></b><?= $r['proctor'] !== '' ? '<div class="small muted">' . e($r['proctor']) . '</div>' : '' ?></td>
          <td class="num nowrap"><?= $u ?> / <?= (int)$r['capacity'] ?></td>
          <td class="num nowrap"><?= !$u ? '—' : ($pr >= $u ? '<span class="tag green">✓ ' . $pr . '</span>' : $pr . ' / ' . $u) ?></td>
          <td class="rp-acts"><?php if ($u): ?>
            <a class="btn sm ghost" target="_blank" href="<?= e($sheetUrl(['room' => $rid, 'order' => 'room', 'sep' => 1])) ?>" title="Shu xonaning javoblar varaqalari (o'rin tartibida)"><?= icon('print', 13) ?>Varaqlar</a>
            <a class="btn sm ghost" target="_blank" href="<?= e(url('room_list', ['id' => $tid, 'room' => $rid])) ?>" title="Davomat ro'yxati (imzo bilan)"><?= icon('print', 13) ?>Davomat</a>
            <a class="btn sm ghost" target="_blank" href="<?= e(url('room_door', ['id' => $tid, 'room' => $rid])) ?>" title="Xona eshigiga: o'rin → ism"><?= icon('print', 13) ?>Eshik</a>
          <?php else: ?><span class="small muted">bo'sh</span><?php endif; ?></td>
          <td class="rp-acts"><?php if ($u): ?>
            <a class="btn sm" data-rp href="<?= e($rpUrl(['fmt' => 'pdf', 'room' => $rid])) ?>" title="Shu xona — bitta PDF fayl"><?= icon('download', 13) ?>PDF</a>
            <?php if ($pr < $u): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="room_printed"><input type="hidden" name="rid" value="<?= $rid ?>"><button class="btn sm ghost" title="Shu xonaning varaqlari chop etildi deb belgilash (PDF dan chop etilgan bo'lsa)">✓ chop etildi</button></form><?php endif; ?>
          <?php endif; ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if ($nNoRoom > 0): ?>
        <tr class="rp-none">
          <td><b>Xonasizlar</b><div class="small muted">joy yetmagan yoki hali joylanmagan</div></td>
          <td class="num"><?= $nNoRoom ?></td><td class="num">—</td>
          <td class="rp-acts"><a class="btn sm ghost" target="_blank" href="<?= e($sheetUrl(['room' => 'none', 'order' => 'room', 'sep' => 1])) ?>"><?= icon('print', 13) ?>Varaqlar</a></td>
          <td class="rp-acts"><a class="btn sm" data-rp href="<?= e($rpUrl(['fmt' => 'pdf', 'room' => 'none'])) ?>"><?= icon('download', 13) ?>PDF</a></td>
        </tr>
      <?php endif; ?>
      </tbody>
    </table></div>
    <p class="small"><a target="_blank" href="<?= e(url('room_list', ['id' => $tid])) ?>">Davomat — hamma xonalar</a> · <a target="_blank" href="<?= e(url('room_door', ['id' => $tid])) ?>">Eshik — hamma xonalar</a> · <a target="_blank" href="<?= e(url('room_door', ['id' => $tid, 'mode' => 'all'])) ?>">Kirishdagi umumiy ro'yxat</a></p>
  </div>
  <?php endif; ?>

  <?php if ($rooms && $nPlaced > 0): $toSend = count($np['bot']) + count($np['sms']); ?>
  <div class="card pane-card" id="regNotify" data-live>
    <h3>O'quvchilarga xona va o'rin xabari</h3>
    <?php if (!$canSend): ?>
      <p class="small muted">Telegram bot yoki Eskiz SMS ulangach yuboriladi. <a href="<?= e(url('settings')) ?>#xabarlar">Sozlamalar →</a></p>
    <?php else: ?>
      <p class="small">Olgan: <b><?= $np['done'] ?></b> · yuboriladi: <b><?= count($np['bot']) ?></b> Telegram + <b><?= count($np['sms']) ?></b> SMS<?php if ($np['none']): ?> · <span class="warn-txt">yetkazib bo'lmaydi: <b><?= count($np['none']) ?></b></span><?php endif; ?></p>
      <div class="row gap wrap">
        <form method="post" onsubmit="return confirm('<?= $toSend ?> ta o\'quvchiga xona va o\'rin yuborilsinmi?<?= count($np['sms']) ? ' (SMS pullik: ' . count($np['sms']) . ' ta)' : '' ?>')"><?= csrf_field() ?><input type="hidden" name="action" value="notify_rooms"><button class="btn sm primary" <?= $toSend ? '' : 'disabled' ?>>Tasdiqlash va yuborish (<?= $toSend ?>)</button></form>
        <form method="post" onsubmit="return confirm('Hammasiga (avval olganlarga ham) qayta yuborilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="notify_rooms"><input type="hidden" name="resend" value="1"><button class="btn sm ghost">Hammasiga qayta</button></form>
      </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</section>
<script type="application/json" id="roomsData" data-live><?= json_encode($roomsJs, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<script>
(function(){
  // 2.5.5: Ro'yxat sahifasi — bo'limlar (yorliqlar), filtr ro'yxat ustida, belgilash paneli pastda (faqat belgilanganda),
  // qatordagi xona tugmasi, naqd to'lov joyida. Sahifa yangilanmaydi — kerakli qismlar almashtiriladi.
  const $ = s => document.querySelector(s);
  const boxes = () => [...document.querySelectorAll('.rowchk')];
  const csrfTok = () => { const m = document.querySelector('meta[name=csrf]'); return m ? m.content : ''; };
  const lost = () => !document.activeElement || document.activeElement === document.body;   // fokus yo'qolgan (element almashtirilgan)
  const listPane = $('#regList');
  if (listPane) listPane.classList.add('js');
  let last = null;

  // ---------- belgilash ----------
  const upd = () => {
    const bx = boxes(), n = bx.filter(b => b.checked).length, all = $('#checkAll'), pb = $('#printSel'), db = $('#massDo'), cnt = $('#selCount'), gb = $('#regGrpBtn'), bar = $('#regMass'), op = $('#regOp');
    bx.forEach(b => b.closest('tr').classList.toggle('sel', b.checked));
    if (cnt) cnt.innerHTML = '<b>' + n + '</b> ta belgilangan';
    if (pb) { pb.disabled = n === 0; pb.lastChild.textContent = n ? 'Chop etish (' + n + ')' : 'Chop etish'; }
    if (db) db.disabled = n === 0 || !(op && op.value);   // amal tanlanmaguncha «Bajarish» bosilmaydi
    if (gb) gb.disabled = n === 0;   // 2.5.2: «Guruhga biriktirish» (assets/students.js)
    if (bar) bar.classList.toggle('on', n > 0);
    if (all) { all.checked = n > 0 && n === bx.length; all.indeterminate = n > 0 && n < bx.length; }
  };
  const roomOp = () => { const op = $('#regOp'), rs = $('.op-room'); if (op && rs) rs.hidden = op.value !== 'room'; };
  const setRange = (to, state) => {
    const bx = boxes(), a = bx.indexOf(last), b = bx.indexOf(to);
    if (a < 0 || b < 0) return;
    bx.slice(Math.min(a, b), Math.max(a, b) + 1).forEach(x => x.checked = state);
  };
  document.addEventListener('change', e => {
    if (e.target.id === 'checkAll') { boxes().forEach(b => b.checked = e.target.checked); upd(); }
    if (e.target.id === 'regOp') { roomOp(); upd(); }
  });
  document.addEventListener('click', e => {
    const t = e.target;
    document.querySelectorAll('.pay-menu[open]').forEach(m => { if (!m.contains(t)) m.removeAttribute('open'); });   // menyu tashqarisi bosilsa yopiladi
    if (t.closest && t.closest('#selClear')) { boxes().forEach(b => b.checked = false); last = null; upd(); return; }
    if (t.classList && t.classList.contains('rowchk')) {          // katakchaning o'zi (Shift bilan — oraliq)
      if (e.shiftKey && last) setRange(t, t.checked);
      last = t; upd(); return;
    }
    const pb = t.closest && t.closest('#printSel');
    if (pb) {
      const bx = boxes(), ids = bx.filter(b => b.checked).map(b => b.value);
      if (!ids.length) return;
      // Hammasi belgilangan bo'lsa — filtr bo'yicha (manzil qisqa qoladi), aks holda belgilangan ID lar bo'yicha
      window.open(ids.length === bx.length ? pb.dataset.allUrl : pb.dataset.url + '&sids=' + ids.join(','), '_blank');
      return;
    }
    const tr = t.closest && t.closest('.reg-tbl tbody tr');       // qatorning bo'sh joyi
    if (!tr || t.closest('input, select, button, a, label, form, details, .cash-ask, .rsel')) return;
    const cb = tr.querySelector('.rowchk'); if (!cb) return;
    if (e.shiftKey && last) { window.getSelection && window.getSelection().removeAllRanges(); setRange(cb, !cb.checked); }
    else cb.checked = !cb.checked;
    last = cb; upd();
  });

  // ---------- bo'limlar (yorliqlar) ----------
  // Manzilda «tab» — qaysi bo'lim ochiq. Kiritilmaganlar filtri (un, ng, nc, ns) bo'lsa server «Qo'shish» ni ochadi —
  // shuning uchun bunday manzilda «Ro'yxat» ham aniq yoziladi (amal yoki F5 dan keyin boshqa bo'limga tushib qolmasin).
  const SRV_ADD = ['un', 'ng', 'nc', 'ns'];
  const here = () => location.pathname.split('/').pop() + location.search + location.hash;
  const tabUrl = (url, k) => {
    const u = new URL(url, location.href);
    if (k === 'list' && !SRV_ADD.some(p => u.searchParams.has(p))) u.searchParams.delete('tab'); else u.searchParams.set('tab', k);
    return u.pathname.split('/').pop() + u.search + u.hash;
  };
  const curTab = () => { const a = document.querySelector('#regTabs a.on'); return a ? a.dataset.tab : 'list'; };
  const showTab = k => {
    if (!document.querySelector('.reg-pane[data-pane="' + k + '"]')) return;
    document.querySelectorAll('.reg-pane').forEach(p => { p.hidden = p.dataset.pane !== k; });
    document.querySelectorAll('#regTabs a[data-tab]').forEach(a => {
      const on = a.dataset.tab === k;
      a.classList.toggle('on', on);
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    const nu = tabUrl(location.href, k);
    if (nu !== here()) history.replaceState(null, '', nu);
  };
  document.addEventListener('click', e => {
    const a = e.target.closest && e.target.closest('a[data-tab]');
    if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.button) return;
    e.preventDefault();
    showTab(a.dataset.tab);
    const nav = $('#regTabs');
    if (nav && nav.getBoundingClientRect().top < 0) nav.scrollIntoView({ block: 'start' });
  });

  // ---------- so'rovlar navbati ----------
  // Har so'rov (filtr yoki amal) yangi raqam oladi: eskirgan javob qo'llanmaydi. Amallar (naqd, xonaga o'tkazish) ketma-ket
  // bajariladi — har birining javobi oldingisidan keyingi holat; filtr javobi yozilayotgan amal tugashini kutadi.
  let seq = 0, ctl = null, timer = null, chain = Promise.resolve();
  const busy = on => { const b = $('#regResults'); if (b) b.classList.toggle('is-loading', on); };

  // ---------- jonli filtr (sahifa yangilanmaydi va joyidan siljimaydi) ----------
  const ff = $('#regFilter');
  const formUrl = () => {
    const q = new URLSearchParams();
    for (const [k, v] of new FormData(ff)) if (String(v).trim() !== '') q.set(k, String(v).trim());
    return 'index.php?' + q.toString();
  };
  // ro'yxat qaysi filtr bo'yicha (tartib standart bo'lsa — yozilmagani bilan bir xil)
  const LIST_KEYS = ['q', 'fp', 'fg', 'room', 'fv', 'fd', 'fc', 'pr', 'o'];
  const listKey = url => {
    const u = new URL(url, location.href), o0 = ff && ff.elements.o && ff.elements.o.options[0] ? ff.elements.o.options[0].value : '';
    return LIST_KEYS.map(k => { let v = (u.searchParams.get(k) || '').trim(); if (k === 'o' && v === o0) v = ''; return k + '=' + v; }).join('&');
  };
  const moreCount = () => {                                                       // «Yana filtrlar (N)» — ichida tanlanganlar soni
    const mb = ff && ff.querySelector('.rf-more-btn'), more = $('#rfMore');
    if (!mb || !more) return;
    const n = [...more.querySelectorAll('select')].filter(x => x.name === 'o' ? x.selectedIndex > 0 : x.value !== '').length;
    mb.textContent = 'Yana filtrlar' + (n ? ' (' + n + ')' : '');
  };
  async function load(url, full) {
    clearTimeout(timer);
    if (ctl) ctl.abort();
    const c = ctl = new AbortController(), my = ++seq;
    busy(true);
    try {
      await chain;                                                                // amal yozilayotgan bo'lsa — tugashini kutamiz
      if (my !== seq) return;
      const html = await fetch(url, { signal: c.signal, credentials: 'same-origin' }).then(r => { if (!r.ok) throw new Error(r.status); return r.text(); });
      if (my !== seq) return;                                                     // shu orada yangiroq so'rov boshlangan
      const doc = new DOMParser().parseFromString(html, 'text/html');
      if (!doc.querySelector('#regResults')) throw new Error('javob noto\'g\'ri');   // masalan, sessiya tugagan
      // full — guruhlar o'zgargach: guruh filtri (sonlari bilan) ham yangilanadi
      ['#regResults', '#regHead'].concat(full ? ['#regFgWrap'] : []).forEach(sel => { const n = doc.querySelector(sel), o = $(sel); if (n && o) o.replaceWith(document.importNode(n, true)); });
      history.replaceState(null, '', tabUrl(url, curTab()));                     // ochiq bo'lim manzilda qoladi
      last = null; roomOp(); upd(); moreCount();
    } catch (err) {
      if (err.name !== 'AbortError' && my === seq) location.href = url;           // xato bo'lsa — oddiy usulda ochamiz
    } finally {
      if (my === seq) { busy(false); ctl = null; }
    }
  }
  const clearFilters = () => {
    ff.q.value = '';
    ff.querySelectorAll('select').forEach(s => { if (s.name !== 'o') s.value = ''; });
    ff.querySelectorAll('input[type=hidden][name=fg]').forEach(h => h.remove());
  };
  if (ff) {
    ff.addEventListener('submit', e => { e.preventDefault(); load(formUrl()); });
    ff.addEventListener('change', e => { if (e.target.tagName === 'SELECT') load(formUrl()); });
    ff.q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => load(formUrl()), 350); });
    const go = ff.querySelector('.rf-go'); if (go) go.hidden = true;           // jonli — «Qidirish» tugmasi shart emas
    const mb = ff.querySelector('.rf-more-btn'), more = $('#rfMore');
    if (mb && more) {                                                           // «Yana filtrlar»: qayerdan, qachon, markaz, varaq, tartib
      mb.hidden = false;
      more.hidden = mb.getAttribute('aria-expanded') !== 'true';
      mb.addEventListener('click', () => { const open = more.hidden; more.hidden = !open; mb.setAttribute('aria-expanded', open ? 'true' : 'false'); });
      ff.addEventListener('change', moreCount);
    }
    document.addEventListener('click', e => {
      const t = e.target;
      // ro'yxat ustidagi filtr belgisi: × — shu filtrni olib tashlash
      const c = t.closest && t.closest('#regHead a[data-clear]');
      if (c) {
        e.preventDefault();
        const k = c.dataset.clear;
        if (k === '*') clearFilters();
        else { const f = ff.elements[k]; if (f) { if (f.type === 'hidden') f.remove(); else f.value = ''; } }
        load(formUrl());
        return;
      }
      // 2.5.2: «Guruhsiz: N» belgisi — guruhsizlar filtrini yoqish / o'chirish
      const g = t.closest && t.closest('#regChips a[data-fg]');
      if (g) {
        e.preventDefault();
        let f = ff.elements.fg;
        if (!f) { f = document.createElement('input'); f.type = 'hidden'; f.name = 'fg'; $('#regFgWrap').appendChild(f); }
        f.value = g.dataset.fg;
        load(formUrl());
        return;
      }
      // tepadagi xulosa: «to'lagan», «band» … — ro'yxat shu bo'yicha
      const s = t.closest && t.closest('a[data-f]');
      if (s && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        showTab('list');
        clearFilters();
        const [k, v] = (s.dataset.f || '').split('=');
        const f = k && ff.elements[k];
        if (f) {
          // tanlovda faqat soni bor holatlar chiqadi — sahifa ochilganda 0 bo'lgan bo'lsa, qo'shib qo'yamiz
          if (f.tagName === 'SELECT' && ![...f.options].some(o => o.value === v)) f.add(new Option(s.dataset.fl || v, v));
          f.value = v;
        }
        load(formUrl());
      }
    });
    window.regReload = () => load(formUrl(), true);   // guruhga biriktirilgach ro'yxatni yangilash (assets/students.js)
  }

  // ---------- amaldan keyin sahifaning o'zgargan qismlarini almashtirish (naqd, xonaga o'tkazish) ----------
  const toast = nodes => {
    if (!nodes.length) return;
    const wrap = document.createElement('div'); wrap.className = 'flash-toast';
    nodes.forEach(n => wrap.appendChild(document.importNode(n, true)));
    document.body.appendChild(wrap);
    setTimeout(() => wrap.classList.add('hide'), 4500);
    setTimeout(() => wrap.remove(), 5200);
    wrap.addEventListener('click', () => wrap.remove());
  };
  const applyPage = (html, sid) => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    if (!doc.querySelector('#regTabs')) return false;   // masalan, sessiya tugagan
    const tab = curTab(), keep = new Set(boxes().filter(b => b.checked).map(b => b.value));
    const anchor = $('#regResults'), top0 = anchor ? anchor.getBoundingClientRect().top : null;
    doc.querySelectorAll('[data-live][id]').forEach(n => {
      const o = document.getElementById(n.id), c = document.importNode(n, true);
      if (o) { o.replaceWith(c); return; }
      let p = n.previousElementSibling;                  // yangi paydo bo'lgan qism — qo'shnisi yoniga
      while (p && !(p.id && document.getElementById(p.id))) p = p.previousElementSibling;
      if (p) document.getElementById(p.id).after(c);
      else if (n.parentElement && n.parentElement.id && document.getElementById(n.parentElement.id)) document.getElementById(n.parentElement.id).prepend(c);
    });
    document.querySelectorAll('[data-live][id]').forEach(o => { if (!doc.getElementById(o.id)) o.remove(); });
    showTab(tab);
    boxes().forEach(b => { if (keep.has(b.value)) b.checked = true; });
    const a2 = $('#regResults');
    if (top0 !== null && a2) window.scrollBy(0, a2.getBoundingClientRect().top - top0);   // ro'yxat ekranda joyidan siljimasin
    toast([...doc.querySelectorAll('main > .alert')]);
    last = null; roomOp(); upd(); rpWhat();
    // amal qilingan qator bir lahza yoritiladi (tartib o'zgargan bo'lsa ham — masalan, to'lagach xonasiga o'tadi)
    const tr = sid && document.querySelector('.reg-tbl tr[data-sid="' + sid + '"]');
    if (tr) {
      tr.classList.add('just'); setTimeout(() => tr.classList.remove('just'), 2600);
      if (lost()) { const f = tr.querySelector('.rchip, .cash-btn, .row-menu > summary'); if (f) f.focus({ preventScroll: true }); }   // klaviatura bilan ishlaganda fokus o'sha qatorda qoladi
    }
    return true;
  };
  const postHere = fields => {
    if (ctl) { ctl.abort(); ctl = null; }   // kutilayotgan filtr javobi eskiradi — amaldan keyin kerak bo'lsa qaytadan olinadi
    const run = chain.then(async () => {
      const my = ++seq, url = location.href;
      const fd = new FormData();
      fd.append('_csrf', csrfTok());
      for (const k in fields) fd.append(k, fields[k]);
      try {
        const r = await fetch(url, { method: 'POST', body: fd, credentials: 'same-origin' });   // javob — amaldan keyingi sahifa (redirect)
        const html = r.ok ? await r.text() : '';
        if (!html || !applyPage(html, fields.sid)) { location.reload(); return; }
        if (ff && my === seq && listKey(formUrl()) !== listKey(url)) load(formUrl());   // shu orada filtr o'zgargan — ro'yxat yangi filtr bo'yicha (kutilayotgan filtr so'rovi bo'lsa — o'zi yangilaydi)
      } catch (err) { location.reload(); }
    });
    chain = run.catch(() => {});
    return run;
  };

  // ---------- 2.5.4: naqd to'lov — «Naqd» → «… olindimi? Ha, olindi» ----------
  // 2.5.5: so'rov katak ustida suzib turadi — jadval kengligi o'zgarmaydi, qatorlar siljimaydi
  const cashCancel = ask => {                     // yozilayotgani bekor bo'lmaydi
    if (ask.dataset.busy) return;
    clearTimeout(ask._t);
    const had = ask.contains(document.activeElement);
    if (ask._btn) ask._btn.style.visibility = '';
    ask.remove();
    if (had && ask._btn && ask._btn.isConnected) ask._btn.focus({ preventScroll: true });
  };
  document.addEventListener('click', e => {
    const t = e.target;
    const cb = t.closest && t.closest('.cash-btn');
    if (cb) {
      document.querySelectorAll('.cash-ask').forEach(cashCancel);   // bir vaqtda bitta so'rov
      const ask = document.createElement('span'); ask.className = 'cash-ask'; ask.dataset.sid = cb.dataset.sid; ask.dataset.price = cb.dataset.price;
      ask.innerHTML = '<span class="ca-q"></span> <button type="button" class="btn sm primary cash-yes">Ha, olindi</button> <button type="button" class="btn sm ghost cash-no" aria-label="Bekor qilish">✕</button>';
      ask.querySelector('.ca-q').textContent = cb.dataset.sum + ' naqd olindimi?';
      ask._btn = cb;
      cb.style.visibility = 'hidden';
      cb.after(ask);
      ask.querySelector('.cash-yes').focus({ preventScroll: true });   // Enter — tasdiq
      ask._t = setTimeout(() => cashCancel(ask), 9000);
      return;
    }
    const no = t.closest && t.closest('.cash-no');
    if (no) { cashCancel(no.closest('.cash-ask')); return; }
    const yes = t.closest && t.closest('.cash-yes');
    if (yes) {
      const ask = yes.closest('.cash-ask'); clearTimeout(ask._t);
      if (ask.dataset.busy) return;
      ask.dataset.busy = '1';
      ask.querySelectorAll('button').forEach(b => b.disabled = true);
      ask.querySelector('.ca-q').textContent = 'yozilmoqda…';
      postHere({ action: 'pay', op: 'cash', sid: ask.dataset.sid, expect: ask.dataset.price });   // ko'rsatilgan narx
    }
  });

  // ---------- qatordagi xona tugmasi: bosilsa — xonalar ro'yxati, tanlansa — o'sha zahoti o'tkaziladi ----------
  // xonalar va bo'sh o'rinlar har safar sahifadagi eng yangi ma'lumotdan (#roomsData amaldan keyin almashtiriladi)
  const roomsData = () => { try { return JSON.parse(($('#roomsData') || {}).textContent || '[]'); } catch (e) { return []; } };
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('.rchip');
    if (!b) return;
    const was = b.dataset.room;
    const sel = document.createElement('select'); sel.className = 'rsel'; sel.setAttribute('aria-label', 'Xonaga o\'tkazish');
    roomsData().forEach(([id, name, free]) => {
      const mine = String(id) === was, o = new Option(mine ? name : name + ' (bo\'sh: ' + free + ')', id);
      if (mine) o.selected = true; else if (free <= 0) o.disabled = true;
      sel.add(o);
    });
    const nn = new Option('— xonasiz —', 0); if (was === '0') nn.selected = true; sel.add(nn);
    b.style.visibility = 'hidden'; b.after(sel);       // tugma ustida suzib turadi — jadval siljimaydi
    sel.focus();
    try { if (sel.showPicker) sel.showPicker(); } catch (err) {}   // ro'yxat darhol ochiladi (brauzer qo'llasa)
    const revert = focus => { if (sel.isConnected && !sel.dataset.busy) { sel.remove(); b.style.visibility = ''; if (focus) b.focus(); } };
    sel.addEventListener('keydown', ev => { if (ev.key === 'Escape') revert(true); });
    sel.addEventListener('blur', () => setTimeout(() => revert(false), 200));
    sel.addEventListener('change', () => {
      if (sel.value === was) { revert(true); return; }
      sel.dataset.busy = '1'; sel.disabled = true;
      postHere({ action: 'move', sid: b.dataset.sid, room: sel.value });
    });
  });
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    document.querySelectorAll('.cash-ask').forEach(cashCancel);
    document.querySelectorAll('.pay-menu[open]').forEach(m => {
      const had = m.contains(document.activeElement);
      m.removeAttribute('open');
      if (had) { const sm = m.querySelector('summary'); if (sm) sm.focus(); }
    });
  });

  // ---------- ⋯ menyusi: jadval o'ramidan (yon tomonga suriladigan) chiqib to'liq ko'rinsin ----------
  // Ro'yxatda 1–2 qator qolganda pastga ochilgan menyu o'ram ichida kesilib qolardi — endi ekranga nisbatan joylanadi
  // (pastda joy bo'lmasa — tepaga ochiladi).
  const placeMenu = d => {
    const list = d.querySelector('.pay-menu-list'), sm = d.querySelector('summary');
    if (!list || !sm) return;
    const r = sm.getBoundingClientRect();
    list.style.position = 'fixed'; list.style.left = 'auto';
    list.style.right = Math.max(8, document.documentElement.clientWidth - r.right) + 'px';
    const h = list.offsetHeight, below = window.innerHeight - r.bottom - 8;
    list.style.top = Math.max(8, h <= below || r.top - 8 < h ? r.bottom + 4 : r.top - h - 4) + 'px';
  };
  // «open» o'zgarishi — mikrovazifada, ekranga chizilishidan oldin (menyu bir lahza ham kesilgan holda ko'rinmaydi)
  new MutationObserver(ms => ms.forEach(m => {
    const d = m.target;
    if (!d.classList || !d.classList.contains('row-menu')) return;
    const list = d.querySelector('.pay-menu-list');
    if (d.open) placeMenu(d); else if (list) list.removeAttribute('style');
  })).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['open'] });
  const replaceMenus = () => document.querySelectorAll('.row-menu[open]').forEach(placeMenu);
  window.addEventListener('scroll', replaceMenus, { passive: true, capture: true });
  window.addEventListener('resize', replaceMenus);

  // ---------- 2.5.4: xonalar bo'yicha yuklab olish — PDF tarkibi (tanlov eslab qolinadi) ----------
  function rpWhat() {
    const sel = document.getElementById('rpWhat');
    if (!sel) return;
    if (!sel.dataset.init) {
      sel.dataset.init = '1';
      try { const v = localStorage.getItem('rpWhat'); if (v && [...sel.options].some(o => o.value === v)) sel.value = v; } catch (e) {}
      sel.addEventListener('change', () => { try { localStorage.setItem('rpWhat', sel.value); } catch (e) {} rpWhat(); });
    }
    document.querySelectorAll('a[data-rp]').forEach(a => {
      const u = new URL(a.getAttribute('href'), location.href);
      if (sel.value === 'all') u.searchParams.delete('what'); else u.searchParams.set('what', sel.value);
      a.setAttribute('href', u.pathname.split('/').pop() + u.search);
    });
  }
  rpWhat();

  // ---------- amal bajarilgach (sahifa qayta yuklanadi) avvalgi joyga qaytish ----------
  const KEY = 'regScroll:' + <?= $tid ?>;
  const save = () => { try { sessionStorage.setItem(KEY, JSON.stringify({ y: window.scrollY, t: Date.now(), tab: curTab() })); } catch (e) {} };
  document.addEventListener('submit', e => { if (e.target !== ff) save(); }, true);
  document.addEventListener('click', e => { if (e.target.closest && e.target.closest('a.keep-scroll')) save(); }, true);
  try {
    const v = JSON.parse(sessionStorage.getItem(KEY) || 'null');
    sessionStorage.removeItem(KEY);
    if (v && Date.now() - v.t < 20000 && v.y > 200 && (!v.tab || v.tab === curTab())) {   // boshqa bo'limga qaytilgan bo'lsa — tepadan
      // Tepadagi xabarni ko'rinadigan joyga — pastki burchakka chiqaramiz (avval ko'chiramiz, keyin scroll — sahifa siljimasligi uchun)
      const msgs = [...document.querySelectorAll('main > .alert')];
      if (msgs.length) {
        const wrap = document.createElement('div'); wrap.className = 'flash-toast';
        msgs.forEach(m => wrap.appendChild(m));
        document.body.appendChild(wrap);
        setTimeout(() => wrap.classList.add('hide'), 4500);
        setTimeout(() => wrap.remove(), 5200);
        wrap.addEventListener('click', () => wrap.remove());
      }
      window.scrollTo(0, v.y);
    }
  } catch (e) {}

  roomOp(); upd();
})();
(function(){
  // «Qo'shish» bo'limi — ro'yxatga kiritilmaganlar: belgilash
  const all = document.getElementById('unAll'), cnt = document.getElementById('unCount');
  if (!all) return;
  const boxes = () => [...document.querySelectorAll('.unchk')];
  const upd = () => { cnt.textContent = boxes().filter(b => b.checked).length + ' ta tanlangan'; };
  all.addEventListener('change', () => { boxes().forEach(b => b.checked = all.checked); upd(); });
  boxes().forEach(b => b.addEventListener('change', upd));
})();
</script>
<script type="application/json" id="stuData"><?= json_encode(['page' => 'registrations', 'test' => $tid, 'groups' => group_counts(), 'none' => students_none_count(), 'reg_none' => $regNone], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<?php page_footer(['assets/students.js']);
