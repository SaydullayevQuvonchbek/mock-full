<?php
defined('APP_ROOT') || exit;
/**
 * 2.5.4: xonalar bo'yicha yuklab olish (admin).
 *  fmt=pdf&room=<id>|none|all — bitta xona paketi (all — xonasiz MOCK: barcha varaqlar), fmt=zip — har xona alohida PDF,
 *  fmt=xlsx — Excel, har xona alohida varaqda. what=all|sheets|lists — PDF tarkibi.
 */
require_once APP_ROOT . '/inc/room_pack.php';
require_once APP_ROOT . '/inc/xlsx_write.php';
$test = get_test_or_404();
$tid = (int)$test['id'];
$what = isset(ROOM_PACK_WHAT[$_GET['what'] ?? '']) ? (string)$_GET['what'] : 'all';
$fmt = in_array($_GET['fmt'] ?? '', ['pdf', 'zip', 'xlsx'], true) ? (string)$_GET['fmt'] : 'pdf';
if (function_exists('set_time_limit')) @set_time_limit(180);
@ini_set('memory_limit', '512M');
[$rooms, $by] = room_pack_data($tid);
$slug = 'mock-' . $tid;
$title = rp_fname((string)$test['title']);
$back = function (string $msg) use ($tid) { flash($msg, 'warn'); redirect('registrations', ['id' => $tid, 'tab' => 'print']); };   // 2.5.5: «Chop etish» bo'limiga

try {
    if ($fmt === 'pdf') {
        $rid = (string)($_GET['room'] ?? '');
        if ($rid === 'all') {   // xonasiz MOCK: barcha varaqlar bitta faylda (ajratuvchi va ro'yxatlarsiz)
            $list = reg_students($tid, ['order' => 'name']);
            if (!$list) $back('Chop etiladigan varaq yo\'q — ro\'yxat bo\'sh');
            $pdf = PdfLite::make($test['title'] . ' — javoblar varaqalari');
            $t = $test + ['key' => json_decode((string)($test['key_json'] ?? ''), true) ?: []];
            $L = sheet_layout($t); $center = (string)app_setting('center');
            foreach ($list as $st) { $pdf->page(); pdf_draw_svg($pdf, sheet_svg($t, $L, $st, $center)); }
            rp_send($pdf->output(), 'application/pdf', $slug . '-varaqlar.pdf', $title . ' — javoblar varaqalari.pdf');
        }
        $room = null;
        if ($rid !== 'none') {
            foreach ($rooms as $r) if ((int)$r['id'] === (int)$rid) $room = $r;
            if (!$room) $back('Xona topilmadi');
        }
        $list = $room ? ($by[(int)$room['id']] ?? []) : ($by[0] ?? []);
        if (!$list && $what === 'sheets') $back('Bu xonada hali hech kim yo\'q');
        $name = $room ? rp_fname((string)$room['name']) : 'Xonasizlar';
        rp_send(room_pack_pdf($test, $room, $list, $what)->output(), 'application/pdf', $slug . '-xona-' . ($room ? (int)$room['id'] : 'none') . '.pdf', $title . ' — ' . $name . '.pdf');
    }

    if ($fmt === 'zip') {
        $files = []; $i = 0; $seen = [];
        $add = function (string $name, string $bin) use (&$files, &$seen) {
            $k = mb_strtolower($name); $n = 1; $base = preg_replace('/\.pdf$/', '', $name);
            while (isset($seen[$k])) { $name = $base . ' (' . (++$n) . ').pdf'; $k = mb_strtolower($name); }
            $seen[$k] = true; $files[$name] = $bin;
        };
        if ($what !== 'sheets') {
            $p = PdfLite::make($test['title'] . ' — kirishdagi umumiy ro\'yxat');
            rp_door_all($p, $test, $by ? array_merge(...array_values($by)) : []);
            $add('00 - Kirishdagi umumiy ro\'yxat.pdf', $p->output());
        }
        foreach ($rooms as $r) {
            $list = $by[(int)$r['id']] ?? [];
            if (!$list) continue;
            $add(sprintf('%02d', ++$i) . ' - ' . rp_fname((string)$r['name']) . '.pdf', room_pack_pdf($test, $r, $list, $what)->output());
        }
        if (!empty($by[0])) $add(sprintf('%02d', ++$i) . ' - Xonasizlar.pdf', room_pack_pdf($test, null, $by[0], $what)->output());
        if (!$i) $back('Xonalarda hali hech kim yo\'q — avval «Joylashtirish» ni bosing');
        rp_send(rp_zip($files), 'application/zip', $slug . '-xonalar.zip', $title . ' — xonalar.zip');
    }

    // Excel: har xona — alohida varaq
    $sheets = [];
    $mk = function (string $name, array $list, ?array $room) use ($test): array {
        $rows = [[['v' => $name . ' — ' . $test['title'], 's' => 'title']],
                 [['v' => count($list) . ' kishi' . ($room ? ' / ' . (int)$room['capacity'] . ' o\'rin' : '') . ($room && (string)$room['proctor'] !== '' ? ' · nazoratchi: ' . $room['proctor'] : ''), 's' => 'muted']],
                 [],
                 array_map(fn($h) => ['v' => $h, 's' => 'head'], ['O\'rin', 'ID', 'F.I.Sh', 'Telefon', 'Maktab / sinf', 'Guruh', 'To\'lov'])];
        foreach (array_values($list) as $i => $s) {
            $pay = (string)$s['pay_status'] === 'paid' ? 'To\'langan' . ((string)($s['pay_method'] ?? '') === 'cash' ? ' (naqd)' : '') : (REG_PAY_LABEL[$s['pay_status']] ?? $s['pay_status']);
            $rows[] = [['v' => $s['seat'] !== null ? (int)$s['seat'] : $i + 1, 's' => 'num'], ['v' => (string)$s['code'], 's' => 'cell'], ['v' => (string)$s['full_name'], 's' => 'cell'],
                       ['v' => $s['phone'] ? fmt_phone((string)$s['phone']) : '', 's' => 'cell'], ['v' => school_grade($s), 's' => 'cell'],
                       ['v' => (string)$s['group_name'], 's' => 'cell'], ['v' => $pay, 's' => 'cell']];
        }
        return ['name' => $name, 'rows' => $rows, 'widths' => [7, 9, 34, 17, 30, 12, 16], 'freeze' => 4];
    };
    foreach ($rooms as $r) $sheets[] = $mk((string)$r['name'], $by[(int)$r['id']] ?? [], $r);
    if (!empty($by[0])) $sheets[] = $mk('Xonasizlar', $by[0], null);
    if (!$sheets) $back('Xonalar kiritilmagan');
    $bin = xlsx_build_book($sheets, $test['title'] . ' — xonalar');
    rp_send($bin, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', $slug . '-xonalar.xlsx', $title . ' — xonalar.xlsx');
} catch (Throwable $ex) {
    error_log('[MOCK room_pack] ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
    $back('Faylni tayyorlab bo\'lmadi: ' . $ex->getMessage());
}
