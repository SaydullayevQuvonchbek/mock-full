<?php
defined('APP_ROOT') || exit;
/**
 * 2.5.2: O'quvchilar — umumiy funksiyalar (pages/students.php, pages/stu_api.php, pages/registrations.php).
 * Tahrirlash formasi ma'lumotlari va saqlash (avval pages/students.php da edi — xatti-harakati o'zgarmagan),
 * guruhga biriktirish, jadval qatori, guruh katagi va tahrirlash oynasining HTML i.
 */

function student_form_data(): array
{
    $cid = (int)($_POST['center_id'] ?? 0);
    return [
        'last' => trim($_POST['last_name'] ?? ''), 'first' => trim($_POST['first_name'] ?? ''), 'middle' => trim($_POST['middle_name'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''), 'school' => trim($_POST['school'] ?? ''), 'grade_level' => trim($_POST['grade_level'] ?? ''),
        'group' => trim($_POST['group_name'] ?? ''), 'center' => $cid ?: null,
        'pname' => trim($_POST['parent_name'] ?? ''), 'pphone' => trim($_POST['parent_phone'] ?? ''), 'pphone2' => trim($_POST['parent_phone2'] ?? ''),
    ];
}
function student_save(array $d, int $id): ?string
{
    $phone = $d['phone'] === '' ? '' : norm_phone($d['phone']);
    if ($d['phone'] !== '' && $phone === '') return 'Telefon raqam noto\'g\'ri: ' . $d['phone'];
    if ($phone !== '' && val('SELECT 1 FROM students WHERE phone=? AND id<>?', [$phone, $id])) return 'Bu telefon raqam boshqa o\'quvchida bor';
    $pp = $d['pphone'] === '' ? '' : norm_phone($d['pphone']);
    if ($d['pphone'] !== '' && $pp === '') return 'Ota-ona telefoni noto\'g\'ri: ' . $d['pphone'];
    $pp2 = $d['pphone2'] === '' ? '' : norm_phone($d['pphone2']);
    if ($d['pphone2'] !== '' && $pp2 === '') return 'Ota-onaning 2-telefoni noto\'g\'ri: ' . $d['pphone2'];
    if ($id === 0) return null;   // faqat tekshirish
    $oldPhone = (string)val('SELECT phone FROM students WHERE id=?', [$id]);
    if ($d['group'] !== '') q('INSERT IGNORE INTO study_groups (name) VALUES (?)', [$d['group']]);
    q('UPDATE students SET last_name=?, first_name=?, middle_name=?, full_name=?, phone=?, school=?, grade_level=?, group_name=?, center_id=?, parent_name=?, parent_phone=?, parent_phone2=? WHERE id=?',
        [$d['last'], $d['first'], $d['middle'], compose_name($d['last'], $d['first'], $d['middle']), $phone, $d['school'], $d['grade_level'], $d['group'], $d['center'], mb_substr($d['pname'], 0, 120), $pp, $pp2, $id]);
    if ($oldPhone !== $phone) q('UPDATE students SET phone_verified_at=NULL WHERE id=?', [$id]);   // telefon o'zgarsa tasdiq bekor bo'ladi
    return null;
}

/** Guruh nomi: ortiqcha bo'shliqlarsiz, 80 belgigacha (students.group_name ustuni) */
function group_name_clean(string $g): string
{
    return mb_substr(trim((string)preg_replace('/\s+/u', ' ', $g)), 0, 80);
}

/**
 * O'quvchilarni guruhga biriktirish. $g — guruh nomi ('' — guruhsiz).
 * Ro'yxatda yo'q nom bo'lsa guruh yaratiladi (study_groups); katta-kichik harf farqi bilan bor bo'lsa — mavjud nom olinadi.
 * Qaytaradi: ['group' => yozilgan nom, 'n' => o'zgargan qatorlar, 'created' => yangi guruh yaratildimi]
 */
function students_set_group(array $ids, string $g): array
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn($v) => $v > 0)));
    $g = group_name_clean($g);
    $created = false;
    if ($g !== '') {
        $have = val('SELECT name FROM study_groups WHERE name=?', [$g]);
        if ($have !== null) $g = (string)$have;
        else $created = q('INSERT IGNORE INTO study_groups (name) VALUES (?)', [$g])->rowCount() > 0;
    }
    $n = 0;
    if ($ids) $n = q('UPDATE students SET group_name=? WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', array_merge([$g], $ids))->rowCount();
    return ['group' => $g, 'n' => $n, 'created' => $created];
}

/** Guruhlar va har biridagi faol o'quvchilar soni. Guruhlar jadvalida yo'q, lekin o'quvchilarda yozilgan nomlar ham qo'shiladi. */
function group_counts(): array
{
    $out = [];
    foreach (rows('SELECT name FROM study_groups') as $g) $out[mb_strtolower($g['name'])] = ['name' => (string)$g['name'], 'n' => 0];
    foreach (rows("SELECT group_name, COUNT(*) n FROM students WHERE group_name<>'' AND archived_at IS NULL GROUP BY group_name") as $r) {
        $k = mb_strtolower($r['group_name']);
        if (isset($out[$k])) $out[$k]['n'] += (int)$r['n'];
        else $out[$k] = ['name' => (string)$r['group_name'], 'n' => (int)$r['n']];
    }
    $out = array_values($out);
    usort($out, fn($a, $b) => strnatcasecmp($a['name'], $b['name']));
    return $out;
}

/** Guruhsiz faol o'quvchilar soni */
function students_none_count(): int
{
    return (int)val("SELECT COUNT(*) FROM students WHERE group_name='' AND archived_at IS NULL");
}

/** MOCK ro'yxatidagi guruhsizlar soni (Ro'yxat sahifasidagi «Guruhsiz: N» belgisi) */
function reg_none_count(int $tid): int
{
    return (int)val("SELECT COUNT(*) FROM test_registrations g JOIN students s ON s.id=g.student_id WHERE g.test_id=? AND s.archived_at IS NULL AND s.group_name=''", [$tid]);
}

/** Guruh katagi: bosilsa — guruh tanlovi (assets/students.js). JS siz — oddiy yozuv. */
function group_chip(int $sid, string $group): string
{
    return '<button type="button" class="gchip' . ($group === '' ? ' none' : '') . '" data-sid="' . $sid . '" data-g="' . e($group) . '" title="'
        . ($group === '' ? 'Guruhga biriktirish' : 'Guruhni o\'zgartirish') . '">' . ($group === '' ? 'guruhsiz' : e($group)) . '</button>';
}

/** Tahrirlash va qo'shish formasidagi maydonlar */
function student_fields(?array $s, array $groups, array $centers, string $defGroup = ''): void
{ ?>
  <div class="grid3">
    <label>Familiya <input name="last_name" value="<?= e($s['last_name'] ?? '') ?>" required></label>
    <label>Ism <input name="first_name" value="<?= e($s['first_name'] ?? '') ?>" required></label>
    <label>Otasining ismi <input name="middle_name" value="<?= e($s['middle_name'] ?? '') ?>"></label>
  </div>
  <div class="grid2">
    <label>Telefon <input name="phone" value="<?= e($s ? fmt_phone((string)($s['phone'] ?? '')) : '') ?>" placeholder="+998 90 123 45 67" inputmode="tel"></label>
    <label>Maktab <input name="school" value="<?= e($s['school'] ?? '') ?>"></label>
    <label>Sinf <input name="grade_level" value="<?= e($s['grade_level'] ?? '') ?>" placeholder="11-sinf"></label>
    <label>Guruh <input name="group_name" value="<?= e($s['group_name'] ?? $defGroup) ?>" list="groups" autocomplete="off"></label>
  </div>
  <input type="hidden" name="center_id" value="<?= (int)($s['center_id'] ?? 0) ?>">
  <fieldset class="parent-fs"><legend>Ota-ona (natija SMS uchun)</legend>
    <div class="grid3">
      <label>Ism <input name="parent_name" value="<?= e($s['parent_name'] ?? '') ?>" maxlength="120" placeholder="Karimov Anvar"></label>
      <label>Telefon <input name="parent_phone" value="<?= e(!empty($s['parent_phone']) ? fmt_phone($s['parent_phone']) : '') ?>" placeholder="+998 90 123 45 67" inputmode="tel"></label>
      <label>2-telefon <input name="parent_phone2" value="<?= e(!empty($s['parent_phone2']) ? fmt_phone($s['parent_phone2']) : '') ?>" placeholder="ixtiyoriy" inputmode="tel"></label>
    </div>
  </fieldset>
<?php }

/** O'quvchilar jadvalidagi qator. $s — students qatori va n (topshirgan testlari soni); $keep — ro'yxat filtrlari (JS siz «Tahrirlash» havolasi uchun) */
function student_row(array $s, array $keep = []): void
{
    $id = (int)$s['id'];
    ?>
      <tr data-sid="<?= $id ?>">
        <td><input type="checkbox" name="ids[]" value="<?= $id ?>" class="rowchk" aria-label="Belgilash"></td>
        <td class="mono"><?= e($s['code']) ?></td>
        <td class="stu-name"><?= e($s['full_name']) ?><?php if ($s['source'] === 'register'): ?> <span class="tag blue" title="Onlayn ro'yxatdan o'tgan">onlayn</span><?php elseif ($s['source'] === 'bot'): ?> <span class="tag blue" title="Telegram botda ro'yxatdan o'tgan">bot</span><?php endif; ?><?php if ($s['tg_chat_id'] !== null): ?> <span class="tag green" title="Telegram botga ulangan<?= $s['tg_username'] ? ': @' . e($s['tg_username']) : '' ?>">TG</span><?php endif; ?>
          <?php if ($s['school'] || $s['grade_level']): ?><div class="small muted"><?= e(school_grade($s)) ?></div><?php endif; ?>
          <span class="gchip-m"><?= group_chip($id, (string)$s['group_name']) ?></span></td>
        <td class="nowrap small"><?= e($s['phone'] ? fmt_phone($s['phone']) : '—') ?></td>
        <td class="small grp-td"><?= group_chip($id, (string)$s['group_name']) ?><?php if ($s['archived_at']): ?><div class="muted">arxiv: <?= e(date('d.m.Y', strtotime((string)$s['archived_at']))) ?></div><?php endif; ?></td>
        <td class="mono small"><?php if ($s['pin'] !== '' && (int)$s['must_change'] === 1): ?><?= e($s['pin']) ?> <span class="tag" title="Vaqtinchalik — o'quvchi hali almashtirmagan">vaqtinchalik</span><?php else: ?><span class="muted" title="O'quvchi o'zi belgilagan">o'zi belgilagan</span><?php endif; ?></td>
        <td class="num"><?= (int)($s['n'] ?? 0) ?></td>
        <td class="right"><a class="btn sm ghost js-edit" data-sid="<?= $id ?>" href="<?= e(url('students', ['edit' => $id] + $keep)) ?>">Tahrirlash</a></td>
      </tr>
<?php }

/**
 * Tahrirlash oynasining ichi (JS bilan — modal oyna, stu_api «form» orqali yuklanadi; JS siz — ?edit=ID dagi karta).
 * Asosiy forma JS bilan stu_api ga yuboriladi; parol, arxiv, o'chirish, TG — oddiy formalar (sahifa yangilanadi).
 * $close — «×» va «Bekor qilish» havolasi (JS siz ro'yxatga qaytish)
 */
function student_edit_panel(array $s, string $close = ''): void
{
    $groups = groups_list();
    $centers = centers_list();
    $id = (int)$s['id'];
    $close = $close !== '' ? $close : url('students');
    $pend = (int)val('SELECT COUNT(*) FROM pay_requests WHERE student_id=? AND status="pending"', [$id]);
    if ($s['last_name'] === '' && $s['first_name'] === '' && trim((string)$s['full_name']) !== '') {   // eski yozuvlar: faqat to'liq ism bor — maydonlar bo'sh qolmasin
        [$s['last_name'], $s['first_name'], $s['middle_name']] = split_name((string)$s['full_name']);
    }
    $temp = $s['pin'] !== '' && (int)$s['must_change'] === 1;
    ?>
  <div class="dlg-h">
    <h3 id="stuEditT">Tahrirlash — ID <span class="mono"><?= e($s['code']) ?></span><?= $s['archived_at'] ? ' <span class="tag red">arxivda</span>' : '' ?></h3>
    <a class="btn sm ghost" href="<?= e(url('qb_mastery', ['sid' => $id])) ?>">O'zlashtirish →</a>
    <a class="btn sm ghost dlg-x" href="<?= e($close) ?>" data-close aria-label="Yopish" title="Yopish (Esc)">×</a>
  </div>
  <div class="stu-meta small">
    <p>Parol: <?php if ($temp): ?><b class="mono"><?= e($s['pin']) ?></b> <span class="tag">vaqtinchalik</span><?php else: ?><span class="muted">o'quvchi o'zi belgilagan</span><?php endif; ?>
      <span class="muted">· <?= $s['source'] === 'register' ? 'onlayn ro\'yxatdan o\'tgan' : ($s['source'] === 'bot' ? 'botda ro\'yxatdan o\'tgan' : 'admin qo\'shgan') ?> · <?= e(substr((string)$s['created_at'], 0, 16)) ?><?= $s['last_login'] ? ' · oxirgi kirish ' . e(substr((string)$s['last_login'], 0, 16)) : ' · hali kirmagan' ?></span></p>
    <p>Telegram: <?php if ($s['tg_chat_id'] !== null): ?><span class="tag green">ulangan</span> <?= $s['tg_username'] ? '@' . e($s['tg_username']) : '' ?> <span class="muted"><?= e(substr((string)$s['tg_linked_at'], 0, 16)) ?></span><?php else: ?><span class="muted">ulanmagan — o'quvchi botga ID va parol yuborsin yoki kabinetdagi «Telegramni ulash» tugmasini bossin</span><?php endif; ?></p>
    <p>Hamyon: <b><?= e(som((int)$s['balance'])) ?></b><?= $pend ? ' · <span class="tag amber">' . $pend . ' ta chek kutilmoqda</span>' : '' ?>
      <?php if (can_finance()): ?>· <a href="<?= e(url('wallets', ['sid' => $id])) ?>">Hamyon va to'lovlar →</a><?php endif; ?></p>
    <?php if ($s['phone'] !== '' || $s['parent_tg_chat'] !== null || $s['parent_optout']): ?><p>
      <?php if ($s['phone'] !== ''): ?><?= $s['phone_verified_at'] ? '<span class="tag green">telefon tasdiqlangan</span>' : '<span class="muted">telefon tasdiqlanmagan</span>' ?><?php endif; ?>
      <?php if ($s['parent_tg_chat'] !== null): ?><span class="tag green">ota-ona Telegrami ulangan</span><?php endif; ?>
      <?php if ($s['parent_optout']): ?><span class="tag red">ota-ona natija olishni rad etgan</span><?php endif; ?></p><?php endif; ?>
  </div>
  <form method="post" class="form stu-edit-form" data-sid="<?= $id ?>">
    <?= csrf_field() ?><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="<?= $id ?>">
    <div class="alert err stu-err" role="alert" hidden></div>
    <?php student_fields($s, $groups, $centers); ?>
    <div class="dlg-foot"><button class="btn primary">Saqlash</button><a class="btn ghost" href="<?= e($close) ?>" data-close>Bekor qilish</a></div>
  </form>
  <div class="row gap wrap stu-acts">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="temp"><input type="hidden" name="id" value="<?= $id ?>"><button class="btn sm" onclick="return confirm('Yangi vaqtinchalik parol yaratilsinmi? Eski parol ishlamay qoladi.')">Yangi vaqtinchalik parol</button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="send_temp"><input type="hidden" name="id" value="<?= $id ?>"><button class="btn sm ghost" title="Botga ulangan bo'lsa botga, aks holda SMS bilan">Parolni botga/SMS ga yuborish</button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="<?= $s['archived_at'] ? 'unarchive' : 'archive' ?>"><input type="hidden" name="id" value="<?= $id ?>"><button class="btn sm ghost" title="<?= $s['archived_at'] ? '' : 'Bitirgan / ketgan o\'quvchi: natijalari saqlanadi, lekin ro\'yxat, topshiriq va bot xabarlarida chiqmaydi, kabinetga kira olmaydi' ?>"><?= $s['archived_at'] ? 'Arxivdan chiqarish' : 'Arxivlash' ?></button></form>
    <?php if ($s['tg_chat_id'] !== null): ?><form method="post" onsubmit="return confirm('Telegram ulanishi uzilsinmi? O\'quvchi botga xabar ololmaydi.')"><?= csrf_field() ?><input type="hidden" name="action" value="tg_unlink"><input type="hidden" name="id" value="<?= $id ?>"><button class="btn sm ghost">TG ni uzish</button></form><?php endif; ?>
    <form method="post" onsubmit="return confirm('O\'quvchi va uning barcha javoblari o\'chirilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $id ?>"><button class="btn sm danger-ghost">O'chirish</button></form>
  </div>
<?php }
