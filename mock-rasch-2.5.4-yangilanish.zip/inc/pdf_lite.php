<?php
/**
 * 2.5.4: kichik PDF yozuvchi — xona paketlarini (javoblar varaqasi, davomat va eshik ro'yxati) PDF qilib yuklab olish uchun.
 * Tashqi kutubxona shart emas. O'lchovlar — millimetr, boshlanish nuqtasi chap-yuqori burchak (SVG kabi), sahifa A4.
 * Shriftlar — TrueType (assets/fonts): PDF ga faqat ishlatilgan belgilar joylanadi (subset), shuning uchun lotin, kirill,
 * oʻ/gʻ (ʻ ʼ) va ✓ ✗ to'g'ri chiqadi. zlib bo'lsa oqimlar siqiladi.
 */
defined('APP_ROOT') || exit;

/** TrueType shrift: o'lchovlar, Unicode → glif, ishlatilgan gliflardan kichik shrift (subset) */
final class PdfTtf
{
    public $psName = 'Font';
    public $upm = 1000;
    public $ascent = 800;
    public $descent = -200;
    public $capHeight = 700;
    public $bbox = [0, -200, 1000, 800];
    public $italicAngle = 0;
    private $d;
    private $tab = [];
    private $map = [];
    private $adv = [];
    private $numGlyphs = 0;
    private $loca = [];

    public function __construct(string $file)
    {
        $d = @file_get_contents($file);
        if ($d === false || strlen($d) < 12) throw new RuntimeException('Shrift topilmadi: ' . basename($file));
        $this->d = $d;
        $n = $this->u16(4);
        for ($i = 0; $i < $n; $i++) {
            $p = 12 + 16 * $i;
            $this->tab[substr($d, $p, 4)] = [$this->u32($p + 8), $this->u32($p + 12)];
        }
        foreach (['head', 'hhea', 'maxp', 'hmtx', 'cmap', 'loca', 'glyf'] as $t) if (!isset($this->tab[$t])) throw new RuntimeException('Shrift buzuq: ' . $t);
        $h = $this->tab['head'][0];
        $this->upm = $this->u16($h + 18) ?: 1000;
        $this->bbox = [$this->i16($h + 36), $this->i16($h + 38), $this->i16($h + 40), $this->i16($h + 42)];
        $longLoca = $this->i16($h + 50) === 1;
        $hh = $this->tab['hhea'][0];
        $this->ascent = $this->i16($hh + 4);
        $this->descent = $this->i16($hh + 6);
        $nh = $this->u16($hh + 34);
        $this->numGlyphs = $this->u16($this->tab['maxp'][0] + 4);
        $hm = $this->tab['hmtx'][0];
        $last = 0;
        for ($g = 0; $g < $this->numGlyphs; $g++) {
            if ($g < $nh) $last = $this->u16($hm + 4 * $g);
            $this->adv[$g] = $last;
        }
        $lo = $this->tab['loca'][0];
        for ($g = 0; $g <= $this->numGlyphs; $g++) $this->loca[$g] = $longLoca ? $this->u32($lo + 4 * $g) : 2 * $this->u16($lo + 2 * $g);
        $this->capHeight = (int)round($this->ascent * 0.7);
        if (isset($this->tab['OS/2'])) {
            $o = $this->tab['OS/2'][0];
            if ($this->u16($o) >= 2 && $this->tab['OS/2'][1] >= 90) $this->capHeight = $this->i16($o + 88);
        }
        if (isset($this->tab['post'])) {
            $p = $this->tab['post'][0];
            $this->italicAngle = $this->i16($p + 4) + $this->u16($p + 6) / 65536;
        }
        $this->readCmap();
        $this->readName();
    }

    private function u16(int $p): int { return (ord($this->d[$p]) << 8) | ord($this->d[$p + 1]); }
    private function i16(int $p): int { $v = $this->u16($p); return $v >= 0x8000 ? $v - 0x10000 : $v; }
    private function u32(int $p): int { return (int)unpack('N', substr($this->d, $p, 4))[1]; }

    private function readCmap(): void
    {
        $c = $this->tab['cmap'][0];
        $n = $this->u16($c + 2);
        $best = null; $rank = -1;
        for ($i = 0; $i < $n; $i++) {
            $pid = $this->u16($c + 4 + 8 * $i); $eid = $this->u16($c + 6 + 8 * $i);
            $off = $c + $this->u32($c + 8 + 8 * $i);
            $fmt = $this->u16($off);
            $r = ($pid === 3 && $eid === 10 && $fmt === 12) ? 4 : (($pid === 0 && $fmt === 12) ? 3 : (($pid === 3 && $eid === 1 && $fmt === 4) ? 2 : (($pid === 0 && $fmt === 4) ? 1 : -1)));
            if ($r > $rank) { $rank = $r; $best = [$off, $fmt]; }
        }
        if (!$best) throw new RuntimeException('Shriftda Unicode jadvali yo\'q');
        [$o, $fmt] = $best;
        if ($fmt === 12) {
            $groups = $this->u32($o + 12);
            for ($i = 0; $i < $groups; $i++) {
                $p = $o + 16 + 12 * $i;
                $s = $this->u32($p); $e = $this->u32($p + 4); $g = $this->u32($p + 8);
                for ($cp = $s; $cp <= $e && $cp <= 0x10FFFF; $cp++, $g++) if ($g > 0 && $g < $this->numGlyphs) $this->map[$cp] = $g;
            }
            return;
        }
        $seg = $this->u16($o + 6) >> 1;
        $ends = $o + 14; $starts = $ends + 2 * $seg + 2; $deltas = $starts + 2 * $seg; $ranges = $deltas + 2 * $seg;
        for ($s = 0; $s < $seg; $s++) {
            $end = $this->u16($ends + 2 * $s); $start = $this->u16($starts + 2 * $s);
            $delta = $this->u16($deltas + 2 * $s); $ro = $this->u16($ranges + 2 * $s);
            for ($cp = $start; $cp <= $end && $cp !== 0xFFFF; $cp++) {
                if ($ro === 0) $g = ($cp + $delta) & 0xFFFF;
                else {
                    $g = $this->u16($ranges + 2 * $s + $ro + 2 * ($cp - $start));
                    if ($g !== 0) $g = ($g + $delta) & 0xFFFF;
                }
                if ($g > 0 && $g < $this->numGlyphs) $this->map[$cp] = $g;
            }
        }
    }

    private function readName(): void
    {
        if (!isset($this->tab['name'])) return;
        $b = $this->tab['name'][0];
        $n = $this->u16($b + 2); $str = $b + $this->u16($b + 4);
        for ($i = 0; $i < $n; $i++) {
            $p = $b + 6 + 12 * $i;
            if ($this->u16($p + 6) !== 6) continue;   // PostScript nomi
            $raw = substr($this->d, $str + $this->u16($p + 10), $this->u16($p + 8));
            $s = $this->u16($p) === 3 || $this->u16($p) === 0 ? (string)@mb_convert_encoding($raw, 'UTF-8', 'UTF-16BE') : $raw;
            $s = preg_replace('/[^A-Za-z0-9\-]/', '', $s);
            if ($s !== '') { $this->psName = $s; return; }
        }
    }

    public function has(int $cp): bool { return isset($this->map[$cp]); }
    public function gid(int $cp): int { return $this->map[$cp] ?? 0; }
    public function adv(int $gid): int { return $this->adv[$gid] ?? 0; }

    /** Ishlatilgan gliflar (va ular tarkibidagi gliflar) qolgan TrueType fayl — glif raqamlari o'zgarmaydi */
    public function subset(array $gids): string
    {
        $glyf = $this->tab['glyf'][0];
        $keep = [0 => true];
        $todo = array_keys($gids);
        while ($todo) {
            $g = (int)array_pop($todo);
            if (isset($keep[$g]) && $g !== 0) continue;
            $keep[$g] = true;
            $a = $this->loca[$g] ?? 0; $b = $this->loca[$g + 1] ?? 0;
            if ($b - $a < 10 || $this->i16($glyf + $a) >= 0) continue;
            $p = $glyf + $a + 10;   // tarkibli glif: qismlari ham kerak
            do {
                $fl = $this->u16($p); $cg = $this->u16($p + 2);
                if (!isset($keep[$cg])) $todo[] = $cg;
                $p += 4 + (($fl & 1) ? 4 : 2) + (($fl & 8) ? 2 : (($fl & 0x40) ? 4 : (($fl & 0x80) ? 8 : 0)));
            } while ($fl & 0x20);
        }
        $newGlyf = ''; $loca = '';
        for ($g = 0; $g < $this->numGlyphs; $g++) {
            $loca .= pack('N', strlen($newGlyf));
            if (isset($keep[$g])) {
                $chunk = substr($this->d, $glyf + $this->loca[$g], $this->loca[$g + 1] - $this->loca[$g]);
                $newGlyf .= $chunk . str_repeat("\0", (4 - strlen($chunk) % 4) % 4);
            }
        }
        $loca .= pack('N', strlen($newGlyf));
        $t = [];
        foreach (['cvt ', 'fpgm', 'prep', 'hhea', 'hmtx', 'maxp', 'OS/2'] as $k) if (isset($this->tab[$k])) $t[$k] = substr($this->d, $this->tab[$k][0], $this->tab[$k][1]);
        $head = substr($this->d, $this->tab['head'][0], $this->tab['head'][1]);
        $head = substr($head, 0, 8) . "\0\0\0\0" . substr($head, 12, 38) . pack('n', 1) . substr($head, 52);   // checkSumAdjustment = 0, long loca
        $t['head'] = $head;
        $t['loca'] = $loca;
        $t['glyf'] = $newGlyf;
        if (isset($this->tab['post'])) $t['post'] = pack('N', 0x00030000) . substr($this->d, $this->tab['post'][0] + 4, 28);   // 3-format: glif nomlarisiz
        ksort($t, SORT_STRING);
        $n = count($t);
        $es = (int)floor(log($n, 2)); $sr = (1 << $es) * 16;
        $dir = pack('Nnnnn', 0x00010000, $n, $sr, $es, $n * 16 - $sr);
        $off = 12 + 16 * $n; $body = '';
        foreach ($t as $tag => $data) {
            $dir .= $tag . pack('NNN', self::checksum($data), $off + strlen($body), strlen($data));
            $body .= $data . str_repeat("\0", (4 - strlen($data) % 4) % 4);
        }
        $font = $dir . $body;
        $adj = (0xB1B0AFBA - self::checksum($font)) & 0xFFFFFFFF;
        $hp = strpos($dir, 'head');
        $headOff = (int)unpack('N', substr($dir, $hp + 8, 4))[1];
        return substr_replace($font, pack('N', $adj), $headOff + 8, 4);
    }

    private static function checksum(string $s): int
    {
        $s .= str_repeat("\0", (4 - strlen($s) % 4) % 4);
        $sum = 0;
        foreach (unpack('N*', $s) as $v) $sum = ($sum + $v) & 0xFFFFFFFF;
        return $sum;
    }
}

/** A4 PDF hujjat: vektor chizish (mm), matn (Unicode), sahifalar */
final class PdfLite
{
    const K = 2.8346456693;   // 1 mm = 2.8346 pt
    const PW = 595.2756;
    const PH = 841.8898;
    private $pages = [];
    private $c = '';
    private $open = false;
    private $fonts = [];      // kalit => ['ttf' => PdfTtf, 'used' => [gid => cp], 'res' => 'F1']
    private $title = '';

    /** $files: ['R' => oddiy, 'B' => qalin, 'S' => belgilar (✓ ✗), 'SB' => qalin belgilar] — fayl yo'llari */
    public function __construct(array $files, string $title = '')
    {
        $i = 0;
        foreach ($files as $k => $f) if ($f !== '' && is_file($f)) $this->fonts[$k] = ['ttf' => new PdfTtf($f), 'used' => [], 'res' => 'F' . (++$i)];
        if (!isset($this->fonts['R'])) throw new RuntimeException('PDF uchun shrift topilmadi (assets/fonts)');
        if (!isset($this->fonts['B'])) $this->fonts['B'] = $this->fonts['R'];
        $this->title = $title;
    }

    /** Standart shriftlar: assets/fonts */
    public static function make(string $title = ''): self
    {
        $d = APP_ROOT . '/assets/fonts/';
        return new self(['R' => $d . 'LiberationSans-Regular.ttf', 'B' => $d . 'LiberationSans-Bold.ttf', 'S' => $d . 'DejaVuSans-Sym.ttf', 'SB' => $d . 'DejaVuSans-Bold-Sym.ttf'], $title);
    }

    public function page(): void
    {
        if ($this->open) $this->pages[] = $this->c;
        $this->c = '';
        $this->open = true;
    }

    public function pageCount(): int { return count($this->pages) + ($this->open ? 1 : 0); }

    private static function n(float $v): string
    {
        $s = sprintf('%.3F', $v);
        $s = rtrim(rtrim($s, '0'), '.');
        return $s === '-0' || $s === '' ? '0' : $s;
    }
    private static function X(float $mm): string { return self::n($mm * self::K); }
    private static function Y(float $mm): string { return self::n(self::PH - $mm * self::K); }

    /** '#rgb' | '#rrggbb' → '0.2 0.2 0.2'; null/none → null */
    private static function rgb(?string $c): ?string
    {
        if ($c === null) return null;
        $c = strtolower(trim($c));
        if ($c === '' || $c === 'none' || $c === 'transparent') return null;
        if ($c === 'black') $c = '#000'; elseif ($c === 'white') $c = '#fff';
        if (!preg_match('/^#([0-9a-f]{3}|[0-9a-f]{6})$/', $c, $m)) return '0 0 0';
        $h = $m[1];
        if (strlen($h) === 3) $h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
        return self::n(hexdec(substr($h, 0, 2)) / 255) . ' ' . self::n(hexdec(substr($h, 2, 2)) / 255) . ' ' . self::n(hexdec(substr($h, 4, 2)) / 255);
    }

    /** Shaklni bo'yash: $fill / $stroke — rang yoki null, $lw — chiziq qalinligi (mm) */
    private function paint(string $path, ?string $fill, ?string $stroke, float $lw): void
    {
        $f = self::rgb($fill); $s = self::rgb($stroke);
        if ($f === null && $s === null) return;
        $o = 'q ';
        if ($f !== null) $o .= $f . ' rg ';
        if ($s !== null) $o .= $s . ' RG ' . self::n(max(0.01, $lw) * self::K) . ' w ';
        $this->c .= $o . $path . ' ' . ($f !== null && $s !== null ? 'B' : ($f !== null ? 'f' : 'S')) . " Q\n";
    }

    public function rect(float $x, float $y, float $w, float $h, ?string $fill = null, ?string $stroke = '#000', float $lw = 0.25, float $rx = 0): void
    {
        if ($rx <= 0) { $this->paint(self::X($x) . ' ' . self::Y($y + $h) . ' ' . self::n($w * self::K) . ' ' . self::n($h * self::K) . ' re', $fill, $stroke, $lw); return; }
        $rx = min($rx, $w / 2, $h / 2); $k = 0.5522847498 * $rx;
        $p = $this->mv($x + $rx, $y) . $this->ln($x + $w - $rx, $y) . $this->cu($x + $w - $rx + $k, $y, $x + $w, $y + $rx - $k, $x + $w, $y + $rx)
           . $this->ln($x + $w, $y + $h - $rx) . $this->cu($x + $w, $y + $h - $rx + $k, $x + $w - $rx + $k, $y + $h, $x + $w - $rx, $y + $h)
           . $this->ln($x + $rx, $y + $h) . $this->cu($x + $rx - $k, $y + $h, $x, $y + $h - $rx + $k, $x, $y + $h - $rx)
           . $this->ln($x, $y + $rx) . $this->cu($x, $y + $rx - $k, $x + $rx - $k, $y, $x + $rx, $y) . 'h';
        $this->paint($p, $fill, $stroke, $lw);
    }

    public function circle(float $cx, float $cy, float $r, ?string $fill = null, ?string $stroke = '#000', float $lw = 0.25): void
    {
        $k = 0.5522847498 * $r;
        $p = $this->mv($cx + $r, $cy) . $this->cu($cx + $r, $cy + $k, $cx + $k, $cy + $r, $cx, $cy + $r) . $this->cu($cx - $k, $cy + $r, $cx - $r, $cy + $k, $cx - $r, $cy)
           . $this->cu($cx - $r, $cy - $k, $cx - $k, $cy - $r, $cx, $cy - $r) . $this->cu($cx + $k, $cy - $r, $cx + $r, $cy - $k, $cx + $r, $cy) . 'h';
        $this->paint($p, $fill, $stroke, $lw);
    }

    public function line(float $x1, float $y1, float $x2, float $y2, string $stroke = '#000', float $lw = 0.25): void
    {
        $this->paint($this->mv($x1, $y1) . $this->ln($x2, $y2), null, $stroke, $lw);
    }

    private function mv(float $x, float $y): string { return self::X($x) . ' ' . self::Y($y) . ' m '; }
    private function ln(float $x, float $y): string { return self::X($x) . ' ' . self::Y($y) . ' l '; }
    private function cu(float $a, float $b, float $c, float $d, float $e, float $f): string
    {
        return self::X($a) . ' ' . self::Y($b) . ' ' . self::X($c) . ' ' . self::Y($d) . ' ' . self::X($e) . ' ' . self::Y($f) . ' c ';
    }

    /** SVG path (faqat M m L l H h V v Z z — to'g'ri chiziqlar) */
    public function path(string $d, ?string $fill = null, ?string $stroke = '#000', float $lw = 0.25): void
    {
        preg_match_all('/[MmLlHhVvZz]|-?(?:\d+\.?\d*|\.\d+)(?:e-?\d+)?/i', $d, $m);
        $tok = $m[0]; $i = 0; $n = count($tok);
        $x = 0.0; $y = 0.0; $sx = 0.0; $sy = 0.0; $cmd = ''; $p = ''; $pts = 0; $area = false;   // $area — 3+ nuqtali qism bor (bo'yash ma'noli)
        $num = function () use (&$i, $tok, $n): ?float { if ($i < $n && !preg_match('/^[A-Za-z]$/', $tok[$i])) return (float)$tok[$i++]; return null; };
        while ($i < $n) {
            if (preg_match('/^[A-Za-z]$/', $tok[$i])) $cmd = $tok[$i++];
            if ($cmd === '') { $i++; continue; }
            if ($cmd === 'Z' || $cmd === 'z') { $p .= 'h '; $x = $sx; $y = $sy; $cmd = ''; continue; }
            if ($cmd === 'H' || $cmd === 'h') { $v = $num(); if ($v === null) { $i++; continue; } $x = $cmd === 'H' ? $v : $x + $v; $p .= $this->ln($x, $y); if (++$pts > 2) $area = true; continue; }
            if ($cmd === 'V' || $cmd === 'v') { $v = $num(); if ($v === null) { $i++; continue; } $y = $cmd === 'V' ? $v : $y + $v; $p .= $this->ln($x, $y); if (++$pts > 2) $area = true; continue; }
            $a = $num(); $b = $num();
            if ($a === null || $b === null) { $i++; continue; }
            $rel = $cmd === 'm' || $cmd === 'l';
            $x = $rel ? $x + $a : $a; $y = $rel ? $y + $b : $b;
            if ($cmd === 'M' || $cmd === 'm') { $p .= $this->mv($x, $y); $sx = $x; $sy = $y; $cmd = $cmd === 'm' ? 'l' : 'L'; $pts = 1; }
            else { $p .= $this->ln($x, $y); if (++$pts > 2) $area = true; }
        }
        if ($p !== '') $this->paint(trim($p), $area ? $fill : null, $stroke, $lw);
    }

    /** Matn bo'laklari: [[kalit, [gid, …], kenglik (shrift birligida/upm)], …] */
    private function runs(string $s, bool $bold): array
    {
        $main = $bold ? 'B' : 'R'; $sym = $bold && isset($this->fonts['SB']) ? 'SB' : (isset($this->fonts['S']) ? 'S' : $main);
        $out = []; $cur = null;
        $cps = preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        foreach ($cps as $ch) {
            $cp = mb_ord($ch, 'UTF-8');
            if ($cp === false) continue;
            if ($cp === 0x09 || $cp === 0x0A || $cp === 0x0D) $cp = 0x20;
            if (self::invisible($cp)) continue;   // boshqaruv va ko'rinmas belgilar (BOM, nol kenglikdagi) chizilmaydi
            if ($cp === 0x2009 || $cp === 0x202F || $cp === 0x00A0) $cp = $this->fonts[$main]['ttf']->has($cp) ? $cp : 0x20;
            $k = $this->fonts[$main]['ttf']->has($cp) ? $main : ($this->fonts[$sym]['ttf']->has($cp) ? $sym : $main);
            $ttf = $this->fonts[$k]['ttf'];
            $g = $ttf->gid($cp);
            if ($g === 0 && $k === $main && $cp > 0x20) { $cp = 0x3F; $g = $ttf->gid($cp); }   // shriftda yo'q belgi — «?»
            $this->fonts[$k]['used'][$g] = $cp;
            if ($cur === null || $cur[0] !== $k) { if ($cur) $out[] = $cur; $cur = [$k, [], 0.0]; }
            $cur[1][] = $g;
            $cur[2] += $ttf->adv($g) / $ttf->upm;
        }
        if ($cur) $out[] = $cur;
        return $out;
    }

    private static function invisible(int $cp): bool
    {
        return $cp < 0x20 || ($cp >= 0x7F && $cp < 0xA0) || $cp === 0xFEFF || $cp === 0x00AD || ($cp >= 0x200B && $cp <= 0x200F) || ($cp >= 0x202A && $cp <= 0x202E) || ($cp >= 0x2060 && $cp <= 0x2064);
    }

    /** Matn kengligi (mm); $size — shrift o'lchami mm da */
    public function width(string $s, float $size, bool $bold = false): float
    {
        $w = 0.0;
        $main = $bold ? 'B' : 'R'; $sym = $bold && isset($this->fonts['SB']) ? 'SB' : (isset($this->fonts['S']) ? 'S' : $main);
        foreach (preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY) ?: [] as $ch) {
            $cp = mb_ord($ch, 'UTF-8');
            if ($cp === false) continue;
            if ($cp === 0x09 || $cp === 0x0A || $cp === 0x0D) $cp = 0x20;
            if (self::invisible($cp)) continue;
            $ttf = $this->fonts[$this->fonts[$main]['ttf']->has($cp) ? $main : ($this->fonts[$sym]['ttf']->has($cp) ? $sym : $main)]['ttf'];
            $g = $ttf->gid($cp) ?: $ttf->gid(0x3F);
            $w += $ttf->adv($g) / $ttf->upm;
        }
        return $w * $size;
    }

    /**
     * Matn: (x, y) — tayanch chiziq (SVG kabi). $size — mm. $o: b — qalin, a — start|middle|end, c — rang.
     * Qaytaradi: kenglik (mm)
     */
    public function text(float $x, float $y, float $size, string $s, array $o = []): float
    {
        if ($s === '') return 0.0;
        $bold = !empty($o['b']);
        $runs = $this->runs($s, $bold);
        $w = 0.0;
        foreach ($runs as $r) $w += $r[2] * $size;
        $a = (string)($o['a'] ?? 'start');
        if ($a === 'middle') $x -= $w / 2; elseif ($a === 'end') $x -= $w;
        $col = self::rgb($o['c'] ?? '#000') ?? '0 0 0';
        $o2 = 'q ' . $col . ' rg BT ';
        foreach ($runs as $r) {
            $hex = '';
            foreach ($r[1] as $g) $hex .= sprintf('%04X', $g);
            $o2 .= '/' . $this->fonts[$r[0]]['res'] . ' ' . self::n($size * self::K) . ' Tf 1 0 0 1 ' . self::X($x) . ' ' . self::Y($y) . ' Tm <' . $hex . '> Tj ';
            $x += $r[2] * $size;
        }
        $this->c .= $o2 . "ET Q\n";
        return $w;
    }

    /** Matnni kenglikka sig'dirish: oxiridan qisqartiradi va «…» qo'yadi */
    public function fit(string $s, float $size, float $maxW, bool $bold = false): string
    {
        if ($this->width($s, $size, $bold) <= $maxW) return $s;
        $chars = preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        while ($chars && $this->width(rtrim(implode('', $chars)) . '…', $size, $bold) > $maxW) array_pop($chars);
        return rtrim(implode('', $chars)) . '…';
    }

    /** Matnni qatorlarga bo'lish (so'z bo'yicha; ustundan uzun so'z — harflar bo'yicha bo'linadi, qo'shni ustunga chiqmaydi) */
    public function wrap(string $s, float $size, float $maxW, bool $bold = false): array
    {
        $lines = []; $cur = '';
        $words = [];
        foreach (preg_split('/\s+/u', trim($s), -1, PREG_SPLIT_NO_EMPTY) ?: [] as $wd) {
            if ($this->width($wd, $size, $bold) <= $maxW) { $words[] = $wd; continue; }
            $part = '';
            foreach (preg_split('//u', $wd, -1, PREG_SPLIT_NO_EMPTY) ?: [] as $ch) {
                if ($part !== '' && $this->width($part . $ch, $size, $bold) > $maxW) { $words[] = $part; $part = ''; }
                $part .= $ch;
            }
            if ($part !== '') $words[] = $part;
        }
        foreach ($words as $wd) {
            $try = $cur === '' ? $wd : $cur . ' ' . $wd;
            if ($cur !== '' && $this->width($try, $size, $bold) > $maxW) { $lines[] = $cur; $cur = $wd; }
            else $cur = $try;
        }
        if ($cur !== '') $lines[] = $cur;
        return $lines ?: [''];
    }

    private static function pdfStr(string $s): string
    {
        $u = (string)@mb_convert_encoding($s, 'UTF-16BE', 'UTF-8');
        return '<FEFF' . strtoupper(bin2hex($u)) . '>';
    }

    private static function stream(string $dict, string $data, bool $deflate = true): string
    {
        if ($deflate && function_exists('gzcompress')) { $data = gzcompress($data, 6); $dict .= ' /Filter /FlateDecode'; }
        return '<< ' . $dict . ' /Length ' . strlen($data) . " >>\nstream\n" . $data . "\nendstream";
    }

    public function output(): string
    {
        if ($this->open) { $this->pages[] = $this->c; $this->open = false; $this->c = ''; }
        if (!$this->pages) $this->pages[] = '';
        $objs = [];
        $add = function (string $o) use (&$objs): int { $objs[] = $o; return count($objs) + 2; };   // 1 — katalog, 2 — sahifalar
        $fontRes = '';
        $done = [];
        foreach ($this->fonts as $k => $f) {
            if (isset($done[$f['res']])) continue;
            $done[$f['res']] = true;
            $used = $f['used'];
            foreach ($this->fonts as $k2 => $f2) if ($f2['res'] === $f['res']) $used += $f2['used'];
            if (!$used) continue;
            ksort($used);
            $ttf = $f['ttf'];
            $sc = 1000 / $ttf->upm;
            $tag = '';
            $h = crc32($f['res'] . implode(',', array_keys($used)));
            for ($i = 0; $i < 6; $i++) { $tag .= chr(65 + $h % 26); $h = intdiv($h, 26); }
            $base = $tag . '+' . $ttf->psName;
            $bin = $ttf->subset($used);
            $file = $add(self::stream('/Length1 ' . strlen($bin), $bin));
            $desc = $add('<< /Type /FontDescriptor /FontName /' . $base . ' /Flags 32 /FontBBox [' . implode(' ', array_map(fn($v) => (int)round($v * $sc), $ttf->bbox)) . ']'
                . ' /ItalicAngle ' . self::n($ttf->italicAngle) . ' /Ascent ' . (int)round($ttf->ascent * $sc) . ' /Descent ' . (int)round($ttf->descent * $sc)
                . ' /CapHeight ' . (int)round($ttf->capHeight * $sc) . ' /StemV 80 /FontFile2 ' . $file . ' 0 R >>');
            $w = '';
            foreach ($used as $g => $cp) $w .= $g . ' [' . (int)round($ttf->adv($g) * $sc) . '] ';
            $cid = $add('<< /Type /Font /Subtype /CIDFontType2 /BaseFont /' . $base . ' /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >>'
                . ' /FontDescriptor ' . $desc . ' 0 R /DW 1000 /W [' . trim($w) . '] /CIDToGIDMap /Identity >>');
            $cm = "/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n";
            foreach (array_chunk($used, 100, true) as $ch) {
                $cm .= count($ch) . " beginbfchar\n";
                foreach ($ch as $g => $cp) {
                    $u = (string)mb_convert_encoding(mb_chr($cp, 'UTF-8'), 'UTF-16BE', 'UTF-8');
                    $cm .= sprintf('<%04X> <%s>', $g, strtoupper(bin2hex($u))) . "\n";
                }
                $cm .= "endbfchar\n";
            }
            $cm .= "endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend";
            $tu = $add(self::stream('', $cm));
            $fo = $add('<< /Type /Font /Subtype /Type0 /BaseFont /' . $base . ' /Encoding /Identity-H /DescendantFonts [' . $cid . ' 0 R] /ToUnicode ' . $tu . ' 0 R >>');
            $fontRes .= '/' . $f['res'] . ' ' . $fo . ' 0 R ';
        }
        $res = $add('<< /ProcSet [/PDF /Text] /Font << ' . $fontRes . '>> >>');
        $kids = [];
        foreach ($this->pages as $pc) {
            $cs = $add(self::stream('', $pc));
            $kids[] = $add('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' . self::n(self::PW) . ' ' . self::n(self::PH) . '] /Resources ' . $res . ' 0 R /Contents ' . $cs . ' 0 R >>');
        }
        $info = $add('<< /Producer ' . self::pdfStr('MOCK Rasch') . ($this->title !== '' ? ' /Title ' . self::pdfStr($this->title) : '') . ' /CreationDate (D:' . date('YmdHis') . ') >>');
        $all = [1 => '<< /Type /Catalog /Pages 2 0 R' . ($this->title !== '' ? ' /ViewerPreferences << /DisplayDocTitle true >>' : '') . ' >>',
                2 => '<< /Type /Pages /Kids [' . implode(' ', array_map(fn($n) => $n . ' 0 R', $kids)) . '] /Count ' . count($kids) . ' >>'];
        foreach ($objs as $i => $o) $all[$i + 3] = $o;
        $out = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $off = [];
        foreach ($all as $n => $o) { $off[$n] = strlen($out); $out .= $n . " 0 obj\n" . $o . "\nendobj\n"; }
        $x = strlen($out);
        $out .= "xref\n0 " . (count($all) + 1) . "\n0000000000 65535 f \n";
        foreach ($all as $n => $_) $out .= sprintf("%010d 00000 n \n", $off[$n]);
        return $out . "trailer\n<< /Size " . (count($all) + 1) . ' /Root 1 0 R /Info ' . $info . " 0 R >>\nstartxref\n" . $x . "\n%%EOF\n";
    }
}

/**
 * Bizning SVG (javoblar varaqasi, viewBox 0 0 210 297 — mm) ni PDF sahifasiga chizish. Faqat sheet_svg() ishlatadigan elementlar:
 * rect, circle, line, path (to'g'ri chiziqlar), text. SVG ning o'zi o'zgarmaydi — PDF undan olinadi.
 */
function pdf_draw_svg(PdfLite $pdf, string $svg): void
{
    preg_match_all('/<(rect|circle|line|path|text)\b([^>]*?)(?:\/>|>(.*?)<\/text>)/s', $svg, $m, PREG_SET_ORDER);
    foreach ($m as $el) {
        preg_match_all('/([a-zA-Z][\w:-]*)="([^"]*)"/', $el[2], $am, PREG_SET_ORDER);
        $a = [];
        foreach ($am as $x) $a[$x[1]] = html_entity_decode($x[2], ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $f = fn(string $k, float $d = 0.0): float => isset($a[$k]) ? (float)$a[$k] : $d;
        $fill = array_key_exists('fill', $a) ? $a['fill'] : '#000';   // SVG da bo'yoq standart — qora
        $stroke = $a['stroke'] ?? null;
        $lw = $f('stroke-width', 1);
        switch ($el[1]) {
            case 'rect': $pdf->rect($f('x'), $f('y'), $f('width'), $f('height'), $fill, $stroke, $lw, $f('rx')); break;
            case 'circle': $pdf->circle($f('cx'), $f('cy'), $f('r'), $fill, $stroke, $lw); break;
            case 'line': $pdf->line($f('x1'), $f('y1'), $f('x2'), $f('y2'), $stroke ?? '#000', $lw); break;
            case 'path': $pdf->path((string)($a['d'] ?? ''), $fill, $stroke, $lw); break;
            case 'text':
                // SVG (xml:space standart): ketma-ket bo'shliqlar bittaga qisqaradi — brauzer ham shunday chizadi
                $t = trim((string)preg_replace('/[ \t\r\n]+/', ' ', html_entity_decode(strip_tags((string)($el[3] ?? '')), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
                $pdf->text($f('x'), $f('y'), $f('font-size', 4), $t, ['b' => in_array($a['font-weight'] ?? '', ['700', 'bold', '800', '900'], true), 'a' => $a['text-anchor'] ?? 'start', 'c' => $fill ?? '#000']);
                break;
        }
    }
}
