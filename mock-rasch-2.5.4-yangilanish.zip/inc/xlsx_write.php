<?php
/**
 * 2.5.3: oddiy .xlsx yozuvchi (bitta varaq; 2.5.4 dan — bir nechta varaq ham: xlsx_build_book). PHP zip kengaytmasi shart emas — ZIP shu yerda yig'iladi (deflate — zlib bo'lsa).
 * $sheet: ['name' => 'Natijalar', 'rows' => [[katak, …], …], 'widths' => [5, 30, …], 'freeze' => 4]
 * Katak: null (bo'sh), int/float (son), string (matn) yoki ['v' => qiymat, 's' => 'title'|'head'|'cell'|'num'|'pct'|'bold'|'muted'].
 * Matn har doim matn sifatida yoziladi (formula bo'lib ishlamaydi).
 */

const XLSX_STYLES = ['' => 0, 'head' => 1, 'title' => 2, 'cell' => 3, 'num' => 3, 'pct' => 4, 'bold' => 5, 'muted' => 6, 'pctb' => 7];

function xlsx_col(int $i): string
{
    $s = '';
    for ($i++; $i > 0; $i = intdiv($i - 1, 26)) $s = chr(65 + ($i - 1) % 26) . $s;
    return $s;
}

function xlsx_esc(string $s): string
{
    $s = (string)preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $s);   // XML da ruxsat etilmagan belgilar
    if (!preg_match('//u', $s)) $s = mb_convert_encoding($s, 'UTF-8', 'UTF-8');
    return htmlspecialchars($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

function xlsx_sheet_xml(array $sheet): string
{
    $x = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
       . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">';
    $fr = (int)($sheet['freeze'] ?? 0);
    $x .= '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>';   // chop etishda kenglik bitta betga sig'adi
    $x .= '<sheetViews><sheetView workbookViewId="0">'
        . ($fr > 0 ? '<pane ySplit="' . $fr . '" topLeftCell="A' . ($fr + 1) . '" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A' . ($fr + 1) . '" sqref="A' . ($fr + 1) . '"/>' : '')
        . '</sheetView></sheetViews>';
    if (!empty($sheet['widths'])) {
        $x .= '<cols>';
        foreach (array_values($sheet['widths']) as $i => $w) $x .= '<col min="' . ($i + 1) . '" max="' . ($i + 1) . '" width="' . round((float)$w, 2) . '" customWidth="1"/>';
        $x .= '</cols>';
    }
    $x .= '<sheetData>';
    foreach (array_values($sheet['rows'] ?? []) as $ri => $row) {
        $r = $ri + 1;
        $x .= '<row r="' . $r . '">';
        foreach (array_values((array)$row) as $ci => $cell) {
            $style = '';
            if (is_array($cell)) { $style = (string)($cell['s'] ?? ''); $cell = $cell['v'] ?? null; }
            if ($cell === null || $cell === '') {
                if ($style !== '') $x .= '<c r="' . xlsx_col($ci) . $r . '" s="' . (XLSX_STYLES[$style] ?? 0) . '"/>';
                continue;
            }
            $s = XLSX_STYLES[$style] ?? 0;
            $ref = xlsx_col($ci) . $r;
            if (is_int($cell) || is_float($cell)) {
                $v = is_float($cell) ? rtrim(rtrim(sprintf('%.10F', $cell), '0'), '.') : (string)$cell;
                $x .= '<c r="' . $ref . '"' . ($s ? ' s="' . $s . '"' : '') . '><v>' . $v . '</v></c>';
            } else {
                $t = (string)$cell;
                $sp = $t !== trim($t) ? ' xml:space="preserve"' : '';
                $x .= '<c r="' . $ref . '" t="inlineStr"' . ($s ? ' s="' . $s . '"' : '') . '><is><t' . $sp . '>' . xlsx_esc($t) . '</t></is></c>';
            }
        }
        $x .= '</row>';
    }
    $x .= '</sheetData>';
    $x .= '<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>';
    $x .= '<pageSetup paperSize="9" orientation="portrait" fitToWidth="1" fitToHeight="0"/>';
    return $x . '</worksheet>';
}

function xlsx_styles_xml(): string
{
    $b = '<left style="thin"><color rgb="FFBFC7D5"/></left><right style="thin"><color rgb="FFBFC7D5"/></right><top style="thin"><color rgb="FFBFC7D5"/></top><bottom style="thin"><color rgb="FFBFC7D5"/></bottom><diagonal/>';
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
        . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<fonts count="4"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font><font><b/><sz val="11"/><name val="Calibri"/><family val="2"/></font>'
        . '<font><b/><sz val="14"/><name val="Calibri"/><family val="2"/></font><font><sz val="10"/><color rgb="FF5B6475"/><name val="Calibri"/><family val="2"/></font></fonts>'
        . '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
        . '<fill><patternFill patternType="solid"><fgColor rgb="FFE8EEF7"/><bgColor indexed="64"/></patternFill></fill></fills>'
        . '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border>' . $b . '</border></borders>'
        . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        . '<cellXfs count="8">'
        . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'                                                                   // 0 oddiy
        . '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>'   // 1 sarlavha qatori
        . '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'                                                     // 2 nom
        . '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>'                                                   // 3 katak
        . '<xf numFmtId="9" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>'                             // 4 foiz
        . '<xf numFmtId="0" fontId="1" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1"/>'                                     // 5 qalin katak
        . '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>'                                                     // 6 izoh
        . '<xf numFmtId="9" fontId="1" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyFont="1" applyBorder="1"/>'               // 7 qalin foiz
        . '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
}

/** .xlsx fayl mazmuni (binary) — bitta varaq */
function xlsx_build(array $sheet): string
{
    return xlsx_build_book([$sheet], (string)($sheet['title'] ?? ''));
}

/** 2.5.4: bir nechta varaqli .xlsx ($sheets — xlsx_build dagi kabi varaqlar; nomlar takrorlansa raqam qo'shiladi) */
function xlsx_build_book(array $sheets, string $title = ''): string
{
    $sheets = array_values($sheets) ?: [['name' => 'Varaq1', 'rows' => []]];
    $names = []; $seen = [];
    foreach ($sheets as $i => $sh) {
        $base = mb_substr((string)preg_replace('/[\[\]\*\?\/\\\\:]/', ' ', (string)($sh['name'] ?? '')), 0, 31);
        $base = trim((string)preg_replace('/[\x00-\x1F\x7F]/', '', $base), "'");   // 2.5.4: Excel boshqaruv belgisi va chetdagi «'» ni qabul qilmaydi
        if (mb_strtolower(trim($base)) === 'history') $base .= ' (1)';            // Excel zahiradagi nom
        if (trim($base) === '') $base = 'Varaq' . ($i + 1);
        $nm = $base; $k = 1;
        while (isset($seen[mb_strtolower($nm)])) { $suf = ' (' . (++$k) . ')'; $nm = mb_substr($base, 0, 31 - mb_strlen($suf)) . $suf; }
        $seen[mb_strtolower($nm)] = true;
        $names[] = $nm;
    }
    $n = count($sheets);
    $now = gmdate('Y-m-d\TH:i:s\Z');
    $ov = ''; $sh = ''; $rel = '';
    for ($i = 1; $i <= $n; $i++) {
        $ov .= '<Override PartName="/xl/worksheets/sheet' . $i . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        $sh .= '<sheet name="' . xlsx_esc($names[$i - 1]) . '" sheetId="' . $i . '" r:id="rId' . $i . '"/>';
        $rel .= '<Relationship Id="rId' . $i . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $i . '.xml"/>';
    }
    $files = [
        '[Content_Types].xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . $ov
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            . '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>',
        '_rels/.rels' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
            . '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>',
        'docProps/core.xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
            . '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            . '<dc:title>' . xlsx_esc($title !== '' ? $title : $names[0]) . '</dc:title><dc:creator>MOCK Rasch</dc:creator>'
            . '<dcterms:created xsi:type="dcterms:W3CDTF">' . $now . '</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">' . $now . '</dcterms:modified></cp:coreProperties>',
        'docProps/app.xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
            . '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>MOCK Rasch</Application></Properties>',
        'xl/workbook.xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<bookViews><workbookView/></bookViews><sheets>' . $sh . '</sheets></workbook>',
        'xl/_rels/workbook.xml.rels' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n"
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . $rel
            . '<Relationship Id="rId' . ($n + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
        'xl/styles.xml' => xlsx_styles_xml(),
    ];
    foreach ($sheets as $i => $sht) $files['xl/worksheets/sheet' . ($i + 1) . '.xml'] = xlsx_sheet_xml($sht);
    return xlsx_zip($files);
}

/** ZIP arxiv (fayl nomlari ASCII): zlib bo'lsa — deflate, bo'lmasa — siqilmagan */
function xlsx_zip(array $files): string
{
    $out = ''; $cd = ''; $n = 0;
    $t = getdate();
    $dosTime = ($t['hours'] << 11) | ($t['minutes'] << 5) | intdiv($t['seconds'], 2);
    $dosDate = ((max(1980, $t['year']) - 1980) << 9) | ($t['mon'] << 5) | $t['mday'];
    foreach ($files as $name => $data) {
        $data = (string)$data;
        $crc = crc32($data);
        $deflate = function_exists('gzdeflate');
        $body = $deflate ? gzdeflate($data, 6) : $data;
        $method = $deflate ? 8 : 0;
        $off = strlen($out);
        $head = pack('vvvvvVVVvv', 20, 0, $method, $dosTime, $dosDate, $crc, strlen($body), strlen($data), strlen($name), 0);
        $out .= pack('V', 0x04034b50) . $head . $name . $body;
        $cd .= pack('V', 0x02014b50) . pack('v', 20) . pack('vvvvvVVVvvvvvVV', 20, 0, $method, $dosTime, $dosDate, $crc, strlen($body), strlen($data), strlen($name), 0, 0, 0, 0, 0, $off) . $name;
        $n++;
    }
    return $out . $cd . pack('VvvvvVVv', 0x06054b50, 0, 0, $n, $n, strlen($cd), strlen($out), 0);
}

/** Brauzerga .xlsx yuborish ($filename — ASCII nom; filename* — UTF-8 nom bilan) */
function xlsx_send(string $filename, array $sheet, string $utfName = ''): void
{
    $bin = xlsx_build($sheet);
    if (function_exists('session_write_close')) @session_write_close();
    while (ob_get_level() > 0) ob_end_clean();
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . str_replace(['"', '\\'], '', $filename) . '"' . ($utfName !== '' ? "; filename*=UTF-8''" . rawurlencode($utfName) : ''));
    header('Content-Length: ' . strlen($bin));
    header('Cache-Control: private, no-store');
    header('X-Content-Type-Options: nosniff');
    echo $bin;
    exit;
}
