<?php
defined('APP_ROOT') || exit;
/**
 * 2.5.1: Telegram bot — administratorlar uchun (cheklarni botda tasdiqlash).
 * Admin Sozlamalar → «Mening Telegramim» dagi bir martalik havola bilan ulanadi (users.tg_chat_id).
 * Yangi chek har bir ulangan «Moliya» adminiga rasm va tugmalar bilan keladi. Birinchi qaror kuchda:
 * qolgan adminlardagi xabar darhol yangilanadi (saytda qilingan qaror ham, o'quvchi bekor qilgani ham).
 * Bitta Telegram hisobi bir vaqtda ham admin, ham o'quvchi bo'lmaydi. Har bir tugma va buyruqda huquq qayta tekshiriladi.
 */

const FIN_TG_KINDS = ['payrq', 'payupd', 'payrem', 'paydig'];
const FIN_MENU = ['🧾 Kutilayotgan cheklar' => '/kutilmoqda', '📅 Bugungi hisobot' => '/bugun', 'ℹ️ Yordam' => '/help'];

/** Uzoq kutayotgan chek haqida eslatma, daqiqa (0 — yo'q) */
function pay_remind_min(): int { $v = app_setting('pay_remind_min', '60'); return ctype_digit($v) ? min((int)$v, 1440) : 60; }
/** Kunlik hisobot vaqti «HH:MM» ('' — yuborilmaydi) */
function pay_digest_time(): string { $v = trim(app_setting('pay_digest', '21:00')); return preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $v) ? $v : ''; }

function tg_admin_by_chat(int $chat): ?array
{
    return $chat ? row('SELECT id, login, name, can_finance, tg_chat_id, tg_username, tg_linked_at FROM users WHERE tg_chat_id=?', [$chat]) : null;
}

/** Ulangan adminlarning chatlari ($finance — faqat «Moliya» huquqi borlar) */
function tg_admin_chats(bool $finance = false): array
{
    return array_map('intval', array_column(rows('SELECT tg_chat_id FROM users WHERE tg_chat_id IS NOT NULL' . ($finance ? ' AND can_finance=1' : '')), 'tg_chat_id'));
}

function admin_display_name(array $u): string { return (string)$u['name'] !== '' ? (string)$u['name'] : (string)$u['login']; }

function tg_fin_menu_kb(): array
{
    $b = array_map(fn($t) => ['text' => $t], array_keys(FIN_MENU));
    return ['keyboard' => [[$b[0], $b[1]], [$b[2]]], 'resize_keyboard' => true, 'is_persistent' => true];
}

function tg_fin_help(): string
{
    return "🛡 <b>Administrator buyruqlari</b>\n\n"
        . "🧾 /kutilmoqda — tekshirilmagan cheklar\n"
        . "💰 /balans 482107 — o‘quvchi balansi va oxirgi yozuvlar (ID yoki telefon)\n"
        . "➕ /toldirish 482107 50000 naqd izoh — balansni qo‘lda to‘ldirish (naqd, o‘qituvchiga to‘langan va h.k.; tasdiqlash so‘raladi)\n"
        . "📅 /bugun — bugungi tushum va qarorlar\n"
        . "/uzish — bu chatni administrator hisobidan uzish\n\n"
        . "Yangi chek shu yerga rasm va tugmalar bilan keladi: ✅ tasdiqlash, ✏️ boshqa summa, ❌ rad etish. Birinchi qaror kuchda — boshqa adminlardagi xabar ham yangilanadi.";
}

/** Bir martalik ulash havolasi (10 daqiqa, bir marta). Bot ulanmagan yoki limit bo'lsa null */
function tg_admin_link_url(int $uid): ?string
{
    $bot = tg_meta('bot');
    if (!tg_ready() || $bot === '') return null;
    if ((int)val('SELECT COUNT(*) FROM tg_admin_links WHERE user_id=? AND used_at IS NULL AND expires_at>NOW()', [$uid]) >= 5) return null;
    $tok = bin2hex(random_bytes(14));
    q('INSERT INTO tg_admin_links (token_hash, user_id, expires_at) VALUES (?,?,DATE_ADD(NOW(), INTERVAL 10 MINUTE))', [hash('sha256', $tok), $uid]);
    if (random_int(1, 20) === 1) q('DELETE FROM tg_admin_links WHERE expires_at < DATE_SUB(NOW(), INTERVAL 1 DAY)');
    return 'https://t.me/' . rawurlencode($bot) . '?start=adm_' . $tok;
}

/** `/start adm_<token>`: chatni administratorga bog'laydi (tg_start_token dan, urinishlar chegarasi bilan) */
function tg_admin_link_start(int $chat, array $from, string $tok): void
{
    $l = preg_match('/^[a-f0-9]{28}$/', $tok) ? row('SELECT * FROM tg_admin_links WHERE token_hash=? AND used_at IS NULL AND expires_at>NOW()', [hash('sha256', $tok)]) : null;
    $u = $l ? row('SELECT * FROM users WHERE id=?', [(int)$l['user_id']]) : null;
    if (!$l || !$u || !q('UPDATE tg_admin_links SET used_at=NOW() WHERE token_hash=? AND used_at IS NULL', [$l['token_hash']])->rowCount()) {
        q('INSERT INTO login_attempts (kind, ident, ip) VALUES ("tgt",?,"tg")', [(string)$chat]);
        tg_log('in', $chat, 'alink', false, 'havola yaroqsiz');
        tg_send($chat, "Havola eskirgan yoki allaqachon ishlatilgan. Saytda Sozlamalar → «Mening Telegramim» dan yangi havola oling (10 daqiqa amal qiladi).");
        return;
    }
    $uid = (int)$u['id'];
    $oldChat = $u['tg_chat_id'] !== null ? (int)$u['tg_chat_id'] : 0;
    $stu = row('SELECT id, full_name FROM students WHERE tg_chat_id=?', [$chat]);
    $par = (int)val('SELECT COUNT(*) FROM students WHERE parent_tg_chat=?', [$chat]);
    db_tx(function () use ($chat, $uid, $from, $stu) {
        if ($stu) q('UPDATE students SET tg_chat_id=NULL, tg_username="", tg_linked_at=NULL WHERE id=?', [$stu['id']]);   // bitta Telegram — admin yoki o'quvchi
        q('UPDATE students SET parent_tg_chat=NULL, parent_tg_at=NULL WHERE parent_tg_chat=?', [$chat]);
        q('UPDATE users SET tg_chat_id=NULL, tg_username="", tg_linked_at=NULL WHERE tg_chat_id=? AND id<>?', [$chat, $uid]);
        q('UPDATE users SET tg_chat_id=?, tg_username=?, tg_linked_at=NOW() WHERE id=?', [$chat, mb_substr((string)($from['username'] ?? ''), 0, 64), $uid]);
        q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
    });
    audit('tg_admin_link', 'user', $uid, $oldChat ? ['chat' => $oldChat] : null, ['chat' => $chat, 'student_unlinked' => $stu ? (int)$stu['id'] : null, 'parent_unlinked' => $par ?: null], 'bot-admin:' . $uid);
    tg_log('in', $chat, 'alink', true, 'user ' . $uid);
    tg_fin_set_commands($chat);
    $s = "✅ <b>Ulandi!</b> Siz administrator sifatida ulandingiz: <b>" . tg_h(admin_display_name($u)) . "</b>.\n\n";
    if ((int)$u['can_finance'] === 1) {
        $n = (int)val('SELECT COUNT(*) FROM pay_requests WHERE status="pending"');
        $s .= "Yangi to‘lov cheklari shu yerga rasm va tugmalar bilan keladi: ✅ tasdiqlash, ✏️ boshqa summa, ❌ rad etish.\n"
            . "Buyruqlar: /kutilmoqda, /balans ID, /toldirish ID summa, /bugun." . ($n ? "\n\nHozir <b>" . $n . "</b> ta chek tekshirilishini kutmoqda — /kutilmoqda" : '');
    } else {
        $s .= "⚠️ Sizda «Moliya» huquqi yo‘q — to‘lov cheklari bu yerga kelmaydi. Huquqni Sozlamalar → Administratorlar da moliya huquqi bor admin beradi.";
    }
    if ($stu) $s .= "\n\nℹ️ Bu Telegram avval o‘quvchi hisobiga (" . tg_h($stu['full_name']) . ") ulangan edi — o‘quvchi ulanishi uzildi.";
    if ($par) $s .= "\n\nℹ️ Bu Telegramdagi ota-ona ulanishi ham uzildi (bitta Telegram — bitta rol).";
    tg_send($chat, $s, tg_fin_menu_kb());
    if ($oldChat && $oldChat !== $chat) {
        tg_call('deleteMyCommands', ['scope' => ['type' => 'chat', 'chat_id' => $oldChat]]);
        tg_send($oldChat, 'Administrator hisobingiz boshqa Telegram profilga ulandi. Bu chatga endi cheklar kelmaydi.', ['remove_keyboard' => true]);
    }
}

function tg_admin_unlink(int $uid, string $actor): void
{
    $chat = (int)val('SELECT tg_chat_id FROM users WHERE id=?', [$uid]);
    q('UPDATE users SET tg_chat_id=NULL, tg_username="", tg_linked_at=NULL WHERE id=?', [$uid]);
    if ($chat) {
        q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
        if (tg_ready()) tg_call('deleteMyCommands', ['scope' => ['type' => 'chat', 'chat_id' => $chat]]);
    }
    audit('tg_admin_unlink', 'user', $uid, $chat ? ['chat' => $chat] : null, null, $actor);
}

/** Admin chatidagi «/» menyusi (faqat shu chat uchun) */
function tg_fin_set_commands(int $chat): void
{
    tg_call('setMyCommands', ['scope' => ['type' => 'chat', 'chat_id' => $chat], 'commands' => [
        ['command' => 'kutilmoqda', 'description' => 'Kutilayotgan cheklar'],
        ['command' => 'balans', 'description' => 'O‘quvchi balansi: /balans ID'],
        ['command' => 'toldirish', 'description' => 'Qo‘lda to‘ldirish: /toldirish ID summa'],
        ['command' => 'bugun', 'description' => 'Bugungi hisobot'],
        ['command' => 'help', 'description' => 'Yordam'],
        ['command' => 'uzish', 'description' => 'Ulanishni uzish'],
    ]]);
}

/* ---------------- Chek kartasi ---------------- */

function pay_admin_row(int $id): ?array
{
    return row('SELECT p.*, s.full_name, s.code, s.group_name, s.balance FROM pay_requests p JOIN students s ON s.id=p.student_id WHERE p.id=?', [$id]);
}

/** Qaror qatori (tasdiqlangan / rad etilgan / bekor qilingan). Matnli maydonlar escape dan oldin qisqartiriladi (HTML buzilmasin) */
function pay_status_line(array $r): string
{
    $who = (string)$r['reviewed_by'] !== '' ? actor_label((string)$r['reviewed_by']) : '';
    $when = !empty($r['reviewed_at']) ? date('d.m H:i', strtotime((string)$r['reviewed_at'])) : '';
    $tail = trim($who . ($who !== '' && $when !== '' ? ', ' : '') . $when);
    $note = mb_substr((string)$r['review_note'], 0, 150);
    if ($r['status'] === 'approved') {
        $s = "✅ <b>Tasdiqlandi: " . tg_h(som((int)$r['approved_amount'])) . "</b>" . ($tail !== '' ? ' — ' . tg_h($tail) : '');
        if ((int)$r['approved_amount'] !== (int)$r['amount']) $s .= "\n(o‘quvchi yozgan: " . tg_h(som((int)$r['amount'])) . ")";
        return $s . ($note !== '' ? "\nIzoh: " . tg_h($note) : '');
    }
    if ($r['status'] === 'rejected') return "❌ <b>Rad etildi</b>" . ($tail !== '' ? ' — ' . tg_h($tail) : '') . ($note !== '' ? "\nSabab: " . tg_h($note) : '');
    if ($r['status'] === 'canceled') return "🚫 <b>O‘quvchi chekni bekor qildi</b>" . ($when !== '' ? ' — ' . $when : '');
    return '';
}

/**
 * Chek kartasining matni (rasm izohi ≤ 1024 belgi). Har qator alohida to'liq HTML bo'lagi: sig'masa qatorlar butunligicha tashlab ketiladi
 * (avval izoh, chek raqami, to'lov vaqti, karta; keyin band MOCK lar) — teg yoki «&#039;» o'rtasidan kesilmaydi.
 */
function pay_admin_caption(array $r): string
{
    $L = [];   // [qator, ustuvorlik: 0 — doim qoladi; kattasi — oldinroq tashlanadi]
    $L[] = ["🧾 <b>To‘lov cheki #" . (int)$r['id'] . "</b> · " . date('d.m H:i', strtotime((string)$r['created_at'])) . ' · ' . ($r['source'] === 'bot' ? 'bot orqali' : 'saytdan'), 0];
    $L[] = ["👤 " . tg_h(mb_substr((string)$r['full_name'], 0, 80)) . " (ID " . tg_h($r['code']) . ")" . ((string)$r['group_name'] !== '' ? ', ' . tg_h(mb_substr((string)$r['group_name'], 0, 40)) : ''), 0];
    $L[] = ["💰 <b>" . tg_h(som((int)$r['amount'])) . "</b> · " . tg_h(PAY_METHODS[$r['method']] ?? $r['method']), 0];
    if ((string)$r['card_to'] !== '') $L[] = ["💳 " . tg_h(mb_substr((string)$r['card_to'], 0, 90)), 3];
    if (!empty($r['paid_at'])) $L[] = ["🕒 To‘lov vaqti: " . date('d.m.Y H:i', strtotime((string)$r['paid_at'])), 4];
    if ((string)$r['receipt_no'] !== '') $L[] = ["🔢 Chek raqami: " . tg_h(mb_substr((string)$r['receipt_no'], 0, 64)), 5];
    if ((string)$r['note'] !== '') $L[] = ["💬 " . tg_h(mb_substr((string)$r['note'], 0, 120)), 6];
    if ($r['status'] === 'pending') {
        $bal = (int)$r['balance'];
        $L[] = ["Balans: " . tg_h(som($bal)) . " → <b>" . tg_h(som($bal + (int)$r['amount'])) . "</b>", 0];
        $band = rows('SELECT t.title, t.price, t.online, t.online_end, t.test_date, t.published FROM test_registrations g JOIN tests t ON t.id=g.test_id
                      WHERE g.student_id=? AND g.pay_status="unpaid" ORDER BY g.created_at LIMIT 4', [(int)$r['student_id']]);
        foreach (array_slice(array_values(array_filter($band, fn($b) => !mock_is_over($b))), 0, 2) as $b)   // tasdiqlansa avtomatik to'lanadi
            $L[] = ["📌 Band: «" . tg_h(mb_substr((string)$b['title'], 0, 40)) . "» — " . tg_h(som(mock_price($b))), 2];
        foreach (array_slice(pay_flags($r), 0, 3) as $i => $f) $L[] = ["⚠️ " . tg_h(mb_substr((string)$f['text'], 0, 170)), $i === 0 ? 0 : 1];
    } else {
        $L[] = ['', 0];
        $L[] = [pay_status_line($r), 0];
    }
    $join = fn(array $L) => implode("\n", array_column($L, 0));
    for ($p = 6; $p >= 1 && tg_vis_len($join($L)) > 1000; $p--) $L = array_values(array_filter($L, fn($x) => $x[1] !== $p));
    return $join($L);
}

/** Telegram hisoblaydigan uzunlik: teglarsiz, «&amp;» kabi belgilar bitta harf (izoh chegarasi 1024 shu bo'yicha) */
function tg_vis_len(string $html): int
{
    return mb_strlen(html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
}

/** Kartaning tugmalari. $view: main | confirm | reasons. Ko'rib chiqilgan chekda — null (tugmalar olib tashlanadi) */
function pay_admin_kb(array $r, string $view = 'main'): ?array
{
    if ($r['status'] !== 'pending') return null;
    $id = (int)$r['id'];
    $a = (int)$r['amount'];
    if ($view === 'confirm') return ['inline_keyboard' => [
        [['text' => '✅ Ha, ' . som($a) . ' balansga yozilsin', 'callback_data' => 'pq:ok:' . $id . ':' . $a]],
        [['text' => '⬅️ Orqaga', 'callback_data' => 'pq:b:' . $id]],
    ]];
    if ($view === 'reasons') {
        $kb = [];
        foreach (PAY_REJECT_REASONS as $k => $t) if ($k !== 'boshqa') $kb[] = [['text' => '❌ ' . $t, 'callback_data' => 'pq:rr:' . $id . ':' . $k]];
        $kb[] = [['text' => '✍️ Boshqa sabab (yozib yuborasiz)', 'callback_data' => 'pq:rw:' . $id]];
        $kb[] = [['text' => '⬅️ Orqaga', 'callback_data' => 'pq:b:' . $id]];
        return ['inline_keyboard' => $kb];
    }
    $kb = [
        [['text' => '✅ ' . som($a) . ' — tasdiqlash', 'callback_data' => 'pq:a:' . $id]],
        [['text' => '✏️ Boshqa summa', 'callback_data' => 'pq:e:' . $id], ['text' => '❌ Rad etish', 'callback_data' => 'pq:r:' . $id]],
    ];
    if (tg_site_url() !== '') $kb[] = [['text' => '🌐 Saytda ochish', 'url' => tg_site_url() . '/index.php?p=pay&id=' . $id]];
    return ['inline_keyboard' => $kb];
}

/**
 * Adminlarga ketgan xabarlar (pay_requests.tg_msgs): ['f' => Telegram file_id, 't' => photo|doc, 'm' => [chat => [['id' => message_id, 'k' => cap|txt], …]]]
 */
function pay_tg_meta(int $id, bool $lock = false): array
{
    $j = json_decode((string)val('SELECT tg_msgs FROM pay_requests WHERE id=?' . ($lock ? ' FOR UPDATE' : ''), [$id]), true);
    if (!is_array($j)) return [];
    $m = [];
    foreach ((array)($j['m'] ?? []) as $chat => $list) {
        if (isset($list['id'])) $list = [$list];
        foreach ((array)$list as $e) if (is_array($e) && !empty($e['id'])) $m[(string)$chat][] = ['id' => (int)$e['id'], 'k' => ($e['k'] ?? '') === 'txt' ? 'txt' : 'cap'];
    }
    $j['m'] = $m;
    return $j;
}

/** tg_msgs ni qulf ostida yangilash (ikki jarayon bir vaqtda yozsa ham yo'qolmaydi) */
function pay_tg_meta_update(int $id, callable $fn): void
{
    db_tx(function () use ($id, $fn) {
        $m = $fn(pay_tg_meta($id, true));
        q('UPDATE pay_requests SET tg_msgs=? WHERE id=?', [json_encode($m, JSON_UNESCAPED_UNICODE), $id]);
    });
}

/** Shu chatdagi shu chekning kartasi (message_id bo'yicha) yoki null */
function pay_tg_own(array $meta, int $chat, int $mid): ?array
{
    if (!$mid) return null;
    foreach ((array)($meta['m'][(string)$chat] ?? []) as $e) if ((int)$e['id'] === $mid) return $e;
    return null;
}

/** Admin ko'radigan rasm: JPEG, eng uzun tomoni 1600 px (fayl yonida «.p» bo'lib keshlanadi). Bo'lmasa '' */
function pay_preview(string $path, string $type): string
{
    $pv = substr($path, 0, -2) . '.p';
    if (is_file($pv) && filemtime($pv) >= filemtime($path)) return $pv;
    $im = pay_gd_open($path, $type);
    if (!$im) return '';
    $w = imagesx($im); $h = imagesy($im);
    $k = min(1, 1600 / max($w, $h));
    $nw = max(1, (int)round($w * $k)); $nh = max(1, (int)round($h * $k));
    $out = imagecreatetruecolor($nw, $nh);
    imagefill($out, 0, 0, imagecolorallocate($out, 255, 255, 255));   // shaffof PNG — oq fon
    imagecopyresampled($out, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
    $ok = @imagejpeg($out, $pv, 86);
    if (PHP_VERSION_ID < 80000) { imagedestroy($im); imagedestroy($out); }
    if ($ok) @chmod($pv, 0644);
    return $ok ? $pv : '';
}

/** Chek kartasini bitta adminga yuborish (rasm/PDF + tugmalar); xabar raqami tg_msgs ga yoziladi */
function pay_admin_send(int $chat, int $id): array
{
    $r = pay_admin_row($id);
    if (!$r) return ['ok' => true, 'skip' => 'chek topilmadi'];
    $cap = pay_admin_caption($r);
    $kb = pay_admin_kb($r);
    $base = ['chat_id' => $chat, 'caption' => $cap, 'parse_mode' => 'HTML'];
    if ($kb) $base['reply_markup'] = $kb;
    $meta = pay_tg_meta($id);
    $res = null; $ft = ''; $kind = 'cap';
    if (!empty($meta['f'])) {   // Telegramda bor fayl (o'quvchi botga yuborgan yoki avval yuklangan) — qayta yuklamasdan
        $isDoc = ($meta['t'] ?? '') === 'doc';
        $res = tg_call($isDoc ? 'sendDocument' : 'sendPhoto', $base + [$isDoc ? 'document' : 'photo' => (string)$meta['f']]);
        if (!$res['ok'] && (int)$res['code'] === 400) $res = null;   // file_id yaroqsiz — qayta yuklaymiz
    }
    if (!$res) {
        $path = pay_file_path($r);
        if ($path === '' || !is_file($path)) {
            $res = tg_send($chat, $cap . "\n\n<i>(chek fayli topilmadi)</i>", $kb);
            $kind = 'txt';
        } elseif ($r['file_type'] === 'application/pdf') {
            $res = tg_call('sendDocument', $base + ['document' => new CURLFile($path, 'application/pdf', 'chek-' . $id . '.pdf')], null, 60);
            $ft = 'doc';
        } else {
            $pv = pay_preview($path, (string)$r['file_type']);
            if ($pv !== '') { $res = tg_call('sendPhoto', $base + ['photo' => new CURLFile($pv, 'image/jpeg', 'chek-' . $id . '.jpg')], null, 60); $ft = 'photo'; }
            if (!$res || (!$res['ok'] && (int)$res['code'] === 400)) {   // rasm qabul qilinmadi (o'lcham/nisbat) — fayl sifatida
                $ext = PAY_FILE_TYPES[(string)$r['file_type']] ?? 'jpg';
                $res = tg_call('sendDocument', $base + ['document' => new CURLFile($path, (string)$r['file_type'], 'chek-' . $id . '.' . $ext)], null, 60);
                $ft = 'doc';
            }
        }
    }
    if (!empty($res['ok'])) {
        $mid = (int)($res['result']['message_id'] ?? 0);
        $fid = '';
        if ($ft === 'photo' && !empty($res['result']['photo']) && is_array($res['result']['photo'])) { $ph = $res['result']['photo']; $fid = (string)($ph[count($ph) - 1]['file_id'] ?? ''); }
        if ($ft === 'doc') $fid = (string)($res['result']['document']['file_id'] ?? '');
        pay_tg_meta_update($id, function (array $m) use ($chat, $mid, $kind, $fid, $ft) {
            if ($fid !== '') { $m['f'] = $fid; $m['t'] = $ft; }
            if ($mid) {
                $list = (array)($m['m'][(string)$chat] ?? []);
                $list[] = ['id' => $mid, 'k' => $kind];
                $m['m'][(string)$chat] = array_slice($list, -3);   // shu chatdagi so'nggi 3 ta karta yangilanadi
            }
            return $m;
        });
    }
    return $res;
}

/** Xabarni (izoh yoki matn) va tugmalarni yangilash */
function tg_fin_edit(int $chat, int $mid, string $k, string $html, ?array $kb): array
{
    $p = ['chat_id' => $chat, 'message_id' => $mid, 'parse_mode' => 'HTML', 'reply_markup' => $kb ?: ['inline_keyboard' => []]];
    if ($k === 'txt') { $p['text'] = $html; $p['disable_web_page_preview'] = true; } else $p['caption'] = $html;
    return tg_call($k === 'txt' ? 'editMessageText' : 'editMessageCaption', $p);
}

function tg_drop_kb(int $chat, int $mid): void
{
    if ($chat && $mid) tg_call('editMessageReplyMarkup', ['chat_id' => $chat, 'message_id' => $mid, 'reply_markup' => ['inline_keyboard' => []]]);
}

/** Barcha adminlardagi karta(lar)ni joriy holatga keltirish. $skip — «chat:message_id» (hozirgina tahrirlangani) */
function pay_admins_refresh_now(int $id, string $skip = ''): int
{
    $r = pay_admin_row($id);
    if (!$r) return 0;
    $cap = pay_admin_caption($r);
    $kb = pay_admin_kb($r);
    $n = 0;
    $live = array_flip(tg_admin_chats(true));   // faqat hozir ulangan «Moliya» adminlari (uzilgan yoki huquqi olingan chatga qaror tafsiloti bormasin)
    foreach ((array)(pay_tg_meta($id)['m'] ?? []) as $chat => $list) {
        if (!isset($live[(int)$chat])) continue;
        foreach ($list as $e) {
            if ($chat . ':' . $e['id'] === $skip) continue;
            if (tg_fin_edit((int)$chat, (int)$e['id'], (string)$e['k'], $cap, $kb)['ok']) $n++;
        }
    }
    return $n;
}

/** Holat o'zgargach (sayt, bot yoki o'quvchi) — navbat orqali adminlardagi kartalarni yangilash */
function pay_admins_refresh(int $id, string $skip = ''): void
{
    if (!function_exists('tg_ready') || !tg_ready() || empty(pay_tg_meta($id)['m'])) return;
    q('DELETE FROM tg_queue WHERE kind="payupd" AND test_id=? AND student_id=0', [$id]);
    tg_enqueue('payupd', $id, 0, 0, $skip !== '' ? ['skip' => $skip] : null);
    tg_drain_after_response();
}

/* ---------------- Navbat ishlari ---------------- */

/** FIN_TG_KINDS: payrq — yangi chek (student_id = admin ID), payupd — kartalarni yangilash, payrem — eslatma, paydig — kunlik hisobot */
function tg_fin_run_job(array $j): array
{
    $kind = (string)$j['kind'];
    if ($kind === 'payupd') {
        $p = json_decode((string)$j['payload'], true) ?: [];
        pay_admins_refresh_now((int)$j['test_id'], (string)($p['skip'] ?? ''));
        return ['ok' => true];
    }
    $u = row('SELECT id, can_finance, tg_chat_id FROM users WHERE id=?', [(int)$j['student_id']]);
    if (!$u || $u['tg_chat_id'] === null) return ['ok' => true, 'skip' => 'admin ulanmagan'];
    if ((int)$u['can_finance'] !== 1) return ['ok' => true, 'skip' => 'moliya huquqi yo‘q'];
    $chat = (int)$u['tg_chat_id'];
    if ($kind === 'payrq') {
        if (val('SELECT status FROM pay_requests WHERE id=?', [(int)$j['test_id']]) !== 'pending') return ['ok' => true, 'skip' => 'chek allaqachon ko‘rib chiqilgan'];
        return pay_admin_send($chat, (int)$j['test_id']);
    }
    if ($kind === 'payrem') {
        $s = tg_fin_reminder_text();
        if ($s === '') return ['ok' => true, 'skip' => 'kutayotgan chek yo‘q'];
        return tg_send($chat, $s, ['inline_keyboard' => [[['text' => '🧾 Kutilayotgan cheklar', 'callback_data' => 'pq:l']]]]);
    }
    if ($kind === 'paydig') {
        $s = tg_fin_today_text(true);
        return $s === '' ? ['ok' => true, 'skip' => 'bugun harakat bo‘lmadi'] : tg_send($chat, $s);
    }
    return ['ok' => true, 'skip' => 'noma’lum tur'];
}

/** Yangi chek: har bir ulangan «Moliya» adminiga karta; eski «admin chat» (Sozlamalar → Telegram) — matnli xabar */
function pay_admins_notify_new(int $id): void
{
    if (!function_exists('tg_ready') || !tg_ready()) return;
    $chats = [];
    foreach (rows('SELECT id, tg_chat_id FROM users WHERE tg_chat_id IS NOT NULL AND can_finance=1') as $u) {
        tg_enqueue('payrq', $id, (int)$u['id'], (int)$u['tg_chat_id']);
        $chats[(int)$u['tg_chat_id']] = 1;
    }
    $chat = (int)tg_meta('admin_chat');
    if ($chat && !isset($chats[$chat]) && !tg_admin_by_chat($chat)) {
        $r = pay_admin_row($id);
        if ($r) {
            $url = tg_site_url() !== '' ? tg_site_url() . '/index.php?p=pay&id=' . $id : '';
            $s = "🧾 <b>Yangi to'lov cheki #" . $id . "</b>\n" . tg_h($r['full_name']) . " (ID " . tg_h($r['code']) . ")" . ((string)$r['group_name'] !== '' ? ', ' . tg_h($r['group_name']) : '')
                . "\nSumma: <b>" . tg_h(som((int)$r['amount'])) . "</b> · " . tg_h(PAY_METHODS[$r['method']] ?? $r['method'])
                . ((string)$r['card_to'] !== '' ? "\nKartaga: " . tg_h($r['card_to']) : '') . "\nHozirgi balans: " . tg_h(som((int)$r['balance']));
            foreach (array_slice(pay_flags($r), 0, 3) as $f) $s .= "\n⚠️ " . tg_h($f['text']);
            tg_enqueue('payadm', $id, 0, $chat, ['html' => $s . ($url !== '' ? "\n\nKo'rish va tasdiqlash: " . tg_h($url) : '')]);
        }
    }
    tg_drain_after_response();
}

/**
 * Javob brauzerga ketgach shu so'rovda navbatga qo'yilgan xabarlarni yuborish (php-fpm/LiteSpeed): adminga chek va o'quvchiga xabar
 * cron ni kutmasdan ketadi, sahifa sekinlashmaydi. Javobni oldin yuborib bo'lmaydigan muhitda (mod_php) — hech narsa qilinmaydi
 * (foydalanuvchi kutmasin; cron yoki webhook yuboradi). bot.php va cron.php (NO_SESSION) o'zi tg_tick chaqiradi; buyruq satrida — yo'q.
 */
function tg_drain_after_response(int $budget = 4): void
{
    static $armed = false;
    if ($armed || PHP_SAPI === 'cli' || defined('NO_SESSION') || !function_exists('tg_ready') || !tg_ready()) return;
    $finish = function_exists('fastcgi_finish_request') ? 'fastcgi_finish_request' : (function_exists('litespeed_finish_request') ? 'litespeed_finish_request' : '');
    if ($finish === '' && PHP_SAPI !== 'cli-server') return;
    $armed = true;
    register_shutdown_function(function () use ($budget, $finish) {
        if (session_status() === PHP_SESSION_ACTIVE) @session_write_close();   // keyingi sahifa sessiya qulfini kutmasin
        if ($finish !== '') @$finish();
        try { tg_drain_ids(tg_req_jobs(), $budget); } catch (Throwable $e) { error_log('[MOCK tg drain] ' . $e->getMessage()); }
    });
}

/* ---------------- Admin chati: xabarlar ---------------- */

/** Admin chatidan kelgan xabar. $file — rasm/hujjat (admin chatida chek qabul qilinmaydi) */
function tg_fin_update(int $chat, array $adm, string $text, bool $file = false): void
{
    $cmd = '';
    if ($text !== '' && $text[0] === '/') $cmd = strtolower((string)preg_replace('/@.*$/', '', (string)strtok($text, " \n")));
    elseif (isset(FIN_MENU[$text])) $cmd = FIN_MENU[$text];
    $args = trim((string)preg_replace('/^\/\S+/u', '', $text));
    if ($cmd === '/start' && $args !== '') {   // o'quvchi yoki ota-ona havolasi admin chatida
        tg_send($chat, 'Bu Telegram administrator sifatida ulangan — uni o‘quvchi yoki ota-ona sifatida ulab bo‘lmaydi (bitta Telegram — bitta rol). Kerak bo‘lsa avval /uzish.', tg_fin_menu_kb());
        return;
    }
    if ($cmd === '/start' || $cmd === '/menu' || $cmd === '/menyu') {
        q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
        $n = (int)val('SELECT COUNT(*) FROM pay_requests WHERE status="pending"');
        tg_send($chat, "Siz administrator sifatida ulangansiz: <b>" . tg_h(admin_display_name($adm)) . "</b>."
            . ((int)$adm['can_finance'] === 1 ? ($n ? "\nTekshirilmagan cheklar: <b>" . $n . "</b> — /kutilmoqda" : "\nTekshirilmagan chek yo‘q.") : "\n⚠️ «Moliya» huquqi yo‘q — cheklar kelmaydi."), tg_fin_menu_kb());
        return;
    }
    if ($cmd === '/help' || $cmd === '/yordam') { tg_send($chat, tg_fin_help(), tg_fin_menu_kb()); return; }
    if ($cmd === '/uzish' || $cmd === '/unlink') {
        tg_admin_unlink((int)$adm['id'], 'bot-admin:' . (int)$adm['id']);
        tg_send($chat, 'Ulanish uzildi. Qayta ulash uchun saytda Sozlamalar → «Mening Telegramim».', ['remove_keyboard' => true]);
        return;
    }
    $fin = (int)$adm['can_finance'] === 1;
    if ($cmd !== '' && !$fin) { tg_send($chat, '⚠️ Bu buyruq uchun «Moliya» huquqi kerak (Sozlamalar → Administratorlar).'); return; }
    if ($cmd === '/kutilmoqda') { tg_fin_pending_list($chat); return; }
    if ($cmd === '/balans') { tg_fin_balance($chat, $args); return; }
    if ($cmd === '/toldirish' || $cmd === '/tolov') { tg_fin_topup_ask($chat, $args); return; }
    if ($cmd === '/bugun') { tg_send($chat, tg_fin_today_text()); return; }
    if ($cmd !== '') { tg_send($chat, tg_fin_help(), tg_fin_menu_kb()); return; }

    $state = row('SELECT * FROM tg_state WHERE chat_id=?', [$chat]);
    if ($state && !empty($state['updated_at']) && time() - strtotime((string)$state['updated_at']) > 1800) { q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); $state = null; }   // admin amali 30 daqiqa kutadi
    if ($fin && $state && !$file && $state['step'] === 'pqamt' && ctype_digit((string)$state['data'])) {   // «✏️ Boshqa summa»
        $id = (int)$state['data'];
        $amt = money_in($text);
        $r = pay_admin_row($id);
        if (!$r || $r['status'] !== 'pending') { q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); tg_send($chat, 'Bu chek allaqachon ko‘rib chiqilgan.'); return; }
        if ($amt < 1 || $amt > PAY_MAX_AMOUNT) { tg_send($chat, 'Summani raqam bilan yozing, masalan: <code>40000</code> (1 dan ' . tg_h(som(PAY_MAX_AMOUNT)) . ' gacha). Bekor qilish: /menu'); return; }
        q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
        tg_send($chat, "✏️ Chek #" . $id . " (" . tg_h($r['full_name']) . "): o‘quvchi yozgan " . tg_h(som((int)$r['amount'])) . ".\n<b>" . tg_h(som($amt)) . "</b> tasdiqlanib, balansga yozilsinmi?",
            ['inline_keyboard' => [[['text' => '✅ Ha, ' . som($amt) . ' tasdiqlansin', 'callback_data' => 'pq:ok:' . $id . ':' . $amt]], [['text' => '⬅️ Yo‘q', 'callback_data' => 'pq:n']]]]);
        return;
    }
    if ($fin && $state && !$file && $state['step'] === 'pqrej' && ctype_digit((string)$state['data'])) {   // «✍️ Boshqa sabab»
        $id = (int)$state['data'];
        $why = mb_substr(trim($text), 0, 200);
        if (mb_strlen($why) < 3) { tg_send($chat, 'Sababni bir-ikki so‘z bilan yozing (o‘quvchiga yuboriladi). Bekor qilish: /menu'); return; }
        if (preg_match('/^[\d\s.,\x{00A0}]+(so.?m|sum)?$/iu', $why)) { tg_send($chat, 'Bu summaga o‘xshaydi. Chek #' . $id . ' ni rad etish sababini so‘z bilan yozing. Summani o‘zgartirish — chek kartasidagi «✏️ Boshqa summa». Bekor qilish: /menu'); return; }
        $r = pay_admin_row($id);
        if (!$r || $r['status'] !== 'pending') { q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); tg_send($chat, 'Bu chek allaqachon ko‘rib chiqilgan.'); return; }
        // yozilgan sabab tasdiqlanadi: qaysi chek va qaysi matn ekanini admin ko'radi (boshqa chek uchun yozilgan matn adashib ketmasin)
        $nonce = bin2hex(random_bytes(4));
        q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'pqrjc', json_encode(['i' => $id, 'w' => $why, 'k' => $nonce], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
        tg_send($chat, "❌ Chek #" . $id . " (" . tg_h($r['full_name']) . ", " . tg_h(som((int)$r['amount'])) . ") rad etilsinmi?\nSabab — o‘quvchiga shu matn boradi:\n<b>" . tg_h($why) . "</b>",
            ['inline_keyboard' => [[['text' => '❌ Ha, rad etilsin', 'callback_data' => 'pq:rx:' . $id . ':' . $nonce]], [['text' => '⬅️ Yo‘q', 'callback_data' => 'pq:n']]]]);
        return;
    }
    if ($fin && $state && $state['step'] === 'pqrjc') {   // tasdiq kutilayotgan chekni boshqa admin hal qilgan bo'lsa — holat tushadi
        $pi = (int)(json_decode((string)$state['data'], true)['i'] ?? 0);
        if (val('SELECT status FROM pay_requests WHERE id=?', [$pi]) !== 'pending') { q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); $state = null; }
    }
    if ($fin && $state && in_array($state['step'], ['ftop', 'pqrjc'], true) && !$file) { tg_send($chat, 'Avvalgi amalni tasdiqlang yoki bekor qiling (tugmalar yuqorida). Bekor qilish: /menu'); return; }
    if ($file) { tg_send($chat, 'Admin chatida chek qabul qilinmaydi — o‘quvchi chekni o‘z Telegramidan yoki saytdan yuboradi. Naqd to‘lov: /toldirish ID summa'); return; }
    tg_send($chat, tg_fin_help(), tg_fin_menu_kb());
}

/** Tekshirilmagan cheklar ro'yxati (har biriga karta ochish tugmasi) */
function tg_fin_pending_list(int $chat): void
{
    $list = rows('SELECT p.id, p.amount, p.created_at, p.source, s.full_name, s.code FROM pay_requests p JOIN students s ON s.id=p.student_id WHERE p.status="pending" ORDER BY p.created_at, p.id LIMIT 12');
    $n = (int)val('SELECT COUNT(*) FROM pay_requests WHERE status="pending"');
    if (!$list) { tg_send($chat, '✅ Tekshirilmagan chek yo‘q.'); return; }
    $s = "🧾 <b>Tekshirilmagan cheklar: " . $n . "</b>";
    $kb = []; $row = [];
    foreach ($list as $r) {
        $s .= "\n• #" . (int)$r['id'] . " · <b>" . tg_h(som((int)$r['amount'])) . "</b> · " . tg_h(mb_substr((string)$r['full_name'], 0, 40)) . " (" . tg_h($r['code']) . ") · " . tg_ago((string)$r['created_at']);
        $row[] = ['text' => '#' . (int)$r['id'], 'callback_data' => 'pq:v:' . (int)$r['id']];
        if (count($row) === 4) { $kb[] = $row; $row = []; }
    }
    if ($row) $kb[] = $row;
    if ($n > count($list)) $s .= "\n…va yana " . ($n - count($list)) . " ta (saytda: Moliya → To‘lovlar)";
    tg_send($chat, $s . "\n\nChekni ochish uchun raqamini bosing.", ['inline_keyboard' => $kb]);
}

/** «5 daqiqa oldin», «2 soat oldin» */
function tg_ago(string $dt): string
{
    $m = max(0, (int)floor((time() - strtotime($dt)) / 60));
    if ($m < 1) return 'hozirgina';
    if ($m < 60) return $m . ' daqiqa oldin';
    if ($m < 1440) return (int)floor($m / 60) . ' soat oldin';
    return (int)floor($m / 1440) . ' kun oldin';
}

/** /balans ID — balans va oxirgi yozuvlar */
function tg_fin_balance(int $chat, string $args): void
{
    if ($args === '') { tg_send($chat, 'O‘quvchi ID yoki telefonini yozing: <code>/balans 482107</code>'); return; }
    $s = student_find_by_ident($args);
    if (!$s) { tg_send($chat, 'O‘quvchi topilmadi: <b>' . tg_h(mb_substr($args, 0, 30)) . '</b>. ID (6 raqam) yoki telefonni tekshiring.'); return; }
    $sid = (int)$s['id'];
    $t = "💰 <b>" . tg_h($s['full_name']) . "</b> (ID " . tg_h($s['code']) . ")" . ((string)$s['group_name'] !== '' ? ', ' . tg_h($s['group_name']) : '')
        . "\nBalans: <b>" . tg_h(som((int)$s['balance'])) . "</b>";
    $pend = row('SELECT COUNT(*) n, COALESCE(SUM(amount),0) s FROM pay_requests WHERE student_id=? AND status="pending"', [$sid]);
    if ((int)$pend['n']) $t .= "\n⏳ Tekshirilmoqda: " . (int)$pend['n'] . " ta chek, " . tg_h(som((int)$pend['s']));
    foreach (rows('SELECT t.title, t.price FROM test_registrations g JOIN tests t ON t.id=g.test_id WHERE g.student_id=? AND g.pay_status="unpaid" LIMIT 5', [$sid]) as $u)
        $t .= "\n📌 Band (to‘lanmagan): «" . tg_h($u['title']) . "» — " . tg_h(som((int)$u['price']));
    $hist = wallet_history($sid, 6);
    if ($hist) {
        $t .= "\n\n<b>Oxirgi yozuvlar:</b>";
        foreach ($hist as $h) $t .= "\n" . date('d.m H:i', strtotime((string)$h['created_at'])) . " · " . ((int)$h['amount'] > 0 ? '+' : '') . tg_h(som((int)$h['amount'])) . " · " . tg_h(mb_substr(wallet_tx_label($h), 0, 60));
    } else $t .= "\n\nHamyonda hali yozuv yo‘q.";
    tg_send($chat, $t . "\n\nQo‘lda to‘ldirish: <code>/toldirish " . tg_h($s['code']) . " 50000 naqd</code>");
}

/** /toldirish ID summa [usul] [izoh] — tasdiqlash so'raladi */
function tg_fin_topup_ask(int $chat, string $args): void
{
    $usage = "Yozilishi: <code>/toldirish 482107 50000 naqd izoh</code>\nUsul: naqd, oqituvchi (o‘qituvchiga to‘langan), karta, click, payme, boshqa — yozilmasa «naqd».";
    $re = '/^(\S+)\s+(\d{1,3}(?:[ .,\x{00A0}]\d{3})+|\d+)(?:\s*(?:so[\'‘’ʻ`]?m|sum|сум))?(?:\s+(naqd|o[\'‘’ʻ`]?qituvchi|karta|click|payme|boshqa))?(?:\s+(.+))?$/iu';
    if (!preg_match($re, $args, $m)) { tg_send($chat, $usage); return; }
    $s = student_find_by_ident($m[1]);
    if (!$s) { tg_send($chat, 'O‘quvchi topilmadi: <b>' . tg_h(mb_substr($m[1], 0, 30)) . "</b>.\n" . $usage); return; }
    $amt = money_in($m[2]);
    if ($amt < 1 || $amt > PAY_MAX_AMOUNT) { tg_send($chat, 'Summa noto‘g‘ri (1 dan ' . tg_h(som(PAY_MAX_AMOUNT)) . " gacha).\n" . $usage); return; }
    $meth = mb_strtolower((string)preg_replace('/[\'‘’ʻ`]/u', '', (string)($m[3] ?? '')));
    if (!isset(PAY_ADMIN_METHODS[$meth])) $meth = 'naqd';
    $note = mb_substr(trim((string)($m[4] ?? '')), 0, 100);
    $nonce = bin2hex(random_bytes(4));
    q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, 'ftop', json_encode(['s' => (int)$s['id'], 'a' => $amt, 'm' => $meth, 'n' => $note, 'k' => $nonce], JSON_UNESCAPED_UNICODE)]);
    $bal = (int)$s['balance'];
    tg_send($chat, "➕ <b>Balansni to‘ldirish</b>\n" . tg_h($s['full_name']) . " (ID " . tg_h($s['code']) . ")\nSumma: <b>" . tg_h(som($amt)) . "</b> · " . tg_h(PAY_ADMIN_METHODS[$meth])
        . ($note !== '' ? "\nIzoh: " . tg_h($note) : '') . "\nBalans: " . tg_h(som($bal)) . " → <b>" . tg_h(som($bal + $amt)) . "</b>\n\nYozilsinmi?",
        ['inline_keyboard' => [[['text' => '✅ Ha, yozilsin', 'callback_data' => 'pt:ok:' . $nonce], ['text' => 'Bekor', 'callback_data' => 'pt:no:' . $nonce]]]]);
}

/** Bugungi hisobot matni. $digest — kunlik xabar uchun (bugun hech narsa bo'lmagan va kutayotgan chek yo'q bo'lsa '') */
function tg_fin_today_text(bool $digest = false): string
{
    $ap = row('SELECT COUNT(*) n, COALESCE(SUM(approved_amount),0) s FROM pay_requests WHERE status="approved" AND reviewed_at >= CURDATE()');
    $rj = (int)val('SELECT COUNT(*) FROM pay_requests WHERE status="rejected" AND reviewed_at >= CURDATE()');
    $new = (int)val('SELECT COUNT(*) FROM pay_requests WHERE created_at >= CURDATE()');
    $pend = (int)val('SELECT COUNT(*) FROM pay_requests WHERE status="pending"');
    // 2.5.4: bekor qilingan naqd belgisi («void») — qo'lda kirim va MOCK to'lovlaridan ayiriladi
    $man = row('SELECT GREATEST(COALESCE(SUM(kind="topup"),0) - COALESCE(SUM(kind="void"),0), 0) n, COALESCE(SUM(amount),0) s FROM wallet_tx
                WHERE ((kind="topup" AND ref_type IN ("manual","test")) OR (kind="void" AND method="naqd")) AND created_at >= CURDATE()');
    $ch = row('SELECT GREATEST(COALESCE(SUM(kind="charge"),0) - COALESCE(SUM(kind="void"),0), 0) n, COALESCE(SUM(-amount),0) s FROM wallet_tx
               WHERE (kind="charge" OR (kind="void" AND method="")) AND created_at >= CURDATE()');
    $rf = row('SELECT COUNT(*) n, COALESCE(SUM(amount),0) s FROM wallet_tx WHERE kind="refund" AND created_at >= CURDATE()');
    if ($digest && !$new && !(int)$ap['n'] && !$rj && !(int)$man['n'] && !(int)$ch['n'] && !(int)$rf['n'] && !$pend) return '';
    $s = ($digest ? "🌙 <b>Kunlik hisobot</b> · " : "📅 <b>Bugun</b> · ") . date('d.m.Y');
    $s .= "\n\n🧾 Yangi cheklar: <b>" . $new . "</b>";
    $s .= "\n✅ Tasdiqlangan: <b>" . (int)$ap['n'] . "</b> ta — <b>" . tg_h(som((int)$ap['s'])) . "</b>";
    $s .= "\n❌ Rad etilgan: <b>" . $rj . "</b>";
    $s .= "\n💵 Qo‘lda (naqd va b.): <b>" . (int)$man['n'] . "</b> ta — <b>" . tg_h(som((int)$man['s'])) . "</b>";
    $s .= "\n📝 MOCK to‘lovlari: <b>" . (int)$ch['n'] . "</b> ta — " . tg_h(som((int)$ch['s']));
    if ((int)$rf['n']) $s .= "\n↩️ Qaytarilgan: " . (int)$rf['n'] . " ta — " . tg_h(som((int)$rf['s']));
    $s .= "\n\n⏳ Tekshirilmagan cheklar: <b>" . $pend . "</b>" . ($pend ? ' — /kutilmoqda' : '');
    return $s;
}

/** Uzoq kutayotgan cheklar haqida eslatma matni ('' — yo'q) */
function tg_fin_reminder_text(): string
{
    $min = pay_remind_min();
    if ($min <= 0) return '';
    $old = rows('SELECT p.id, p.amount, p.created_at, s.full_name FROM pay_requests p JOIN students s ON s.id=p.student_id WHERE p.status="pending" AND p.created_at < DATE_SUB(NOW(), INTERVAL ? MINUTE) ORDER BY p.created_at LIMIT 6', [$min]);
    if (!$old) return '';
    $n = (int)val('SELECT COUNT(*) FROM pay_requests WHERE status="pending" AND created_at < DATE_SUB(NOW(), INTERVAL ? MINUTE)', [$min]);
    $s = "⏰ <b>" . $n . "</b> ta chek " . mock_minutes_label($min) . "dan ko‘p kutmoqda:";
    foreach ($old as $r) $s .= "\n• #" . (int)$r['id'] . " · " . tg_h(som((int)$r['amount'])) . " · " . tg_h(mb_substr((string)$r['full_name'], 0, 40)) . " · " . tg_ago((string)$r['created_at']);
    return $s;
}

/** Sozlama (meta) — keshsiz o'qish: vaqtli ishlar boshqa jarayon yozgan qiymatni ko'rsin */
function meta_fresh(string $k, string $default = ''): string
{
    $v = val('SELECT v FROM meta WHERE k=?', ['set_' . $k]);
    return $v === null ? $default : (string)$v;
}

/** Vaqtli ishlar (tg_tick dan, qulf ostida): eslatma (8:00–22:00, soatiga ko'pi bilan bir marta) va kunlik hisobot */
function tg_fin_tick(bool $anyHour = false): void
{
    if (!tg_ready()) return;
    $admins = rows('SELECT id, tg_chat_id FROM users WHERE tg_chat_id IS NOT NULL AND can_finance=1');
    if (!$admins) return;
    $min = pay_remind_min();
    $h = (int)date('G');
    if ($min > 0 && ($anyHour || ($h >= 8 && $h < 22)) && time() - (int)meta_fresh('pay_remind_at', '0') >= 3600
        && val('SELECT 1 FROM pay_requests WHERE status="pending" AND created_at < DATE_SUB(NOW(), INTERVAL ? MINUTE) LIMIT 1', [$min])) {
        set_app_setting('pay_remind_at', (string)time());
        $slot = (int)floor(time() / 3600);
        foreach ($admins as $a) tg_enqueue('payrem', $slot, (int)$a['id'], (int)$a['tg_chat_id']);
    }
    $dg = pay_digest_time();
    $today = date('Y-m-d');
    if ($dg !== '' && date('H:i') >= $dg && meta_fresh('pay_digest_day') !== $today) {
        set_app_setting('pay_digest_day', $today);
        foreach ($admins as $a) tg_enqueue('paydig', (int)date('Ymd'), (int)$a['id'], (int)$a['tg_chat_id']);
    }
}

/* ---------------- Admin chati: tugmalar ---------------- */

/** Shu chek bo'yicha kutilayotgan admin holatini (summa, sabab, sabab tasdig'i) o'chirish — chek boshqa joyda ko'rib chiqilganda */
function tg_fin_clear_state(int $chat, int $id): void
{
    $s = row('SELECT step, data FROM tg_state WHERE chat_id=?', [$chat]);
    if (!$s) return;
    $sid = in_array($s['step'], ['pqamt', 'pqrej'], true) ? (int)$s['data'] : ($s['step'] === 'pqrjc' ? (int)(json_decode((string)$s['data'], true)['i'] ?? 0) : 0);
    if ($sid === $id) q('DELETE FROM tg_state WHERE chat_id=? AND step=?', [$chat, $s['step']]);
}

/** pq:… (chek) va pt:… (qo'lda to'ldirish) tugmalari */
function tg_fin_callback(int $chat, array $adm, string $data, callable $ans, int $mid): void
{
    if ((int)$adm['can_finance'] !== 1) { $ans('«Moliya» huquqi yo‘q', true); return; }
    if (preg_match('/^pt:(ok|no):([a-f0-9]{8})$/', $data, $m)) { tg_fin_topup_confirm($chat, $adm, $m[1] === 'ok', $m[2], $ans, $mid); return; }
    if ($data === 'pq:l') { $ans(); tg_fin_pending_list($chat); return; }
    if ($data === 'pq:n') { q('DELETE FROM tg_state WHERE chat_id=? AND step="pqrjc"', [$chat]); $ans('Bekor qilindi'); tg_drop_kb($chat, $mid); return; }
    if (!preg_match('/^pq:(a|ok|e|r|rr|rw|rx|b|v):(\d+)(?::(\w+))?$/', $data, $m)) { $ans(); return; }
    $act = $m[1]; $id = (int)$m[2]; $arg = $m[3] ?? '';
    $r = pay_admin_row($id);
    if (!$r) { $ans('Chek topilmadi', true); tg_drop_kb($chat, $mid); return; }
    $own = pay_tg_own(pay_tg_meta($id), $chat, $mid);   // tugma shu chekning kartasida bosildimi
    if ($act === 'v') { $ans(); pay_admin_send($chat, $id); return; }   // ro'yxatdan — kartani (qayta) ochish
    if ($r['status'] !== 'pending') {
        tg_fin_clear_state($chat, $id);
        $ans('Bu chek allaqachon ko‘rib chiqilgan: ' . mb_strtolower(PAY_STATUS[$r['status']] ?? $r['status']) . ((string)$r['reviewed_by'] !== '' ? ' — ' . actor_label((string)$r['reviewed_by']) : ''), true);
        if ($own) tg_fin_edit($chat, $mid, $own['k'], pay_admin_caption($r), null); else tg_drop_kb($chat, $mid);
        return;
    }
    if ($act === 'a' || $act === 'r' || $act === 'b') {   // ko'rinishni almashtirish: tasdiqlash so'rovi / sabablar / asosiy
        $ans();
        $view = $act === 'a' ? 'confirm' : ($act === 'r' ? 'reasons' : 'main');
        if ($own) tg_call('editMessageReplyMarkup', ['chat_id' => $chat, 'message_id' => $mid, 'reply_markup' => pay_admin_kb($r, $view)]);
        else { tg_drop_kb($chat, $mid); tg_send($chat, pay_admin_caption($r), pay_admin_kb($r, $view)); }
        return;
    }
    if ($act === 'e') {
        $ans();
        $p = tg_send($chat, "✏️ Chek #" . $id . " uchun tasdiqlanadigan summani yozib yuboring (so‘m).\nO‘quvchi yozgan: <b>" . tg_h(som((int)$r['amount'])) . "</b>. Bekor qilish: /menu");
        q('REPLACE INTO tg_state (chat_id, step, data, msg_id) VALUES (?,?,?,?)', [$chat, 'pqamt', (string)$id, (int)($p['result']['message_id'] ?? 0)]);
        return;
    }
    if ($act === 'rw') {
        $ans();
        tg_send($chat, "✍️ Chek #" . $id . " ni rad etish sababini yozib yuboring — o‘quvchiga shu matn boradi. Bekor qilish: /menu");
        q('REPLACE INTO tg_state (chat_id, step, data, msg_id) VALUES (?,?,?,?)', [$chat, 'pqrej', (string)$id, 0]);
        return;
    }
    if ($act === 'rx') {   // yozilgan sabab tasdiqlandi — holat bir marta olinadi (ikki marta bosilsa ham bitta qaror)
        $why = '';
        $claimed = db_tx(function () use ($chat, $id, $arg, &$why) {
            $st = row('SELECT * FROM tg_state WHERE chat_id=? AND step="pqrjc" AND updated_at > DATE_SUB(NOW(), INTERVAL 30 MINUTE) FOR UPDATE', [$chat]);
            $d = $st ? json_decode((string)$st['data'], true) : null;
            if (!is_array($d) || (int)($d['i'] ?? 0) !== $id || ($d['k'] ?? '') !== $arg || (string)($d['w'] ?? '') === '') return false;
            q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
            $why = (string)$d['w'];
            return true;
        });
        if (!$claimed) { $ans('Bu so‘rov eskirgan — sababni qayta yozing', true); tg_drop_kb($chat, $mid); return; }
        tg_fin_decide($chat, $adm, $id, 'reject', 0, $why, $ans, $mid);
        return;
    }
    if ($act === 'rr') {
        if (!isset(PAY_REJECT_REASONS[$arg]) || $arg === 'boshqa') { $ans(); return; }
        tg_fin_decide($chat, $adm, $id, 'reject', 0, PAY_REJECT_REASONS[$arg], $ans, $mid);
        return;
    }
    if ($act === 'ok') {
        $amt = ctype_digit($arg) ? (int)$arg : 0;
        if ($amt < 1 || $amt > PAY_MAX_AMOUNT) { $ans('Summa noto‘g‘ri', true); return; }
        tg_fin_decide($chat, $adm, $id, 'approve', $amt, '', $ans, $mid);
    }
}

/**
 * Qaror: pay_request_decide (sayt bilan bir xil yo'l). Tugma bosilgan karta darhol yangilanadi, qolganlari — navbat orqali.
 * $ans — tugma javobi (matn bilan yozilgan sababda null), $mid — bosilgan xabar (0 — matn).
 */
function tg_fin_decide(int $chat, array $adm, int $id, string $dec, int $amount, string $note, ?callable $ans, int $mid): void
{
    $uid = (int)$adm['id'];
    if ((int)val('SELECT can_finance FROM users WHERE id=? AND tg_chat_id=?', [$uid, $chat]) !== 1) { if ($ans) $ans('«Moliya» huquqi yo‘q', true); return; }
    $res = pay_request_decide($id, $dec, $amount, $note, 'bot-admin:' . $uid);
    $r = pay_admin_row($id);
    $own = pay_tg_own(pay_tg_meta($id), $chat, $mid);
    if (!$res['ok']) {
        if ($r && $r['status'] !== 'pending') tg_fin_clear_state($chat, $id);
        if ($ans) $ans(mb_substr($res['error'], 0, 190), true); else tg_send($chat, '⚠️ ' . tg_h($res['error']));
        if ($r && $own) tg_fin_edit($chat, $mid, $own['k'], pay_admin_caption($r), pay_admin_kb($r));
        elseif ($r && $r['status'] !== 'pending') tg_drop_kb($chat, $mid);
        return;
    }
    if ($ans) $ans($dec === 'approve' ? '✅ Tasdiqlandi: ' . som($amount) : '❌ Rad etildi');
    if ($r && $own) tg_fin_edit($chat, $mid, $own['k'], pay_admin_caption($r), null);
    else tg_drop_kb($chat, $mid);   // «Boshqa summa» tasdiq xabari
    pay_admins_refresh($id, $own ? $chat . ':' . $mid : '');   // boshqa kartalar (bot.php oxirida tg_tick yuboradi)
    $who = $r ? tg_h($r['full_name']) . ' (ID ' . tg_h($r['code']) . ')' : '';
    if ($dec === 'approve') {
        $t = "✅ Chek #" . $id . " tasdiqlandi: <b>+" . tg_h(som($amount)) . "</b> — " . $who . "\nYangi balans: <b>" . tg_h(som((int)$res['balance'])) . "</b>";
        foreach ((array)($res['settled'] ?? []) as $x) $t .= "\n📝 Avtomatik to‘landi: «" . tg_h($x['title']) . "» — " . tg_h(som((int)$x['price']));
        if (!$own || !empty($res['settled'])) tg_send($chat, $t);
    } elseif (!$own) tg_send($chat, "❌ Chek #" . $id . " rad etildi — " . $who . ". Sabab o‘quvchiga yuborildi.");
}

/** «/toldirish» tasdiqlandi yoki bekor qilindi */
function tg_fin_topup_confirm(int $chat, array $adm, bool $yes, string $nonce, callable $ans, int $mid): void
{
    $d = null;
    $claimed = db_tx(function () use ($chat, $nonce, &$d) {   // holat bir marta olinadi: ikki marta bosilsa ham bir marta yoziladi
        $st = row('SELECT * FROM tg_state WHERE chat_id=? AND step="ftop" AND updated_at > DATE_SUB(NOW(), INTERVAL 30 MINUTE) FOR UPDATE', [$chat]);   // eski tasdiq (30 daqiqadan ko'p) yozmaydi
        $d = $st ? json_decode((string)$st['data'], true) : null;
        if (!is_array($d) || ($d['k'] ?? '') !== $nonce) return false;
        q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
        return true;
    });
    tg_drop_kb($chat, $mid);
    if (!$claimed) { $ans('Bu so‘rov eskirgan — buyruqni qayta yuboring', true); return; }
    if (!$yes) { $ans('Bekor qilindi'); return; }
    $res = wallet_admin_op((int)$d['s'], 'topup', (int)$d['a'], (string)$d['m'], (string)($d['n'] ?? ''), 'bot-admin:' . (int)$adm['id']);
    if (!$res['ok']) { $ans(mb_substr($res['error'], 0, 190), true); return; }
    $ans('✅ Yozildi');
    $s = row('SELECT full_name, code FROM students WHERE id=?', [(int)$d['s']]);
    $t = "✅ <b>+" . tg_h(som((int)$d['a'])) . "</b> yozildi — " . tg_h($s ? $s['full_name'] : '') . " (ID " . tg_h($s ? $s['code'] : '') . ")\nYangi balans: <b>" . tg_h(som((int)$res['balance'])) . "</b>";
    foreach ((array)($res['settled'] ?? []) as $x) $t .= "\n📝 Avtomatik to‘landi: «" . tg_h($x['title']) . "» — " . tg_h(som((int)$x['price']));
    tg_send($chat, $t);
}
