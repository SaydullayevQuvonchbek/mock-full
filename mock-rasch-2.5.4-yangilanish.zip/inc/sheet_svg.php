<?php
/**
 * Javoblar varaqasi (SVG, A4, mm) — 2.5.4 da pages/sheet.php dan ko'chirildi (o'zgarishsiz): chop etish sahifasi va PDF (inc/room_pack.php) bitta chizmadan foydalanadi.
 */
defined('APP_ROOT') || exit;

function sheet_svg(array $test, array $L, ?array $st, string $center): string
{
    $r = $L['r'];
    $o = '<svg class="sheet" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 210 297" width="210mm" height="297mm" font-family="Arial, Helvetica, sans-serif">';
    $o .= '<rect x="0" y="0" width="210" height="297" fill="#fff"/>';
    $m = $L['marker'];
    foreach ($L['markers'] as [$x, $y]) $o .= '<rect x="' . ($x - $m / 2) . '" y="' . ($y - $m / 2) . '" width="' . $m . '" height="' . $m . '" fill="#000"/>';
    foreach ($L['sides'] ?? [] as $pair) foreach ($pair as [$x, $y]) $o .= '<rect x="' . ($x - $m / 2) . '" y="' . ($y - $m / 2) . '" width="' . $m . '" height="' . $m . '" fill="#000"/>';
    $or = $L['orient'];
    $o .= '<rect x="' . $or['x'] . '" y="' . $or['y'] . '" width="' . $or['w'] . '" height="' . $or['h'] . '" fill="#000"/>';
    // Sarlavha
    $o .= '<text x="105" y="15" text-anchor="middle" font-size="6" font-weight="700">JAVOBLAR VARAQASI</text>';
    $o .= '<text x="105" y="21.5" text-anchor="middle" font-size="3.4">' . e($center) . ' · ' . e($test['subject']) . ' · milliy sertifikat formatida</text>';
    $o .= '<text x="105" y="27.5" text-anchor="middle" font-size="4" font-weight="700">' . e($test['title']) . '</text>';
    $o .= '<line x1="14" y1="31" x2="196" y2="31" stroke="#000" stroke-width="0.3"/>';
    // F.I.Sh
    $o .= '<text x="16" y="38" font-size="3.2">Familiya, ism:</text><line x1="40" y1="38.6" x2="140" y2="38.6" stroke="#000" stroke-width="0.25"/>';
    if ($st) $o .= '<text x="42" y="37.6" font-size="4" font-weight="700">' . e($st['full_name']) . '</text>';
    if ($st && array_key_exists('room_id', $st) && $st['room_id']) {
        // MOCK ro'yxatidan: guruh o'rniga xona va o'rin
        $o .= '<text x="143" y="38" font-size="3.2">Xona:</text><line x1="152" y1="38.6" x2="196" y2="38.6" stroke="#000" stroke-width="0.25"/>';
        $o .= '<text x="154" y="37.6" font-size="3.8" font-weight="700">' . e($st['room_name']) . ' · o\'rin ' . (int)$st['seat'] . '</text>';
    } else {
        $o .= '<text x="145" y="38" font-size="3.2">Guruh:</text><line x1="157" y1="38.6" x2="196" y2="38.6" stroke="#000" stroke-width="0.25"/>';
        if ($st) $o .= '<text x="159" y="37.6" font-size="3.6">' . e($st['group_name']) . '</text>';
    }
    // ID bloki
    // Ramka ichida, katakchalarning chap chetiga tekislangan (ramka: 16.5–64.5 mm, ustunlar markazi 40.5 mm)
    $o .= '<text x="20" y="46.6" font-size="3.2" font-weight="700">O\'quvchi ID</text>';
    $code = $st['code'] ?? '';
    foreach ($L['id']['cols'] as $d => $col) {
        $x = $col[0]['x'];
        $o .= '<rect x="' . ($x - 3) . '" y="49.5" width="6" height="6.5" fill="none" stroke="#000" stroke-width="0.3"/>';
        if ($code !== '') $o .= '<text x="' . $x . '" y="54.5" text-anchor="middle" font-size="4.2" font-weight="700">' . $code[$d] . '</text>';
        foreach ($col as $b) {
            $filled = $code !== '' && $code[$d] === $b['v'];
            $o .= '<circle cx="' . $b['x'] . '" cy="' . $b['y'] . '" r="' . $r . '" fill="' . ($filled ? '#000' : 'none') . '" stroke="#444" stroke-width="0.25"/>';
            if (!$filled) $o .= '<text x="' . $b['x'] . '" y="' . ($b['y'] + 1.05) . '" text-anchor="middle" font-size="2.6" fill="#b5b5b5">' . $b['v'] . '</text>';
        }
    }
    $o .= '<rect x="16.5" y="41.5" width="48" height="71" fill="none" stroke="#000" stroke-width="0.3" rx="1"/>';
    // Yo'riqnoma
    $ix = 72;
    $lines = [
        ['Diqqat!', 1],
        ['• Doirachani to\'liq, qora yoki ko\'k ruchka bilan bo\'yang:', 0],
        ['• Har bir savolga faqat bitta javob belgilang.', 0],
        ['• Tuzatilgan va bir nechta belgilangan javoblar hisobga olinmaydi.', 0],
        ['• ID raqamingizni katakchalarga yozing va har ustunda bitta raqamni bo\'yang.', 0],
        ['• Ochiq topshiriq javoblarini katakchaga aniq va sodda holda yozing.', 0],
        ['• ✓ / ✗ doirachalarni faqat TEKSHIRUVCHI to\'ldiradi.', 1],
        ['• Varaqni bukmang, chetdagi qora kvadratlarni to\'smang va bo\'yamang.', 0],
    ];
    $y = 50;
    foreach ($lines as [$t, $bold]) { $o .= '<text x="' . $ix . '" y="' . $y . '" font-size="3.1"' . ($bold ? ' font-weight="700"' : '') . '>' . e($t) . '</text>'; $y += 5.4; }
    $o .= '<circle cx="173" cy="54.4" r="' . $r . '" fill="#000"/><text x="177" y="55.4" font-size="2.8">to\'g\'ri</text>';
    $o .= '<circle cx="188" cy="54.4" r="' . $r . '" fill="none" stroke="#444" stroke-width="0.25"/><path d="M186.5,53 l3,3 M189.5,53 l-3,3" stroke="#000" stroke-width="0.5"/>';
    $o .= '<text x="' . $ix . '" y="' . ($y + 3) . '" font-size="3.1">Imzo: ______________________        Sana: ____________</text>';
    // Yopiq savollar
    $o .= '<text x="16" y="118.5" font-size="3.4" font-weight="700">Yopiq test topshiriqlari (1–' . count($L['mc']) . ')</text>';
    $o .= '<line x1="14" y1="120.5" x2="196" y2="120.5" stroke="#000" stroke-width="0.25"/>';
    foreach ($L['mc'] as $q) {
        $o .= '<text x="' . ($q['nx'] + 6.5) . '" y="' . ($q['y'] + 1.3) . '" text-anchor="end" font-size="3.6" font-weight="700">' . e($q['label']) . '</text>';
        foreach ($q['opts'] as $b) {
            $o .= '<circle cx="' . $b['x'] . '" cy="' . $b['y'] . '" r="' . $r . '" fill="none" stroke="#444" stroke-width="0.25"/>';
            $o .= '<text x="' . $b['x'] . '" y="' . ($b['y'] + 1.05) . '" text-anchor="middle" font-size="2.7" fill="#b5b5b5">' . $b['v'] . '</text>';
        }
    }
    // Ochiq topshiriqlar
    if ($L['open']) {
        $o .= '<text x="16" y="192" font-size="3.4" font-weight="700">Ochiq topshiriqlar — javobni katakchaga yozing</text>';
        $o .= '<text x="190" y="192" text-anchor="end" font-size="2.8">Tekshiruvchi to\'liq bo\'yaydi: ✓ — to\'g\'ri, ✗ — noto\'g\'ri</text>';
        $o .= '<line x1="14" y1="194.5" x2="196" y2="194.5" stroke="#000" stroke-width="0.25"/>';
        foreach ($L['open_rows'] as $row) {
            $o .= '<text x="' . ($row['x'] + 7) . '" y="' . ($row['y'] + 1.4) . '" text-anchor="end" font-size="3.8" font-weight="700">' . $row['no'] . '</text>';
        }
        foreach ($L['open'] as $b) {
            $bx = $b['box'];
            $o .= '<text x="' . ($bx['x'] - 1) . '" y="' . ($b['y'] + 1.1) . '" text-anchor="end" font-size="3">' . $b['part'] . ')</text>';
            $o .= '<rect x="' . $bx['x'] . '" y="' . $bx['y'] . '" width="' . $bx['w'] . '" height="' . $bx['h'] . '" fill="none" stroke="#666" stroke-width="0.25" rx="0.8"/>';
            foreach ([[$b['x'], '✓'], [$b['xw'], '✗']] as [$cx, $glyph]) {
                $o .= '<circle cx="' . $cx . '" cy="' . $b['y'] . '" r="' . $r . '" fill="none" stroke="#444" stroke-width="0.25"/>';
                $o .= '<text x="' . $cx . '" y="' . ($b['y'] + 1.0) . '" text-anchor="middle" font-size="2.7" fill="#b5b5b5">' . $glyph . '</text>';
            }
        }
    }
    if ($L['open']) {
        // Tekshiruvchi uchun ko'rsatma: doirachani to'liq bo'yash (ptichka/X emas)
        $o .= '<text x="16" y="264" font-size="2.9" font-weight="700">Tekshiruvchi: ✓ yoki ✗ doirachani TO\'LIQ bo\'yang — ptichka yoki X chizmang. Har qismda faqat bittasi.</text>';
        $o .= '<circle cx="168" cy="263" r="' . $r . '" fill="#000"/><text x="171.5" y="264" font-size="2.6">to\'g\'ri</text>';
        $o .= '<circle cx="184" cy="263" r="' . $r . '" fill="none" stroke="#444" stroke-width="0.25"/><path d="M182.9,263.1 l0.8,0.9 l1.6,-1.9" stroke="#000" stroke-width="0.35" fill="none"/>';
        $o .= '<path d="M181.4,265.6 l5.2,-5.2" stroke="#000" stroke-width="0.3"/><text x="187.5" y="264" font-size="2.6">xato</text>';
    }
    $o .= '<line x1="14" y1="268" x2="196" y2="268" stroke="#000" stroke-width="0.25"/>';
    $o .= '<text x="16" y="274" font-size="3">Tekshiruvchi: ______________________   imzo: __________</text>';
    $o .= '<text x="196" y="274" text-anchor="end" font-size="2.6" fill="#666">Test #' . (int)$test['id'] . '</text>';
    $o .= '</svg>';
    return $o;
}
