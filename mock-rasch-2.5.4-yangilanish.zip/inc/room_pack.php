<?php
/**
 * 2.5.4: xona paketlari — yuklab olish uchun.
 *  PDF (bitta xona): eshik ro'yxati, davomat ro'yxati, ajratuvchi varaq va javoblar varaqalari (o'rin tartibida);
 *  ZIP: har xona — alohida PDF (+ kirishdagi umumiy ro'yxat); Excel: har xona — alohida varaq.
 * Chop etiladigan HTML sahifalar o'zgarmaydi. PDF ular bilan bir xil ma'lumot va tuzilishda; javoblar varaqasi — aynan o'sha
 * SVG chizmadan (inc/sheet_svg.php), shuning uchun skaner uchun o'lchamlar bir xil.
 */
defined('APP_ROOT') || exit;
require_once __DIR__ . '/pdf_lite.php';
require_once __DIR__ . '/sheet_layout.php';
require_once __DIR__ . '/sheet_svg.php';

const ROOM_PACK_WHAT = ['all' => 'PDF: ro\'yxatlar + varaqlar', 'sheets' => 'PDF: faqat varaqlar', 'lists' => 'PDF: faqat ro\'yxatlar'];
const RP_PT = 0.3527777778;   // 1 pt = mm

/** Xonalar va ularning ro'yxati (to'lanmagan bandlarsiz — chop etish sahifalari bilan bir xil). 0 — xonasizlar */
function room_pack_data(int $tid): array
{
    $by = [];
    foreach (reg_students($tid, ['order' => 'room']) as $s) $by[(int)$s['room_id']][] = $s;
    return [test_rooms($tid), $by];
}

/** Sarlavhadagi kichik yozuv: markaz · MOCK · sana */
function rp_caption(array $test): string
{
    $date = !empty($test['test_date']) ? date('d.m.Y', strtotime((string)$test['test_date'])) : '';
    return implode(' · ', array_filter([trim((string)app_setting('center')), (string)$test['title'], $date], fn($v) => $v !== ''));
}

/** CSS «line-height: normal» qatordagi tayanch chiziq (shrift o'lchamidan): Arial/Liberation uchun */
function rp_base(float $sizePt, float $lh = 1.149): float
{
    return ((($lh - 1.117) / 2) + 0.905) * $sizePt * RP_PT;
}

/** Eshik ro'yxati (room_door.php, xona bo'yicha) — kerak bo'lsa bir necha sahifa */
function rp_door(PdfLite $pdf, array $test, array $room, array $list): void
{
    $L = 14.0; $R = 196.0; $W = $R - $L; $bottom = 297 - 14.0;
    $list = array_values(array_filter($list, fn($s) => $s['room_id'] && $s['seat']));
    $cap = rp_caption($test);
    $head = function (bool $cont) use ($pdf, $cap, $room, $list, $L, $R): float {
        $pdf->page();
        $y = 14.0;
        $pdf->text($L, $y + rp_base(9), 9 * RP_PT, $cap, ['c' => '#555']);
        $y += 9 * RP_PT * 1.149 + 1;
        $title = (string)$room['name'] . ($cont ? ' (davomi)' : '');
        $sz = 40 * RP_PT;
        $title = $pdf->fit($title, $sz, $R - $L - 32, true);
        $pdf->text($L, $y + rp_base(40, 1.05), $sz, $title, ['b' => true, 'c' => '#111']);
        $y += 40 * RP_PT * 1.05;
        if ((string)$room['proctor'] !== '') {
            $y += 2;
            $w = $pdf->text($L, $y + rp_base(12), 12 * RP_PT, 'Nazoratchi: ', ['c' => '#111']);
            $pdf->text($L + $w, $y + rp_base(12), 12 * RP_PT, (string)$room['proctor'], ['b' => true, 'c' => '#111']);
            $y += 12 * RP_PT * 1.149;
        }
        // o'ng tomonda: «N kishi» (pastki chiziqqa tekislangan)
        $bl = $y - (18 * RP_PT * 1.149 - rp_base(18));
        $tw = $pdf->width(' kishi', 14 * RP_PT);
        $pdf->text($R, $bl, 14 * RP_PT, ' kishi', ['a' => 'end', 'c' => '#333']);
        $pdf->text($R - $tw, $bl, 18 * RP_PT, (string)count($list), ['a' => 'end', 'b' => true, 'c' => '#333']);
        $y += 3;
        $pdf->rect($L, $y, $R - $L, 0.79, '#111', null);
        return $y + 0.79 + 5;
    };
    $y0 = $head(false);
    if (!$list) { $pdf->text($L, $y0 + rp_base(11), 11 * RP_PT, 'Bu xonaga hech kim joylashtirilmagan.', ['c' => '#777']); return; }
    $two = count($list) > 22;
    $colW = $two ? ($W - 10) / 2 : $W;
    $rowH = function (array $s) use ($pdf, $colW): array {
        $nmW = $colW - 11 - 4 - 4 - $pdf->width((string)$s['code'], 9 * RP_PT);
        $lines = $pdf->wrap((string)$s['full_name'], 14 * RP_PT, max(20, $nmW));
        return [$lines, 17 * RP_PT * 1.149 + (count($lines) - 1) * 14 * RP_PT * 1.149 + 3.2];
    };
    $rows = array_map(fn($s) => [$s, $rowH($s)], $list);
    $n = count($rows); $i = 0; $y = $y0;
    // ustunga sig'adigan qatorlar soni ($from dan boshlab, $avail mm)
    $fitCol = function (int $from, float $avail) use ($rows, $n): int {
        $h = 0.0; $k = $from;
        while ($k < $n && $h + $rows[$k][1][1] <= $avail) { $h += $rows[$k][1][1]; $k++; }
        return max(1, $k - $from);
    };
    while ($i < $n) {
        $avail = $bottom - $y;
        $c1 = min($n - $i, $fitCol($i, $avail)); $c2 = 0;
        if ($two && $i + $c1 < $n) $c2 = min($n - $i - $c1, $fitCol($i + $c1, $avail));
        $take = $c1 + $c2;
        if ($two && $i + $take >= $n && $take > 1) {   // oxirgi sahifa: ustunlar balandlik bo'yicha teng (CSS ustunlari kabi)
            $tot = 0.0; for ($k = $i; $k < $n; $k++) $tot += $rows[$k][1][1];
            $h = 0.0; $b = 0;
            while ($b < $take && $h < $tot / 2 - 0.01) { $h += $rows[$i + $b][1][1]; $b++; }
            $c1 = max(1, min($c1, $b)); $c2 = $take - $c1;
        }
        $k = $i;
        foreach ([$c1, $c2] as $col => $cnt) {
            $x = $L + $col * ($colW + 10); $yy = $y;
            for ($m = 0; $m < $cnt; $m++, $k++) {
                [$s, [$lines, $rh]] = $rows[$k];
                $bl = $yy + 1.6 + rp_base(17);
                $pdf->text($x + 11, $bl, 17 * RP_PT, (string)(int)$s['seat'], ['a' => 'end', 'b' => true, 'c' => '#111']);
                foreach ($lines as $li => $ln) $pdf->text($x + 15, $bl + $li * 14 * RP_PT * 1.149, 14 * RP_PT, $ln, ['c' => '#111']);
                $pdf->text($x + $colW, $bl, 9 * RP_PT, (string)$s['code'], ['a' => 'end', 'c' => '#666']);
                $yy += $rh;
                $pdf->line($x, $yy, $x + $colW, $yy, '#ccc', 0.26);
            }
        }
        $i += $take;
        if ($i < $n) $y = $head(true);
    }
}

/** Davomat ro'yxati (room_list.php) — jadval, kerak bo'lsa davomi keyingi sahifada (sarlavha qatori takrorlanadi) */
function rp_attendance(PdfLite $pdf, array $test, array $sec): void
{
    $L = 14.0; $R = 196.0; $W = $R - $L; $bottom = 297 - 16.0;
    $list = $sec['list'];
    $cap = rp_caption($test);
    $fs = 10 * RP_PT; $hs = 9 * RP_PT; $pad = 2.0; $vp = 1.8; $lh = $fs * 1.149;
    // ustunlar: o'rin, ID, F.I.Sh, maktab, keldi, imzo (brauzer jadvali kabi: belgilangan kengliklar + qolgani mazmunga qarab)
    $wNum = 12 + 2 * $pad; $wBox = 12 + 2 * $pad; $wSign = 30 + 2 * $pad;
    // brauzerdagi avtomatik jadval kabi: har ustun eng kami — eng uzun so'z, qolgan joy (eng uzun matn − eng uzun so'z) ga mutanosib
    $mm = function (array $texts, string $head) use ($pdf, $fs, $hs): array {
        $max = $pdf->width($head, $hs, true); $min = $max;
        foreach ($texts as $t) {
            $max = max($max, $pdf->width($t, $fs));
            foreach (preg_split('/\s+/u', $t, -1, PREG_SPLIT_NO_EMPTY) ?: [] as $wd) $min = max($min, $pdf->width($wd, $fs));
        }
        return [$min, $max];
    };
    $schools = array_map('school_grade', $list);
    [$idMin, $idMax] = $mm(array_map(fn($s) => (string)$s['code'], $list), 'ID');
    [$nmMin, $nmMax] = $mm(array_map(fn($s) => (string)$s['full_name'], $list), 'F.I.Sh');
    [$scMin, $scMax] = $mm($schools, 'Maktab / sinf');
    $wId = $idMax + 2 * $pad + 0.5;
    $rest = $W - $wNum - $wBox - $wSign - $wId;
    $a = $nmMax + 2 * $pad; $b = $scMax + 2 * $pad;
    if ($a + $b <= $rest) { $wNm = $a + ($rest - $a - $b) * $a / max(0.1, $a + $b); $wSc = $rest - $wNm; }
    else {
        $a0 = $nmMin + 2 * $pad; $b0 = $scMin + 2 * $pad;
        $extra = max(0.0, $rest - $a0 - $b0); $da = max(0.0, $a - $a0); $db = max(0.0, $b - $b0);
        $wNm = $a0 + ($da + $db > 0 ? $extra * $da / ($da + $db) : $extra / 2);
        $wSc = $rest - $wNm;
    }
    $cols = [['O\'rin', $wNum, 'c'], ['ID', $wId, 'l'], ['F.I.Sh', $wNm, 'l'], ['Maktab / sinf', $wSc, 'l'], ['Keldi', $wBox, 'l'], ['Imzo', $wSign, 'l']];
    $head = function (bool $cont) use ($pdf, $cap, $sec, $list, $L, $R): float {
        $pdf->page();
        $y = 16.0;
        $pdf->text($L, $y + rp_base(9), 9 * RP_PT, $cap, ['c' => '#555']);
        $y += 9 * RP_PT * 1.149 + 1;
        $pdf->text($L, $y + rp_base(20), 20 * RP_PT, $pdf->fit((string)$sec['title'] . ($cont ? ' (davomi)' : ''), 20 * RP_PT, $R - $L - 45, true), ['b' => true, 'c' => '#111']);
        $y += 20 * RP_PT * 1.149;
        $bl = $y - (18 * RP_PT * 1.149 - rp_base(18));
        $tail = $sec['cap'] ? ' / ' . $sec['cap'] . ' o\'rin' : ' kishi';
        $tw = $pdf->width($tail, 11 * RP_PT);
        $pdf->text($R, $bl, 11 * RP_PT, $tail, ['a' => 'end', 'c' => '#333']);
        $pdf->text($R - $tw, $bl, 18 * RP_PT, (string)count($list), ['a' => 'end', 'b' => true, 'c' => '#333']);
        $y += 3;
        $pdf->rect($L, $y, $R - $L, 0.53, '#111', null);
        return $y + 0.53 + 4;
    };
    $thead = function (float $y) use ($pdf, $cols, $L, $hs, $pad, $vp): float {
        $h = $hs * 1.149 + 2 * $vp;
        $x = $L;
        foreach ($cols as [$t, $w, $al]) {
            $pdf->rect($x, $y, $w, $h, '#f0f0f0', '#999', 0.26);
            $pdf->text($al === 'c' ? $x + $w / 2 : $x + $pad, $y + $vp + rp_base(9), $hs, $t, ['b' => true, 'a' => $al === 'c' ? 'middle' : 'start', 'c' => '#111']);
            $x += $w;
        }
        return $y + $h;
    };
    $y = $thead($head(false));
    if (!$list) {
        $h = $lh + 2 * $vp;
        $pdf->rect($L, $y, $W, $h, null, '#999', 0.26);
        $pdf->text($L + $W / 2, $y + $vp + rp_base(10), $fs, 'Bu xonaga hali hech kim joylashtirilmagan', ['a' => 'middle', 'c' => '#777']);
        $y += $h;
    }
    foreach (array_values($list) as $i => $s) {
        $nm = $pdf->wrap((string)$s['full_name'], $fs, $wNm - 2 * $pad);
        $sc = $pdf->wrap(school_grade($s), $fs, $wSc - 2 * $pad);
        $nl = max(count($nm), count($sc), 1);
        $h = $nl * $lh + 2 * $vp;
        if ($y + $h > $bottom) $y = $thead($head(true));
        $x = $L; $bl = $y + $vp + rp_base(10);
        $cells = [[(string)($s['seat'] ? (int)$s['seat'] : $i + 1)], [(string)$s['code']], $nm, $sc, [], []];
        foreach ($cols as $ci => [$t, $w, $al]) {
            $pdf->rect($x, $y, $w, $h, null, '#999', 0.26);
            foreach ($cells[$ci] as $li => $ln) $pdf->text($al === 'c' ? $x + $w / 2 : $x + $pad, $bl + $li * $lh, $fs, $ln, ['a' => $al === 'c' ? 'middle' : 'start', 'b' => $ci === 0, 'c' => '#111']);
            if ($ci === 4) $pdf->rect($x + $pad, $y + $vp + ($lh - 4) / 2 + 0.3, 4, 4, null, '#333', 0.26);   // «Keldi» katakchasi
            $x += $w;
        }
        $y += $h;
    }
    // pastki qism: nazoratchi, imzo, kelmaganlar soni
    if ($y + 8 + $lh > $bottom + 8) { $pdf->page(); $y = 16.0; } else $y += 8;
    $bl = $y + rp_base(10);
    $w = $pdf->text($L, $bl, $fs, 'Nazoratchi: ', ['c' => '#111']);
    if ((string)$sec['proctor'] !== '') $pdf->text($L + $w, $bl, $fs, (string)$sec['proctor'], ['b' => true, 'c' => '#111']);
    else $pdf->text($L + $w, $bl, $fs, '______________________', ['c' => '#111']);
    $pdf->text(105, $bl, $fs, 'Imzo: ____________', ['a' => 'middle', 'c' => '#111']);
    $pdf->text($R, $bl, $fs, 'Kelmaganlar soni: ______', ['a' => 'end', 'c' => '#111']);
}

/** Ajratuvchi varaq (sheet.php, «sep») — xona nomi va o'rinlar ro'yxati */
function rp_separator(PdfLite $pdf, array $test, string $roomName, string $proctor, array $grp): void
{
    $pdf->page();
    $L = 20.0; $R = 190.0; $y = 22.0;
    $pdf->text($L, $y + rp_base(11), 11 * RP_PT, implode(' · ', array_filter([(string)$test['title'], trim((string)app_setting('center'))], fn($v) => $v !== '')), ['c' => '#555']);
    $y += 11 * RP_PT * 1.149 + 3;
    $pdf->line($L, $y, $R, $y, '#999', 0.26);
    $y += 14;
    $pdf->text($L, $y + rp_base(54, 1.05), 54 * RP_PT, $pdf->fit($roomName, 54 * RP_PT, $R - $L, true), ['b' => true, 'c' => '#1f1e1b']);
    $y += 54 * RP_PT * 1.05 + 4;
    $bl = $y + rp_base(14);
    $w = $pdf->text($L, $bl, 14 * RP_PT, count($grp) . ' ta', ['b' => true, 'c' => '#1f1e1b']);
    $w += $pdf->text($L + $w, $bl, 14 * RP_PT, ' javoblar varaqasi', ['c' => '#1f1e1b']);
    if ($proctor !== '') {
        $w += $pdf->text($L + $w, $bl, 14 * RP_PT, ' · nazoratchi: ', ['c' => '#1f1e1b']);
        $pdf->text($L + $w, $bl, 14 * RP_PT, $proctor, ['b' => true, 'c' => '#1f1e1b']);
    }
    $y += 14 * RP_PT * 1.149 + 8;
    $three = count($grp) > 70;
    $fs = ($three ? 8 : 9.5) * RP_PT; $cols = $three ? 3 : 2; $gap = 8.0;
    $colW = ($R - $L - ($cols - 1) * $gap) / $cols;
    $rowH = $fs * 1.149 + 2 + 0.26;
    $per = (int)ceil(count($grp) / $cols);
    $maxRows = (int)floor((297 - 22 - 15 - $y) / $rowH);
    if ($per > $maxRows) $per = $maxRows;   // sahifaga sig'magani kesiladi (HTML dagi kabi)
    foreach (array_values($grp) as $i => $x) {
        $c = intdiv($i, max(1, $per));
        if ($c >= $cols) break;
        $cx = $L + $c * ($colW + $gap); $cy = $y + ($i % max(1, $per)) * $rowH;
        $bl = $cy + 1 + rp_base($three ? 8 : 9.5);
        $seat = $x['seat'] !== null ? (string)(int)$x['seat'] : '—';
        $sw = max(7.0, $pdf->width($seat, $fs, true));
        $pdf->text($cx, $bl, $fs, $seat, ['b' => true, 'c' => '#1f1e1b']);
        $code = ' ' . (string)$x['code'];
        $cw = $pdf->width($code, $fs * 0.9);
        $nm = $pdf->fit(' ' . (string)$x['full_name'], $fs, $colW - $sw - $cw - 1);
        $nw = $pdf->text($cx + $sw, $bl, $fs, $nm, ['c' => '#1f1e1b']);
        $pdf->text($cx + $sw + $nw, $bl, $fs * 0.9, $code, ['c' => '#666']);
        $pdf->line($cx, $cy + $rowH, $cx + $colW, $cy + $rowH, '#ddd', 0.26);
    }
    $ny = $y + min($per, count($grp)) * $rowH + 6;
    $pdf->text($L, $ny + rp_base(9), 9 * RP_PT, 'Bu ajratuvchi varaq — skanerlanmaydi. Keyingi varaqlar o\'rin tartibida.', ['c' => '#777']);
}

/** Kirishdagi umumiy ro'yxat (room_door.php, mode=all): F.I.Sh → xona · o'rin, alifbo tartibida */
function rp_door_all(PdfLite $pdf, array $test, array $all): void
{
    $placed = array_values(array_filter($all, fn($s) => $s['room_id'] && $s['seat']));
    usort($placed, fn($a, $b) => strcasecmp((string)$a['full_name'], (string)$b['full_name']));
    $L = 14.0; $R = 196.0; $W = $R - $L; $bottom = 297 - 14.0;
    $fs = 12.5 * RP_PT; $rowH = $fs * 1.149 + 2.4 + 0.26;
    $cap = rp_caption($test);
    $wNum = 18 + 4; $wRoom = 0.0;
    foreach ($placed as $s) $wRoom = max($wRoom, $pdf->width((string)$s['room_name'], $fs, true));
    $wRoom = min(70, max(30, $wRoom + 4)); $wName = $W - $wRoom - $wNum;
    $perFirst = (int)floor(($bottom - 14 - 30) / $rowH);
    $pages = max(1, (int)ceil(count($placed) / max(1, $perFirst)));
    foreach (array_chunk($placed, max(1, $perFirst)) ?: [[]] as $pi => $chunk) {
        $pdf->page();
        $y = 14.0;
        $pdf->text($L, $y + rp_base(9), 9 * RP_PT, $cap, ['c' => '#555']);
        $y += 9 * RP_PT * 1.149 + 1;
        $pdf->text($L, $y + rp_base(22), 22 * RP_PT, 'Xona va o\'rinlar', ['b' => true, 'c' => '#111']);
        if ($pages > 1) $pdf->text($R, $y + rp_base(22) - 1, 11 * RP_PT, ($pi + 1) . ' / ' . $pages, ['a' => 'end', 'c' => '#333']);
        $y += 22 * RP_PT * 1.149 + 3;
        $pdf->rect($L, $y, $W, 0.79, '#111', null);
        $y += 0.79 + 5;
        $th = 9 * RP_PT;
        $pdf->text($L + 2, $y + 1 + rp_base(9), $th, 'F.I.SH', ['b' => true, 'c' => '#555']);
        $pdf->text($L + $wName + 2, $y + 1 + rp_base(9), $th, 'XONA', ['b' => true, 'c' => '#555']);
        $pdf->text($R - 2, $y + 1 + rp_base(9), $th, 'O\'RIN', ['b' => true, 'c' => '#555', 'a' => 'end']);
        $y += $th * 1.149 + 2;
        $pdf->rect($L, $y, $W, 0.53, '#111', null);
        $y += 0.53;
        foreach ($chunk as $s) {
            $bl = $y + 1.2 + rp_base(12.5);
            $pdf->text($L + 2, $bl, $fs, $pdf->fit((string)$s['full_name'], $fs, $wName - 4), ['c' => '#111']);
            $pdf->text($L + $wName + 2, $bl, $fs, $pdf->fit((string)$s['room_name'], $fs, $wRoom - 4, true), ['b' => true, 'c' => '#111']);
            $pdf->text($R - 2, $bl, $fs, (string)(int)$s['seat'], ['b' => true, 'c' => '#111', 'a' => 'end']);
            $y += $rowH;
            $pdf->line($L, $y, $R, $y, '#ddd', 0.26);
        }
        if (!$chunk) $pdf->text($L, $y + 6, 11 * RP_PT, 'Hali hech kim xonaga joylashtirilmagan.', ['c' => '#777']);
    }
}

/**
 * Bitta xona paketi. $room — test_rooms qatori yoki null (xonasizlar), $list — o'rin tartibida, $what — all|sheets|lists.
 * $pdf berilsa — o'shanga qo'shiladi.
 */
function room_pack_pdf(array $test, ?array $room, array $list, string $what = 'all', ?PdfLite $pdf = null): PdfLite
{
    $what = isset(ROOM_PACK_WHAT[$what]) ? $what : 'all';
    $name = $room ? (string)$room['name'] : 'Xonasizlar';
    $pdf = $pdf ?? PdfLite::make($test['title'] . ' — ' . $name);
    if ($what !== 'sheets') {
        if ($room) rp_door($pdf, $test, $room, $list);
        rp_attendance($pdf, $test, ['title' => $name, 'cap' => $room ? (int)$room['capacity'] : 0, 'proctor' => $room ? (string)$room['proctor'] : '', 'list' => $list]);
    }
    if ($what !== 'lists' && $list) {
        rp_separator($pdf, $test, $room ? $name : 'Xonasiz', $room ? (string)$room['proctor'] : '', $list);
        $t = $test;
        if (!isset($t['key'])) $t['key'] = json_decode((string)($t['key_json'] ?? ''), true) ?: [];
        $L = sheet_layout($t);
        $center = (string)app_setting('center');
        foreach ($list as $st) {
            $pdf->page();
            pdf_draw_svg($pdf, sheet_svg($t, $L, $st, $center));
        }
    }
    return $pdf;
}

/** Fayl nomi uchun xavfsiz qism (UTF-8 saqlanadi) */
function rp_fname(string $s): string
{
    $s = trim((string)preg_replace('/[\/\\\\:*?"<>|\x00-\x1F]+/u', ' ', $s));
    return mb_substr(preg_replace('/\s+/u', ' ', $s), 0, 80) ?: 'xona';
}

/** ZIP (UTF-8 fayl nomlari bilan): [nom => mazmun] */
function rp_zip(array $files): string
{
    $out = ''; $cd = ''; $n = 0;
    $t = getdate();
    $dosTime = ($t['hours'] << 11) | ($t['minutes'] << 5) | intdiv($t['seconds'], 2);
    $dosDate = ((max(1980, $t['year']) - 1980) << 9) | ($t['mon'] << 5) | $t['mday'];
    foreach ($files as $name => $data) {
        $name = (string)$name; $data = (string)$data;
        $crc = crc32($data);
        $body = function_exists('gzdeflate') ? gzdeflate($data, 6) : $data;
        $method = function_exists('gzdeflate') ? 8 : 0;
        $off = strlen($out);
        $out .= pack('V', 0x04034b50) . pack('vvvvvVVVvv', 20, 0x0800, $method, $dosTime, $dosDate, $crc, strlen($body), strlen($data), strlen($name), 0) . $name . $body;
        $cd .= pack('V', 0x02014b50) . pack('v', 20) . pack('vvvvvVVVvvvvvVV', 20, 0x0800, $method, $dosTime, $dosDate, $crc, strlen($body), strlen($data), strlen($name), 0, 0, 0, 0, 0, $off) . $name;
        $n++;
    }
    return $out . $cd . pack('VvvvvVVv', 0x06054b50, 0, 0, $n, $n, strlen($cd), strlen($out), 0);
}

/** Brauzerga fayl yuborish: $ascii — zaxira nom, $utf — asl nom */
function rp_send(string $bin, string $type, string $ascii, string $utf): void
{
    if (function_exists('session_write_close')) @session_write_close();
    while (ob_get_level() > 0) ob_end_clean();
    header('Content-Type: ' . $type);
    header('Content-Disposition: attachment; filename="' . str_replace(['"', '\\'], '', $ascii) . "\"; filename*=UTF-8''" . rawurlencode($utf));
    header('Content-Length: ' . strlen($bin));
    header('Cache-Control: private, no-store');
    header('X-Content-Type-Options: nosniff');
    echo $bin;
    exit;
}
