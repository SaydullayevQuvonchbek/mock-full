<?php
defined('APP_ROOT') || exit;
/**
 * 2.5: Moliya → Hamyonlar. O'quvchilar balansi; o'quvchi sahifasida tarix va qo'lda amallar:
 * to'ldirish (naqd yoki o'qituvchiga to'langan), tuzatish (± izoh bilan, qarzga ham), naqd qaytarib berish.
 */
require_finance();
if (is_post()) {
    csrf_check();
    $sid = (int)($_POST['sid'] ?? 0);
    $op = (string)($_POST['op'] ?? '');
    $amount = $op === 'adjust' ? (int)(($_POST['sign'] ?? '+') === '-' ? -1 : 1) * money_in($_POST['amount'] ?? '') : money_in($_POST['amount'] ?? '');
    $r = wallet_admin_op($sid, $op, $amount, (string)($_POST['method'] ?? 'naqd'), (string)($_POST['note'] ?? ''));
    if ($r['ok']) {
        $msg = ['topup' => 'Balans to\'ldirildi', 'adjust' => 'Tuzatish yozildi', 'withdraw' => 'Naqd qaytarish yozildi'][$op] . '. Yangi balans: ' . som((int)$r['balance']);
        if (!empty($r['settled'])) $msg .= '. Avtomatik to\'landi: ' . implode(', ', array_map(fn($x) => '«' . $x['title'] . '» (' . som($x['price']) . ')', $r['settled']));
        flash($msg);
    } else flash($r['error'], 'err');
    redirect('wallets', ['sid' => $sid]);
}

$sid = (int)($_GET['sid'] ?? 0);
$st = $sid ? row('SELECT * FROM students WHERE id=?', [$sid]) : null;
if ($st):
    $hist = wallet_history($sid, 300);
    $reqs = rows('SELECT * FROM pay_requests WHERE student_id=? ORDER BY id DESC LIMIT 20', [$sid]);
    $regs = rows('SELECT t.id, t.title, t.test_date, t.price, g.pay_status, g.paid_amount, g.paid_at, g.via FROM test_registrations g JOIN tests t ON t.id=g.test_id
                  WHERE g.student_id=? ORDER BY g.created_at DESC LIMIT 20', [$sid]);
    $sumIn = 0; $sumOut = 0;
    foreach ($hist as $t) { if ((int)$t['amount'] > 0) $sumIn += (int)$t['amount']; else $sumOut += -(int)$t['amount']; }
    $check = (int)val('SELECT COALESCE(SUM(amount),0) FROM wallet_tx WHERE student_id=?', [$sid]);
    page_header('Hamyon — ' . $st['full_name']);
    ?>
    <div class="page-head"><div>
      <?= crumbs([['Hamyonlar', url('wallets')], $st['full_name']]) ?>
      <h1><?= e($st['full_name']) ?> <span class="muted small">ID <?= e($st['code']) ?><?= $st['group_name'] !== '' ? ' · ' . e($st['group_name']) : '' ?></span><?= $st['archived_at'] ? ' <span class="tag red">arxivda</span>' : '' ?></h1>
    </div><a class="btn ghost" href="<?= e(url('students', ['edit' => $sid])) ?>"><?= icon('user', 16) ?>O'quvchi</a></div>
    <?php if ($check !== (int)$st['balance']): ?><div class="alert err"><?= icon('alert') ?><span>Balans (<?= e(som((int)$st['balance'])) ?>) yozuvlar yig'indisiga (<?= e(som($check)) ?>) teng emas — dasturchiga xabar bering.</span></div><?php endif; ?>
    <div class="stats4 small-stats">
      <div class="stat accent"><span><?= e(som((int)$st['balance'])) ?></span>Balans</div>
      <div class="stat"><span><?= e(som($sumIn)) ?></span>Jami kirim</div>
      <div class="stat"><span><?= e(som($sumOut)) ?></span>Jami chiqim</div>
      <div class="stat"><span><?= count(array_filter($reqs, fn($r) => $r['status'] === 'pending')) ?></span>Kutilayotgan chek</div>
    </div>
    <div class="grid-side">
      <div>
        <div class="card">
          <h2 style="margin-top:0">Kirim va chiqimlar</h2>
          <?php if (!$hist): ?><p class="empty">Yozuv yo'q.</p><?php else: ?>
          <div class="table-wrap"><table class="tbl compact-tbl tx-tbl adm">
            <thead><tr><th>#</th><th>Sana</th><th>Izoh</th><th>Kim</th><th class="num">Summa</th><th class="num">Balans</th></tr></thead>
            <tbody>
            <?php foreach ($hist as $t): ?>
              <tr><td class="small muted"><?= (int)$t['id'] ?></td><td class="nowrap small"><?= e(date('d.m.Y H:i', strtotime((string)$t['created_at']))) ?></td>
                <td class="small"><?= e(wallet_tx_label($t)) ?><?php if ($t['ref_type'] === 'pay'): ?> <a href="<?= e(url('pay', ['id' => $t['ref_id']])) ?>">chek →</a><?php endif; ?></td>
                <td class="small muted"><?= e(actor_label((string)$t['actor'])) ?></td>
                <td class="num nowrap <?= (int)$t['amount'] > 0 ? 'ok-t' : '' ?>"><?= (int)$t['amount'] > 0 ? '+' : '' ?><?= e(som((int)$t['amount'])) ?></td><td class="num nowrap"><?= e(som((int)$t['balance_after'])) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
          </table></div>
          <?php endif; ?>
        </div>
        <?php if ($regs): ?>
        <div class="card">
          <h2 style="margin-top:0">MOCK lar</h2>
          <div class="table-wrap"><table class="tbl compact-tbl"><thead><tr><th>MOCK</th><th>Sana</th><th>To'lov</th><th class="num">Summa</th></tr></thead><tbody>
          <?php foreach ($regs as $g): ?>
            <tr><td><a href="<?= e(url('registrations', ['id' => $g['id'], 'q' => $st['code']])) ?>"><?= e($g['title']) ?></a></td><td class="small nowrap"><?= e($g['test_date'] ?: '—') ?></td>
              <td><span class="tag <?= REG_PAY_TAG[$g['pay_status']] ?? '' ?>"><?= e($g['pay_status'] === 'unpaid' ? 'Band' : (REG_PAY_LABEL[$g['pay_status']] ?? $g['pay_status'])) ?></span></td>
              <td class="num nowrap"><?= (int)$g['paid_amount'] ? e(som((int)$g['paid_amount'])) : (in_array($g['pay_status'], ['unpaid'], true) ? '<span class="muted">' . e(som((int)$g['price'])) . '</span>' : '—') ?></td></tr>
          <?php endforeach; ?>
          </tbody></table></div>
        </div>
        <?php endif; ?>
      </div>
      <div>
        <div class="card">
          <h2 style="margin-top:0">Balansni to'ldirish</h2>
          <p class="small muted" style="margin-top:-.3rem">O'quvchi naqd yoki o'qituvchining kartasiga to'lagan bo'lsa. Band qilingan MOCK lari avtomatik to'lanadi.</p>
          <form method="post" class="form" onsubmit="return confirm('Balansga ' + this.amount.value + ' so\'m qo\'shilsinmi?')"><?= csrf_field() ?><input type="hidden" name="sid" value="<?= $sid ?>"><input type="hidden" name="op" value="topup">
            <div class="grid2"><label>Summa, so'm <input name="amount" required inputmode="numeric" autocomplete="off" class="money-in"></label>
              <label>Usul <select name="method"><?php foreach (PAY_ADMIN_METHODS as $k => $v): ?><option value="<?= $k ?>"><?= e($v) ?></option><?php endforeach; ?></select></label></div>
            <label>Izoh <input name="note" maxlength="200" placeholder="masalan: 27.10 da naqd berdi"></label>
            <button class="btn primary">To'ldirish</button>
          </form>
        </div>
        <details class="card">
          <summary><h2 style="display:inline">Tuzatish</h2></summary>
          <p class="small muted">Xato yozuvni to'g'rilash yoki qarz yozish (balans manfiy bo'lishi mumkin). Sabab majburiy — tarixda qoladi.</p>
          <form method="post" class="form" onsubmit="return confirm('Tuzatish yozilsinmi?')"><?= csrf_field() ?><input type="hidden" name="sid" value="<?= $sid ?>"><input type="hidden" name="op" value="adjust">
            <div class="grid2"><label>Yo'nalish <select name="sign"><option value="+">+ qo'shish</option><option value="-">− ayirish</option></select></label>
              <label>Summa, so'm <input name="amount" required inputmode="numeric" autocomplete="off" class="money-in"></label></div>
            <label>Sabab * <input name="note" required minlength="3" maxlength="200"></label>
            <button class="btn">Tuzatishni yozish</button>
          </form>
        </details>
        <details class="card">
          <summary><h2 style="display:inline">Naqd qaytarib berish</h2></summary>
          <p class="small muted">Hamyondagi pulni o'quvchiga naqd qaytardingiz (masalan, o'qishni tugatdi). Balansdan ko'p bo'lmaydi.</p>
          <form method="post" class="form" onsubmit="return confirm('Hamyondan ' + this.amount.value + ' so\'m naqd qaytarildi deb yozilsinmi?')"><?= csrf_field() ?><input type="hidden" name="sid" value="<?= $sid ?>"><input type="hidden" name="op" value="withdraw">
            <label>Summa, so'm <input name="amount" required inputmode="numeric" autocomplete="off" class="money-in" value="<?= (int)$st['balance'] > 0 ? e(number_format((int)$st['balance'], 0, '.', ' ')) : '' ?>"></label>
            <label>Izoh * <input name="note" required minlength="3" maxlength="200" placeholder="kimga, qachon berildi"></label>
            <button class="btn">Yozish</button>
          </form>
        </details>
        <?php if ($reqs): ?>
        <div class="card">
          <h2 style="margin-top:0">Cheklar</h2>
          <?php foreach ($reqs as $r): ?>
            <div class="row between small pv-other"><a href="<?= e(url('pay', ['id' => $r['id']])) ?>">#<?= (int)$r['id'] ?> · <?= e(date('d.m.Y', strtotime((string)$r['created_at']))) ?></a><span><?= e(som((int)($r['status'] === 'approved' ? $r['approved_amount'] : $r['amount']))) ?> <span class="tag <?= ['pending' => 'amber', 'approved' => 'green', 'rejected' => 'red'][$r['status']] ?? '' ?>"><?= e(PAY_STATUS[$r['status']] ?? $r['status']) ?></span></span></div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <script>
    document.querySelectorAll('.money-in').forEach(function (a) {
      a.addEventListener('input', function () { var d = a.value.replace(/\D/g, '').slice(0, 9); a.value = d.replace(/\B(?=(\d{3})+(?!\d))/g, ' '); });
    });
    </script>
    <?php
    page_footer();
    return;
endif;

// Ro'yxat
$q = trim((string)($_GET['q'] ?? ''));
$f = in_array($_GET['f'] ?? '', ['pos', 'neg', 'unpaid', 'any'], true) ? (string)$_GET['f'] : 'any';
$w = ['(s.balance<>0 OR EXISTS (SELECT 1 FROM wallet_tx t WHERE t.student_id=s.id) OR EXISTS (SELECT 1 FROM pay_requests r WHERE r.student_id=s.id))'];
$p = [];
if ($f === 'pos') $w[] = 's.balance>0';
if ($f === 'neg') $w[] = 's.balance<0';
if ($f === 'unpaid') $w[] = 'EXISTS (SELECT 1 FROM test_registrations g WHERE g.student_id=s.id AND g.pay_status="unpaid")';
if ($q !== '') { [$sw, $sp] = student_search_sql($q); $w = [$sw]; $p = $sp; if ($f === 'pos') $w[] = 's.balance>0'; if ($f === 'neg') $w[] = 's.balance<0'; }
$list = rows('SELECT s.id, s.code, s.full_name, s.group_name, s.balance, s.archived_at,
                     (SELECT MAX(created_at) FROM wallet_tx t WHERE t.student_id=s.id) last_tx,
                     (SELECT COUNT(*) FROM pay_requests r WHERE r.student_id=s.id AND r.status="pending") pend,
                     (SELECT COUNT(*) FROM test_registrations g WHERE g.student_id=s.id AND g.pay_status="unpaid") unpaid
              FROM students s WHERE ' . implode(' AND ', $w) . ' ORDER BY s.balance DESC, s.full_name LIMIT 500', $p);
$tot = row('SELECT COALESCE(SUM(CASE WHEN balance>0 THEN balance END),0) pos, COALESCE(SUM(CASE WHEN balance<0 THEN balance END),0) neg, SUM(balance<>0) n FROM students');
$month = row('SELECT COALESCE(SUM(CASE WHEN kind="topup" OR (kind="void" AND method="naqd") THEN amount END),0) inc,
                     COALESCE(SUM(CASE WHEN kind="charge" OR (kind="void" AND method="") THEN -amount END),0) - COALESCE(SUM(CASE WHEN kind="refund" THEN amount END),0) spent
              FROM wallet_tx WHERE created_at >= DATE_FORMAT(CURDATE(), "%Y-%m-01")');
page_header('Hamyonlar');
?>
<div class="page-head"><div><h1>Hamyonlar</h1><p class="muted" style="margin:0">O'quvchilar balansi, kirim-chiqim tarixi va qo'lda amallar.</p></div>
  <a class="btn ghost" href="<?= e(url('pay')) ?>"><?= icon('receipt', 16) ?>To'lovlar<?= pay_pending_count() ? ' (' . pay_pending_count() . ')' : '' ?></a></div>
<div class="stats4 small-stats">
  <div class="stat accent"><span><?= e(som((int)$tot['pos'])) ?></span>O'quvchilar hamyonida (markaz majburiyati)</div>
  <div class="stat"><span><?= e(som(-(int)$tot['neg'])) ?></span>Qarzlar</div>
  <div class="stat"><span><?= e(som((int)$month['inc'])) ?></span>Shu oy kirim</div>
  <div class="stat"><span><?= e(som((int)$month['spent'])) ?></span>Shu oy MOCK larga</div>
</div>
<form class="row gap wrap filter" method="get"><input type="hidden" name="p" value="wallets">
  <input name="q" value="<?= e($q) ?>" placeholder="Ism, ID yoki telefon — istalgan o'quvchi" aria-label="Qidirish">
  <select name="f" aria-label="Filtr"><option value="any">Hamyoni bor hammasi</option><option value="pos" <?= $f === 'pos' ? 'selected' : '' ?>>Balansi bor</option><option value="neg" <?= $f === 'neg' ? 'selected' : '' ?>>Qarzdorlar</option><option value="unpaid" <?= $f === 'unpaid' ? 'selected' : '' ?>>Band ro'yxati bor</option></select>
  <button class="btn sm">Ko'rsatish</button><span class="small muted"><?= count($list) ?> ta</span></form>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>ID</th><th>F.I.Sh</th><th>Guruh</th><th class="num">Balans</th><th>Holat</th><th>Oxirgi amal</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($list as $s): ?>
    <tr><td class="mono"><?= e($s['code']) ?></td><td><a href="<?= e(url('wallets', ['sid' => $s['id']])) ?>"><?= e($s['full_name']) ?></a><?= $s['archived_at'] ? ' <span class="tag red">arxiv</span>' : '' ?></td><td class="small"><?= e($s['group_name'] ?: '—') ?></td>
      <td class="num nowrap <?= (int)$s['balance'] < 0 ? 'critical-t' : '' ?>"><b><?= e(som((int)$s['balance'])) ?></b></td>
      <td><?= (int)$s['pend'] ? '<span class="tag amber">' . (int)$s['pend'] . ' chek</span>' : '' ?><?= (int)$s['unpaid'] ? '<span class="tag">' . (int)$s['unpaid'] . ' band</span>' : '' ?></td>
      <td class="small muted nowrap"><?= $s['last_tx'] ? e(date('d.m.Y H:i', strtotime((string)$s['last_tx']))) : '—' ?></td>
      <td class="right"><a class="btn sm ghost" href="<?= e(url('wallets', ['sid' => $s['id']])) ?>">Ochish</a></td></tr>
  <?php endforeach; ?>
  <?php if (!$list): ?><tr><td colspan="7" class="empty"><?= $q !== '' ? 'O\'quvchi topilmadi' : 'Hali hamyon amallari yo\'q. O\'quvchi chek yuborganda yoki siz balans to\'ldirganda shu yerda ko\'rinadi. Istalgan o\'quvchini qidiruv orqali topib, balansini to\'ldirishingiz mumkin.' ?></td></tr><?php endif; ?>
  </tbody>
</table></div>
<?php page_footer();
