<?php
defined('APP_ROOT') || exit;
require_once APP_ROOT . '/inc/students_lib.php';   // 2.5.2: guruh katagi, guruhga biriktirish (assets/students.js + stu_api)
require_once APP_ROOT . '/inc/room_pack.php';      // 2.5.4: xonalar bo'yicha yuklab olish (PDF, ZIP, Excel)
$test = get_test_or_404();
$tid = (int)$test['id'];
// Amaldan keyin shu sahifaga filtrlar saqlangan holda qaytish (formalar joriy manzilga yuboriladi, shuning uchun $_GET da filtrlar bor)
$back = function () use ($tid) {
    $keep = ['id' => $tid];
    foreach (['room', 'pr', 'q', 'fg', 'fc', 'fp', 'fv', 'fd', 'o', 'un', 'ng', 'nc', 'ns'] as $k) $keep[$k] = (string)($_POST['f_' . $k] ?? $_GET[$k] ?? '');
    redirect('registrations', array_filter($keep, fn($v) => $v !== ''));
};

/** Shu test ro'yxatiga hali kiritilmagan o'quvchilar uchun WHERE va parametrlar (filtr: guruh, markaz, qidiruv) */
$unregSql = function (string $g, string $c, string $s) use ($tid): array {
    $w = ['s.archived_at IS NULL', 'NOT EXISTS (SELECT 1 FROM test_registrations r WHERE r.test_id=? AND r.student_id=s.id)']; $p = [$tid];
    if ($g === '@none') $w[] = "s.group_name=''";
    elseif ($g !== '') { $w[] = 's.group_name=?'; $p[] = $g; }
    if ($c === 'own') $w[] = 's.center_id IS NULL';
    elseif ($c !== '') { $w[] = 's.center_id=?'; $p[] = (int)$c; }
    if ($s !== '') { [$sw, $sp] = student_search_sql($s); $w[] = $sw; $p = array_merge($p, $sp); }
    return [implode(' AND ', $w), $p];
};

if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    $fin = can_finance();
    // 2.5: qo'shish — yagona qoida (mock_register): pullik MOCK da admin tanlagan to'lov usuli bilan
    $payMode = (string)($_POST['pay'] ?? 'auto');
    if (!in_array($payMode, $fin ? ['auto', 'unpaid', 'cash', 'waive'] : ['auto', 'unpaid'], true)) $payMode = 'auto';
    $payNote = '';
    $addIds = function (array $ids) use ($tid, $payMode, &$payNote): int {
        $c = ['paid' => 0, 'unpaid' => 0, 'waived' => 0];
        $n = 0;
        foreach ($ids as $sid) {
            try { $r = mock_register((int)$sid, $tid, 'admin', ['pay' => $payMode, 'force' => true]); }
            catch (Throwable $ex) { error_log('[MOCK reg-add] ' . $ex->getMessage()); continue; }   // bittasidagi xato qolganlarini to'xtatmasin
            if (!$r['ok'] || $r['status'] === 'exists') continue;
            $n++;
            if (isset($c[$r['status']])) $c[$r['status']]++;
        }
        $payNote = ($c['paid'] ? ", to'langan: " . $c['paid'] : '') . ($c['unpaid'] ? ", band (to'lov kutilmoqda): " . $c['unpaid'] : '') . ($c['waived'] ? ', imtiyoz: ' . $c['waived'] : '');
        return $n;
    };
    if ($act === 'remove') {
        $r = mock_cancel((int)$_POST['sid'], $tid, 'admin', ['refund' => !($fin && !empty($_POST['norefund']))]);
        if (!$r['ok']) flash($r['error'], 'err');
        elseif ($r['refund'] > 0) flash('Ro\'yxatdan chiqarildi, ' . som($r['refund']) . ' hamyoniga qaytarildi', 'warn');
    }
    if ($act === 'pay' && $fin) {
        if (($_POST['op'] ?? '') === 'uncash') {   // 2.5.4: xato qo'yilgan naqd belgisini bekor qilish
            $r = mock_admin_uncash((int)$_POST['sid'], $tid);
            flash($r['ok'] ? 'Naqd to\'lov belgisi bekor qilindi' . ($r['status'] === 'unpaid' ? ' — o\'quvchi yana «band» (to\'lov kutilmoqda)' : '') : $r['error'], $r['ok'] ? 'warn' : 'err');
        } else {
            $r = mock_admin_pay((int)$_POST['sid'], $tid, (string)($_POST['op'] ?? ''), (string)($_POST['note'] ?? ''), null, isset($_POST['expect']) && $_POST['expect'] !== '' ? (int)$_POST['expect'] : null);
            $who = $r['ok'] ? (string)val('SELECT full_name FROM students WHERE id=?', [(int)$_POST['sid']]) : '';
            flash($r['ok'] ? (['paid' => !empty($r['cash']) ? 'Naqd to\'lov yozildi' : 'To\'lov yozildi', 'waived' => 'Imtiyoz berildi (bepul)', 'unpaid' => 'To\'lov talab qilindi — o\'quvchi to\'lagach qatnashadi'][$r['status']] ?? 'Saqlandi') . ($who !== '' ? ': ' . $who : '')
                . (!empty($r['seat']['room']) && !empty($r['seat']['new']) ? ' · ' . $r['seat']['room'] . ', ' . (int)$r['seat']['seat'] . '-o\'rin' : '') : $r['error'], $r['ok'] ? 'ok' : 'err');
        }
    }
    if ($act === 'room_printed') {   // 2.5.4: xona varaqlari chop etildi (PDF yuklab olib chop etilganda)
        $n = q('UPDATE test_registrations SET printed_at=NOW() WHERE test_id=? AND room_id=? AND pay_status<>"unpaid" AND printed_at IS NULL', [$tid, (int)$_POST['rid']])->rowCount();
        flash($n . ' ta varaq "chop etilgan" deb belgilandi');
    }
    if ($act === 'toggle') {
        q('UPDATE tests SET reg_open=1-reg_open WHERE id=?', [$tid]);
        if ((int)$test['reg_open'] === 1) {   // yopildi — to'lanmagan bandlar bekor
            $nx = mock_expire_unpaid($tid);
            if ($nx) flash('Ro\'yxat yopildi: ' . $nx . ' ta to\'lanmagan band bekor qilindi', 'warn');
        }
    }
    if ($act === 'add') {
        // Telefon orqali yoki markazga kelib ro'yxatdan o'tganlar: admin ID bo'yicha qo'shadi (ro'yxat yopiq bo'lsa ham)
        $ids = []; $miss = [];
        foreach (preg_split('/[\s,;]+/', (string)($_POST['codes'] ?? ''), -1, PREG_SPLIT_NO_EMPTY) as $code) {
            $sid = val('SELECT id FROM students WHERE code=? AND archived_at IS NULL', [preg_replace('/\D/', '', $code)]);
            if ($sid) $ids[] = $sid; else $miss[] = $code;
        }
        $n = $addIds($ids);
        flash("Qo'shildi: $n" . $payNote . ($miss ? '. Topilmagan ID: ' . implode(', ', array_slice($miss, 0, 10)) : ''), $miss ? 'warn' : 'ok');
    }
    if ($act === 'add_group') {
        $g = trim((string)($_POST['group'] ?? ''));
        if ($g === '') { flash('Guruh tanlanmagan', 'warn'); $back(); }
        if ($g === '@all') { $ids = array_column(rows('SELECT id FROM students WHERE archived_at IS NULL'), 'id'); $from = "Barcha o'quvchilardan"; }
        elseif ($g === '@none') { $ids = array_column(rows("SELECT id FROM students WHERE group_name='' AND archived_at IS NULL"), 'id'); $from = 'Guruhsizlardan'; }
        else { $ids = array_column(rows('SELECT id FROM students WHERE group_name=? AND archived_at IS NULL', [$g]), 'id'); $from = "\"$g\" guruhidan"; }
        $n = $addIds($ids);
        flash("$from $n ta o'quvchi qo'shildi" . $payNote . (count($ids) > $n ? ' (' . (count($ids) - $n) . ' tasi avval ro\'yxatda edi)' : ''));
    }
    if ($act === 'add_sel') {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
        if (!$ids) flash('O\'quvchi tanlanmagan', 'warn');
        else { $n = $addIds($ids); flash($n . " ta o'quvchi ro'yxatga qo'shildi" . $payNote); }
    }
    if ($act === 'add_filter') {
        [$w, $p] = $unregSql((string)($_POST['f_ng'] ?? ''), (string)($_POST['f_nc'] ?? ''), trim((string)($_POST['f_ns'] ?? '')));
        $n = $addIds(array_column(rows("SELECT s.id FROM students s WHERE $w", $p), 'id'));
        flash("$n ta o'quvchi ro'yxatga qo'shildi" . $payNote);
    }
    // --- Xonalar ---
    if ($act === 'room_add') {
        $name = mb_substr(trim((string)($_POST['name'] ?? '')), 0, 60);
        $cap = max(1, min(500, (int)($_POST['capacity'] ?? 30)));
        $cnt = max(1, min(50, (int)($_POST['count'] ?? 1)));
        $sort = (int)val('SELECT COALESCE(MAX(sort),0) FROM test_rooms WHERE test_id=?', [$tid]);
        for ($i = 1; $i <= $cnt; $i++) {
            $nm = $cnt > 1 || $name === '' ? ($name !== '' ? "$name-$i" : ($sort + 1) . '-xona') : $name;
            q('INSERT INTO test_rooms (test_id, name, capacity, sort) VALUES (?,?,?,?)', [$tid, $nm, $cap, ++$sort]);
        }
        flash($cnt > 1 ? "$cnt ta xona qo'shildi" : 'Xona qo\'shildi');
    }
    if ($act === 'room_preset') {
        $n = center_rooms_apply($tid);
        flash($n ? "Markaz xonalaridan $n ta qo'shildi. Endi «Joylashtirish» ni bosing." : 'Markaz xonalari allaqachon qo\'shilgan', $n ? 'ok' : 'warn');
    }
    if ($act === 'room_edit') {
        $rid = (int)$_POST['rid'];
        $cap = max(1, min(500, (int)($_POST['capacity'] ?? 30)));
        $used = (int)val('SELECT MAX(seat) FROM test_registrations WHERE test_id=? AND room_id=?', [$tid, $rid]);
        if ($cap < $used) flash("Sig'imni $used dan kamaytirib bo'lmaydi — avval o'quvchilarni boshqa xonaga o'tkazing yoki qaytadan taqsimlang", 'err');
        else q('UPDATE test_rooms SET name=?, capacity=?, proctor=? WHERE id=? AND test_id=?', [mb_substr(trim((string)$_POST['name']), 0, 60) ?: 'Xona', $cap, mb_substr(trim((string)($_POST['proctor'] ?? '')), 0, 120), $rid, $tid]);
    }
    if ($act === 'room_del') {
        $rid = (int)$_POST['rid'];
        q('UPDATE test_registrations SET room_id=NULL, seat=NULL WHERE test_id=? AND room_id=?', [$tid, $rid]);
        q('DELETE FROM test_rooms WHERE id=? AND test_id=?', [$rid, $tid]);
        flash('Xona o\'chirildi, undagi o\'quvchilar xonasiz qoldi', 'warn');
    }
    if ($act === 'distribute') {
        $ord = in_array($_POST['order'] ?? '', ['name', 'school', 'group', 'time', 'random', 'mix'], true) ? $_POST['order'] : 'name';
        $seedIn = trim((string)($_POST['seed'] ?? ''));
        [$done, $left, $seed] = distribute_rooms($tid, ($_POST['mode'] ?? 'new') === 'all' ? 'all' : 'new', $ord, !empty($_POST['balance']), $seedIn !== '' ? (int)$seedIn : null);
        flash("$done ta o'quvchi xonalarga joylashtirildi" . (in_array($ord, ['random', 'mix'], true) ? " (seed: $seed — shu raqam bilan bir xil joylashuvni qayta olish mumkin)" : '') . ($left ? ". $left tasiga joy yetmadi — xona qo'shing yoki sig'imni oshiring" : ''), $left ? 'warn' : 'ok');
    }
    if ($act === 'notify_rooms') {
        if (!tg_ready() && !sms_ready()) flash('Xabar yuborish uchun Telegram bot yoki Eskiz SMS ulanmagan (Sozlamalar)', 'err');
        else {
            $n = room_notify_queue($tid, isset($_POST['resend']));
            if ($n['bot'] + $n['sms'] > 0) tg_tick(20);
            flash('Xona va o\'rin xabari navbatga qo\'yildi: Telegram ' . $n['bot'] . ', SMS ' . $n['sms'] . ($n['none'] ? '; yetkazib bo\'lmaydi (bot ham, telefon ham yo\'q): ' . $n['none'] : ''), ($n['bot'] + $n['sms']) ? 'ok' : 'warn');
        }
    }
    if ($act === 'move') {
        if (!move_to_room($tid, (int)$_POST['sid'], (int)$_POST['room'])) flash('Bu xonada bo\'sh o\'rin yo\'q', 'err');
    }
    // --- Belgilanganlar bilan ---
    if ($act === 'mass') {
        $ids = array_map('intval', (array)($_POST['ids'] ?? []));
        $op = $_POST['op'] ?? '';
        if (!$ids) flash('O\'quvchi tanlanmagan', 'warn');
        else {
            $in = implode(',', array_fill(0, count($ids), '?'));
            if ($op === 'room') {
                $full = 0; foreach ($ids as $sid) if (!move_to_room($tid, $sid, (int)($_POST['to_room'] ?? 0))) $full++;
                flash(count($ids) - $full . ' ta o\'quvchi ko\'chirildi' . ($full ? ", $full tasiga joy yetmadi" : ''), $full ? 'warn' : 'ok');
            } elseif ($op === 'printed') {
                q("UPDATE test_registrations SET printed_at=NOW() WHERE test_id=? AND student_id IN ($in)", array_merge([$tid], $ids));
                flash(count($ids) . ' ta varaq "chop etilgan" deb belgilandi');
            } elseif ($op === 'unprinted') {
                q("UPDATE test_registrations SET printed_at=NULL WHERE test_id=? AND student_id IN ($in)", array_merge([$tid], $ids));
                flash(count($ids) . ' ta varaq qayta chop etish uchun belgilandi');
            } elseif ($op === 'remove' || ($op === 'remove_keep' && $fin)) {
                $n = 0; $sum = 0;
                foreach ($ids as $sid) { $r = mock_cancel($sid, $tid, 'admin', ['refund' => $op === 'remove']); if ($r['ok']) { $n++; $sum += (int)$r['refund']; } }
                flash($n . ' ta o\'quvchi ro\'yxatdan chiqarildi' . ($sum ? ', hamyonlariga qaytarildi: ' . som($sum) : ''), 'warn');
            } elseif (in_array($op, ['cash', 'wallet', 'waive', 'unpaid'], true) && $fin) {
                $ok = 0; $errs = [];
                foreach ($ids as $sid) {
                    try { $r = mock_admin_pay($sid, $tid, $op); } catch (Throwable $ex) { error_log('[MOCK reg-pay] ' . $ex->getMessage()); $r = ['ok' => false, 'error' => 'ichki xato']; }
                    if ($r['ok']) $ok++; else $errs[$r['error']] = ($errs[$r['error']] ?? 0) + 1;
                }
                $msg = $ok . ' ta: ' . ['cash' => 'naqd to\'lov yozildi', 'wallet' => 'hamyondan yechildi', 'waive' => 'imtiyoz berildi', 'unpaid' => 'to\'lov talab qilindi'][$op];
                foreach (array_slice($errs, 0, 3, true) as $er => $k) $msg .= '; ' . $k . ' tasi — ' . $er;
                flash($msg, $errs ? 'warn' : 'ok');
            }
        }
    }
    $back();
}

$rooms = test_rooms($tid);
// Ro'yxat filtri — shu filtr chop etishga ham o'tadi (ro'yxatda nima ko'rinsa, o'sha chop etiladi, o'sha tartibda)
$fRoom = (string)($_GET['room'] ?? '');
$fPr = in_array($_GET['pr'] ?? '', ['new', 'done'], true) ? $_GET['pr'] : '';
$fQ = trim((string)($_GET['q'] ?? ''));
$fG = (string)($_GET['fg'] ?? '');
$fC = (string)($_GET['fc'] ?? '');
$fO = in_array($_GET['o'] ?? '', ['room', 'name', 'school', 'time'], true) ? $_GET['o'] : ($rooms ? 'room' : 'name');
$fP = isset(REG_PAY_LABEL[$_GET['fp'] ?? '']) ? (string)$_GET['fp'] : '';
$fV = in_array($_GET['fv'] ?? '', ['self', 'bot', 'web', 'admin'], true) ? (string)$_GET['fv'] : '';   // 2.5.4: qayerdan yozilgan
$fD = (string)($_GET['fd'] ?? '');                                                                       // 2.5.4: qachon
if (!in_array($fD, ['today', 'old'], true) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fD)) $fD = '';
wallet_tick(true);
$price = mock_price($test);
$fin = can_finance();
$allPay = reg_students($tid, ['order' => $fO, 'pay' => 'all']);
$all = array_values(array_filter($allPay, fn($s) => $s['pay_status'] !== 'unpaid'));   // joy, varaq, xabar — to'lanmagan bandlarsiz
$list = reg_students($tid, ['room' => $fRoom, 'only' => $fPr, 'q' => $fQ, 'group' => $fG, 'center' => $fC, 'order' => $fO, 'pay' => $fP !== '' ? $fP : 'all', 'via' => $fV, 'day' => $fD]);
$filtered = $fRoom !== '' || $fPr !== '' || $fQ !== '' || $fG !== '' || $fC !== '' || $fP !== '' || $fV !== '' || $fD !== '';
$payCnt = ['free' => 0, 'paid' => 0, 'unpaid' => 0, 'waived' => 0];
$income = 0;
$cashN = 0; $cashSum = 0;
$viaCnt = ['bot' => 0, 'web' => 0, 'admin' => 0]; $dayCnt = [];   // 2.5.4: qayerdan va qachon yozilgan
foreach ($allPay as $s) {
    $payCnt[$s['pay_status']] = ($payCnt[$s['pay_status']] ?? 0) + 1;
    if ($s['pay_status'] === 'paid') { $income += (int)$s['paid_amount']; if ($s['pay_method'] === 'cash') { $cashN++; $cashSum += (int)$s['paid_amount']; } }
    $v = (string)$s['via'];
    $viaCnt[$v === 'bot' ? 'bot' : (in_array($v, ['web', 'register'], true) ? 'web' : 'admin')]++;
    $d = substr((string)$s['reg_at'], 0, 10);
    $dayCnt[$d] = ($dayCnt[$d] ?? 0) + 1;
}
krsort($dayCnt);
$today = date('Y-m-d');
$nToday = (int)($dayCnt[$today] ?? 0);
$showPay = $price > 0 || $payCnt['paid'] + $payCnt['unpaid'] + $payCnt['waived'] > 0;
$nExpiring = $test['reg_open'] ? mock_unpaid_count($tid, true) : 0;
// Ro'yxatdagilarning guruhlari (filtr uchun, soni bilan)
$regGroups = [];
foreach ($allPay as $s) $regGroups[$s['group_name']] = ($regGroups[$s['group_name']] ?? 0) + 1;
ksort($regGroups);
$regNone = (int)($regGroups[''] ?? 0);   // 2.5.2: ro'yxatdagi guruhsizlar — «Guruhsiz: N» belgisi
// «Guruhsiz: N» belgisi: bosilsa — shu filtr yoqiladi/o'chadi (boshqa filtrlar saqlanadi)
$noneChipUrl = url('registrations', ['id' => $tid] + array_filter(['room' => $fRoom, 'pr' => $fPr, 'q' => $fQ, 'fc' => $fC, 'fp' => $fP, 'fv' => $fV, 'fd' => $fD, 'o' => $fO !== ($rooms ? 'room' : 'name') ? $fO : ''], fn($v) => $v !== '') + ($fG === '@none' ? [] : ['fg' => '@none'])) . '#regList';
$resp = [];
foreach (rows('SELECT student_id, status FROM responses WHERE test_id=?', [$tid]) as $r) $resp[(int)$r['student_id']] = $r['status'];
$N = count($all);
$nPrinted = count(array_filter($all, fn($s) => $s['printed_at']));
$nPlaced = count(array_filter($all, fn($s) => $s['room_id']));
$seats = array_sum(array_map(fn($r) => (int)$r['capacity'], $rooms));
// Guruhlar: jami o'quvchi (n) va shu ro'yxatga hali kiritilmaganlar (free)
$gstat = rows('SELECT s.group_name g, COUNT(*) n, SUM(r.student_id IS NULL) free FROM students s
               LEFT JOIN test_registrations r ON r.test_id=? AND r.student_id=s.id WHERE s.archived_at IS NULL GROUP BY s.group_name ORDER BY s.group_name', [$tid]);
$nStudents = (int)array_sum(array_column($gstat, 'n'));
$freeAll = (int)array_sum(array_column($gstat, 'free'));
$groups = array_values(array_filter($gstat, fn($g) => $g['g'] !== ''));
$noGroup = current(array_filter($gstat, fn($g) => $g['g'] === '')) ?: null;
$gLabel = fn(int $free) => $free ? "(+$free)" : '✓';   // +N — qo'shiladiganlar soni, ✓ — hammasi ro'yxatda
$centers = centers_list();
// Ro'yxatga kiritilmaganlar bo'limi
$nf = ['g' => (string)($_GET['ng'] ?? ''), 'c' => (string)($_GET['nc'] ?? ''), 's' => trim((string)($_GET['ns'] ?? ''))];
[$uw, $up] = $unregSql($nf['g'], $nf['c'], $nf['s']);
$unTotal = (int)val("SELECT COUNT(*) FROM students s WHERE $uw", $up);
$unList = rows("SELECT s.id, s.code, s.full_name, s.group_name, s.center_id, s.school, s.grade_level, s.phone FROM students s WHERE $uw ORDER BY s.full_name LIMIT 500", $up);
$unFiltered = $nf['g'] !== '' || $nf['c'] !== '' || $nf['s'] !== '';
// 2.5.4: o'zi ochilib turadi faqat ro'yxat butunlay bo'sh bo'lsa (avval «band»lar hisobga olinmasdi — hamma to'lanmagan bo'lsa,
// bazadagi barcha o'quvchilar ro'yxatdagidek ko'rinib, chalg'itardi)
$unOpen = $unFiltered || !empty($_GET['un']) || (count($allPay) === 0 && $freeAll > 0);
$link = app_base_url() . 'index.php?' . http_build_query(['p' => 'register', 'test' => $tid]);
$sheetUrl = fn(array $p) => url('sheet', ['id' => $tid, 'group' => '@reg'] + $p);
// Joriy filtr bo'yicha varaqlar (ro'yxatdagi tartibda)
$filterSheetUrl = $sheetUrl(array_filter(['room' => $fRoom, 'only' => $fPr, 'q' => $fQ, 'fg' => $fG, 'fc' => $fC, 'fv' => $fV, 'fd' => $fD, 'order' => $fO], fn($v) => $v !== ''));

// Pullik MOCK: qo'shish formalaridagi to'lov tanlovi
$paySel = function () use ($price, $fin): string {
    if ($price <= 0) return '';
    $o = ['auto' => 'To\'lov: hamyondan', 'unpaid' => 'To\'lov: band', ] + ($fin ? ['cash' => 'To\'lov: naqd olindi', 'waive' => 'To\'lov: imtiyoz'] : []);
    $h = '<select name="pay" aria-label="To\'lov" title="Pullik MOCK (' . e(som($price)) . '). Hamyondan — balans yetsa yechiladi, yetmasa band qilinadi; band — to\'lov kutiladi; naqd — kirim va yechim yoziladi; imtiyoz — bepul">';
    foreach ($o as $k => $v) $h .= '<option value="' . $k . '">' . e($v) . '</option>';
    return $h . '</select>';
};
$nAllPay = count($allPay);
page_header('Ro\'yxat — ' . $test['title']);
test_tabs($test, 'registrations');
?>
<div class="stats4 reg-kpi" id="regKpi">
  <div class="stat"><span><?= $nAllPay ?></span>Ro'yxatda<?= $payCnt['unpaid'] ? '<small class="warn-txt">' . $payCnt['unpaid'] . ' tasi band (to\'lanmagan)</small>' : '' ?></div>
  <div class="stat"><span><?= $rooms ? "$nPlaced / $N" : '—' ?></span>Xonaga joylashgan</div>
  <div class="stat"><span><?= $rooms ? $seats : '—' ?></span>Jami o'rin<?= $rooms && $seats < $N ? ' <b class="warn-txt">· yetmaydi</b>' : '' ?></div>
  <div class="stat"><span><?= $nPrinted ?> / <?= $N ?></span>Varaq chop etilgan</div>
</div>
<?php if ($showPay): ?>
<div class="pay-strip" id="payStrip">
  <span><?= icon('wallet', 15) ?>Narxi: <b><?= e(mock_price_label($test)) ?></b></span>
  <a href="<?= e(url('registrations', ['id' => $tid, 'fp' => 'paid'])) ?>#regList">To'lagan: <b><?= $payCnt['paid'] ?></b><?= $cashN ? ' <span class="muted">(naqd: ' . $cashN . ')</span>' : '' ?></a>
  <a href="<?= e(url('registrations', ['id' => $tid, 'fp' => 'unpaid'])) ?>#regList" class="<?= $payCnt['unpaid'] ? 'warn-txt' : '' ?>">Band (to'lanmagan): <b><?= $payCnt['unpaid'] ?></b></a>
  <?php if ($payCnt['waived']): ?><a href="<?= e(url('registrations', ['id' => $tid, 'fp' => 'waived'])) ?>#regList">Imtiyoz: <b><?= $payCnt['waived'] ?></b></a><?php endif; ?>
  <?php if ($payCnt['free'] && $price > 0): ?><a href="<?= e(url('registrations', ['id' => $tid, 'fp' => 'free'])) ?>#regList" title="Narx qo'yilishidan oldin yozilganlar — qatnasha oladi">Bepul yozilgan: <b><?= $payCnt['free'] ?></b></a><?php endif; ?>
  <span>Tushum: <b><?= e(som($income)) ?></b><?= $cashSum ? ' <span class="muted">· naqd ' . e(som($cashSum)) . '</span>' : '' ?></span>
  <?php if ($payCnt['unpaid']): ?><span class="small muted">Band qilinganlar xonaga joylanmaydi, varaq va xabar olmaydi<?= $test['online'] ? ', onlayn testni boshlay olmaydi' : '' ?>.</span><?php endif; ?>
</div>
<?php endif; ?>
<?php if ($nAllPay): $fu = fn(array $f) => e(url('registrations', ['id' => $tid] + $f)) . '#regList'; ?>
<div class="src-strip" id="srcStrip" title="Ro'yxatga kim va qachon qo'shilgan — bosilsa, faqat o'shalar ko'rinadi">
  <span class="muted">Qayerdan:</span>
  <?php foreach (['bot' => 'Bot orqali', 'web' => 'Sayt orqali', 'admin' => 'Admin qo\'shgan'] as $k => $lbl): if (!$viaCnt[$k]) continue; ?>
    <a href="<?= $fu(['fv' => $k]) ?>" class="<?= $fV === $k ? 'on' : '' ?>"><?= $lbl ?>: <b><?= $viaCnt[$k] ?></b></a>
  <?php endforeach; ?>
  <span class="src-sep" aria-hidden="true"></span>
  <span class="muted">Qachon:</span>
  <a href="<?= $fu(['fd' => 'today']) ?>" class="<?= $fD === 'today' ? 'on' : '' ?>">Bugun: <b><?= $nToday ?></b></a>
  <?php if ($nAllPay > $nToday): ?><a href="<?= $fu(['fd' => 'old']) ?>" class="<?= $fD === 'old' ? 'on' : '' ?>">Bugungacha: <b><?= $nAllPay - $nToday ?></b></a><?php endif; ?>
</div>
<?php endif; ?>

<div class="reg-flow">
  <!-- 1. Ro'yxat -->
  <section class="card reg-step <?= $N ? 'ok' : 'now' ?>">
    <div class="rs-h"><span class="rs-n">1</span><div><h2>Ro'yxat</h2><p class="small muted"><?= $nAllPay ? "<b>$nAllPay</b> kishi ro'yxatda" . ($payCnt['unpaid'] ? ' (band: ' . $payCnt['unpaid'] . ')' : '') : 'Hali hech kim yo\'q' ?><?= $test['reg_open'] ? ' · onlayn ro\'yxat <b>ochiq</b>' : '' ?></p></div></div>
    <?php if ($nStudents && $freeAll): ?>
    <?php /* 2.5.4: guruh oldindan tanlanmaydi (avval birinchi guruh — ko'pincha «Guruhsizlar», ya'ni bot orqali kelganlarning hammasi —
             tanlangan turardi va «Qo'shish» bir bosishda hammani qo'shib yuborardi); har qanday guruhni qo'shishdan oldin soni bilan so'raladi */ ?>
    <form method="post" class="row gap filter add-row" onsubmit="var o=this.group.selectedOptions[0]; return !!(o && o.value) && confirm(o.dataset.ask)"><?= csrf_field() ?><input type="hidden" name="action" value="add_group">
      <select name="group" aria-label="Guruh" class="grow" required>
        <option value="" selected disabled>Guruhni qo'shish — tanlang…</option>
        <?php foreach ($groups as $g): if (!(int)$g['free']) continue; ?><option value="<?= e($g['g']) ?>" data-ask="<?= e('«' . $g['g'] . '» guruhidan ' . (int)$g['free'] . ' ta o\'quvchi shu MOCK ro\'yxatiga qo\'shilsinmi?') ?>"><?= e($g['g']) ?> — +<?= (int)$g['free'] ?> kishi</option><?php endforeach; ?>
        <?php if ($noGroup && (int)$noGroup['free']): ?><option value="@none" data-ask="<?= e('Guruhsiz ' . (int)$noGroup['free'] . ' ta o\'quvchi (bot va saytda ro\'yxatdan o\'tganlar shu yerda) shu MOCK ro\'yxatiga qo\'shilsinmi?') ?>">Guruhsizlar — +<?= (int)$noGroup['free'] ?></option><?php endif; ?>
        <option value="@all" data-ask="<?= e('DIQQAT: bazadagi BARCHA faol o\'quvchilar (' . $freeAll . ' ta) shu MOCK ro\'yxatiga qo\'shilsinmi?') ?>">Barcha o'quvchilar — +<?= $freeAll ?></option>
      </select>
      <?= $paySel() ?>
      <button class="btn primary">Qo'shish</button></form>
    <?php elseif ($nStudents): ?><p class="small muted">Barcha faol o'quvchilar ro'yxatda ✓</p>
    <?php else: ?><p class="small muted">Bazada o'quvchi yo'q — <a href="<?= e(url('students')) ?>">O'quvchilar</a> sahifasida qo'shing.</p><?php endif; ?>
    <details class="rs-more"><summary>ID bo'yicha yoki tanlab qo'shish</summary>
      <form method="post" class="form"><?= csrf_field() ?><input type="hidden" name="action" value="add">
        <label>ID lar <textarea name="codes" rows="2" class="mono" placeholder="545742, 929446 …"></textarea></label>
        <div class="row gap wrap center-v"><?= $paySel() ?><button class="btn sm">Qo'shish</button></div></form>
      <?php if ($freeAll): ?><p class="small"><a href="#unreg" onclick="document.getElementById('unreg').open=true">Ro'yxatga kiritilmaganlardan belgilab qo'shish (<?= $freeAll ?>) ↓</a></p><?php endif; ?>
    </details>
    <details class="rs-more"><summary>Onlayn ro'yxatdan o'tish (havola) — <?= $test['reg_open'] ? 'ochiq' : 'yopiq' ?></summary>
      <form method="post"<?= $nExpiring ? ' onsubmit="return confirm(' . e(json_encode('Ro\'yxat yopilsa, to\'lanmagan ' . $nExpiring . ' ta band bekor bo\'ladi (kutilayotgan cheki borlar chek ko\'rib chiqilguncha qoladi). Davom etasizmi?', JSON_UNESCAPED_UNICODE)) . ')"' : '' ?>><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><button class="btn sm <?= $test['reg_open'] ? 'ghost' : '' ?>"><?= $test['reg_open'] ? 'Ro\'yxatni yopish' : 'Ro\'yxatni ochish' ?></button></form>
      <p class="small muted">Ochiq bo'lsa, o'quvchilar shu havola orqali o'zi yoziladi:</p>
      <input class="mono small copy-in" readonly value="<?= e($link) ?>" onclick="this.select()" aria-label="Ro'yxatdan o'tish havolasi">
    </details>
  </section>

  <!-- 2. Xonalar -->
  <section class="card reg-step <?= $rooms ? ($seats >= $N ? 'ok' : 'warn') : ($N ? 'now' : '') ?>">
    <?php $autoSeat = seat_auto_on() && !(int)$test['online']; /* 2.5.2: to'lov tasdiqlanganda o'rin avtomatik */ ?>
    <div class="rs-h"><span class="rs-n">2</span><div><h2>Xonalar</h2><p class="small muted"><?= $rooms ? count($rooms) . ' ta xona · ' . $seats . ' o\'rin' . ($seats < $N ? ' — <b class="warn-txt">' . ($N - $seats) . ' o\'rin yetmaydi</b>' : '') . ($autoSeat ? ' · to\'lov tasdiqlanganda o\'rin avtomatik beriladi' : '') : ($autoSeat ? 'Xonalar kiritilmagan — qo\'shsangiz, to\'lov tasdiqlanganda o\'rin avtomatik beriladi va o\'quvchiga botda yuboriladi' : 'Xonalar kiritilmagan (bitta xonada o\'tsa — shart emas)') ?></p></div></div>
    <?php if ($rooms): ?>
      <div class="room-rows">
        <?php foreach ($rooms as $r): $full = (int)$r['used'] >= (int)$r['capacity']; ?>
          <div class="room-row">
            <form method="post" class="room-edit filter"><?= csrf_field() ?><input type="hidden" name="action" value="room_edit"><input type="hidden" name="rid" value="<?= (int)$r['id'] ?>">
              <input name="name" value="<?= e($r['name']) ?>" maxlength="60" aria-label="Xona nomi">
              <input name="capacity" type="number" min="1" max="500" value="<?= (int)$r['capacity'] ?>" class="num-in" aria-label="Sig'im" title="Sig'im">
              <input name="proctor" value="<?= e($r['proctor']) ?>" maxlength="120" placeholder="Nazoratchi" aria-label="Nazoratchi" title="Nazoratchi (xona ro'yxatida va o'quvchi kabinetida ko'rinadi)">
              <button class="btn sm ghost" title="Saqlash"><?= icon('check', 14) ?></button>
            </form>
            <span class="room-used <?= $full ? 'warn-txt' : '' ?>" title="Band o'rinlar"><?= (int)$r['used'] ?>/<?= (int)$r['capacity'] ?></span>
            <form method="post" onsubmit="return confirm('Xona o\'chirilsinmi? Undagi o\'quvchilar xonasiz qoladi.')"><?= csrf_field() ?><input type="hidden" name="action" value="room_del"><input type="hidden" name="rid" value="<?= (int)$r['id'] ?>"><button class="btn sm danger-ghost" title="O'chirish">×</button></form>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <?php $cr = center_rooms(); $crNew = array_filter($cr, function ($c) use ($rooms) { foreach ($rooms as $r) if (mb_strtolower($r['name']) === mb_strtolower($c['name'])) return false; return true; }); ?>
    <?php if ($crNew): ?>
      <form method="post" class="mt"><?= csrf_field() ?><input type="hidden" name="action" value="room_preset">
        <button class="btn <?= $rooms ? '' : 'primary' ?> wide">Markaz xonalarini qo'shish — <?= count($crNew) ?> ta, <?= array_sum(array_map(fn($c) => (int)$c['capacity'], $crNew)) ?> o'rin</button></form>
    <?php elseif (!$cr): ?>
      <p class="small muted mt">Markaz xonalarini bir marta <a href="<?= e(url('settings')) ?>#xonalar">Sozlamalar → Xonalar va sig'im</a> da kiriting — keyin har MOCK ga bir bosishda qo'shiladi.</p>
    <?php endif; ?>
    <details class="rs-more" <?= !$rooms && !$cr ? 'open' : '' ?>><summary>Boshqa xona qo'shish</summary>
      <form method="post" class="form room-add"><?= csrf_field() ?><input type="hidden" name="action" value="room_add">
        <div class="grid3">
          <label>Nomi <input name="name" maxlength="60" placeholder="12-xona"></label>
          <label>Sig'im <input name="capacity" type="number" min="1" max="500" value="30"></label>
          <label>Soni <input name="count" type="number" min="1" max="50" value="1" title="Bir nechta bir xil xona qo'shish"></label>
        </div>
        <button class="btn sm">Qo'shish</button>
      </form>
    </details>
  </section>

  <!-- 3. Joylashtirish -->
  <section class="card reg-step <?= !$rooms ? 'off' : ($nPlaced === $N && $N ? 'ok' : ($N ? 'now' : '')) ?>">
    <div class="rs-h"><span class="rs-n">3</span><div><h2>Xonalarga joylashtirish</h2><p class="small muted"><?= !$rooms ? 'Avval xona qo\'shing' : ($N ? "Joylashgan: <b>$nPlaced / $N</b>" . ($nPlaced < $N ? ' · xonasiz: <b>' . ($N - $nPlaced) . '</b>' : ' ✓') : 'Ro\'yxat bo\'sh') ?></p></div></div>
    <?php if ($rooms && $N): ?>
    <form method="post" class="form dist-form"><?= csrf_field() ?><input type="hidden" name="action" value="distribute"><input type="hidden" name="balance" value="1">
      <label>Qanday o'tqazilsin
        <select name="order"><option value="mix">Aralash — bir guruh/maktab yonma-yon o'tirmaydi (tavsiya)</option><option value="name">Alifbo bo'yicha</option><option value="random">Tasodifiy</option><option value="group">Guruh bo'yicha</option><option value="school">Maktab / sinf bo'yicha</option><option value="time">Ro'yxatdan o'tish vaqti bo'yicha</option></select></label>
      <?php if ($nPlaced > 0): ?>
        <label class="check"><input type="radio" name="mode" value="new" checked> Faqat xonasizlarni joylash<?= $nPlaced < $N ? ' (' . ($N - $nPlaced) . ')' : '' ?></label>
        <label class="check"><input type="radio" name="mode" value="all"> Hammasini qaytadan joylash</label>
      <?php else: ?><input type="hidden" name="mode" value="new"><?php endif; ?>
      <details class="rs-more"><summary>Qo'shimcha</summary>
        <label>Seed <input name="seed" inputmode="numeric" maxlength="9" placeholder="bo'sh — yangi tasodifiy" title="Tasodifiy/aralash tartib uchun: bir xil raqam — bir xil joylashuv"></label>
        <p class="small muted">Xonalar teng to'ldiriladi (masalan 100 kishi, 3 xona: 34/33/33). Keyin istalgan o'quvchini pastdagi ro'yxatda boshqa xonaga o'tkazish mumkin.</p>
      </details>
      <button class="btn primary wide" onclick="var m=this.form.querySelector('input[name=mode]:checked'); return !m || m.value!=='all' || confirm('Barcha o\'rinlar qaytadan taqsimlanadi. Chop etilgan varaqlardagi va o\'quvchilarga yuborilgan xona/o\'rin eskiradi — keyin «Tasdiqlash va yuborish» bilan yangisini yuboring. Davom etasizmi?')">Joylashtirish</button>
    </form>
    <?php endif; ?>
  </section>

  <!-- 4. Tasdiqlash: chop etish va xabar -->
  <section class="card reg-step <?= $N && $nPrinted === $N ? 'ok' : ($N && (!$rooms || $nPlaced === $N) ? 'now' : '') ?>">
    <div class="rs-h"><span class="rs-n">4</span><div><h2>Tasdiqlash: varaqlar va xabar</h2><p class="small muted">Varaqda ism, ID<?= $rooms ? ', xona va o\'rin' : '' ?> yoziladi. Chop etilganlar belgilanadi.</p></div></div>
    <?php if ($N): ?>
    <div class="rs-actions">
      <?php if ($rooms): ?>
        <a class="btn primary" target="_blank" href="<?= e($sheetUrl(['order' => 'room', 'sep' => 1])) ?>" title="Xona → o'rin tartibida; har xona oldidan ajratuvchi varaq"><?= icon('print', 16) ?>Javoblar varaqalari — xonalar bo'yicha</a>
      <?php endif; ?>
      <a class="btn <?= $rooms ? '' : 'primary' ?>" target="_blank" href="<?= e($sheetUrl(['only' => 'new'] + ($rooms ? ['order' => 'room', 'sep' => 1] : []))) ?>"><?= icon('print', 16) ?>Faqat yangilar (<?= $N - $nPrinted ?>)</a>
      <?php if (!$rooms): ?><a class="btn" target="_blank" href="<?= e($sheetUrl([])) ?>">Hammasi (<?= $N ?>)</a>
        <a class="btn ghost" href="<?= e(url('room_pack', ['id' => $tid, 'fmt' => 'pdf', 'room' => 'all', 'what' => 'sheets'])) ?>" title="Barcha varaqlar bitta PDF faylda (printerga yoki boshqa kompyuterga)"><?= icon('download', 16) ?>PDF yuklab olish</a><?php endif; ?>
    </div>
    <?php if ($rooms): ?><p class="small"><a href="#rpBox">Har xona alohida chop etish va PDF yuklab olish — «Xonalar bo'yicha» ↓</a></p><?php endif; ?>
    <?php if ($rooms && $nPlaced > 0): $np = room_notify_plan($tid, false); $canSend = tg_ready() || sms_ready(); $toSend = count($np['bot']) + count($np['sms']); ?>
      <div class="rs-notify">
        <b>O'quvchilarga xona va o'rin xabari</b>
        <?php if (!$canSend): ?>
          <p class="small muted">Telegram bot yoki Eskiz SMS ulangach yuboriladi. <a href="<?= e(url('settings')) ?>#xabarlar">Sozlamalar →</a></p>
        <?php else: ?>
          <p class="small" style="margin:.2rem 0">Olgan: <b><?= $np['done'] ?></b> · yuboriladi: <b><?= count($np['bot']) ?></b> Telegram + <b><?= count($np['sms']) ?></b> SMS<?php if ($np['none']): ?> · <span class="warn-txt">yetkazib bo'lmaydi: <b><?= count($np['none']) ?></b></span><?php endif; ?></p>
          <div class="row gap wrap">
            <form method="post" onsubmit="return confirm('<?= $toSend ?> ta o\'quvchiga xona va o\'rin yuborilsinmi?<?= count($np['sms']) ? ' (SMS pullik: ' . count($np['sms']) . ' ta)' : '' ?>')"><?= csrf_field() ?><input type="hidden" name="action" value="notify_rooms"><button class="btn sm primary" <?= $toSend ? '' : 'disabled' ?>>Tasdiqlash va yuborish (<?= $toSend ?>)</button></form>
            <form method="post" onsubmit="return confirm('Hammasiga (avval olganlarga ham) qayta yuborilsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="notify_rooms"><input type="hidden" name="resend" value="1"><button class="btn sm ghost">Hammasiga qayta</button></form>
          </div>
        <?php endif; ?>
      </div>
    <?php endif; ?>
    <?php else: ?><p class="small muted">Ro'yxat bo'sh.</p><?php endif; ?>
  </section>
</div>

    <?php if ($rooms && $N): /* 2.5.4: xonalar bo'yicha — har xona alohida chop etish va yuklab olish (PDF), hammasi — ZIP / Excel */
    $rpUrl = fn(array $p) => url('room_pack', ['id' => $tid] + $p);
    $rpPr = []; foreach ($all as $x) if ($x['room_id'] && $x['printed_at']) $rpPr[(int)$x['room_id']] = ($rpPr[(int)$x['room_id']] ?? 0) + 1;
    $nNoRoom = $N - $nPlaced; ?>
  <section class="card rp-box" id="rpBox">
    <div class="rp-head">
      <div><h2 style="margin:0">Xonalar bo'yicha</h2><p class="small muted" style="margin:.15rem 0 0">Har xona — alohida chop etish yoki bitta PDF fayl (eshik va davomat ro'yxati, javoblar varaqalari o'rin tartibida)</p></div>
      <span class="rp-dl">
        <select id="rpWhat" aria-label="PDF ga nima kirsin" title="Yuklab olinadigan PDF tarkibi"><?php foreach (ROOM_PACK_WHAT as $k => $lbl): ?><option value="<?= $k ?>"><?= e($lbl) ?></option><?php endforeach; ?></select>
        <a class="btn sm" data-rp href="<?= e($rpUrl(['fmt' => 'zip'])) ?>" title="Har xona — alohida PDF fayl, hammasi bitta ZIP arxivda"><?= icon('download', 14) ?>Hamma xonalar (ZIP)</a>
        <a class="btn sm ghost" href="<?= e($rpUrl(['fmt' => 'xlsx'])) ?>" title="Excel: har xona — alohida varaq"><?= icon('download', 14) ?>Excel</a>
      </span>
    </div>
    <div class="table-wrap"><table class="tbl compact-tbl rp-tbl">
      <thead><tr><th>Xona</th><th class="num">Kishi</th><th class="num">Chop etilgan</th><th>Chop etish</th><th>Yuklab olish</th></tr></thead>
      <tbody>
      <?php foreach ($rooms as $r): $u = (int)$r['used']; $rid = (int)$r['id']; $pr = (int)($rpPr[$rid] ?? 0); ?>
        <tr>
          <td><b><?= e($r['name']) ?></b><?= $r['proctor'] !== '' ? '<div class="small muted">' . e($r['proctor']) . '</div>' : '' ?></td>
          <td class="num nowrap"><?= $u ?> / <?= (int)$r['capacity'] ?></td>
          <td class="num nowrap"><?= !$u ? '—' : ($pr >= $u ? '<span class="tag green">✓ ' . $pr . '</span>' : $pr . ' / ' . $u) ?></td>
          <td class="rp-acts"><?php if ($u): ?>
            <a class="btn sm ghost" target="_blank" href="<?= e($sheetUrl(['room' => $rid, 'order' => 'room', 'sep' => 1])) ?>" title="Shu xonaning javoblar varaqalari (o'rin tartibida)"><?= icon('print', 13) ?>Varaqlar</a>
            <a class="btn sm ghost" target="_blank" href="<?= e(url('room_list', ['id' => $tid, 'room' => $rid])) ?>" title="Davomat ro'yxati (imzo bilan)"><?= icon('print', 13) ?>Davomat</a>
            <a class="btn sm ghost" target="_blank" href="<?= e(url('room_door', ['id' => $tid, 'room' => $rid])) ?>" title="Xona eshigiga: o'rin → ism"><?= icon('print', 13) ?>Eshik</a>
          <?php else: ?><span class="small muted">bo'sh</span><?php endif; ?></td>
          <td class="rp-acts"><?php if ($u): ?>
            <a class="btn sm" data-rp href="<?= e($rpUrl(['fmt' => 'pdf', 'room' => $rid])) ?>" title="Shu xona — bitta PDF fayl"><?= icon('download', 13) ?>PDF</a>
            <?php if ($pr < $u): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="room_printed"><input type="hidden" name="rid" value="<?= $rid ?>"><button class="btn sm ghost" title="Shu xonaning varaqlari chop etildi deb belgilash (PDF dan chop etilgan bo'lsa)">✓ chop etildi</button></form><?php endif; ?>
          <?php endif; ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if ($nNoRoom > 0): ?>
        <tr class="rp-none">
          <td><b>Xonasizlar</b><div class="small muted">joy yetmagan yoki hali joylanmagan</div></td>
          <td class="num"><?= $nNoRoom ?></td><td class="num">—</td>
          <td class="rp-acts"><a class="btn sm ghost" target="_blank" href="<?= e($sheetUrl(['room' => 'none', 'order' => 'room', 'sep' => 1])) ?>"><?= icon('print', 13) ?>Varaqlar</a></td>
          <td class="rp-acts"><a class="btn sm" data-rp href="<?= e($rpUrl(['fmt' => 'pdf', 'room' => 'none'])) ?>"><?= icon('download', 13) ?>PDF</a></td>
        </tr>
      <?php endif; ?>
      </tbody>
    </table></div>
    <p class="small"><a target="_blank" href="<?= e(url('room_list', ['id' => $tid])) ?>">Davomat — hamma xonalar</a> · <a target="_blank" href="<?= e(url('room_door', ['id' => $tid])) ?>">Eshik — hamma xonalar</a> · <a target="_blank" href="<?= e(url('room_door', ['id' => $tid, 'mode' => 'all'])) ?>">Kirishdagi umumiy ro'yxat</a></p>
  </section>
<?php endif; ?>

<details class="card" id="unreg" <?= $unOpen ? 'open' : '' ?>>
  <summary><h2 style="display:inline">Ro'yxatga kiritilmagan o'quvchilar <span class="muted">(<?= $freeAll ?>)</span></h2></summary>
  <p class="small muted mt">Bazada bor, lekin shu MOCK ro'yxatida yo'q o'quvchilar (masalan, admin qo'shgan, lekin testga biriktirmagan). Belgilab qo'shing yoki filtrga mos hammasini bir bosishda qo'shing.</p>
  <?php if (!$nStudents): ?>
    <p class="empty">Bazada hali o'quvchi yo'q — avval <a href="<?= e(url('students')) ?>">"O'quvchilar"</a> sahifasida qo'shing.</p>
  <?php elseif (!$freeAll): ?>
    <p class="empty">Barcha o'quvchilar shu MOCK ro'yxatida.</p>
  <?php else: ?>
  <form method="get" class="row gap wrap center-v filter filter-row">
    <input type="hidden" name="p" value="registrations"><input type="hidden" name="id" value="<?= $tid ?>"><input type="hidden" name="un" value="1">
    <input name="ns" value="<?= e($nf['s']) ?>" placeholder="Ism, ID, telefon yoki maktab" aria-label="Qidirish">
    <select name="ng" aria-label="Guruh"><option value="">Barcha guruhlar</option><?php foreach ($groups as $g): ?><option value="<?= e($g['g']) ?>" <?= $nf['g'] === $g['g'] ? 'selected' : '' ?>><?= e($g['g']) ?></option><?php endforeach; ?><?php if ($noGroup): ?><option value="@none" <?= $nf['g'] === '@none' ? 'selected' : '' ?>>Guruhsizlar</option><?php endif; ?></select>
    <?php if ($centers): ?><select name="nc"><option value="">Barcha markazlar</option><option value="own" <?= $nf['c'] === 'own' ? 'selected' : '' ?>>O'z markazimiz</option><?php foreach ($centers as $cid => $cn): ?><option value="<?= (int)$cid ?>" <?= $nf['c'] === (string)$cid ? 'selected' : '' ?>><?= e($cn) ?></option><?php endforeach; ?></select><?php endif; ?>
    <button class="btn sm">Filtr</button>
    <?php if ($unFiltered): ?><a class="small keep-scroll" href="<?= e(url('registrations', ['id' => $tid, 'un' => 1])) ?>">Tozalash</a><?php endif; ?>
  </form>
  <?php if ($unList): ?>
  <form method="post">
    <?= csrf_field() ?><input type="hidden" name="f_un" value="1"><input type="hidden" name="f_ng" value="<?= e($nf['g']) ?>"><input type="hidden" name="f_nc" value="<?= e($nf['c']) ?>"><input type="hidden" name="f_ns" value="<?= e($nf['s']) ?>">
    <div class="mass-bar card soft mt">
      <label class="check"><input type="checkbox" id="unAll"> Barchasi</label>
      <?= $paySel() ?>
      <button class="btn sm primary" name="action" value="add_sel">Tanlanganlarni qo'shish</button>
      <span class="muted small" id="unCount">0 ta tanlangan</span>
      <button class="btn sm" style="margin-left:auto" name="action" value="add_filter" onclick="return confirm('<?= $unFiltered ? 'Filtrga mos' : 'Ro\'yxatga kiritilmagan' ?> <?= $unTotal ?> ta o\'quvchi shu MOCK ro\'yxatiga qo\'shilsinmi?')"><?= $unFiltered ? 'Filtrdagi' : 'Hammasini' ?> qo'shish (<?= $unTotal ?>)</button>
    </div>
    <div class="table-wrap"><table class="tbl compact-tbl">
      <thead><tr><th></th><th>ID</th><th>F.I.Sh</th><th>Guruh</th><th>Telefon</th></tr></thead>
      <tbody>
      <?php foreach ($unList as $s): ?>
        <tr>
          <td><input type="checkbox" name="ids[]" value="<?= (int)$s['id'] ?>" class="unchk" aria-label="Belgilash"></td>
          <td class="mono"><?= e($s['code']) ?></td>
          <td><?= e($s['full_name']) ?><?php if ($s['school'] || $s['grade_level']): ?><div class="small muted"><?= e(school_grade($s)) ?></div><?php endif; ?></td>
          <td class="small"><?= e($s['group_name'] ?: '—') ?><?php if ($s['center_id']): ?><div class="muted"><?= e($centers[(int)$s['center_id']] ?? '') ?></div><?php endif; ?></td>
          <td class="nowrap small"><?= e($s['phone'] ? fmt_phone($s['phone']) : '—') ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php if ($unTotal > count($unList)): ?><p class="small muted">Birinchi <?= count($unList) ?> tasi ko'rsatildi (jami <?= $unTotal ?>) — filtrdan foydalaning yoki "<?= $unFiltered ? 'Filtrdagi' : 'Hammasini' ?> qo'shish" tugmasini bosing.</p><?php endif; ?>
  </form>
  <?php else: ?>
    <p class="empty">Filtrga mos o'quvchi yo'q.</p>
  <?php endif; ?>
  <?php endif; ?>
</details>

<div class="reg-list" id="regList">
  <div>
    <div class="row between center-v wrap gap">
      <div class="row gap wrap center-v reg-h"><h2 style="margin:0">Ro'yxatdagilar <span class="muted" id="regCount">(<?= count($list) ?><?= $filtered ? " / $N" : '' ?>)</span></h2>
        <span id="regChips"><?php if ($regNone || $fG === '@none'): ?><a class="gx-chip<?= $fG === '@none' ? ' on' : '' ?>" href="<?= e($noneChipUrl) ?>" data-fg="<?= $fG === '@none' ? '' : '@none' ?>" title="<?= $fG === '@none' ? 'Filtrni olib tashlash' : 'Faqat guruhga biriktirilmaganlarni ko\'rsatish' ?>">Guruhsiz: <b><?= $regNone ?></b><?= $fG === '@none' ? ' <span aria-hidden="true">×</span>' : '' ?></a><?php endif; ?></span></div>
      <a class="btn sm ghost" href="<?= e(url('export', ['what' => 'registrations', 'id' => $tid])) ?>"><?= icon('download', 14) ?>Excel</a>
    </div>
    <form method="get" class="row gap wrap center-v filter filter-row reg-filter mt" id="regFilter">
      <input type="hidden" name="p" value="registrations"><input type="hidden" name="id" value="<?= $tid ?>">
      <input type="search" name="q" value="<?= e($fQ) ?>" placeholder="Ism, ID, telefon yoki maktab" autocomplete="off" aria-label="Qidirish">
      <span id="regFgWrap" class="fg-wrap"><?php if (count($regGroups) > 1 || ($regGroups && !isset($regGroups['']))): ?><select name="fg" aria-label="Guruh"><option value="">Barcha guruhlar</option><?php foreach ($regGroups as $g => $n): ?><option value="<?= $g === '' ? '@none' : e($g) ?>" <?= $fG === ($g === '' ? '@none' : (string)$g) ? 'selected' : '' ?>><?= $g === '' ? 'Guruhsizlar' : e($g) ?> (<?= $n ?>)</option><?php endforeach; ?></select><?php elseif ($fG !== ''): ?><input type="hidden" name="fg" value="<?= e($fG) ?>"><?php endif; ?></span>
      <?php if ($centers): ?><select name="fc"><option value="">Barcha markazlar</option><option value="own" <?= $fC === 'own' ? 'selected' : '' ?>>O'z markazimiz</option><?php foreach ($centers as $cid => $cn): ?><option value="<?= (int)$cid ?>" <?= $fC === (string)$cid ? 'selected' : '' ?>><?= e($cn) ?></option><?php endforeach; ?></select><?php endif; ?>
      <?php if ($rooms): ?><select name="room" aria-label="Xona"><option value="">Barcha xonalar</option><?php foreach ($rooms as $r): ?><option value="<?= (int)$r['id'] ?>" <?= $fRoom === (string)$r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?><option value="none" <?= $fRoom === 'none' ? 'selected' : '' ?>>Xonasizlar</option></select><?php endif; ?>
      <?php if ($showPay): ?><select name="fp" aria-label="To'lov holati"><option value="">To'lov: hammasi</option><?php foreach (REG_PAY_LABEL as $k => $lbl): if (!$payCnt[$k] && $fP !== $k) continue; ?><option value="<?= $k ?>" <?= $fP === $k ? 'selected' : '' ?>><?= e($lbl) ?> (<?= $payCnt[$k] ?>)</option><?php endforeach; ?></select><?php endif; ?>
      <?php if ($nAllPay): ?><select name="fv" aria-label="Qayerdan yozilgan"><option value="">Qayerdan: hammasi</option><?php foreach (['self' => 'O\'zi yozilgan (bot, sayt)', 'bot' => 'Bot orqali', 'web' => 'Sayt orqali', 'admin' => 'Admin qo\'shgan'] as $k => $lbl): $n = $k === 'self' ? $viaCnt['bot'] + $viaCnt['web'] : $viaCnt[$k]; if (!$n && $fV !== $k) continue; ?><option value="<?= $k ?>" <?= $fV === $k ? 'selected' : '' ?>><?= $lbl ?> (<?= $n ?>)</option><?php endforeach; ?></select>
      <select name="fd" aria-label="Qachon yozilgan"><option value="">Qachon: istalgan</option><option value="today" <?= $fD === 'today' ? 'selected' : '' ?>>Bugun (<?= $nToday ?>)</option><option value="old" <?= $fD === 'old' ? 'selected' : '' ?>>Bugungacha (<?= $nAllPay - $nToday ?>)</option><?php foreach (array_slice($dayCnt, 0, 14, true) as $d => $n): ?><option value="<?= e($d) ?>" <?= $fD === $d ? 'selected' : '' ?>><?= e(date('d.m.Y', strtotime($d))) ?> (<?= $n ?>)</option><?php endforeach; ?></select><?php endif; ?>
      <select name="pr" aria-label="Varaq holati"><option value="">Varaq: hammasi</option><option value="new" <?= $fPr === 'new' ? 'selected' : '' ?>>chop etilmagan</option><option value="done" <?= $fPr === 'done' ? 'selected' : '' ?>>chop etilgan</option></select>
      <select name="o" title="Ro'yxat va varaqlar shu tartibda chiqadi"><?php foreach (array_filter(['room' => $rooms ? 'Tartib: xona va o\'rin' : null, 'name' => 'Tartib: alifbo', 'school' => 'Tartib: maktab / sinf', 'time' => 'Tartib: qo\'shilgan vaqt']) as $k => $lbl): ?><option value="<?= $k ?>" <?= $fO === $k ? 'selected' : '' ?>><?= $lbl ?></option><?php endforeach; ?></select>
      <button class="btn sm">Qidirish</button>
      <span id="regClear"><?php if ($filtered): ?><a class="small" href="<?= e(url('registrations', ['id' => $tid] + ($fO !== ($rooms ? 'room' : 'name') ? ['o' => $fO] : []))) ?>">× Filtrni tozalash</a><?php endif; ?></span>
    </form>

    <div id="regResults">
    <form method="post" id="regMass" class="reg-bar-wrap">
      <?= csrf_field() ?><input type="hidden" name="action" value="mass">
      <div class="mass-bar card soft reg-bar">
        <label class="check"><input type="checkbox" id="checkAll"<?= $list ? '' : ' disabled' ?>> Barchasi</label>
        <span class="small" id="selCount"><b>0</b> ta belgilangan</span>
        <button type="button" class="btn sm primary" id="printSel" disabled data-url="<?= e($sheetUrl(['order' => $fO])) ?>" data-all-url="<?= e($filterSheetUrl) ?>"><?= icon('print', 14) ?>Belgilanganlarni chop etish</button>
        <?php if ($list): ?><a class="btn sm" target="_blank" href="<?= e($filterSheetUrl) ?>"><?= icon('print', 14) ?><?= $filtered ? 'Filtrdagilarni' : 'Hammasini' ?> chop etish (<?= count($list) ?>)</a><?php endif; ?>
        <button type="button" class="btn sm" id="regGrpBtn" disabled title="Belgilangan o'quvchilarni guruhga biriktirish"><?= icon('users', 14) ?>Guruhga biriktirish</button>
        <span class="bar-ops">
        <select name="op" id="regOp" aria-label="Belgilanganlar bilan amal">
          <?php if ($rooms): ?><option value="room">Xonaga o'tkazish</option><?php endif; ?>
          <option value="printed">"Chop etilgan" deb belgilash</option>
          <option value="unprinted">Qayta chop etishga belgilash</option>
          <option value="remove">Ro'yxatdan chiqarish<?= $showPay ? ' (pul qaytadi)' : '' ?></option>
          <?php if ($showPay && $fin): ?>
          <option value="remove_keep">Chiqarish — pul qaytmaydi</option>
          <?php if ($price > 0): ?><option value="cash">To'lov: naqd olindi</option><option value="wallet">To'lov: hamyondan</option><option value="unpaid">To'lov talab qilish</option><?php endif; ?>
          <option value="waive">To'lov: imtiyoz</option>
          <?php endif; ?>
        </select>
        <?php if ($rooms): ?><select name="to_room" class="op-room" aria-label="Qaysi xonaga"><?php foreach ($rooms as $r): ?><option value="<?= (int)$r['id'] ?>"><?= e($r['name']) ?></option><?php endforeach; ?><option value="0">— xonasiz —</option></select><?php endif; ?>
        <button class="btn sm" id="massDo" disabled onclick="var v=document.getElementById('regOp').value; return (v!=='remove' && v!=='remove_keep' && v!=='cash') || confirm(v==='cash' ? 'Belgilanganlar naqd to\'lagan deb yozilsinmi? (kirim va yechim yoziladi)' : 'Belgilanganlar ro\'yxatdan chiqarilsinmi?' + (v==='remove_keep' ? ' To\'lov QAYTARILMAYDI.' : ''))">Bajarish</button>
        </span>
      </div>
    </form>
    <p class="small muted reg-hint">Qatorni bosib belgilang. <b>Shift</b> bosib turib ikkinchi qatorni bossangiz — oradagilarning hammasi belgilanadi.</p>
    <div class="table-wrap"><table class="tbl reg-tbl">
      <thead><tr><th></th><th>ID</th><th>F.I.Sh</th><th>Telefon</th><?php if ($rooms): ?><th>Xona · o'rin</th><?php endif; ?><?php if ($showPay): ?><th>To'lov</th><?php endif; ?><th>Varaq</th><th>Holat</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($list as $s): $sid = (int)$s['id']; $rs = $resp[$sid] ?? null; $sub = implode(' · ', array_filter([$s['school'], $s['grade_level']], fn($v) => $v !== '')); ?>
        <tr data-sid="<?= $sid ?>">
          <td><input type="checkbox" name="ids[]" value="<?= $sid ?>" class="rowchk" form="regMass" aria-label="Belgilash"></td>
          <td class="mono"><?= e($s['code']) ?></td>
          <td><?= e($s['full_name']) ?><div class="small muted reg-sub"><?= group_chip($sid, (string)$s['group_name']) ?><?= $sub !== '' ? ' · ' . e($sub) : '' ?>
            <span class="reg-src" title="Ro'yxatga qo'shilgan: <?= e(date('d.m.Y H:i', strtotime((string)$s['reg_at']))) ?>"><?= e(REG_VIA_LABEL[(string)$s['via']] ?? (string)$s['via']) ?> · <?= e(date('d.m H:i', strtotime((string)$s['reg_at']))) ?></span></div></td>
          <td class="nowrap small"><?= e($s['phone'] ? fmt_phone($s['phone']) : '—') ?></td>
          <?php if ($rooms): ?>
          <td class="nowrap">
            <form method="post" class="inline room-cell filter"><?= csrf_field() ?><input type="hidden" name="action" value="move"><input type="hidden" name="sid" value="<?= $sid ?>">
              <select name="room" onchange="this.form.submit()" title="Boshqa xonaga o'tkazish"><option value="0">—</option><?php foreach ($rooms as $r): ?><option value="<?= (int)$r['id'] ?>" <?= (int)$s['room_id'] === (int)$r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?></select>
              <?php if ($s['seat']): ?><b class="seat">· <?= (int)$s['seat'] ?></b><?php if ($s['notified_at']): ?> <span class="tag green" title="Xona/o'rin haqida xabar yuborilgan: <?= e($s['notified_at']) ?>">✉</span><?php endif; ?><?php endif; ?>
            </form></td>
          <?php endif; ?>
          <?php if ($showPay): $ps = (string)$s['pay_status']; $cash = $ps === 'paid' && (string)$s['pay_method'] === 'cash'; ?>
          <td class="nowrap small pay-cell">
            <span class="tag <?= REG_PAY_TAG[$ps] ?? '' ?>" title="<?= e(($s['paid_at'] ? 'To\'langan: ' . date('d.m.Y H:i', strtotime((string)$s['paid_at'])) . ($cash ? ' (naqd)' : '') . ' · ' : '') . 'qayerdan: ' . (REG_VIA_LABEL[$s['via']] ?? $s['via'])) ?>"><?= e($ps === 'unpaid' ? 'Band' : (REG_PAY_LABEL[$ps] ?? $ps)) ?><?= $ps === 'paid' ? ' · ' . e(som((int)$s['paid_amount'])) : '' ?><?= $cash ? ' · naqd' : '' ?></span>
            <?php if ($fin && $price > 0 && in_array($ps, ['unpaid', 'free'], true)): /* 2.5.4: naqd to'lovni shu joyida belgilash */ ?><button type="button" class="btn sm cash-btn" data-sid="<?= $sid ?>" data-sum="<?= e(som($price)) ?>" data-price="<?= $price ?>" data-name="<?= e($s['full_name']) ?>" title="O'quvchi naqd to'ladi — shu yerda belgilash (<?= e(som($price)) ?>)">Naqd</button><?php endif; ?>
            <?php if ($ps === 'unpaid'): ?><span class="muted pc-bal">balansi: <?= e(som((int)$s['balance'])) ?></span><?php endif; ?>
            <?php if ($fin && $cash && !isset($resp[$sid])): ?>
            <details class="pay-menu"><summary class="btn sm ghost" title="To'lov amallari" aria-label="To'lov amallari">⋯</summary>
              <div class="pay-menu-list">
                <form method="post" onsubmit="return confirm(<?= e(json_encode('«' . $s['full_name'] . '» uchun naqd to\'lov belgisi bekor qilinsinmi? (xato belgilangan bo\'lsa) O\'quvchi yana «band» bo\'ladi.', JSON_UNESCAPED_UNICODE)) ?>)"><?= csrf_field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="op" value="uncash"><input type="hidden" name="sid" value="<?= $sid ?>"><button class="btn sm ghost">↶ Naqd belgisini bekor qilish</button></form>
              </div>
            </details>
            <?php endif; ?>
            <?php if ($fin && in_array($ps, ['unpaid', 'free'], true) && ($price > 0 || $ps === 'unpaid')): ?>
            <details class="pay-menu"><summary class="btn sm ghost" title="To'lov amallari" aria-label="To'lov amallari">⋯</summary>
              <div class="pay-menu-list">
                <?php if ($price > 0): ?>
                <form method="post" onsubmit="return confirm(<?= e(json_encode('Naqd ' . som($price) . ' qabul qilindi deb yozilsinmi?', JSON_UNESCAPED_UNICODE)) ?>)"><?= csrf_field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="op" value="cash"><input type="hidden" name="sid" value="<?= $sid ?>"><input type="hidden" name="expect" value="<?= $price ?>"><button class="btn sm ghost">Naqd to'landi (<?= e(som($price)) ?>)</button></form>
                <?php if ((int)$s['balance'] >= $price): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="op" value="wallet"><input type="hidden" name="sid" value="<?= $sid ?>"><button class="btn sm ghost">Hamyondan yechish</button></form><?php endif; ?>
                <?php if ($ps === 'free'): ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="op" value="unpaid"><input type="hidden" name="sid" value="<?= $sid ?>"><button class="btn sm ghost">To'lov talab qilish</button></form><?php endif; ?>
                <?php endif; ?>
                <form method="post" class="row gap"><?= csrf_field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="op" value="waive"><input type="hidden" name="sid" value="<?= $sid ?>"><input name="note" placeholder="izoh" maxlength="120" aria-label="Imtiyoz izohi"><button class="btn sm ghost">Imtiyoz</button></form>
              </div>
            </details>
            <?php endif; ?>
          </td>
          <?php endif; ?>
          <td class="nowrap small"><?= $s['printed_at'] ? '<span class="tag green" title="' . e($s['printed_at']) . '">✓ ' . e(date('d.m', strtotime($s['printed_at']))) . '</span>' : '<span class="tag">yangi</span>' ?></td>
          <td><?= $rs === 'submitted' ? '<span class="tag green">topshirdi</span>' : ($rs ? '<span class="tag amber">jarayonda</span>' : '<span class="tag">kutilmoqda</span>') ?></td>
          <td class="right nowrap">
            <a class="btn sm ghost" target="_blank" title="Shu o'quvchining varag'ini chop etish" href="<?= e($sheetUrl(['sid' => $sid])) ?>"><?= icon('print', 14) ?></a>
            <form method="post" class="inline" onsubmit="return confirm(<?= e(json_encode('Ro\'yxatdan chiqarilsinmi?' . ($s['pay_status'] === 'paid' && (int)$s['paid_amount'] > 0 ? ' To\'lagan ' . som((int)$s['paid_amount']) . ' hamyoniga qaytariladi.' : ''), JSON_UNESCAPED_UNICODE)) ?>)"><?= csrf_field() ?><input type="hidden" name="action" value="remove"><input type="hidden" name="sid" value="<?= $sid ?>"><button class="btn sm danger-ghost" title="Ro'yxatdan chiqarish" aria-label="Ro'yxatdan chiqarish">×</button></form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$list): ?><tr><td colspan="9" class="empty"><?= $nAllPay ? 'Filtrga mos o\'quvchi yo\'q' : 'Hali hech kim ro\'yxatdan o\'tmagan' ?></td></tr><?php endif; ?>
      </tbody>
    </table></div>
    </div>
  </div>

</div>
<script>
(function(){
  // Ro'yxatdagilar: belgilash (qatorni bosish, Shift bilan oraliq), belgilanganlarni chop etish.
  // Filtr sahifani qayta yuklamaydi — faqat jadval almashtiriladi, shuning uchun hodisalar hujjat darajasida ushlanadi.
  const $ = s => document.querySelector(s);
  const boxes = () => [...document.querySelectorAll('.rowchk')];
  let last = null;
  const upd = () => {
    const bx = boxes(), n = bx.filter(b => b.checked).length, all = $('#checkAll'), pb = $('#printSel'), db = $('#massDo'), cnt = $('#selCount'), gb = $('#regGrpBtn');
    bx.forEach(b => b.closest('tr').classList.toggle('sel', b.checked));
    if (cnt) cnt.innerHTML = '<b>' + n + '</b> ta belgilangan';
    if (pb) { pb.disabled = n === 0; pb.lastChild.textContent = n ? 'Belgilanganlarni chop etish (' + n + ')' : 'Belgilanganlarni chop etish'; }
    if (db) db.disabled = n === 0;
    if (gb) gb.disabled = n === 0;   // 2.5.2: «Guruhga biriktirish» (assets/students.js)
    if (all) { all.checked = n > 0 && n === bx.length; all.indeterminate = n > 0 && n < bx.length; }
  };
  const roomOp = () => { const op = $('#regOp'), rs = $('.op-room'); if (op && rs) rs.hidden = op.value !== 'room'; };
  const setRange = (to, state) => {
    const bx = boxes(), a = bx.indexOf(last), b = bx.indexOf(to);
    if (a < 0 || b < 0) return;
    bx.slice(Math.min(a, b), Math.max(a, b) + 1).forEach(x => x.checked = state);
  };
  document.addEventListener('change', e => {
    if (e.target.id === 'checkAll') { boxes().forEach(b => b.checked = e.target.checked); upd(); }
    if (e.target.id === 'regOp') roomOp();
  });
  document.addEventListener('click', e => {
    const t = e.target;
    document.querySelectorAll('.pay-menu[open]').forEach(m => { if (!m.contains(t)) m.removeAttribute('open'); });   // to'lov menyusi tashqarisi bosilsa yopiladi
    if (t.classList && t.classList.contains('rowchk')) {          // katakchaning o'zi (Shift bilan — oraliq)
      if (e.shiftKey && last) setRange(t, t.checked);
      last = t; upd(); return;
    }
    const pb = t.closest && t.closest('#printSel');
    if (pb) {
      const bx = boxes(), ids = bx.filter(b => b.checked).map(b => b.value);
      if (!ids.length) return;
      // Hammasi belgilangan bo'lsa — filtr bo'yicha (manzil qisqa qoladi), aks holda belgilangan ID lar bo'yicha
      window.open(ids.length === bx.length ? pb.dataset.allUrl : pb.dataset.url + '&sids=' + ids.join(','), '_blank');
      return;
    }
    const tr = t.closest && t.closest('.reg-tbl tbody tr');       // qatorning bo'sh joyi
    if (!tr || t.closest('input, select, button, a, label, form, details, .cash-ask')) return;
    const cb = tr.querySelector('.rowchk'); if (!cb) return;
    if (e.shiftKey && last) { window.getSelection && window.getSelection().removeAllRanges(); setRange(cb, !cb.checked); }
    else cb.checked = !cb.checked;
    last = cb; upd();
  });

  // --- Jonli filtr: sahifa yangilanmaydi va joyidan siljimaydi ---
  const ff = $('#regFilter');
  let ctl = null, timer = null;
  const formUrl = () => {
    const q = new URLSearchParams();
    for (const [k, v] of new FormData(ff)) if (String(v).trim() !== '') q.set(k, String(v).trim());
    return 'index.php?' + q.toString();
  };
  async function load(url, full) {
    if (ctl) ctl.abort();
    ctl = new AbortController();
    const box = $('#regResults'); box.classList.add('is-loading');
    try {
      const html = await fetch(url, { signal: ctl.signal, credentials: 'same-origin' }).then(r => { if (!r.ok) throw new Error(r.status); return r.text(); });
      const doc = new DOMParser().parseFromString(html, 'text/html');
      if (!doc.querySelector('#regResults')) throw new Error('javob noto\'g\'ri');   // masalan, sessiya tugagan
      // full — guruhlar o'zgargach: guruh filtri (sonlari bilan) ham yangilanadi
      ['#regResults', '#regCount', '#regClear', '#regChips'].concat(full ? ['#regFgWrap'] : []).forEach(sel => { const n = doc.querySelector(sel), o = $(sel); if (n && o) o.replaceWith(document.importNode(n, true)); });
      history.replaceState(null, '', url);
      last = null; roomOp(); upd();
    } catch (err) {
      if (err.name !== 'AbortError') location.href = url;           // xato bo'lsa — oddiy usulda ochamiz
    } finally {
      const b = $('#regResults'); if (b) b.classList.remove('is-loading');
    }
  }
  if (ff) {
    ff.addEventListener('submit', e => { e.preventDefault(); clearTimeout(timer); load(formUrl()); });
    ff.addEventListener('change', e => { if (e.target.tagName === 'SELECT') load(formUrl()); });
    ff.q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => load(formUrl()), 350); });
    document.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('#regClear a');
      if (!a) return;
      e.preventDefault();
      ff.q.value = '';
      ff.querySelectorAll('select').forEach(s => { if (s.name !== 'o') s.value = ''; });
      ff.querySelectorAll('input[type=hidden][name=fg]').forEach(h => h.remove());
      load(formUrl());
    });
    // 2.5.2: «Guruhsiz: N» belgisi — guruhsizlar filtrini yoqish / o'chirish
    document.addEventListener('click', e => {
      const a = e.target.closest && e.target.closest('#regChips a[data-fg]');
      if (!a) return;
      e.preventDefault();
      let f = ff.elements.fg;
      if (!f) { f = document.createElement('input'); f.type = 'hidden'; f.name = 'fg'; $('#regFgWrap').appendChild(f); }
      f.value = a.dataset.fg;
      load(formUrl());
    });
    window.regReload = () => load(formUrl(), true);   // guruhga biriktirilgach ro'yxatni yangilash (assets/students.js)
  }

  // --- 2.5.4: naqd to'lovni ro'yxatning o'zida belgilash: «Naqd» → «… olindimi? Ha» (sahifa yangilanmaydi, joyidan siljimaydi) ---
  const csrfTok = () => { const m = document.querySelector('meta[name=csrf]'); return m ? m.content : ''; };
  const toast = nodes => {
    if (!nodes.length) return;
    const wrap = document.createElement('div'); wrap.className = 'flash-toast';
    nodes.forEach(n => wrap.appendChild(document.importNode(n, true)));
    document.body.appendChild(wrap);
    setTimeout(() => wrap.classList.add('hide'), 4500);
    setTimeout(() => wrap.remove(), 5200);
    wrap.addEventListener('click', () => wrap.remove());
  };
  // Amaldan keyingi sahifadan kerakli qismlarni olib, joriy sahifada almashtirish (belgilangan qatorlar saqlanadi)
  const applyPage = html => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    if (!doc.querySelector('#regResults')) return false;   // masalan, sessiya tugagan
    const keep = new Set(boxes().filter(b => b.checked).map(b => b.value));
    const top0 = $('#regResults').getBoundingClientRect().top;
    // yangi paydo bo'lgan qism shu joyga qo'yiladi (masalan, birinchi to'lovdan keyin «Xonalar bo'yicha»), yo'qolgani olib tashlanadi
    const place = { '#payStrip': ['after', '#regKpi'], '#srcStrip': ['after', '#payStrip', '#regKpi'], '#rpBox': ['before', '#unreg'] };
    ['#regKpi', '#payStrip', '#srcStrip', '#regResults', '#regCount', '#regChips', '#rpBox'].forEach(sel => {
      const n = doc.querySelector(sel), o = $(sel);
      if (n && o) o.replaceWith(document.importNode(n, true));
      else if (o) o.remove();
      else if (n && place[sel]) { const [how, ...refs] = place[sel]; const r = refs.map(x => $(x)).find(Boolean); if (r) r[how](document.importNode(n, true)); }
    });
    // qadamlar sarlavhalaridagi sonlar (formalarga tegilmaydi)
    ['.reg-flow .rs-h', '.reg-flow .rs-actions'].forEach(sel => {
      const nn = doc.querySelectorAll(sel), oo = document.querySelectorAll(sel);
      if (nn.length === oo.length) oo.forEach((o, i) => o.replaceWith(document.importNode(nn[i], true)));
    });
    boxes().forEach(b => { if (keep.has(b.value)) b.checked = true; });
    window.scrollBy(0, $('#regResults').getBoundingClientRect().top - top0);   // ro'yxat ekranda joyidan siljimasin (tepadagi qismlar o'zgarsa ham)
    toast([...doc.querySelectorAll('main > .alert')]);
    last = null; roomOp(); upd(); rpWhat();
    return true;
  };
  const cashCancel = ask => { if (ask.dataset.busy) return; clearTimeout(ask._t); if (ask.isConnected && ask._btn) ask.replaceWith(ask._btn); };   // yozilayotgani bekor bo'lmaydi
  document.addEventListener('click', async e => {
    const t = e.target;
    const cb = t.closest && t.closest('.cash-btn');
    if (cb) {
      document.querySelectorAll('.cash-ask').forEach(cashCancel);   // bir vaqtda bitta so'rov
      const ask = document.createElement('span'); ask.className = 'cash-ask'; ask.dataset.sid = cb.dataset.sid; ask.dataset.price = cb.dataset.price;
      ask.innerHTML = '<span class="ca-q"></span> <button type="button" class="btn sm primary cash-yes">Ha, olindi</button> <button type="button" class="btn sm ghost cash-no" aria-label="Bekor qilish">✕</button>';
      ask.querySelector('.ca-q').textContent = cb.dataset.sum + ' naqd olindimi?';
      ask._btn = cb;
      cb.replaceWith(ask);
      ask.querySelector('.cash-yes').focus({ preventScroll: true });   // Enter — tasdiq
      ask._t = setTimeout(() => cashCancel(ask), 9000);
      return;
    }
    const no = t.closest && t.closest('.cash-no');
    if (no) { cashCancel(no.closest('.cash-ask')); return; }
    const yes = t.closest && t.closest('.cash-yes');
    if (yes) {
      const ask = yes.closest('.cash-ask'); clearTimeout(ask._t);
      if (ask.dataset.busy) return;
      ask.dataset.busy = '1';
      ask.querySelectorAll('button').forEach(b => b.disabled = true);
      ask.querySelector('.ca-q').textContent = 'yozilmoqda…';
      try {
        const fd = new FormData();
        fd.append('_csrf', csrfTok()); fd.append('action', 'pay'); fd.append('op', 'cash'); fd.append('sid', ask.dataset.sid); fd.append('expect', ask.dataset.price);   // ko'rsatilgan narx
        const r = await fetch(location.href, { method: 'POST', body: fd, credentials: 'same-origin' });   // javob — amaldan keyingi sahifa (redirect)
        if (!r.ok || !applyPage(await r.text())) location.reload();
      } catch (err) { location.reload(); }
    }
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') document.querySelectorAll('.cash-ask').forEach(cashCancel); });

  // --- 2.5.4: xonalar bo'yicha yuklab olish — PDF tarkibi (tanlov eslab qolinadi) ---
  function rpWhat() {
    const sel = document.getElementById('rpWhat');
    if (!sel) return;
    if (!sel.dataset.init) {
      sel.dataset.init = '1';
      try { const v = localStorage.getItem('rpWhat'); if (v && [...sel.options].some(o => o.value === v)) sel.value = v; } catch (e) {}
      sel.addEventListener('change', () => { try { localStorage.setItem('rpWhat', sel.value); } catch (e) {} rpWhat(); });
    }
    document.querySelectorAll('a[data-rp]').forEach(a => {
      const u = new URL(a.getAttribute('href'), location.href);
      if (sel.value === 'all') u.searchParams.delete('what'); else u.searchParams.set('what', sel.value);
      a.setAttribute('href', u.pathname.split('/').pop() + u.search);
    });
  }
  rpWhat();

  // --- Amal bajarilgach (sahifa qayta yuklanadi) avvalgi joyga qaytish ---
  const KEY = 'regScroll:' + <?= $tid ?>;
  const save = () => { try { sessionStorage.setItem(KEY, JSON.stringify({ y: window.scrollY, t: Date.now() })); } catch (e) {} };
  document.addEventListener('submit', e => { if (e.target !== ff) save(); }, true);
  document.addEventListener('change', e => { if (e.target.closest && e.target.closest('form.room-cell')) save(); }, true);   // xona tanlovi o'zi yuboradi
  document.addEventListener('click', e => { if (e.target.closest && e.target.closest('a.keep-scroll')) save(); }, true);
  try {
    const v = JSON.parse(sessionStorage.getItem(KEY) || 'null');
    sessionStorage.removeItem(KEY);
    if (v && Date.now() - v.t < 20000 && v.y > 200) {
      // Tepadagi xabarni ko'rinadigan joyga — pastki burchakka chiqaramiz (avval ko'chiramiz, keyin scroll — sahifa siljimasligi uchun)
      const msgs = [...document.querySelectorAll('main > .alert')];
      if (msgs.length) {
        const wrap = document.createElement('div'); wrap.className = 'flash-toast';
        msgs.forEach(m => wrap.appendChild(m));
        document.body.appendChild(wrap);
        setTimeout(() => wrap.classList.add('hide'), 4500);
        setTimeout(() => wrap.remove(), 5200);
        wrap.addEventListener('click', () => wrap.remove());
      }
      window.scrollTo(0, v.y);
    }
  } catch (e) {}

  roomOp(); upd();
})();
(function(){
  // Ro'yxatga kiritilmaganlar bo'limi: belgilash
  const all = document.getElementById('unAll'), cnt = document.getElementById('unCount');
  if (!all) return;
  const boxes = () => [...document.querySelectorAll('.unchk')];
  const upd = () => { cnt.textContent = boxes().filter(b => b.checked).length + ' ta tanlangan'; };
  all.addEventListener('change', () => { boxes().forEach(b => b.checked = all.checked); upd(); });
  boxes().forEach(b => b.addEventListener('change', upd));
})();
</script>
<script type="application/json" id="stuData"><?= json_encode(['page' => 'registrations', 'test' => $tid, 'groups' => group_counts(), 'none' => students_none_count(), 'reg_none' => $regNone], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<?php page_footer(['assets/students.js']);
