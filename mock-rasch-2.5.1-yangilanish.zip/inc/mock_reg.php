<?php
/**
 * 2.5: MOCK ga yozilish, to'lov holati, chiqish va qaytarish — sayt, bot va admin uchun yagona qoida.
 * test_registrations.pay_status: free — bepul MOCK (yoki narx qo'yilishidan oldin yozilgan), paid — hamyondan to'langan,
 * unpaid — band qilingan (to'lov kutilmoqda), waived — imtiyoz (admin bepul qilgan).
 * Har bir pul amali: o'quvchi qatori qulflanadi, ro'yxat qatori avval «egallanadi» (shartli UPDATE/INSERT), keyin pul yechiladi —
 * shunda ikki marta bosish, ikki qurilma yoki parallel jarayon pulni ikki marta yecha olmaydi.
 */
defined('APP_ROOT') || exit;

const REG_PAY_LABEL = ['free' => 'Bepul', 'paid' => 'To\'langan', 'unpaid' => 'Band — to\'lov kutilmoqda', 'waived' => 'Imtiyoz'];
const REG_PAY_TAG = ['free' => '', 'paid' => 'green', 'unpaid' => 'amber', 'waived' => 'blue'];
const REG_VIA_LABEL = ['web' => 'sayt', 'bot' => 'bot', 'register' => 'ro\'yxatdan o\'tish', 'admin' => 'admin', '' => '—'];

function mock_price(array $t): int { return max(0, (int)($t['price'] ?? 0)); }

/** Narx yozuvi: «Bepul» yoki «50 000 so'm» */
function mock_price_label(array $t): string { $p = mock_price($t); return $p > 0 ? som($p) : 'Bepul'; }

/** MOCK o'tib bo'lganmi: natija e'lon qilingan, onlayn muddati yoki oflayn sanasi o'tgan */
function mock_is_over(array $t): bool
{
    if (!empty($t['published'])) return true;
    if (!empty($t['online'])) return !empty($t['online_end']) && strtotime((string)$t['online_end']) < time();
    return !empty($t['test_date']) && (string)$t['test_date'] < date('Y-m-d');
}

/**
 * MOCK boshlanganmi — o'quvchi to'lovni o'zi qaytara olmaydi: onlayn — boshlanish vaqti kelgan (vaqt belgilanmagan bo'lsa test
 * istalgan payt ochiq, shuning uchun «boshlangan» hisoblanadi), oflayn — imtihon kuni, natija e'lon qilingan bo'lsa — albatta.
 */
function mock_begun(array $t): bool
{
    if (!empty($t['published'])) return true;
    if (!empty($t['online'])) return empty($t['online_start']) || strtotime((string)$t['online_start']) <= time();
    return !empty($t['test_date']) && (string)$t['test_date'] <= date('Y-m-d');
}

/** Boshlanish vaqti (unix) — qaytarish muddatini ko'rsatish uchun; noma'lum bo'lsa 0 */
function mock_begin_ts(array $t): int
{
    if (!empty($t['online'])) return !empty($t['online_start']) ? (int)strtotime((string)$t['online_start']) : 0;
    return !empty($t['test_date']) ? (int)strtotime((string)$t['test_date'] . ' 00:00:00') : 0;
}

function mock_reg_row(int $sid, int $tid, bool $lock = false): ?array
{
    return row('SELECT * FROM test_registrations WHERE test_id=? AND student_id=?' . ($lock ? ' FOR UPDATE' : ''), [$tid, $sid]);
}

function mock_test_row(int $tid): ?array
{
    return row('SELECT id, title, price, reg_open, online, online_start, online_end, duration_min, test_date, published, tg_enabled FROM tests WHERE id=?', [$tid]);
}

/** Hamyondan MOCK uchun yechim (qulf ostida chaqiriladi). Qaytaradi wallet_post natijasi */
function mock_charge(int $sid, int $tid, int $price, string $actor, string $title, bool $afterCash = false): array
{
    // $afterCash: shu tranzaksiyada aynan shu summa naqd kirim qilingan — sof ta'sir 0, avvalgi qarz (manfiy balans) to'siq bo'lmasin
    return wallet_post($sid, -$price, 'charge', ['ref_type' => 'test', 'ref_id' => $tid, 'actor' => $actor, 'note' => '«' . $title . '»', 'allow_negative' => $afterCash]);   // nom yozuvda qoladi (MOCK o'chirilsa ham)
}

/**
 * MOCK ga yozish. $via: web | bot | register | admin.
 * $o['pay']: wallet — balansdan (yetmasa rad), auto — balansdan, yetmasa band, cash — admin: naqd kirim + yechim,
 *            waive — admin: imtiyoz, unpaid — admin: band. Narx 0 bo'lsa — har doim «free».
 * $o['force'] — ro'yxat yopiq bo'lsa ham (admin); $o['expect_price'] — tasdiqlash oynasida ko'rsatilgan narx (o'zgargan bo'lsa to'xtaydi);
 * $o['note'], $o['actor'], $o['notify'] (standart: true).
 * Qaytaradi: ['ok', 'status' => free|paid|unpaid|waived|exists|closed|insufficient|price|error, 'error', 'price', 'balance', 'need', 'title']
 */
function mock_register(int $sid, int $tid, string $via, array $o = []): array
{
    $mode = (string)($o['pay'] ?? 'wallet');
    $actor = (string)($o['actor'] ?? ($via === 'admin' ? actor_tag() : 'student:' . $sid));   // o'quvchining o'z amali (shu brauzerda admin ham kirgan bo'lsa ham)
    $note = mb_substr(trim((string)($o['note'] ?? '')), 0, 200);
    $via = isset(REG_VIA_LABEL[$via]) ? $via : 'web';
    $res = db_tx(function () use ($sid, $tid, $via, $mode, $actor, $note, $o) {
        $st = row('SELECT id, balance, archived_at FROM students WHERE id=? FOR UPDATE', [$sid]);
        $t = mock_test_row($tid);
        $price = $t ? mock_price($t) : 0;
        $base = ['ok' => false, 'status' => 'error', 'error' => '', 'price' => $price, 'balance' => $st ? (int)$st['balance'] : 0, 'need' => 0, 'title' => $t ? (string)$t['title'] : ''];
        if (!$st || !$t) return ['error' => 'O\'quvchi yoki MOCK topilmadi'] + $base;
        if ($st['archived_at'] !== null) return ['error' => 'Hisob arxivlangan'] + $base;
        $reg = mock_reg_row($sid, $tid);
        if ($reg) return ['ok' => true, 'status' => 'exists', 'reg' => $reg] + $base;
        if (empty($o['force']) && (!(int)$t['reg_open'] || mock_is_over($t))) return ['status' => 'closed', 'error' => 'Bu MOCK ga ro\'yxat yopilgan'] + $base;
        if (isset($o['expect_price']) && (int)$o['expect_price'] !== $price)
            return ['status' => 'price', 'error' => 'MOCK narxi o\'zgardi: endi ' . mock_price_label($t) . '. Qayta tasdiqlang.'] + $base;
        $bal = (int)$st['balance'];
        if ($price === 0) $status = 'free';
        elseif ($mode === 'waive') $status = 'waived';
        elseif ($mode === 'unpaid') $status = 'unpaid';
        elseif ($mode === 'cash' || $bal >= $price) $status = 'paid';
        elseif ($mode === 'auto') $status = 'unpaid';
        else return ['status' => 'insufficient', 'need' => $price - $bal, 'error' => 'Balans yetarli emas: yana ' . som($price - $bal) . ' kerak'] + $base;
        // ro'yxat qatori avval yoziladi; parallel so'rov uni yozib ulgurgan bo'lsa — pul yechilmaydi
        $ins = q('INSERT IGNORE INTO test_registrations (test_id, student_id, pay_status, via) VALUES (?,?,?,?)', [$tid, $sid, $status === 'paid' ? 'unpaid' : $status, $via]);
        if (!$ins->rowCount()) return ['ok' => true, 'status' => 'exists', 'reg' => mock_reg_row($sid, $tid)] + $base;
        $txId = null;
        if ($status === 'paid') {
            if ($mode === 'cash') {
                $w = wallet_post($sid, $price, 'topup', ['ref_type' => 'test', 'ref_id' => $tid, 'method' => 'naqd', 'note' => '«' . $t['title'] . '» uchun' . ($note !== '' ? ', ' . $note : ''), 'actor' => $actor]);
                if (!$w['ok']) throw new RuntimeException('Naqd kirim yozilmadi: ' . $w['error']);
            }
            $c = mock_charge($sid, $tid, $price, $actor, (string)$t['title'], $mode === 'cash');
            if (!$c['ok']) throw new RuntimeException('Yechim yozilmadi: ' . $c['error']);   // balans qulf ostida tekshirilgan — bo'lmasligi kerak
            q('UPDATE test_registrations SET pay_status="paid", paid_amount=?, paid_at=NOW(), tx_id=? WHERE test_id=? AND student_id=?', [$price, $c['tx_id'], $tid, $sid]);
            $bal = $c['balance'];
            $txId = $c['tx_id'];
        }
        audit('mock_register', 'reg', $tid, null, ['sid' => $sid, 'status' => $status, 'price' => $price, 'via' => $via, 'mode' => $mode, 'tx' => $txId, 'note' => $note], $actor);
        return ['ok' => true, 'status' => $status, 'balance' => $bal, 'test' => $t, 'cash' => $mode === 'cash'] + $base;
    });
    if ($res['ok'] && $res['status'] !== 'exists' && ($o['notify'] ?? true) && $via !== 'bot') mock_reg_notify($sid, $res + ['via' => $via]);
    return $res;
}

/** «➕ Hisobni to'ldirish» tugmasi (botda chek yuborish), yetishmayotgan summa taklif qilinadi */
function wallet_topup_kb(int $need = 0): array
{
    return ['inline_keyboard' => [[['text' => '➕ Hisobni to‘ldirish (chek yuborish)', 'callback_data' => 'w:t' . ($need > 0 ? ':' . max($need, pay_min()) : '')]]]];
}

/** Ro'yxatga yozilish haqida bot xabari (pul bilan bog'liq hollarda va 2.5.1 dan saytda bepul yozilganda; botdagi amalga bot o'zi javob beradi) */
function mock_reg_notify(int $sid, array $r): void
{
    $title = '«' . tg_h($r['title']) . '»';
    $kb = null;
    if ($r['status'] === 'free') {
        if (($r['via'] ?? '') !== 'web') return;   // admin ro'yxatga qo'shganda (ko'pincha ommaviy) — xabarsiz
        $t = $r['test'] ?? [];
        $when = !empty($t['online']) && !empty($t['online_start']) ? tg_dt((string)$t['online_start']) . ', onlayn' : (!empty($t['test_date']) ? date('d.m.Y', strtotime((string)$t['test_date'])) : '');
        $s = "📝 " . $title . " MOCK ga ro'yxatdan o'tdingiz (saytda)." . ($when !== '' ? "\nSana: " . $when : '');
    } elseif ($r['price'] <= 0 && $r['status'] !== 'waived') return;
    elseif ($r['status'] === 'paid') $s = "📝 " . $title . " MOCK ga ro'yxatdan o'tdingiz.\nTo'lov: <b>" . tg_h(som($r['price'])) . "</b>" . (!empty($r['cash']) ? ' (naqd)' : ' (hamyondan)') . "\nBalans: <b>" . tg_h(som((int)$r['balance'])) . "</b>";
    elseif ($r['status'] === 'unpaid') {
        $s = "📌 " . $title . " MOCK ga joyingiz band qilindi.\nTo'lov kutilmoqda: <b>" . tg_h(som($r['price'])) . "</b>, balansingiz: " . tg_h(som((int)$r['balance']))
            . ".\nHisobni to'ldiring — chek tasdiqlangach to'lov avtomatik yechiladi. Ro'yxat yopilguncha to'lanmasa, band bekor bo'ladi.";
        $kb = wallet_topup_kb((int)$r['price'] - (int)$r['balance']);
    }
    elseif ($r['status'] === 'waived') $s = "🎁 " . $title . " MOCK ga imtiyoz bilan (bepul) ro'yxatga olindingiz.";
    else return;
    wallet_notify($sid, 'regpd', (int)($r['test']['id'] ?? 0), $s, $kb);
}

/**
 * O'quvchi o'zi chiqa oladimi. $reg — ro'yxat qatori (pay_status, paid_amount, paid_at), $t — test, $started — javob yozuvi bor.
 * Qaytaradi: ['ok', 'reason', 'refund' => so'm, 'until' => to'lovni qaytarish muddati (unix) yoki 0]
 */
function mock_cancel_check(array $reg, array $t, bool $started): array
{
    if ($started) return ['ok' => false, 'reason' => 'Test boshlangan — ro\'yxatdan chiqib bo\'lmaydi', 'refund' => 0, 'until' => 0];
    if ($reg['pay_status'] === 'unpaid') return ['ok' => true, 'reason' => '', 'refund' => 0, 'until' => 0];   // band — istalgan vaqt
    if (!(int)$t['reg_open'] || mock_is_over($t)) return ['ok' => false, 'reason' => 'Ro\'yxat yopilgan — chiqish uchun markazga murojaat qiling', 'refund' => 0, 'until' => 0];
    if ($reg['pay_status'] === 'paid' && (int)$reg['paid_amount'] > 0) {
        if (mock_begun($t)) return ['ok' => false, 'reason' => 'MOCK boshlangan — chiqish faqat markaz orqali', 'refund' => 0, 'until' => 0];   // savollar tarqatilgandan keyin pul qaytmaydi
        $win = pay_cancel_min();
        $until = !empty($reg['paid_at']) ? strtotime((string)$reg['paid_at']) + $win * 60 : 0;
        $b = mock_begin_ts($t);
        if ($b > 0 && $until > $b) $until = $b;
        if ($win <= 0 || time() > $until)
            return ['ok' => false, 'reason' => $win > 0 ? 'To\'lovdan keyin ' . mock_minutes_label($win) . ' o\'tdi — chiqish faqat markaz orqali (pul qaytarish bilan)' : 'To\'langan ro\'yxatdan chiqish faqat markaz orqali', 'refund' => 0, 'until' => $until];
        return ['ok' => true, 'reason' => '', 'refund' => (int)$reg['paid_amount'], 'until' => $until];
    }
    return ['ok' => true, 'reason' => '', 'refund' => 0, 'until' => 0];
}

function mock_minutes_label(int $m): string
{
    if ($m % 1440 === 0) return ($m / 1440) . ' kun';
    if ($m % 60 === 0) return ($m / 60) . ' soat';
    return $m . ' daqiqa';
}

/**
 * Ro'yxatdan chiqarish. $by: student | admin. $o: refund (admin uchun, standart true), note, actor, notify.
 * Qaytaradi: ['ok', 'error', 'refund' => qaytarilgan so'm, 'status' => eski holat, 'title']
 */
function mock_cancel(int $sid, int $tid, string $by, array $o = []): array
{
    $actor = (string)($o['actor'] ?? ($by === 'student' ? 'student:' . $sid : actor_tag()));
    $note = mb_substr(trim((string)($o['note'] ?? '')), 0, 200);
    $res = db_tx(function () use ($sid, $tid, $by, $o, $actor, $note) {
        if (!row('SELECT id FROM students WHERE id=? FOR UPDATE', [$sid])) return ['ok' => false, 'error' => 'O\'quvchi topilmadi'];
        $reg = mock_reg_row($sid, $tid, true);
        if (!$reg) return ['ok' => false, 'error' => 'Ro\'yxatda yo\'q (allaqachon chiqarilgan)', 'gone' => true];
        $t = mock_test_row($tid);
        if (!$t) return ['ok' => false, 'error' => 'MOCK topilmadi'];
        if ($by === 'student') {
            $chk = mock_cancel_check($reg, $t, (bool)val('SELECT 1 FROM responses WHERE test_id=? AND student_id=?', [$tid, $sid]));
            if (!$chk['ok']) return ['ok' => false, 'error' => $chk['reason']];
            $refund = $chk['refund'];
        } else {
            $refund = $reg['pay_status'] === 'paid' && ($o['refund'] ?? true) ? (int)$reg['paid_amount'] : 0;
        }
        q('DELETE FROM test_registrations WHERE test_id=? AND student_id=?', [$tid, $sid]);
        $bal = null;
        if ($refund > 0) {
            $w = wallet_post($sid, $refund, 'refund', ['ref_type' => 'test', 'ref_id' => $tid, 'actor' => $actor, 'note' => '«' . $t['title'] . '»' . ($note !== '' ? ' — ' . $note : '')]);
            if (!$w['ok']) throw new RuntimeException('Qaytarish yozilmadi: ' . $w['error']);
            $bal = $w['balance'];
        }
        audit('mock_cancel', 'reg', $tid, ['sid' => $sid, 'pay_status' => $reg['pay_status'], 'paid_amount' => (int)$reg['paid_amount'], 'via' => $reg['via']],
            ['by' => $by, 'refund' => $refund, 'note' => $note], $actor);
        return ['ok' => true, 'error' => '', 'refund' => $refund, 'status' => (string)$reg['pay_status'], 'title' => (string)$t['title'], 'balance' => $bal, 'paid' => (int)$reg['paid_amount']];
    });
    if ($res['ok'] && ($o['notify'] ?? true) && ($o['via'] ?? '') !== 'bot') {
        if ($res['refund'] > 0) wallet_notify($sid, 'regrf', $tid, "↩️ «" . tg_h($res['title']) . "» MOCK ro'yxatidan " . ($by === 'admin' ? 'chiqarildingiz' : 'chiqdingiz')
            . ".\nHamyoningizga qaytarildi: <b>+" . tg_h(som($res['refund'])) . "</b>. Balans: <b>" . tg_h(som((int)$res['balance'])) . "</b>");
        elseif ($by === 'admin' && $res['status'] === 'paid') wallet_notify($sid, 'regrf', $tid, "«" . tg_h($res['title']) . "» MOCK ro'yxatidan chiqarildingiz." . ($note !== '' ? "\nIzoh: " . tg_h($note) : ''));
        elseif ($by === 'student') wallet_notify($sid, 'regrf', $tid, $res['status'] === 'unpaid' ? "📌 «" . tg_h($res['title']) . "» MOCK uchun band bekor qilindi (saytda)."   // 2.5.1: ikkinchi kanalda tasdiq
            : "↩️ «" . tg_h($res['title']) . "» MOCK ro'yxatidan chiqdingiz (saytda).");
    }
    return $res;
}

/** Band qilingan ro'yxatni hozir hamyondan to'lash (o'quvchi «To'lash» ni bosganda yoki bot tugmasi) */
function mock_pay_unpaid(int $sid, int $tid, ?string $actor = null, ?int $expectPrice = null): array
{
    $actor = $actor ?? 'student:' . $sid;
    return db_tx(function () use ($sid, $tid, $actor, $expectPrice) {
        $st = row('SELECT balance FROM students WHERE id=? FOR UPDATE', [$sid]);
        $reg = $st ? mock_reg_row($sid, $tid, true) : null;
        $t = mock_test_row($tid);
        $price = $t ? mock_price($t) : 0;
        $base = ['ok' => false, 'status' => 'error', 'error' => '', 'price' => $price, 'balance' => $st ? (int)$st['balance'] : 0, 'need' => 0, 'title' => $t ? (string)$t['title'] : ''];
        if (!$reg || !$t || $reg['pay_status'] !== 'unpaid') return ['error' => 'To\'lanishi kerak bo\'lgan band topilmadi'] + $base;
        if (mock_is_over($t)) return ['error' => 'MOCK o\'tib bo\'lgan'] + $base;
        if ($expectPrice !== null && $expectPrice !== $price) return ['status' => 'price', 'error' => 'MOCK narxi o\'zgardi: endi ' . mock_price_label($t) . '. Qayta tasdiqlang.'] + $base;
        if ($price === 0) {
            q('UPDATE test_registrations SET pay_status="free" WHERE test_id=? AND student_id=?', [$tid, $sid]);
            return ['ok' => true, 'status' => 'free'] + $base;
        }
        if ((int)$st['balance'] < $price) return ['status' => 'insufficient', 'need' => $price - (int)$st['balance'], 'error' => 'Balans yetarli emas: yana ' . som($price - (int)$st['balance']) . ' kerak'] + $base;
        $c = mock_charge($sid, $tid, $price, $actor, (string)$t['title']);
        if (!$c['ok']) return ['error' => $c['error']] + $base;
        q('UPDATE test_registrations SET pay_status="paid", paid_amount=?, paid_at=NOW(), tx_id=? WHERE test_id=? AND student_id=?', [$price, $c['tx_id'], $tid, $sid]);
        audit('mock_pay', 'reg', $tid, ['sid' => $sid, 'pay_status' => 'unpaid'], ['pay_status' => 'paid', 'price' => $price, 'tx' => $c['tx_id']], $actor);
        return ['ok' => true, 'status' => 'paid', 'balance' => $c['balance']] + $base;
    });
}

/**
 * Hisob to'ldirilgach band qilingan MOCK larni avtomatik to'laydi (eng eskisi birinchi; balans yetganlari).
 * Qaytaradi: [['test_id', 'title', 'price'], …]
 */
function mock_settle_unpaid(int $sid, ?string $actor = null): array
{
    $actor = $actor ?? actor_tag();
    return db_tx(function () use ($sid, $actor) {
        $st = row('SELECT balance FROM students WHERE id=? FOR UPDATE', [$sid]);
        if (!$st) return [];
        $bal = (int)$st['balance'];
        $out = [];
        foreach (rows('SELECT g.test_id, t.title, t.price, t.online, t.online_end, t.test_date, t.published
                       FROM test_registrations g JOIN tests t ON t.id=g.test_id
                       WHERE g.student_id=? AND g.pay_status="unpaid" ORDER BY g.created_at, g.test_id', [$sid]) as $r) {
            if (mock_is_over($r)) continue;
            $tid = (int)$r['test_id'];
            $price = mock_price($r);
            if ($price === 0) { q('UPDATE test_registrations SET pay_status="free" WHERE test_id=? AND student_id=? AND pay_status="unpaid"', [$tid, $sid]); continue; }
            if ($bal < $price) continue;
            // qator avval egallanadi (shu payt band bekor qilingan bo'lsa — pul yechilmaydi)
            if (!q('UPDATE test_registrations SET pay_status="paid", paid_amount=?, paid_at=NOW() WHERE test_id=? AND student_id=? AND pay_status="unpaid"', [$price, $tid, $sid])->rowCount()) continue;
            $c = mock_charge($sid, $tid, $price, $actor, (string)$r['title']);
            if (!$c['ok']) throw new RuntimeException('Yechim yozilmadi: ' . $c['error']);
            q('UPDATE test_registrations SET tx_id=? WHERE test_id=? AND student_id=?', [$c['tx_id'], $tid, $sid]);
            audit('mock_settle', 'reg', $tid, ['sid' => $sid, 'pay_status' => 'unpaid'], ['pay_status' => 'paid', 'price' => $price, 'tx' => $c['tx_id']], $actor);
            $bal = $c['balance'];
            $out[] = ['test_id' => $tid, 'title' => (string)$r['title'], 'price' => $price];
        }
        return $out;
    });
}

/**
 * Muddati o'tgan bandlarni bekor qiladi: o'quvchi o'zi band qilgan (sayt, bot, ro'yxatdan o'tish), MOCK ro'yxati yopilgan yoki MOCK o'tgan.
 * Kutilayotgan cheki bor o'quvchining bandi chek ko'rib chiqilguncha saqlanadi (MOCK o'tib ketmagan bo'lsa).
 * Admin qo'ygan band (via=admin) avtomatik bekor bo'lmaydi. Qaytaradi: bekor qilinganlar soni.
 */
function mock_expire_unpaid(?int $tid = null, ?int $sid = null): int
{
    $w = ['g.pay_status="unpaid"', 'g.via IN ("web","bot","register")'];
    $p = [];
    if ($tid) { $w[] = 'g.test_id=?'; $p[] = $tid; }
    if ($sid) { $w[] = 'g.student_id=?'; $p[] = $sid; }
    $n = 0;
    foreach (rows('SELECT g.test_id, g.student_id, g.via, t.title, t.reg_open, t.online, t.online_end, t.test_date, t.published,
                          (SELECT COUNT(*) FROM pay_requests pr WHERE pr.student_id=g.student_id AND pr.status="pending") pend
                   FROM test_registrations g JOIN tests t ON t.id=g.test_id WHERE ' . implode(' AND ', $w), $p) as $r) {
        $over = mock_is_over($r);
        if (!$over && ((int)$r['reg_open'] || (int)$r['pend'] > 0)) continue;
        if (!q('DELETE FROM test_registrations WHERE test_id=? AND student_id=? AND pay_status="unpaid"', [$r['test_id'], $r['student_id']])->rowCount()) continue;
        $n++;
        audit('mock_expire', 'reg', (int)$r['test_id'], ['sid' => (int)$r['student_id'], 'pay_status' => 'unpaid', 'via' => $r['via']], ['over' => $over], 'system');
        if (!$over) wallet_notify((int)$r['student_id'], 'regex', (int)$r['test_id'], "⌛ «" . tg_h($r['title']) . "» MOCK uchun band qilingan joyingiz bekor qilindi: ro'yxat yopildi, to'lov qilinmadi.");
    }
    return $n;
}

/** Ro'yxat yopilsa bekor bo'ladigan bandlar soni (admin ogohlantirishi uchun) */
function mock_unpaid_count(int $tid, bool $expiringOnly = false): int
{
    return (int)val('SELECT COUNT(*) FROM test_registrations WHERE test_id=? AND pay_status="unpaid"' . ($expiringOnly ? ' AND via IN ("web","bot","register")' : ''), [$tid]);
}

/**
 * Onlayn MOCK ni boshlash mumkinmi (sayt va bot uchun bitta qoida). Bepul MOCK — hozirgidek;
 * pullik — faqat ro'yxatda va to'lov holati «band» bo'lmasa (to'langan, imtiyoz yoki narx qo'yilishidan oldin yozilgan).
 * Qaytaradi: ['ok', 'reason', 'code' => ''|noreg|unpaid]
 */
function mock_can_start(int $sid, array $t, bool $lock = false): array
{
    $price = mock_price($t);
    if ($price === 0) return ['ok' => true, 'reason' => '', 'code' => ''];
    $reg = mock_reg_row($sid, (int)$t['id'], $lock);
    if (!$reg) return ['ok' => false, 'reason' => 'Bu MOCK pullik (' . som($price) . '). Avval ro\'yxatdan o\'ting va to\'lovni amalga oshiring.', 'code' => 'noreg'];
    if ($reg['pay_status'] === 'unpaid') return ['ok' => false, 'reason' => 'Joyingiz band qilingan, lekin to\'lov qilinmagan (' . som($price) . '). Hisobni to\'ldiring — to\'lov avtomatik yechiladi.', 'code' => 'unpaid'];
    return ['ok' => true, 'reason' => '', 'code' => ''];
}

/**
 * Onlayn MOCK ni boshlash — javob yozuvini ochish (sayt va bot uchun bitta yo'l). O'quvchi qatori qulflanadi va to'lov sharti
 * qulf ostida qayta tekshiriladi: bir vaqtda yuborilgan «bekor qilish» bilan poyga bo'lmaydi (mock_cancel ham shu qatorni qulflaydi).
 * Qaytaradi: ['ok', 'reason', 'code', 'resp' => javob qatori yoki null]
 */
function mock_start_online(int $sid, array $test): array
{
    return db_tx(function () use ($sid, $test) {
        $none = ['ok' => false, 'reason' => '', 'code' => '', 'resp' => null];
        if (!row('SELECT id FROM students WHERE id=? AND archived_at IS NULL FOR UPDATE', [$sid])) return ['reason' => 'Hisob topilmadi'] + $none;
        $r = row('SELECT * FROM responses WHERE test_id=? AND student_id=?', [$test['id'], $sid]);
        if ($r) return ['ok' => true, 'reason' => '', 'code' => '', 'resp' => $r];
        if (!online_open($test)) return ['reason' => 'Test hozir ochiq emas', 'code' => 'closed'] + $none;
        $can = mock_can_start($sid, $test, true);
        if (!$can['ok']) return ['reason' => $can['reason'], 'code' => $can['code']] + $none;
        q('INSERT IGNORE INTO responses (test_id, student_id, answers, source, status, started_at) VALUES (?,?,?,?,?,NOW())', [$test['id'], $sid, '{}', 'online', 'in_progress']);
        return ['ok' => true, 'reason' => '', 'code' => '', 'resp' => row('SELECT * FROM responses WHERE test_id=? AND student_id=?', [$test['id'], $sid])];
    });
}

/** O'quvchining MOCK lari (sayt va bot uchun bir xil ro'yxat): xona/o'rin, javob holati, to'lov va chiqish imkoni bilan */
function mock_student_list(int $sid): array
{
    $list = rows('SELECT t.id, t.title, t.subject, t.test_date, t.reg_open, t.online, t.online_start, t.online_end, t.duration_min, t.published, t.price, t.tg_enabled,
                         g.seat, g.created_at reg_at, g.pay_status, g.paid_amount, g.paid_at, g.via, rm.name room, rm.proctor,
                         (SELECT status FROM responses r WHERE r.test_id=t.id AND r.student_id=g.student_id) rstatus
                  FROM test_registrations g JOIN tests t ON t.id=g.test_id LEFT JOIN test_rooms rm ON rm.id=g.room_id
                  WHERE g.student_id=? ORDER BY t.test_date IS NULL, t.test_date DESC, t.id DESC', [$sid]);
    foreach ($list as &$x) {
        $x['over'] = mock_is_over($x);
        $x['cancel'] = mock_cancel_check($x, $x, $x['rstatus'] !== null);
    }
    unset($x);
    return $list;
}

/** Yozilish mumkin bo'lgan MOCK lar (ro'yxat ochiq, o'tib ketmagan, o'quvchi hali yozilmagan) */
function mock_open_list(int $sid = 0): array
{
    $out = [];
    foreach (rows('SELECT t.id, t.title, t.subject, t.test_date, t.reg_open, t.online, t.online_start, t.online_end, t.duration_min, t.published, t.price,
                          (SELECT COUNT(*) FROM test_registrations x WHERE x.test_id=t.id AND x.pay_status<>"unpaid") n_reg
                   FROM tests t WHERE t.reg_open=1 AND NOT EXISTS (SELECT 1 FROM test_registrations g WHERE g.test_id=t.id AND g.student_id=?)
                   ORDER BY t.test_date IS NULL, t.test_date, t.id', [$sid]) as $t) {
        if (!mock_is_over($t)) $out[] = $t;
    }
    return $out;
}

/**
 * Admin: mavjud ro'yxatning to'lov holatini o'zgartirish.
 * $op: cash (naqd to'landi: kirim + yechim), wallet (hamyondan yechish), waive (imtiyoz), unpaid (to'lov talab qilish — bepul yozilganlar uchun).
 */
function mock_admin_pay(int $sid, int $tid, string $op, string $note = '', ?string $actor = null): array
{
    $actor = $actor ?? actor_tag();
    $note = mb_substr(trim($note), 0, 200);
    $res = db_tx(function () use ($sid, $tid, $op, $note, $actor) {
        $st = row('SELECT balance FROM students WHERE id=? FOR UPDATE', [$sid]);
        $reg = $st ? mock_reg_row($sid, $tid, true) : null;
        $t = mock_test_row($tid);
        if (!$reg || !$t) return ['ok' => false, 'error' => 'Ro\'yxat topilmadi'];
        $price = mock_price($t);
        $from = (string)$reg['pay_status'];
        if (!in_array($from, ['unpaid', 'free'], true)) return ['ok' => false, 'error' => 'Bu ro\'yxat holati: ' . mb_strtolower(REG_PAY_LABEL[$from] ?? $from)];
        if ($op === 'waive') {
            q('UPDATE test_registrations SET pay_status="waived" WHERE test_id=? AND student_id=?', [$tid, $sid]);
            audit('reg_waive', 'reg', $tid, ['sid' => $sid, 'pay_status' => $from], ['pay_status' => 'waived', 'note' => $note], $actor);
            return ['ok' => true, 'error' => '', 'status' => 'waived', 'title' => $t['title'], 'price' => $price];
        }
        if ($price <= 0) return ['ok' => false, 'error' => 'MOCK bepul — to\'lov kerak emas'];
        if ($op === 'unpaid') {
            if ($from !== 'free') return ['ok' => false, 'error' => 'Faqat bepul yozilganlardan to\'lov talab qilinadi'];
            q('UPDATE test_registrations SET pay_status="unpaid", via="admin" WHERE test_id=? AND student_id=?', [$tid, $sid]);   // admin bandi — muddat bilan bekor bo'lmaydi
            audit('reg_require', 'reg', $tid, ['sid' => $sid, 'pay_status' => $from], ['pay_status' => 'unpaid', 'note' => $note], $actor);
            return ['ok' => true, 'error' => '', 'status' => 'unpaid', 'title' => $t['title'], 'price' => $price];
        }
        if ($op !== 'cash' && $op !== 'wallet') return ['ok' => false, 'error' => 'Noma\'lum amal'];
        if ($op === 'wallet' && (int)$st['balance'] < $price) return ['ok' => false, 'error' => 'Balans yetarli emas: ' . som((int)$st['balance']) . ', kerak ' . som($price)];
        if ($op === 'cash') {
            $w = wallet_post($sid, $price, 'topup', ['ref_type' => 'test', 'ref_id' => $tid, 'method' => 'naqd', 'note' => '«' . $t['title'] . '» uchun' . ($note !== '' ? ', ' . $note : ''), 'actor' => $actor]);
            if (!$w['ok']) return ['ok' => false, 'error' => $w['error']];
        }
        $c = mock_charge($sid, $tid, $price, $actor, (string)$t['title'], $op === 'cash');
        if (!$c['ok']) throw new RuntimeException('Yechim yozilmadi: ' . $c['error']);
        q('UPDATE test_registrations SET pay_status="paid", paid_amount=?, paid_at=NOW(), tx_id=? WHERE test_id=? AND student_id=?', [$price, $c['tx_id'], $tid, $sid]);
        audit('reg_' . $op, 'reg', $tid, ['sid' => $sid, 'pay_status' => $from], ['pay_status' => 'paid', 'price' => $price, 'tx' => $c['tx_id'], 'note' => $note], $actor);
        return ['ok' => true, 'error' => '', 'status' => 'paid', 'title' => $t['title'], 'price' => $price, 'balance' => $c['balance'], 'cash' => $op === 'cash'];
    });
    if ($res['ok'] && in_array($res['status'], ['paid', 'waived'], true))
        mock_reg_notify($sid, ['status' => $res['status'], 'price' => (int)$res['price'], 'title' => (string)$res['title'], 'balance' => (int)($res['balance'] ?? 0), 'cash' => !empty($res['cash']), 'test' => ['id' => $tid]]);
    if ($res['ok'] && $res['status'] === 'unpaid')
        wallet_notify($sid, 'regpd', $tid, "📌 «" . tg_h($res['title']) . "» MOCK uchun to'lov talab qilinadi: <b>" . tg_h(som((int)$res['price'])) . "</b>.\nHisobni to'ldiring — to'lov avtomatik yechiladi.",
            wallet_topup_kb((int)$res['price'] - wallet_balance($sid)));
    return $res;
}

/** MOCK narxi o'zgarganda: narx 0 bo'lsa bandlar «bepul» ga o'tadi (to'langanlar o'zgarmaydi) */
function mock_price_changed(int $tid, int $old, int $new): void
{
    if ($old === $new) return;
    audit('test_price', 'test', $tid, ['price' => $old], ['price' => $new]);
    if ($new === 0) q('UPDATE test_registrations SET pay_status="free" WHERE test_id=? AND pay_status="unpaid"', [$tid]);
}

/** Vaqtli ish: muddati o'tgan bandlar. cron har daqiqa chaqiradi; $lazy — sahifalardan (cron sozlanmagan bo'lsa ham), daqiqasiga ko'pi bilan bir marta */
function wallet_tick(bool $lazy = false): void
{
    if ($lazy && time() - (int)app_setting('wallet_tick', '0') < 60) return;
    try {
        set_app_setting('wallet_tick', (string)time());
        mock_expire_unpaid();
        mock_due_remind();   // 2.5.1
    } catch (Throwable $e) { error_log('[MOCK wallet_tick] ' . $e->getMessage()); }
}

/**
 * 2.5.1: joyi band, lekin to'lanmagan MOCK boshlanishiga 24 soatdan kam qolganda — o'quvchiga botda bir marta eslatma
 * (yetishmayotgan summa bilan «➕ Hisobni to'ldirish» yoki balans yetsa «💳 To'lash»). Kechasi yuborilmaydi (9:00–21:00).
 */
function mock_due_remind(bool $anyHour = false): int
{
    if (!function_exists('tg_ready') || !tg_ready()) return 0;
    $h = (int)date('G');
    if (!$anyHour && ($h < 9 || $h >= 21)) return 0;
    $n = 0;
    foreach (rows('SELECT g.test_id, g.student_id, t.title, t.price, t.online, t.online_start, t.online_end, t.test_date, t.published, s.balance
                   FROM test_registrations g JOIN tests t ON t.id=g.test_id JOIN students s ON s.id=g.student_id
                   WHERE g.pay_status="unpaid" AND s.tg_chat_id IS NOT NULL AND s.archived_at IS NULL') as $r) {
        $b = mock_begin_ts($r);
        if ($b <= time() || $b - time() > 86400 || mock_is_over($r)) continue;
        $tid = (int)$r['test_id']; $sid = (int)$r['student_id'];
        if (val('SELECT 1 FROM tg_queue WHERE kind="regdue" AND test_id=? AND student_id=?', [$tid, $sid])) continue;   // bir marta
        $price = mock_price($r);
        $need = max(0, $price - (int)$r['balance']);
        $when = !empty($r['online']) ? tg_dt((string)$r['online_start']) . ' (onlayn)' : date('d.m.Y', $b);
        wallet_notify($sid, 'regdue', $tid, "📌 «" . tg_h($r['title']) . "» — " . $when . ".\nJoyingiz band, lekin to'lov qilinmagan: <b>" . tg_h(som($price)) . "</b>."
            . ($need > 0 ? "\nHisobni to'ldiring — chek tasdiqlangach to'lov avtomatik yechiladi. To'lanmasa, ro'yxat yopilganda band bekor bo'ladi." : "\nBalansingiz yetarli — «💳 To'lash» ni bosing."),
            $need > 0 ? wallet_topup_kb($need) : ['inline_keyboard' => [[['text' => '💳 To‘lash: ' . som($price), 'callback_data' => 'join:' . $tid]]]]);
        $n++;
    }
    return $n;
}
