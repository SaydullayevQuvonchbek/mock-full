<?php
defined('APP_ROOT') || exit;
/**
 * 2.5.1: Telegram bot — o'quvchi hamyoni, chek yuborish (rasm/PDF), «MOCK ga yozilish», ro'yxatdan chiqish, profil.
 * Pul qoidalari saytdagi bilan bir xil: pay_request_create, mock_register, mock_cancel (inc/wallet.php, inc/mock_reg.php).
 * Holatlar (tg_state.step): wamt — summa kutilmoqda, wcard — karta tanlash, wfile — chek fayli kutilmoqda (1 soat), wfid — fayl bor, summa
 * kutilmoqda yoki izohdagi summani tasdiqlash (30 daqiqa), wdone — chek albomi qabul qilingan (albomdagi qolgan rasmlar e'tiborsiz).
 * Bitta chatning yangilanishlari ketma-ket ishlanadi (tg_handle_update dagi qulf) — albom yoki ikki marta bosish ikkita chek yaratmaydi.
 */

const TG_MENU_V = 2;   // menyu versiyasi: yangi tugmalar qo'shilsa oshiriladi (o'quvchiga bir marta yangi menyu yuboriladi)
const TG_W_STEPS = ['wamt', 'wcard', 'wfile', 'wfid', 'wdone'];

/** Hamyon holati (eskirgan bo'lsa o'chiriladi) */
function tg_w_state(int $chat): ?array
{
    $s = row('SELECT * FROM tg_state WHERE chat_id=?', [$chat]);
    if (!$s || !in_array($s['step'], TG_W_STEPS, true)) return null;
    $ttl = ['wdone' => 120, 'wfid' => 1800][$s['step']] ?? 3600;   // eski holat bilan begona rasm chek bo'lib qolmasin
    if (!empty($s['updated_at']) && time() - strtotime((string)$s['updated_at']) > $ttl) {
        q('DELETE FROM tg_state WHERE chat_id=? AND step=?', [$chat, $s['step']]);
        return null;
    }
    $s['d'] = json_decode((string)$s['data'], true) ?: [];
    return $s;
}

function tg_w_set(int $chat, string $step, array $d): void
{
    q('REPLACE INTO tg_state (chat_id, step, data) VALUES (?,?,?)', [$chat, $step, json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
}

/** Matndan summa: «50000», «50 000 so'm», «chek 50.000» → 50000. Eng kam summa va chegaradan tashqaridagilar e'tiborsiz (0) */
function tg_w_amount(string $s): int
{
    $v = money_in($s);
    if ($v >= pay_min() && $v <= PAY_MAX_AMOUNT) return $v;
    if (preg_match_all('/\d{1,3}(?:[ .,\x{00A0}\x{202F}\'’]\d{3})+|\d+/u', $s, $m)) {
        foreach ($m[0] as $c) { $v = money_in($c); if ($v >= pay_min() && $v <= PAY_MAX_AMOUNT) return $v; }
    }
    return 0;
}

/** Summa matnidan qolgani — izoh (masalan «50000 MOCK 5 uchun» → «MOCK 5 uchun») */
function tg_w_note(string $s): string
{
    $s = trim((string)preg_replace('/^\s*(\d{1,3}(?:[ .,\x{00A0}\x{202F}\'’]\d{3})+|\d+)\s*(so[\'‘’ʻ`]?m|sum|сум|uzs)?[\s,.:;—-]*/iu', '', $s, 1));
    return mb_substr($s, 0, 100);
}

/** O'quvchining to'lov kutayotgan bandlari va yetishmayotgan summa */
function tg_w_due(int $sid, int $bal): array
{
    $unpaid = array_values(array_filter(mock_student_list($sid), fn($x) => $x['pay_status'] === 'unpaid' && !$x['over']));
    return [$unpaid, max(0, array_sum(array_map(fn($x) => mock_price($x), $unpaid)) - $bal)];
}

/* ---------------- 💰 Hamyon ---------------- */

/** Hamyon xabari: [matn, klaviatura] */
function tg_wallet_view(int $sid): array
{
    $st = row('SELECT balance FROM students WHERE id=?', [$sid]);
    $bal = (int)($st['balance'] ?? 0);
    $s = "💰 <b>Hamyon</b>\nBalans: <b>" . tg_h(som($bal)) . "</b>";
    $kb = [];
    $pend = rows('SELECT id, amount, created_at FROM pay_requests WHERE student_id=? AND status="pending" ORDER BY id', [$sid]);
    foreach ($pend as $p) {
        $s .= "\n⏳ Tekshirilmoqda: " . tg_h(som((int)$p['amount'])) . " (chek #" . (int)$p['id'] . ", " . date('d.m H:i', strtotime((string)$p['created_at'])) . ")";
        if (count($kb) < 3) $kb[] = [['text' => '🚫 Chek #' . (int)$p['id'] . ' ni bekor qilish', 'callback_data' => 'w:c:' . (int)$p['id']]];
    }
    [$unpaid, $need] = tg_w_due($sid, $bal);
    foreach ($unpaid as $u) {
        $pr = mock_price($u);
        $s .= "\n📌 To‘lov kutilmoqda: «" . tg_h($u['title']) . "» — " . tg_h(som($pr));
        if ($bal >= $pr && count($kb) < 6) $kb[] = [['text' => '💳 To‘lash: ' . mb_substr((string)$u['title'], 0, 28), 'callback_data' => 'join:' . (int)$u['id']]];
    }
    if ($need > 0) $s .= "\nMOCK lar uchun yana kerak: <b>" . tg_h(som($need)) . "</b>" . ($pend ? ' (chek tasdiqlansa yetishi mumkin)' : '');
    $last = wallet_history($sid, 3);
    if ($last) {
        $s .= "\n\n<b>So‘nggi yozuvlar:</b>";
        foreach ($last as $h) $s .= "\n" . date('d.m', strtotime((string)$h['created_at'])) . " · " . ((int)$h['amount'] > 0 ? '+' : '') . tg_h(som((int)$h['amount'])) . " · " . tg_h(mb_substr(wallet_tx_label($h), 0, 48));
    }
    $s .= "\n\nMOCK larga yozilganda to‘lov shu balansdan yechiladi. Hisobni to‘ldirish: kartaga o‘tkazib, chekni shu yerga yuborasiz — admin tekshirgach summa balansga tushadi.";
    array_unshift($kb, [['text' => '➕ Hisobni to‘ldirish', 'callback_data' => 'w:t' . ($need > 0 ? ':' . max($need, pay_min()) : '')], ['text' => '🧾 Tarix', 'callback_data' => 'w:h']]);
    $kb[] = [['text' => '🌐 Saytda ochish', 'callback_data' => 'w:s']];
    return [$s, ['inline_keyboard' => $kb]];
}

/** 🧾 Tarix: so'nggi 15 yozuv va cheklar */
function tg_wallet_history_text(int $sid): string
{
    $h = wallet_history($sid, 15);
    $s = "🧾 <b>Kirim va chiqimlar</b>";
    if (!$h) $s .= "\nHali yozuv yo‘q.";
    foreach ($h as $t) $s .= "\n" . date('d.m.Y H:i', strtotime((string)$t['created_at'])) . "\n   " . ((int)$t['amount'] > 0 ? '+' : '') . "<b>" . tg_h(som((int)$t['amount'])) . "</b> · " . tg_h(mb_substr(wallet_tx_label($t), 0, 70)) . " · qoldiq " . tg_h(som((int)$t['balance_after']));
    $req = rows('SELECT id, amount, approved_amount, status, review_note, created_at FROM pay_requests WHERE student_id=? ORDER BY id DESC LIMIT 6', [$sid]);
    if ($req) {
        $s .= "\n\n<b>Cheklarim:</b>";
        $ic = ['pending' => '⏳', 'approved' => '✅', 'rejected' => '❌', 'canceled' => '🚫'];
        foreach ($req as $r) {
            $s .= "\n" . ($ic[$r['status']] ?? '•') . " #" . (int)$r['id'] . " · " . tg_h(som((int)($r['status'] === 'approved' ? $r['approved_amount'] : $r['amount']))) . " · " . date('d.m', strtotime((string)$r['created_at'])) . " · " . tg_h(mb_strtolower(PAY_STATUS[$r['status']] ?? $r['status']));
            if ($r['status'] === 'rejected' && (string)$r['review_note'] !== '') $s .= " — " . tg_h(mb_substr((string)$r['review_note'], 0, 60));
        }
    }
    return $s;
}

/* ---------------- ➕ Hisobni to'ldirish ---------------- */

/** To'ldirishni boshlash: karta(lar), yo'riqnoma, summa so'raladi. $hint — taklif qilinadigan summa (MOCK uchun yetishmayotgani) */
function tg_topup_start(int $chat, array $st, int $hint = 0): void
{
    $sid = (int)$st['id'];
    $np = (int)val('SELECT COUNT(*) FROM pay_requests WHERE student_id=? AND status="pending"', [$sid]);
    if ($np >= pay_max_pending()) {
        tg_send($chat, "⏳ Sizda " . $np . " ta chek tekshirilmoqda. Admin ko‘rib chiqqach yangisini yuborishingiz mumkin — natija shu yerga keladi.", ['inline_keyboard' => [[['text' => '💰 Hamyon', 'callback_data' => 'w:b']]]]);
        return;
    }
    $cards = pay_cards();
    $s = "➕ <b>Hisobni to‘ldirish</b>\n\n";
    if ($cards) {
        $s .= "1️⃣ Pulni kartaga o‘tkazing (Click, Payme yoki bank ilovasi orqali):";
        foreach ($cards as $c) {
            $no = preg_match('/^[\d\s-]{12,}$/', $c['no']) ? (string)preg_replace('/[\s-]+/', '', $c['no']) : $c['no'];
            $s .= "\n💳 <code>" . tg_h($no) . "</code>" . ($c['owner'] !== '' || $c['bank'] !== '' ? " — " . tg_h(trim($c['owner'] . ($c['owner'] !== '' && $c['bank'] !== '' ? ', ' : '') . $c['bank'])) : '');
        }
        $s .= "\n<i>Raqamni bossangiz, nusxa olinadi.</i>";
    } else {
        $s .= "1️⃣ Karta raqamini o‘quv markazidan so‘rang yoki naqd to‘lang (naqd to‘lovni admin balansingizga o‘zi yozadi).";
    }
    if (pay_note() !== '') $s .= "\n\nℹ️ " . tg_h(mb_substr(pay_note(), 0, 600));
    $s .= "\n\n2️⃣ Qancha o‘tkazdingiz? Summani raqam bilan yozing, masalan: <code>50000</code> (eng kami " . tg_h(som(pay_min())) . ")";
    $s .= "\n3️⃣ So‘ng chek rasmini (skrinshot) yoki PDF ni yuborasiz.\n\nRasm izohiga summani yozib, bitta xabarda ham yuborsa bo‘ladi. Bekor qilish: /menu";
    $kb = [];
    if ($hint >= pay_min() && $hint <= PAY_MAX_AMOUNT) $kb[] = [['text' => '✅ ' . som($hint) . ' o‘tkazdim', 'callback_data' => 'w:a:' . $hint]];
    $kb[] = [['text' => 'Bekor qilish', 'callback_data' => 'w:x']];
    tg_w_set($chat, 'wamt', []);
    tg_send($chat, $s, ['inline_keyboard' => $kb]);
}

/** Summa olindi: kartani so'rash (bir nechta karta bo'lsa) yoki chekni */
function tg_topup_amount(int $chat, array $st, int $amount, array $d = []): void
{
    $cards = pay_cards();
    if (!empty($d['f'])) {   // chek fayli avval yuborilgan
        if (count($cards) > 1 && !isset($d['c'])) { tg_topup_ask_card($chat, ['a' => $amount] + $d); return; }
        tg_topup_create($chat, $st, $amount, $d);
        return;
    }
    if (count($cards) > 1 && !isset($d['c'])) { tg_topup_ask_card($chat, ['a' => $amount] + $d); return; }
    tg_w_set($chat, 'wfile', ['a' => $amount, 'c' => (int)($d['c'] ?? 0)]);
    tg_send($chat, "Summa: <b>" . tg_h(som($amount)) . "</b>.\n3️⃣ Endi to‘lov chekini yuboring: skrinshot (rasm) yoki PDF — 📎 tugmasi orqali.\n\nSummani o‘zgartirish uchun yangisini yozing. Bekor qilish: /menu");
}

function tg_topup_ask_card(int $chat, array $d): void
{
    $kb = [];
    foreach (pay_cards() as $i => $c) $kb[] = [['text' => '💳 ' . mb_substr($c['no'], 0, 24) . ($c['bank'] !== '' ? ' · ' . mb_substr($c['bank'], 0, 14) : ''), 'callback_data' => 'w:k:' . $i]];
    tg_w_set($chat, 'wcard', $d);
    tg_send($chat, "Summa: <b>" . tg_h(som((int)$d['a'])) . "</b>. Qaysi kartaga o‘tkazdingiz?", ['inline_keyboard' => $kb]);
}

/** Chekni Telegramdan yuklab olish (uploads/pay/tmp ga). Qaytaradi: vaqtinchalik fayl yo'li yoki null ($err) */
function tg_file_fetch(string $fileId, ?string &$err): ?string
{
    $err = '';
    $r = tg_call('getFile', ['file_id' => $fileId], null, 20);
    if (!$r['ok'] || empty($r['result']['file_path'])) {
        $err = stripos((string)$r['desc'], 'too big') !== false ? 'Fayl juda katta (ko‘pi bilan 8 MB). Skrinshot yuboring.' : 'Faylni Telegramdan olib bo‘lmadi. Qayta yuboring.';
        return null;
    }
    if ((int)($r['result']['file_size'] ?? 0) > PAY_FILE_MAX) { $err = 'Fayl juda katta (ko‘pi bilan 8 MB). Skrinshot yuboring.'; return null; }
    $fp = (string)$r['result']['file_path'];
    if (!preg_match('#^[\w./-]{1,200}$#', $fp) || strpos($fp, '..') !== false) { $err = 'Faylni olib bo‘lmadi.'; return null; }
    $dir = pay_dir() . '/tmp';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) { $err = 'Faylni saqlab bo‘lmadi (papka).'; return null; }
    $tmp = $dir . '/' . bin2hex(random_bytes(16)) . '.r';
    $fh = @fopen($tmp, 'wb');
    if (!$fh) { $err = 'Faylni saqlab bo‘lmadi.'; return null; }
    $ch = curl_init(tg_api_base() . '/file/bot' . tg_token() . '/' . $fp);
    curl_setopt_array($ch, [CURLOPT_FILE => $fh, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 60, CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_MAXFILESIZE => PAY_FILE_MAX + 1, CURLOPT_NOPROGRESS => false,
        CURLOPT_PROGRESSFUNCTION => function ($c, $dlTotal, $dlNow) { return $dlNow > PAY_FILE_MAX ? 1 : 0; }]);
    $ok = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if (PHP_VERSION_ID < 80000) curl_close($ch);
    fclose($fh);
    clearstatcache(true, $tmp);
    $size = is_file($tmp) ? (int)filesize($tmp) : 0;
    if (!$ok || $http !== 200 || $size <= 0 || $size > PAY_FILE_MAX) {
        @unlink($tmp);
        $err = $size > PAY_FILE_MAX ? 'Fayl juda katta (ko‘pi bilan 8 MB). Skrinshot yuboring.' : 'Faylni Telegramdan olib bo‘lmadi. Qayta yuboring.';
        return null;
    }
    return $tmp;
}

/** Chekni yaratish (sayt bilan bir xil tekshiruv va saqlash). $d: f (file_id), t (p|d), c (karta), n (izoh) */
function tg_topup_create(int $chat, array $st, int $amount, array $d): void
{
    $sid = (int)$st['id'];
    $err = '';
    $tmp = tg_file_fetch((string)$d['f'], $err);
    if ($tmp === null) {
        tg_w_set($chat, 'wfile', ['a' => $amount, 'c' => (int)($d['c'] ?? 0)]);
        tg_send($chat, '⚠️ ' . tg_h($err));
        return;
    }
    $cards = pay_cards();
    $ci = (int)($d['c'] ?? 0);
    $cardTo = isset($cards[$ci]) ? pay_card_label($cards[$ci]) : '';
    try {
        $r = pay_request_create($sid, ['amount' => (string)$amount, 'method' => 'karta', 'card_to' => $cardTo, 'paid_at' => '', 'receipt_no' => '', 'note' => (string)($d['n'] ?? '')],
            ['tmp' => $tmp, 'size' => (int)filesize($tmp)], 'bot');
    } finally {
        @unlink($tmp);
    }
    if (!$r['ok']) {
        $retry = strpos($r['error'], 'rasm') !== false || strpos($r['error'], 'Fayl') !== false || strpos($r['error'], 'fayl') !== false;
        if ($retry) tg_w_set($chat, 'wfile', ['a' => $amount, 'c' => $ci]); else q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
        tg_send($chat, '⚠️ ' . tg_h($r['error']) . ($retry ? "\nBoshqa fayl yuboring yoki /menu." : ''));
        return;
    }
    $id = (int)$r['id'];
    // Telegramdagi fayl adminlarga qayta yuklanmasdan yuboriladi
    pay_tg_meta_update($id, fn(array $m) => ['f' => (string)$d['f'], 't' => ($d['t'] ?? 'p') === 'd' ? 'doc' : 'photo'] + $m);
    if (!empty($d['g'])) tg_w_set($chat, 'wdone', ['g' => (string)$d['g']]); else q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
    tg_log('in', $chat, 'payrq', true, 'chek ' . $id);
    tg_send($chat, "✅ <b>Chek qabul qilindi</b> (#" . $id . "): " . tg_h(som($amount)) . ".\nAdmin tekshirgach summa balansingizga tushadi — natija shu yerga keladi."
        . (mock_unpaid_n($sid) ? "\nBand qilingan MOCK lar to‘lovi tasdiqdan keyin avtomatik yechiladi." : ''),
        ['inline_keyboard' => [[['text' => '💰 Hamyon', 'callback_data' => 'w:b'], ['text' => '🚫 Bekor qilish', 'callback_data' => 'w:c:' . $id]]]]);
}

function mock_unpaid_n(int $sid): int
{
    return (int)val('SELECT COUNT(*) FROM test_registrations WHERE student_id=? AND pay_status="unpaid"', [$sid]);
}

/** O'quvchi rasm yoki hujjat yubordi (chek) */
function tg_w_file(int $chat, array $st, array $m): void
{
    $doc = $m['document'] ?? null;
    $ph = $m['photo'] ?? null;
    $group = (string)($m['media_group_id'] ?? '');
    $busy = row('SELECT step, updated_at FROM tg_state WHERE chat_id=?', [$chat]);   // test yechish paytida rasm — chek emas
    if ($busy && in_array($busy['step'], ['ans', 'qb', 'qbkeys', 'qbsec', 'qbcnt'], true) && time() - strtotime((string)$busy['updated_at']) <= 6 * 3600) {
        tg_send($chat, 'Rasm qabul qilinmaydi — javobni harf yoki son bilan yozing. To‘lov chekini yuborish: 💰 Hamyon → ➕ Hisobni to‘ldirish.');
        return;
    }
    $state = tg_w_state($chat);
    $d = $state ? $state['d'] : [];
    if ($group !== '' && (string)($d['g'] ?? '') === $group) return;   // albomdagi keyingi rasm — birinchisi olingan
    if (is_array($ph) && $ph) {
        $big = $ph[count($ph) - 1];
        $f = ['f' => (string)($big['file_id'] ?? ''), 't' => 'p', 's' => (int)($big['file_size'] ?? 0)];
    } elseif (is_array($doc)) {
        $mime = strtolower((string)($doc['mime_type'] ?? ''));
        if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'], true)) {
            tg_send($chat, 'Chek sifatida faqat rasm (JPG, PNG, WebP) yoki PDF qabul qilinadi. Skrinshot yuboring.');
            return;
        }
        $f = ['f' => (string)($doc['file_id'] ?? ''), 't' => 'd', 's' => (int)($doc['file_size'] ?? 0)];
    } else return;
    if ($f['f'] === '' || strlen($f['f']) > 160) { tg_send($chat, 'Faylni o‘qib bo‘lmadi. Qayta yuboring.'); return; }
    if ($f['s'] > PAY_FILE_MAX) { tg_send($chat, 'Fayl juda katta (ko‘pi bilan 8 MB). Chekning skrinshotini yuboring.'); return; }
    if ($group !== '') $f['g'] = $group;
    $np = (int)val('SELECT COUNT(*) FROM pay_requests WHERE student_id=? AND status="pending"', [(int)$st['id']]);
    if ($np >= pay_max_pending()) { tg_send($chat, "⏳ Sizda " . $np . " ta chek tekshirilmoqda. Admin ko‘rib chiqqach yangisini yuboring."); return; }
    $cap = trim((string)($m['caption'] ?? ''));
    $pure = $cap !== '' ? money_in($cap) : 0;   // izoh faqat summadan iborat: «50000», «50 000 so'm»
    if ($pure < pay_min() || $pure > PAY_MAX_AMOUNT) $pure = 0;
    if ($pure > 0 && ($pure % 1000 !== 0 || (string)$pure === (string)$st['code'])) $pure = 0;   // yaxlit bo'lmagan son yoki o'z ID si — tasdiq bilan
    $stAmt = $state && in_array($state['step'], ['wfile', 'wcard'], true) ? (int)($d['a'] ?? 0) : 0;   // «➕ Hisobni to'ldirish» da yozilgan summa
    if (isset($d['c'])) $f['c'] = (int)$d['c'];
    if ($pure > 0 || $stAmt > 0) {
        $f['n'] = $pure > 0 ? '' : mb_substr($cap, 0, 100);
        tg_topup_amount($chat, $st, $pure > 0 ? $pure : $stAmt, $f);
        return;
    }
    // Kontekstsiz rasm: izoh ichidagi son summa bo'lishi ham, bo'lmasligi ham mumkin (telefon raqami va h.k.) — tasdiq so'raladi
    $sug = $cap !== '' ? tg_w_amount($cap) : 0;
    $f['n'] = $sug > 0 ? tg_w_note($cap) : mb_substr($cap, 0, 100);
    $kb = [];
    if ($sug > 0) { $f['sa'] = $sug; $kb[] = [['text' => '✅ Ha, chek — ' . som($sug), 'callback_data' => 'w:y:' . $sug]]; }
    $kb[] = [['text' => 'Bekor qilish', 'callback_data' => 'w:x']];
    tg_w_set($chat, 'wfid', $f);
    tg_send($chat, $sug > 0
        ? "🧾 Bu to‘lov chekimi? Summa: <b>" . tg_h(som($sug)) . "</b>\nTo‘g‘ri bo‘lsa «✅ Ha» ni bosing; summa boshqa bo‘lsa — raqam bilan yozing. Chek bo‘lmasa: /menu"
        : "🧾 Chek olindi. Qancha o‘tkazdingiz? Summani raqam bilan yozing, masalan: <code>50000</code>\n\nBu chek bo‘lmasa: /menu", ['inline_keyboard' => $kb]);
}

/** Hamyon holatidagi matn (summa). true — qayta ishlandi */
function tg_w_text(int $chat, array $st, array $state, string $text): bool
{
    $d = $state['d'];
    if ($state['step'] === 'wdone') { q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); return false; }
    if ($state['step'] === 'wcard') { tg_send($chat, 'Qaysi kartaga o‘tkazganingizni tugma bilan tanlang (yuqorida). Bekor qilish: /menu'); return true; }
    if ($state['step'] === 'wfid' && !preg_match('/\d/', $text)) { q('DELETE FROM tg_state WHERE chat_id=? AND step="wfid"', [$chat]); return false; }   // rasm chek emas ekan — oddiy xabar
    $amount = tg_w_amount($text);
    if ($amount === 0) {
        tg_send($chat, 'Summani raqam bilan yozing, masalan: <code>50000</code> (' . tg_h(som(pay_min())) . ' dan ' . tg_h(som(PAY_MAX_AMOUNT)) . ' gacha). Bekor qilish: /menu');
        return true;
    }
    if ($state['step'] === 'wfid') {
        $note = tg_w_note($text);
        if ($note !== '' && (string)($d['n'] ?? '') === '') $d['n'] = $note;
    }
    tg_topup_amount($chat, $st, $amount, $state['step'] === 'wfid' ? $d : array_intersect_key($d, ['c' => 1]));
    return true;
}

/* ---------------- 👤 Profil, 🎟 MOCK ga yozilish ---------------- */

function tg_profile_view(array $st): array
{
    $s = row('SELECT * FROM students WHERE id=?', [(int)$st['id']]) ?: $st;
    $t = "👤 <b>Profil</b>\n\nF.I.Sh: <b>" . tg_h($s['full_name'] ?: '—') . "</b>\nID: <code>" . tg_h($s['code']) . "</code>";
    $t .= "\nTelefon: " . ((string)$s['phone'] !== '' ? tg_h(fmt_phone((string)$s['phone'])) . (!empty($s['phone_verified_at']) ? ' ✅' : ' (tasdiqlanmagan)') : 'kiritilmagan');
    if ((string)$s['group_name'] !== '') $t .= "\nGuruh: " . tg_h($s['group_name']);
    if ((string)$s['school'] !== '' || (string)$s['grade_level'] !== '') $t .= "\nMaktab: " . tg_h(trim($s['school'] . ((string)$s['school'] !== '' && (string)$s['grade_level'] !== '' ? ', ' : '') . $s['grade_level']));
    $t .= "\nBalans: <b>" . tg_h(som((int)$s['balance'])) . "</b>";
    $t .= "\nTelegram: ulangan" . ((string)$s['tg_username'] !== '' ? ' (@' . tg_h($s['tg_username']) . ')' : '');
    if ((string)$s['parent_phone'] !== '' || $s['parent_tg_chat'] !== null) $t .= "\nOta-ona: " . ((string)$s['parent_name'] !== '' ? tg_h($s['parent_name']) . ', ' : '') . ((string)$s['parent_phone'] !== '' ? tg_h(fmt_phone((string)$s['parent_phone'])) : '') . ($s['parent_tg_chat'] !== null ? ' · Telegram ulangan' : '');
    $t .= "\n\nMa’lumotlarni o‘zgartirish, telefonni tasdiqlash va parol — saytdagi profilda. F.I.Sh xato bo‘lsa, o‘quv markaziga ayting (sertifikatda shu ism chiqadi).";
    return [$t, ['inline_keyboard' => [[['text' => '✏️ Saytda tahrirlash', 'callback_data' => 'w:p']], [['text' => '💰 Hamyon', 'callback_data' => 'w:b'], ['text' => '🗓 MOCKlarim', 'callback_data' => 'w:m']]]]];
}

/** 🎟 MOCK ga yozilish: ro'yxati ochiq MOCK lar (narx va tugma bilan) */
function tg_open_view(int $sid): array
{
    $open = mock_open_list($sid);
    $bal = wallet_balance($sid);
    if (!$open) return ["🎟 Hozir ro‘yxati ochiq MOCK yo‘q. Yangi MOCK e’lon qilinganda shu yerda va «🗓 MOCKlarim» da ko‘rinadi.", null];
    $s = "🎟 <b>MOCK ga yozilish</b>\nBalansingiz: " . tg_h(som($bal));
    $kb = [];
    foreach (array_slice($open, 0, 8) as $t) {
        $when = $t['online'] && $t['online_start'] ? tg_dt($t['online_start']) . ', onlayn' : ($t['test_date'] ? date('d.m.Y', strtotime((string)$t['test_date'])) . ($t['online'] ? ', onlayn' : ', markazda') : 'sana keyinroq');
        $s .= "\n\n• <b>" . tg_h($t['title']) . "</b> — " . $when . "\n  " . tg_h(mock_price_label($t)) . " · " . (int)$t['n_reg'] . " kishi ro‘yxatda";
        $kb[] = [['text' => '📝 ' . mb_substr((string)$t['title'], 0, 30) . ' · ' . mock_price_label($t), 'callback_data' => 'join:' . (int)$t['id']]];
    }
    if (count($open) > 8) $s .= "\n\n…va yana " . (count($open) - 8) . " ta — saytdagi «MOCK lar» sahifasida.";
    return [$s . "\n\nTugmani bosing — narx va balans ko‘rsatilib, tasdiq so‘raladi.", ['inline_keyboard' => $kb]];
}

/* ---------------- Tugmalar ---------------- */

/** w:… tugmalari (hamyon, to'ldirish, profil) */
function tg_w_cb(int $chat, array $st, string $data, callable $ans, int $mid): void
{
    $sid = (int)$st['id'];
    if ($data === 'w:b') { $ans(); [$s, $kb] = tg_wallet_view($sid); tg_send($chat, $s, $kb); return; }
    if ($data === 'w:h') { $ans(); tg_send($chat, tg_wallet_history_text($sid)); return; }
    if ($data === 'w:m') { $ans(); [$s, $kb] = tg_mock_list($sid); tg_send($chat, $s, $kb); return; }
    if ($data === 'w:x') { $ans('Bekor qilindi'); q('DELETE FROM tg_state WHERE chat_id=? AND step IN ("wamt","wcard","wfile","wfid")', [$chat]); tg_drop_kb($chat, $mid); return; }
    if (preg_match('/^w:t(?::(\d{1,9}))?$/', $data, $m)) { $ans(); tg_topup_start($chat, $st, isset($m[1]) ? (int)$m[1] : 0); return; }
    if (preg_match('/^w:y:(\d{1,9})$/', $data, $m)) {   // izohdagi summa tasdiqlandi («Bu to'lov chekimi?»)
        $state = tg_w_state($chat);
        $a = (int)$m[1];
        if (!$state || $state['step'] !== 'wfid' || (int)($state['d']['sa'] ?? 0) !== $a) { $ans('Bu so‘rov eskirgan — chekni qayta yuboring', true); tg_drop_kb($chat, $mid); return; }
        $ans(); tg_drop_kb($chat, $mid);
        tg_topup_amount($chat, $st, $a, $state['d']);
        return;
    }
    if (preg_match('/^w:a:(\d{1,9})$/', $data, $m)) {   // taklif qilingan summa tugmasi
        $state = tg_w_state($chat);
        if (!$state || $state['step'] !== 'wamt') { $ans('Bu so‘rov eskirgan — «➕ Hisobni to‘ldirish» ni qayta bosing', true); tg_drop_kb($chat, $mid); return; }
        $a = (int)$m[1];
        if ($a < pay_min() || $a > PAY_MAX_AMOUNT) { $ans('Summa noto‘g‘ri', true); return; }
        $ans(); tg_drop_kb($chat, $mid);
        tg_topup_amount($chat, $st, $a, $state['d']);
        return;
    }
    if (preg_match('/^w:k:(\d)$/', $data, $m)) {   // karta tanlandi
        $state = tg_w_state($chat);
        $cards = pay_cards();
        if (!$state || $state['step'] !== 'wcard' || !isset($cards[(int)$m[1]])) { $ans('Bu so‘rov eskirgan — «➕ Hisobni to‘ldirish» ni qayta bosing', true); tg_drop_kb($chat, $mid); return; }
        $ans(); tg_drop_kb($chat, $mid);
        $d = $state['d']; $d['c'] = (int)$m[1];
        tg_topup_amount($chat, $st, (int)$d['a'], $d);
        return;
    }
    if (preg_match('/^w:(c|cc):(\d+)$/', $data, $m)) {   // kutilayotgan chekni bekor qilish
        $id = (int)$m[2];
        $r = row('SELECT id, amount, status FROM pay_requests WHERE id=? AND student_id=?', [$id, $sid]);
        if (!$r || $r['status'] !== 'pending') { $ans($r ? 'Bu chek allaqachon ko‘rib chiqilgan: ' . mb_strtolower(PAY_STATUS[$r['status']] ?? $r['status']) : 'Chek topilmadi', true); tg_drop_kb($chat, $mid); return; }
        if ($m[1] === 'c') {
            $ans();
            tg_send($chat, "Chek #" . $id . " (" . tg_h(som((int)$r['amount'])) . ") bekor qilinsinmi? Admin uni ko‘rmaydi; kerak bo‘lsa yangisini yuborasiz.",
                ['inline_keyboard' => [[['text' => '🚫 Ha, bekor qilinsin', 'callback_data' => 'w:cc:' . $id], ['text' => 'Yo‘q', 'callback_data' => 'w:n']]]]);
            return;
        }
        $ok = pay_request_cancel($id, $sid);
        $ans($ok ? 'Chek bekor qilindi' : 'Bu chek allaqachon ko‘rib chiqilgan', !$ok);
        tg_drop_kb($chat, $mid);
        if ($ok) tg_send($chat, "🚫 Chek #" . $id . " bekor qilindi.", ['inline_keyboard' => [[['text' => '➕ Yangi chek yuborish', 'callback_data' => 'w:t'], ['text' => '💰 Hamyon', 'callback_data' => 'w:b']]]]);
        return;
    }
    if ($data === 'w:n') { $ans(); tg_drop_kb($chat, $mid); return; }
    if ($data === 'w:s' || $data === 'w:p') {   // saytga bir martalik havola (bosilganda yaratiladi)
        $link = tg_make_link($sid, 0, $data === 'w:s' ? 'wallet' : 'profile');
        if ($link === null) { $ans(tg_site_url() === '' ? 'Sayt manzili sozlanmagan — markazga xabar bering' : 'Avvalgi havolalar hali amalda — bir oz kuting', true); return; }
        $ans();
        tg_send($chat, "Havola 15 daqiqa amal qiladi va bir marta ishlaydi. Boshqalarga yubormang.", tg_kb_url($data === 'w:s' ? '🌐 Hamyonni saytda ochish' : '✏️ Profilni ochish', $link));
        return;
    }
    $ans();
}

/** «↩️ Chiqish» (jout:<id>) — tasdiq so'raydi; joutc:<id> — ro'yxatdan chiqarish (pul qaytishi sayt qoidasi bilan) */
function tg_jout_cb(int $chat, array $st, bool $confirm, int $tid, callable $ans, int $mid): void
{
    $sid = (int)$st['id'];
    $reg = mock_reg_row($sid, $tid);
    $t = mock_test_row($tid);
    if (!$reg || !$t) { $ans('Siz bu MOCK ro‘yxatida emassiz', true); tg_drop_kb($chat, $mid); return; }
    $chk = mock_cancel_check($reg, $t, (bool)val('SELECT 1 FROM responses WHERE test_id=? AND student_id=?', [$tid, $sid]));
    if (!$chk['ok']) { $ans(mb_substr($chk['reason'], 0, 190), true); return; }
    $title = '«' . tg_h($t['title']) . '»';
    if (!$confirm) {
        $ans();
        $s = $reg['pay_status'] === 'unpaid' ? "📌 " . $title . " uchun band qilingan joyingiz bekor qilinsinmi?"
            : "↩️ " . $title . " ro‘yxatidan chiqasizmi?" . ($chk['refund'] > 0 ? "\nHamyoningizga <b>" . tg_h(som($chk['refund'])) . "</b> qaytariladi." . ($chk['until'] ? " (Pul qaytishi " . date('d.m H:i', $chk['until']) . " gacha amal qiladi.)" : '') : '');
        tg_send($chat, $s, ['inline_keyboard' => [[['text' => '✅ Ha, chiqaman', 'callback_data' => 'joutc:' . $tid], ['text' => 'Yo‘q', 'callback_data' => 'w:n']]]]);
        return;
    }
    $r = mock_cancel($sid, $tid, 'student', ['via' => 'bot', 'actor' => 'student:' . $sid]);
    tg_drop_kb($chat, $mid);
    if (!$r['ok']) { $ans(mb_substr($r['error'], 0, 190), true); return; }
    $ans($r['status'] === 'unpaid' ? 'Band bekor qilindi' : 'Ro‘yxatdan chiqdingiz');
    tg_send($chat, ($r['status'] === 'unpaid' ? "📌 " . $title . " uchun band bekor qilindi." : "↩️ " . $title . " ro‘yxatidan chiqdingiz.")
        . ($r['refund'] > 0 ? "\nHamyoningizga qaytarildi: <b>+" . tg_h(som($r['refund'])) . "</b>. Balans: <b>" . tg_h(som((int)$r['balance'])) . "</b>" : ''));
}

/** Yangi menyu tugmalari haqida bir marta xabar (eski klaviatura almashtiriladi) */
function tg_menu_upgrade(int $chat, array $st, string $cmd): void
{
    q('UPDATE students SET tg_menu_v=? WHERE id=?', [TG_MENU_V, (int)$st['id']]);
    if (in_array($cmd, ['/start', '/menu', '/help'], true)) return;   // bular menyuni o'zi yuboradi
    tg_send($chat, "🆕 Botda yangi bo‘limlar: <b>💰 Hamyon</b> (balans, chek yuborish), <b>🎟 MOCK ga yozilish</b> va <b>👤 Profil</b>. Menyu yangilandi 👇", tg_menu_kb());
}
