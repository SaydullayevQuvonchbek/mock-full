<?php
defined('APP_ROOT') || exit;
/**
 * Savollar bazasi: bo'limlar daraxti, PDF dan qirqilgan savol rasmlari, javob kaliti, o'quvchi mashq testlari, PDF chiqarish.
 * Mashq natijasi faqat nechta to'g'ri topilgani (umumiy va bo'limlar bo'yicha) — qaysi savol xato ekani va to'g'ri javoblar ko'rsatilmaydi.
 */

function qb_dir(): string
{
    $d = APP_ROOT . '/uploads/qb';
    if (!is_dir($d)) @mkdir($d, 0755, true);
    if (is_dir($d) && !is_file($d . '/.htaccess')) @file_put_contents($d . '/.htaccess', "Require all denied\n");   // rasmlar faqat index.php?p=qb_img orqali
    return $d;
}

/* ---------------- Bo'limlar ---------------- */

/**
 * Bo'limlar daraxti (tekis ro'yxat, tartib bilan): ['id','parent_id','name','level','depth','own','ready','total','ready_total']
 *  own/ready — shu bo'limning o'z savollari (kaliti borlari), total/ready_total — ichki bo'limlar bilan.
 *  level (2.4) — bo'lim qiyinligi: 1–3, 0 — aralash (har savolga alohida).
 */
function qb_tree(): array
{
    $secs = rows('SELECT id, parent_id, name, sort, level FROM qb_sections ORDER BY sort, name, id');
    $cnt = [];
    foreach (rows("SELECT section_id, COUNT(*) n, SUM(answer<>'') r FROM qb_questions GROUP BY section_id") as $r) $cnt[(int)$r['section_id']] = [(int)$r['n'], (int)$r['r']];
    $by = [];
    foreach ($secs as $s) $by[(int)($s['parent_id'] ?? 0)][] = $s;
    $out = [];
    $walk = function (int $pid, int $depth) use (&$walk, &$by, &$out, $cnt) {
        $tot = [0, 0];
        foreach ($by[$pid] ?? [] as $s) {
            $id = (int)$s['id'];
            $idx = count($out);
            $out[] = ['id' => $id, 'parent_id' => $s['parent_id'] !== null ? (int)$s['parent_id'] : 0, 'name' => $s['name'], 'level' => (int)($s['level'] ?? 0), 'depth' => $depth,
                      'own' => $cnt[$id][0] ?? 0, 'ready' => $cnt[$id][1] ?? 0, 'total' => 0, 'ready_total' => 0];
            $sub = $walk($id, $depth + 1);
            $out[$idx]['total'] = ($cnt[$id][0] ?? 0) + $sub[0];
            $out[$idx]['ready_total'] = ($cnt[$id][1] ?? 0) + $sub[1];
            $tot[0] += $out[$idx]['total']; $tot[1] += $out[$idx]['ready_total'];
        }
        return $tot;
    };
    $walk(0, 0);
    return $out;
}

/** Bo'lim va uning barcha ichki bo'limlari ID lari */
function qb_descendants(array $ids): array
{
    $ids = array_values(array_unique(array_map('intval', $ids)));
    $all = $ids;
    $frontier = $ids;
    for ($guard = 0; $frontier && $guard < 12; $guard++) {
        $in = implode(',', array_fill(0, count($frontier), '?'));
        $next = array_map('intval', array_column(rows("SELECT id FROM qb_sections WHERE parent_id IN ($in)", $frontier), 'id'));
        $next = array_values(array_diff($next, $all));
        $all = array_merge($all, $next);
        $frontier = $next;
    }
    return $all;
}

function qb_section_path(int $id): string
{
    $parts = [];
    for ($i = 0; $id && $i < 12; $i++) {
        $r = row('SELECT name, parent_id FROM qb_sections WHERE id=?', [$id]);
        if (!$r) break;
        array_unshift($parts, $r['name']);
        $id = (int)($r['parent_id'] ?? 0);
    }
    return implode(' › ', $parts);
}

/* ---------------- Javobni tekshirish ---------------- */

/** Ochiq javobni solishtirish uchun normallashtirish: bo'sh joy olinadi, vergul → nuqta, a/b kasr → son */
function qb_norm_open(string $s): string
{
    $s = mb_strtolower(trim($s));
    $s = str_replace([' ', "\u{00A0}", ','], ['', '', '.'], $s);
    $s = str_replace(['−', '–'], '-', $s);
    if (preg_match('#^(-?\d+(?:\.\d+)?)/(\d+(?:\.\d+)?)$#', $s, $m) && (float)$m[2] != 0.0) return rtrim(rtrim(sprintf('%.9F', (float)$m[1] / (float)$m[2]), '0'), '.');
    if (is_numeric($s)) return rtrim(rtrim(sprintf('%.9F', (float)$s), '0'), '.');
    return $s;
}

/** Javob to'g'rimi? Ochiq savolda kalitda bir nechta variant ";" bilan berilishi mumkin (masalan 0.5;1/2) */
function qb_check(array $q, string $given): bool
{
    $given = trim($given);
    if ($given === '' || (string)$q['answer'] === '') return false;
    if ($q['kind'] !== 'open') return strtoupper($given) === strtoupper(trim((string)$q['answer']));
    $g = qb_norm_open($given);
    foreach (explode(';', (string)$q['answer']) as $a) if ($g === qb_norm_open($a) && $g !== '') return true;
    return false;
}

/** Kalit qiymatini tozalash: test savoli uchun A..D (A..F), ochiq uchun matn. Noto'g'ri bo'lsa null */
function qb_clean_answer(string $kind, int $nopt, string $v): ?string
{
    $v = trim($v);
    if ($v === '') return '';
    if ($kind === 'open') return mb_substr($v, 0, 80);
    $v = strtoupper($v);
    $max = chr(64 + max(2, min(6, $nopt)));
    return (strlen($v) === 1 && $v >= 'A' && $v <= $max) ? $v : null;
}

/**
 * Tezkor kalit matnini [tartib raqami => javob] ga aylantiradi. Qabul qilinadigan ko'rinishlar:
 *  "ACDBB…" (har harf — bitta savol), "1A 2C 3D", "1:A 2:C 3:12 4:0.5;1/2" (bo'sh joy bilan ajratilgan).
 */
function qb_parse_key(string $s): array
{
    $s = trim($s);
    if ($s === '') return [];
    $compact = preg_replace('/[\s,]+/u', '', $s);
    if (preg_match('/^[A-Fa-f]+$/', $compact)) {
        $out = [];
        foreach (str_split(strtoupper($compact)) as $i => $c) $out[$i + 1] = $c;
        return $out;
    }
    if (preg_match('/^(?:\d{1,3}[A-Fa-f])+$/', $compact) && preg_match_all('/(\d{1,3})([A-Fa-f])/', $compact, $m, PREG_SET_ORDER)) {
        $out = [];
        foreach ($m as $x) $out[(int)$x[1]] = strtoupper($x[2]);
        return $out;
    }
    $out = []; $pos = 0;
    foreach (preg_split('/\s+/u', $s, -1, PREG_SPLIT_NO_EMPTY) as $tok) {
        if (preg_match('/^(\d{1,3})[:=)](.+)$/u', $tok, $mm)) { $pos = (int)$mm[1]; $v = $mm[2]; }
        else { $pos++; $v = $tok; }
        $out[$pos] = $v;
    }
    return $out;
}

/* ---------------- Rasm saqlash ---------------- */

/**
 * Yuklangan PNG ni tekshirib saqlaydi va savol yaratadi. $level — qiyinlik (1–3); berilmasa (0) — bo'lim darajasi (2.4).
 * Qaytaradi: [id|null, xato]
 */
function qb_add_image(int $sectionId, string $tmp, string $label, string $src = '', string $kind = 'mc', int $nopt = 4, int $level = 0): array
{
    $sec = row('SELECT id, level FROM qb_sections WHERE id=?', [$sectionId]);
    if (!$sec) return [null, 'Bo\'lim topilmadi'];
    if ($level < 1 || $level > 3) $level = (int)$sec['level'];
    if (!is_uploaded_file($tmp) && !is_file($tmp)) return [null, 'Fayl topilmadi'];
    $size = filesize($tmp);
    if ($size < 200 || $size > 4 * 1024 * 1024) return [null, 'Rasm hajmi noto\'g\'ri (4 MB gacha)'];
    $head = file_get_contents($tmp, false, null, 0, 8);
    if ($head !== "\x89PNG\r\n\x1a\n") return [null, 'Faqat PNG qabul qilinadi'];
    $info = @getimagesize($tmp);
    if (!$info || $info[2] !== IMAGETYPE_PNG || $info[0] < 20 || $info[1] < 20 || $info[0] > 4000 || $info[1] > 6000) return [null, 'Rasm o\'lchami noto\'g\'ri'];
    $name = 'q' . bin2hex(random_bytes(8)) . '.png';
    $dest = qb_dir() . '/' . $name;
    if (!@move_uploaded_file($tmp, $dest) && !@copy($tmp, $dest)) return [null, 'Rasmni saqlab bo\'lmadi'];
    $sort = (int)val('SELECT COALESCE(MAX(sort),0) FROM qb_questions WHERE section_id=?', [$sectionId]) + 1;
    $kind = $kind === 'open' ? 'open' : 'mc';
    q('INSERT INTO qb_questions (section_id, label, img, w, h, kind, nopt, src, sort, level) VALUES (?,?,?,?,?,?,?,?,?,?)',
        [$sectionId, mb_substr($label, 0, 40), $name, $info[0], $info[1], $kind, $nopt === 6 ? 6 : 4, mb_substr($src, 0, 160), $sort, $level >= 1 && $level <= 3 ? $level : 0]);
    return [(int)db()->lastInsertId(), ''];
}

/** PNG faylni tekshirish (qb_add_image bilan bir xil qoida). Qaytaradi: [getimagesize|null, xato] */
function qb_check_png(string $tmp): array
{
    if (!is_uploaded_file($tmp) && !is_file($tmp)) return [null, 'Fayl topilmadi'];
    $size = filesize($tmp);
    if ($size < 200 || $size > 4 * 1024 * 1024) return [null, 'Rasm hajmi noto\'g\'ri (4 MB gacha)'];
    if (file_get_contents($tmp, false, null, 0, 8) !== "\x89PNG\r\n\x1a\n") return [null, 'Faqat PNG qabul qilinadi'];
    $info = @getimagesize($tmp);
    if (!$info || $info[2] !== IMAGETYPE_PNG || $info[0] < 20 || $info[1] < 20 || $info[0] > 4000 || $info[1] > 6000) return [null, 'Rasm o\'lchami noto\'g\'ri'];
    return [$info, ''];
}

/** Savol rasmini almashtirish (masalan, savol raqami olib tashlangan nusxa). Eski fayl o'chiriladi. */
function qb_replace_image(int $id, string $tmp): array
{
    $r = row('SELECT img FROM qb_questions WHERE id=?', [$id]);
    if (!$r) return [false, 'Savol topilmadi'];
    [$info, $err] = qb_check_png($tmp);
    if (!$info) return [false, $err];
    $name = 'q' . bin2hex(random_bytes(8)) . '.png';
    $dest = qb_dir() . '/' . $name;
    if (!@move_uploaded_file($tmp, $dest) && !@copy($tmp, $dest)) return [false, 'Rasmni saqlab bo\'lmadi'];
    q('UPDATE qb_questions SET img=?, w=?, h=? WHERE id=?', [$name, $info[0], $info[1], $id]);
    $old = qb_dir() . '/' . basename((string)$r['img']);
    if (preg_match('/^q[0-9a-f]{16}\.png$/', basename($old)) && is_file($old)) @unlink($old);
    return [true, ''];
}

function qb_delete_question(int $id): void
{
    $r = row('SELECT img FROM qb_questions WHERE id=?', [$id]);
    if (!$r) return;
    $f = qb_dir() . '/' . basename((string)$r['img']);
    if (preg_match('/^q[0-9a-f]{16}\.png$/', basename($f)) && is_file($f)) @unlink($f);
    q('DELETE FROM qb_questions WHERE id=?', [$id]);
}

/** Bo'limni (ichki bo'limlari va savollari bilan) o'chirish */
function qb_delete_section(int $id): int
{
    $ids = qb_descendants([$id]);
    $in = implode(',', array_fill(0, count($ids), '?'));
    foreach (rows("SELECT id FROM qb_questions WHERE section_id IN ($in)", $ids) as $r) qb_delete_question((int)$r['id']);
    q("DELETE FROM qb_sections WHERE id IN ($in)", array_reverse($ids));
    return count($ids);
}

/* ---------------- Qiyinlik darajasi (2.3) ---------------- */

/** Darajalar. 0 — belgilanmagan (2.3 dan oldin yuklangan savollar) */
const QB_LEVELS = [1 => 'Oson', 2 => 'O\'rta', 3 => 'Qiyin'];

function qb_level_name(int $lv): string
{
    return QB_LEVELS[$lv] ?? 'Belgilanmagan';
}

/** Rangli daraja belgisi */
function qb_level_tag(int $lv): string
{
    $lv = isset(QB_LEVELS[$lv]) ? $lv : 0;
    return '<span class="lv lv' . $lv . '" title="Qiyinlik darajasi">' . e($lv ? QB_LEVELS[$lv] : '—') . '</span>';
}

/** Bo'lim darajasi belgisi (2.4): 1–3 yoki «aralash» (0 — har savolga alohida) */
function qb_section_level_tag(int $lv): string
{
    return isset(QB_LEVELS[$lv]) ? qb_level_tag($lv) : '<span class="lv lv0" title="Har savolning darajasi alohida">aralash</span>';
}

/** Bo'lim darajasi tanlovi: $cur null — tanlanmagan (majburiy) */
function qb_section_level_select(string $name, ?int $cur): string
{
    $h = '<select name="' . e($name) . '" required>' . ($cur === null ? '<option value="">— tanlang —</option>' : '');
    foreach (QB_LEVELS as $k => $nm) $h .= '<option value="' . $k . '"' . ($cur === $k ? ' selected' : '') . '>' . e($nm) . '</option>';
    return $h . '<option value="mix"' . ($cur === 0 ? ' selected' : '') . '>Aralash — har savolga alohida</option></select>';
}

/** Tartiblash uchun: oson → (belgilanmagan, o'rta) → qiyin */
function qb_level_rank(int $lv): int
{
    return $lv === 1 ? 1 : ($lv === 3 ? 3 : 2);
}

/** O'quvchilar javoblaridan taklif: to'g'ri javoblar ulushi 70%+ — oson, 40–69% — o'rta, pastroq — qiyin (kamida $min ta javob bo'lsa; aks holda 0) */
function qb_level_from_stats(int $n, int $k, int $min = 8): int
{
    if ($n < $min || $n <= 0) return 0;
    $p = $k / $n;
    return $p >= 0.7 ? 1 : ($p >= 0.4 ? 2 : 3);
}

/** «1:3,2:5,3:2» ⇄ [1=>3, 2=>5, 3=>2] (topshiriqdagi darajalar bo'yicha soni) */
function qb_levels_parse(string $s): array
{
    $out = [];
    foreach (explode(',', $s) as $part) if (preg_match('/^\s*([1-3])\s*:\s*(\d{1,2})\s*$/', $part, $m) && (int)$m[2] > 0) $out[(int)$m[1]] = (int)$m[2];
    ksort($out);
    return $out;
}

function qb_levels_label(array $lv): string
{
    $p = [];
    foreach ($lv as $k => $c) if (isset(QB_LEVELS[$k]) && $c > 0) $p[] = QB_LEVELS[$k] . ' ' . (int)$c;
    return implode(', ', $p);
}

/* ---------------- Savollar havzasi va tanlash (2.3) ---------------- */

/** Tanlangan bo'limlar ichki bo'limlari bilan (bo'sh — barcha bo'limlar) */
function qb_scope_ids(array $sectionIds): array
{
    $sectionIds = array_values(array_filter(array_map('intval', $sectionIds)));
    return $sectionIds ? qb_descendants($sectionIds) : array_map('intval', array_column(rows('SELECT id FROM qb_sections'), 'id'));
}

/** Kalitli savollar: [['id','section_id','name','level'],…]. $levels — faqat shu darajalar (null — hammasi) */
function qb_pool(array $sectionIds, ?array $levels = null): array
{
    $all = qb_scope_ids($sectionIds);
    if (!$all) return [];
    $params = $all;
    $sql = "SELECT q.id, q.section_id, s.name, q.level FROM qb_questions q JOIN qb_sections s ON s.id=q.section_id WHERE q.answer<>'' AND q.section_id IN (" . implode(',', array_fill(0, count($all), '?')) . ')';
    if ($levels !== null) {
        $levels = array_values(array_unique(array_map('intval', $levels)));
        if (!$levels) return [];
        $sql .= ' AND q.level IN (' . implode(',', array_fill(0, count($levels), '?')) . ')';
        $params = array_merge($params, $levels);
    }
    return rows($sql . ' ORDER BY q.id', $params);
}

/** Tanlangan bo'limlarda (ichki bo'limlari bilan; bo'sh = hammasi) mashqqa yaroqli (kalitli) savollar soni */
function qb_pool_size(array $sectionIds, ?array $levels = null): int
{
    $all = qb_scope_ids($sectionIds);
    if (!$all) return 0;
    $params = $all;
    $sql = "SELECT COUNT(*) FROM qb_questions WHERE answer<>'' AND section_id IN (" . implode(',', array_fill(0, count($all), '?')) . ')';
    if ($levels !== null) {
        $levels = array_values(array_unique(array_map('intval', $levels)));
        if (!$levels) return 0;
        $sql .= ' AND level IN (' . implode(',', array_fill(0, count($levels), '?')) . ')';
        $params = array_merge($params, $levels);
    }
    return (int)val($sql, $params);
}

/**
 * $k ni chelaklarga iloji boricha teng bo'lish: [kalit => sig'im] → [kalit => soni]. Sig'imi yetmagan chelakning ulushi boshqalarga o'tadi.
 * Qoldiq: $ordered — chelaklar tartibida («navbat bilan»: 3 bo'lim, 5 savol → har biridan 1, keyin birinchi ikkitasidan yana 1),
 * aks holda tasodifiy chelaklarga (mashqlarda — har safar boshqacha).
 */
function qb_split(array $caps, int $k, bool $ordered = false): array
{
    $out = array_fill_keys(array_keys($caps), 0);
    $active = array_keys(array_filter($caps, function ($c) { return $c > 0; }));
    if (!$ordered) shuffle($active);
    while ($k > 0 && $active) {
        $share = intdiv($k, count($active));
        if ($share === 0) {
            foreach (array_slice($active, 0, $k) as $key) $out[$key]++;
            break;
        }
        $next = [];
        foreach ($active as $key) {
            $g = min($share, $caps[$key] - $out[$key]);
            $out[$key] += $g;
            $k -= $g;
            if ($out[$key] < $caps[$key]) $next[] = $key;
        }
        $active = $next;
    }
    return $out;
}

/**
 * Bo'limlar bo'yicha teng taqsimlash: har bo'limning O'Z savollaridan nechta olinadi — [section_id => soni] (jami ≤ $n).
 * $tops — tanlangan bo'limlar (bo'sh — barcha asosiy bo'limlar): har biriga teng ulush; bo'lim ichida esa
 * ichki bo'limlari va bo'limning o'z savollari orasida yana teng. Biror joyda savol yetmasa, ulushi boshqalarga o'tadi.
 */
function qb_alloc(array $pool, array $tops, int $n, bool $ordered = false, ?array &$shape = null): array
{
    $shape = ['tops' => [], 'kids' => []];   // navbat uchun: tanlangan (asosiy) bo'limlar va daraxt
    if ($n <= 0 || !$pool) return [];
    $par = [];
    foreach (rows('SELECT id, parent_id FROM qb_sections ORDER BY sort, name, id') as $r) $par[(int)$r['id']] = $r['parent_id'] !== null ? (int)$r['parent_id'] : 0;
    $kids = [];
    foreach ($par as $id => $p) {
        if ($p && !isset($par[$p])) { $p = 0; $par[$id] = 0; }   // ota bo'limi yo'q — asosiy bo'lim deb olamiz
        $kids[$p][] = $id;
    }
    $own = [];
    foreach ($pool as $r) $own[(int)$r['section_id']] = ($own[(int)$r['section_id']] ?? 0) + 1;
    $memo = [];
    $cap = function (int $id, int $d = 0) use (&$cap, &$memo, $own, $kids): int {
        if (isset($memo[$id])) return $memo[$id];
        $c = $own[$id] ?? 0;
        if ($d < 20) foreach ($kids[$id] ?? [] as $k) $c += $cap($k, $d + 1);
        return $memo[$id] = $c;
    };
    $tops = array_values(array_unique(array_filter(array_map('intval', $tops), function ($i) use ($par) { return isset($par[$i]); })));
    if ($tops) {
        $set = array_flip($tops);   // ota bo'limi ham tanlangan bo'lsa, ichkisi ota ichida teng taqsimlanadi
        $tops = array_values(array_filter($tops, function ($id) use ($par, $set) {
            for ($x = $par[$id] ?? 0, $g = 0; $x && $g < 20; $x = $par[$x] ?? 0, $g++) if (isset($set[$x])) return false;
            return true;
        }));
    } else {
        $tops = $kids[0] ?? [];
    }
    $alloc = [];
    $take = function (int $id, int $k, int $d) use (&$take, &$alloc, $own, $kids, $cap, $ordered) {
        $caps = [];
        if (!empty($own[$id])) $caps['o'] = $own[$id];
        if ($d < 20) foreach ($kids[$id] ?? [] as $c) { $cc = $cap($c, $d + 1); if ($cc > 0) $caps['s' . $c] = $cc; }
        foreach (qb_split($caps, $k, $ordered) as $key => $m) {
            if ($m <= 0) continue;
            if ($key === 'o') $alloc[$id] = ($alloc[$id] ?? 0) + $m;
            else $take((int)substr((string)$key, 1), $m, $d + 1);
        }
    };
    if ($ordered && count($tops) > 1) {   // navbat — bo'limlar daraxtdagi tartibida (shakldagi ro'yxat bilan bir xil)
        $rank = [];
        $dfs = function (int $p, int $d) use (&$dfs, &$rank, $kids) { foreach ($kids[$p] ?? [] as $c) { $rank[$c] = count($rank); if ($d < 20) $dfs($c, $d + 1); } };
        $dfs(0, 0);
        usort($tops, function ($a, $b) use ($rank) { return ($rank[$a] ?? 0) <=> ($rank[$b] ?? 0); });
    }
    $caps = [];
    foreach ($tops as $t) { $c = $cap($t); if ($c > 0) $caps['s' . $t] = $c; }
    foreach (qb_split($caps, $n, $ordered) as $key => $m) if ($m > 0) $take((int)substr((string)$key, 1), $m, 0);
    $shape = ['tops' => $tops, 'kids' => $kids];
    return $alloc;
}

/**
 * Bo'limlar bo'yicha teng taqsimlab $n ta savol tanlash (qb_alloc + har bo'lim ichida tartib).
 * $order — bo'lim ichidagi ustuvorlik tartibi (qatorlar ro'yxatini qaytaradi); berilmasa tasodifiy.
 * $ordered (2.4, topshiriqlar) — bo'limlar navbat bilan: qoldiq tartib bo'yicha, natija ham navbatda (1-bo'lim, 2-bo'lim, …, yana 1-bo'lim).
 */
function qb_pick_balanced(array $pool, array $tops, int $n, ?callable $order = null, bool $ordered = false): array
{
    $own = [];
    foreach ($pool as $r) $own[(int)$r['section_id']][] = $r;
    $shape = null;
    $picked = [];
    foreach (qb_alloc($pool, $tops, $n, $ordered, $shape) as $sec => $m) {
        $list = $own[$sec];
        if ($order) $list = $order($list); else shuffle($list);
        $picked[$sec] = array_slice($list, 0, $m);
    }
    if (!$ordered) return $picked ? array_merge(...array_values($picked)) : [];
    // navbat tanlangan bo'limlar darajasida: 1-tanlangan, 2-tanlangan, … yana 1-tanlangan; har birining ichida — o'z savollari va ichki bo'limlari navbat bilan
    $build = function (int $id, int $d) use (&$build, $picked, $shape): array {
        $lists = [];
        if (!empty($picked[$id])) $lists[] = $picked[$id];
        if ($d < 20) foreach ($shape['kids'][$id] ?? [] as $c) { $l = $build((int)$c, $d + 1); if ($l) $lists[] = $l; }
        return qb_interleave($lists);
    };
    $lists = [];
    foreach ($shape['tops'] as $t) { $l = $build((int)$t, 0); if ($l) $lists[] = $l; }
    return qb_interleave($lists);
}

/** Ro'yxatlarni navbat bilan qo'shish: [[a1,a2],[b1],[c1,c2]] → a1, b1, c1, a2, c2 */
function qb_interleave(array $lists): array
{
    $out = [];
    for ($r = 0, $any = true; $any; $r++) {
        $any = false;
        foreach ($lists as $l) if (isset($l[$r])) { $out[] = $l[$r]; $any = true; }
    }
    return $out;
}

/**
 * O'quvchining har bir savol bo'yicha OXIRGI natijasi: [question_id => ['ok'=>0|1, 'at'=>unix]].
 * Mashqlar va xatolari ko'rsatiladigan (review=1), yopilgan topshiriqlar hisobga olinadi; «faqat natija soni» (review=0)
 * yoki hali yopilmagan topshiriqdagi javoblar olinmaydi — aks holda qaysi savol xato bo'lgani mashq orqali bilinib qolardi.
 */
function qb_student_history(int $sid): array
{
    $h = [];
    foreach (rows('SELECT i.question_id, i.ok, t.finished_at FROM qb_items i JOIN qb_tests t ON t.id=i.test_id LEFT JOIN qb_assign a ON a.id=t.assign_id
                   WHERE t.student_id=? AND t.status="done" AND i.ok IS NOT NULL AND (t.assign_id IS NULL OR (a.review=1 AND a.closed_at IS NOT NULL))
                   ORDER BY t.finished_at, t.id', [$sid]) as $r)
        $h[(int)$r['question_id']] = ['ok' => (int)$r['ok'], 'at' => (int)strtotime((string)$r['finished_at'])];
    return $h;
}

/**
 * Mashq havzasi: o'quvchining hali yopilmagan topshiriqlaridagi savollar mashqqa chiqmaydi
 * (aks holda topshiriq javobini mashq orqali «sinab ko'rish» mumkin bo'lardi). Sinf testida — o'quvchining javobi hali kiritilmagan bo'lsa,
 * test oldindan (masalan, kecha) tayyorlanganda savollarni mashqda ko'rib qo'ymasin; 7 kundan keyin (test o'tib ketgan) to'smaydi.
 */
function qb_practice_pool(int $sid, array $sectionIds, ?array $levels = null): array
{
    $pool = qb_pool($sectionIds, $levels);
    if (!$pool) return [];
    $block = array_flip(array_map('intval', array_column(rows('SELECT DISTINCT ai.question_id FROM qb_tests t JOIN qb_assign a ON a.id=t.assign_id
                                                                JOIN qb_assign_items ai ON ai.assign_id=a.id WHERE t.student_id=?
                                                                AND ((a.mode<>"paper" AND a.closed_at IS NULL)
                                                                  OR (a.mode="paper" AND t.status="open" AND a.created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)))', [$sid]), 'question_id')));
    return $block ? array_values(array_filter($pool, function ($r) use ($block) { return !isset($block[(int)$r['id']]); })) : $pool;
}

/** Oxirgi urinishda xato qilingan / javobsiz qoldirilgan savollar soni (mashqqa chiqa oladiganlari) */
function qb_wrong_count(int $sid, array $sectionIds = []): int
{
    $h = qb_student_history($sid);
    if (!$h) return 0;
    $n = 0;
    foreach (qb_practice_pool($sid, $sectionIds) as $r) if (isset($h[(int)$r['id']]) && $h[(int)$r['id']]['ok'] === 0) $n++;
    return $n;
}

/**
 * Moslashuvchan mashq testi (2.3). Savollar bo'limlar bo'yicha teng taqsimlanadi va o'quvchining tarixiga qarab olinadi:
 *  1) oxirgi urinishda xato qilingan yoki javobsiz qolgan savollar — testning yarmigacha (eng eski xato birinchi);
 *  2) qolgani hali ishlanmagan savollar;
 *  3) to'g'ri yechilganlar faqat boshqa savol qolmaganda (eng eskisi birinchi) — qayta-qayta berilmaydi.
 * $opt: mode = 'mix' | 'errors' («Xatolarim ustida ishlash» — avval faqat xatolar), levels = [1,2,3] (daraja filtri).
 * Qaytaradi: [test_id|null, xato, ['wrong'=>…, 'fresh'=>…, 'again'=>…]]
 */
function qb_build_test(int $sid, array $sectionIds, int $n, string $via = 'web', array $opt = []): array
{
    $n = max(1, min(60, $n));
    $mode = ($opt['mode'] ?? 'mix') === 'errors' ? 'errors' : 'mix';
    $levels = !empty($opt['levels']) ? array_values(array_unique(array_intersect(array_map('intval', (array)$opt['levels']), [0, 1, 2, 3]))) : [];
    if (!array_diff([1, 2, 3], $levels)) $levels = [];   // uchala daraja belgilansa — filtrsiz (darajasi belgilanmagan eski savollar ham)
    $sectionIds = array_values(array_filter(array_map('intval', $sectionIds)));
    if (!qb_scope_ids($sectionIds)) return [null, 'Savollar bazasi bo\'sh', []];
    $pool = qb_practice_pool($sid, $sectionIds, $levels ? $levels : null);
    if (!$pool) return [null, $levels ? 'Tanlangan bo\'lim va darajada tayyor savol yo\'q' : 'Tanlangan bo\'limlarda tayyor savol yo\'q', []];
    $hist = qb_student_history($sid);
    $W = []; $F = []; $C = [];
    foreach ($pool as $r) {
        $h = $hist[(int)$r['id']] ?? null;
        if ($h === null) $F[] = $r; elseif ($h['ok'] === 0) $W[] = $r; else $C[] = $r;
    }
    if ($mode === 'errors' && !$W) return [null, 'Bu bo\'limlarda xato qilgan yoki javobsiz qoldirgan savolingiz yo\'q — barakalla! Oddiy mashq tuzing.', []];
    $inOpen = array_flip(array_map('intval', array_column(rows('SELECT i.question_id FROM qb_items i JOIN qb_tests t ON t.id=i.test_id WHERE t.student_id=? AND t.status="open"', [$sid]), 'question_id')));
    $byAge = function (array $list) use ($hist, $inOpen) {   // eng eski urinish birinchi; yakunlanmagan boshqa mashqda turganlari oxirida
        shuffle($list);
        usort($list, function ($a, $b) use ($hist, $inOpen) {
            return [(int)isset($inOpen[(int)$a['id']]), $hist[(int)$a['id']]['at'] ?? 0] <=> [(int)isset($inOpen[(int)$b['id']]), $hist[(int)$b['id']]['at'] ?? 0];
        });
        return $list;
    };
    $freshOrder = function (array $list) use ($inOpen) {
        shuffle($list);
        usort($list, function ($a, $b) use ($inOpen) { return (int)isset($inOpen[(int)$a['id']]) <=> (int)isset($inOpen[(int)$b['id']]); });
        return $list;
    };
    $total = count($pool);
    if ($mode === 'errors') $n = min($n, count($W));
    $n = max($n, min(5, $total));   // 1–2 savollik test «to'g'rimi?» degan so'rovga aylanib qolmasin: kamida 5 ta (baza kichik bo'lsa — borcha)
    if ($mode === 'errors') {
        // xatolar ustida: avval xatolar (bo'limlar bo'yicha teng), yetmasa — yangi, keyin to'g'ri yechilganlar
        $pick = qb_pick_balanced($W, $sectionIds, $n, $byAge);
        $pick = array_merge($pick, qb_pick_balanced($F, $sectionIds, $n - count($pick), $freshOrder));
        if (count($pick) < $n) $pick = array_merge($pick, qb_pick_balanced($C, $sectionIds, $n - count($pick), $byAge));
    } else {
        // har bo'limning ulushi butun havza bo'yicha teng taqsimlanadi; ulush ichida: xatolar (jami testning yarmigacha) → yangi → qolgan xatolar → to'g'ri yechilganlar
        $alloc = qb_alloc($pool, $sectionIds, $n);
        $by = ['W' => [], 'F' => [], 'C' => []];
        foreach (['W' => $W, 'F' => $F, 'C' => $C] as $k => $list) foreach ($list as $r) $by[$k][(int)$r['section_id']][] = $r;
        $wCaps = [];
        foreach ($alloc as $sec => $m) $wCaps['s' . $sec] = min($m, count($by['W'][$sec] ?? []));
        $wTake = qb_split($wCaps, min(count($W), intdiv($n + 1, 2)));
        $pick = [];
        foreach ($alloc as $sec => $m) {
            $w = $byAge($by['W'][$sec] ?? []);
            $k = $wTake['s' . $sec] ?? 0;
            $sel = array_slice($w, 0, $k);
            $sel = array_merge($sel, array_slice($freshOrder($by['F'][$sec] ?? []), 0, $m - count($sel)));
            if (count($sel) < $m) $sel = array_merge($sel, array_slice($w, $k, $m - count($sel)));
            if (count($sel) < $m) $sel = array_merge($sel, array_slice($byAge($by['C'][$sec] ?? []), 0, $m - count($sel)));
            $pick = array_merge($pick, $sel);
        }
    }
    if (!$pick) return [null, 'Savol tanlab bo\'lmadi', []];
    $info = ['wrong' => 0, 'fresh' => 0, 'again' => 0];
    foreach ($pick as $r) {
        $h = $hist[(int)$r['id']] ?? null;
        $info[$h === null ? 'fresh' : ($h['ok'] === 0 ? 'wrong' : 'again')]++;
    }
    shuffle($pick);
    $names = [];
    foreach ($sectionIds as $x) { $nm = (string)val('SELECT name FROM qb_sections WHERE id=?', [$x]); if ($nm !== '') $names[] = $nm; }
    $lvl = [];
    foreach ($levels as $lv) if (isset(QB_LEVELS[$lv])) $lvl[] = mb_strtolower(QB_LEVELS[$lv]);
    $title = ($mode === 'errors' ? 'Xatolar ustida: ' : 'Mashq: ') . ($names ? implode(', ', $names) : 'barcha bo\'limlar') . ($lvl ? ' (' . implode(', ', $lvl) . ')' : '');
    q('INSERT INTO qb_tests (student_id, title, n, via) VALUES (?,?,?,?)', [$sid, mb_strimwidth($title, 0, 150, '…'), count($pick), $via === 'bot' ? 'bot' : 'web']);
    $tid = (int)db()->lastInsertId();
    $ins = db()->prepare('INSERT INTO qb_items (test_id, pos, question_id, section_id, section_name) VALUES (?,?,?,?,?)');
    foreach ($pick as $i => $r) $ins->execute([$tid, $i + 1, $r['id'], $r['section_id'], $r['name']]);
    return [$tid, '', $info];
}

/** Test tarkibi haqida o'quvchiga qisqa izoh (bo'sh — izoh kerak emas) */
function qb_build_note(array $info): string
{
    $p = [];
    if (!empty($info['wrong'])) $p[] = 'avval xato qilgan yoki javobsiz qoldirgan ' . (int)$info['wrong'] . ' ta savolingiz';
    if (!empty($info['fresh']) && $p) $p[] = (int)$info['fresh'] . ' ta yangi savol';
    $s = $p ? 'Testda ' . implode(' va ', $p) . ' bor.' : '';
    if (!empty($info['again'])) $s = trim($s . ' Bu bo\'limdagi boshqa savollarni ishlab bo\'lgansiz — ' . (int)$info['again'] . ' tasi takrorlash uchun eski savollardan olindi.');
    return $s;
}

/** Mashq testini yakunlaydi: javoblar [pos => given]. Qaytaradi: to'g'rilar soni */
function qb_finish(int $testId, array $answers): int
{
    $t = row('SELECT * FROM qb_tests WHERE id=?', [$testId]);
    if (!$t || $t['status'] === 'done') return (int)($t['correct'] ?? 0);
    $ok = 0; $graded = 0;
    foreach (rows('SELECT i.pos, i.question_id, i.given, q.kind, q.answer FROM qb_items i LEFT JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=?', [$testId]) as $it) {
        $given = array_key_exists((int)$it['pos'], $answers) ? mb_substr(trim((string)$answers[(int)$it['pos']]), 0, 80) : (string)$it['given'];
        if ($given === '-') $given = '';   // botda «o'tkazib yuborish»
        if ($it['kind'] === null || (string)$it['answer'] === '') {
            // savol bazadan olib tashlangan yoki kaliti o'chirilgan — o'quvchiga zarar bo'lmasin: hisobga olinmaydi
            q('UPDATE qb_items SET given=?, ok=NULL WHERE test_id=? AND pos=?', [$given, $testId, $it['pos']]);
            continue;
        }
        $graded++;
        $good = qb_check(['kind' => $it['kind'], 'answer' => $it['answer']], $given);
        q('UPDATE qb_items SET given=?, ok=? WHERE test_id=? AND pos=?', [$given, $good ? 1 : 0, $testId, $it['pos']]);
        if ($good) $ok++;
    }
    q('UPDATE qb_tests SET status="done", correct=?, n=?, finished_at=NOW() WHERE id=? AND status<>"done"', [$ok, $graded, $testId]);
    return $ok;
}

/** Natija: umumiy va bo'limlar bo'yicha (faqat sonlar) */
function qb_result(int $testId): array
{
    $t = row('SELECT * FROM qb_tests WHERE id=?', [$testId]);
    $sec = [];
    foreach (rows('SELECT section_name, SUM(ok IS NOT NULL) n, SUM(ok=1) k FROM qb_items WHERE test_id=? GROUP BY section_id, section_name ORDER BY section_name', [$testId]) as $r)
        if ((int)$r['n'] > 0) $sec[] = ['name' => $r['section_name'], 'total' => (int)$r['n'], 'ok' => (int)$r['k']];
    return ['test' => $t, 'total' => (int)($t['n'] ?? 0), 'ok' => (int)($t['correct'] ?? 0), 'sections' => $sec];
}

/** Mashq/topshiriq testining kodi (PDF, bot va saytda bir xil) */
/**
 * Test kodi: mashq — «#<test id>», topshiriq — «#A<topshiriq id>» (hamma o'quvchida bir xil; admin chop etgan PDF bilan ham ishlaydi,
 * bot uni yuborgan o'quvchining o'z testiga bog'laydi).
 */
function qb_code(int $tid): string
{
    static $c = [];
    if (!array_key_exists($tid, $c)) $c[$tid] = (int)val('SELECT assign_id FROM qb_tests WHERE id=?', [$tid]);
    return $c[$tid] ? '#A' . $c[$tid] : '#' . $tid;
}

/** «#123» yoki «#A12» → shu o'quvchining test id si (topilmasa 0) */
function qb_code_resolve(string $code, int $sid): int
{
    if (!preg_match('/^#?([Aa]?)(\d{1,9})$/', trim($code), $m)) return 0;
    if ($m[1] !== '') return (int)val('SELECT id FROM qb_tests WHERE assign_id=? AND student_id=? AND via<>"pap"', [(int)$m[2], $sid]);   // sinf testi javoblari botdan qabul qilinmaydi
    return (int)val('SELECT id FROM qb_tests WHERE id=? AND student_id=?', [(int)$m[2], $sid]);
}

/** O'quvchining testi uchun PDF (kalitsiz, test kodi bilan). null — GD yo'q yoki savol qolmagan */
function qb_test_pdf(array $t): ?string
{
    $qs = rows("SELECT i.pos AS no, q.id, q.img, q.kind, q.nopt, '' AS answer, q.label FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? ORDER BY i.pos", [$t['id']]);
    if (!$qs) return null;
    $st = row('SELECT full_name, code FROM students WHERE id=?', [$t['student_id']]);
    return qb_pdf((string)$t['title'], trim((($st['full_name'] ?? '') ?: 'O\'quvchi') . ' · ID ' . ($st['code'] ?? '') . ' · ' . date('d.m.Y', strtotime((string)$t['created_at']))), $qs, false, qb_code((int)$t['id']));
}

/**
 * Bitta xabardagi javoblar (botga «#123 ABCD…» yoki «1:A 2:C 9:12»): testga saqlaydi.
 * Qaytaradi: ['saved'=>[pos=>val], 'bad'=>[pos=>sabab], 'missing'=>[pos,…], 'total'=>n]
 */
function qb_apply_keys(int $tid, string $text): array
{
    $text = trim((string)preg_replace('/^#[Aa]?\d+(?:\s*:\s*|\s+-\s+|\s+|$)/u', '', trim($text)));   // «#45 -3» da minus javobga tegishli
    $items = rows('SELECT i.pos, i.given, q.kind, q.nopt FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? ORDER BY i.pos', [$tid]);
    $key = qb_parse_key($text);
    $lettersOnly = preg_match('/^[A-Fa-f\s,]+$/', $text) === 1;
    $out = ['saved' => [], 'bad' => [], 'missing' => [], 'total' => count($items)];
    $byPos = [];
    foreach ($items as $it) $byPos[(int)$it['pos']] = $it;
    foreach ($key as $pos => $v) {
        $pos = (int)$pos; $v = trim((string)$v);
        if (!isset($byPos[$pos])) { $out['bad'][$pos] = 'bunday savol yo‘q'; continue; }
        $it = $byPos[$pos];
        if ($it['kind'] === 'open') {
            if ($lettersOnly) { $out['bad'][$pos] = 'ochiq savol — ' . $pos . ':javob ko‘rinishida yozing'; continue; }
            if ($v === '' || mb_strlen($v) > 80) { $out['bad'][$pos] = 'javob 1–80 belgi'; continue; }
        } else {
            $v = strtoupper($v); $max = (int)$it['nopt'] === 6 ? 'F' : 'D';
            if (!preg_match('/^[A-F]$/', $v) || $v > $max) { $out['bad'][$pos] = 'A–' . $max . ' bo‘lishi kerak'; continue; }
        }
        q('UPDATE qb_items SET given=? WHERE test_id=? AND pos=?', [$v, $tid, $pos]);
        $out['saved'][$pos] = $v;
    }
    foreach (rows('SELECT i.pos FROM qb_items i JOIN qb_questions q ON q.id=i.question_id WHERE i.test_id=? AND i.given IN ("","-") ORDER BY i.pos', [$tid]) as $r) $out['missing'][] = (int)$r['pos'];   // bazadan o'chirilgan savol «javobsiz» deb turmasin
    ksort($out['saved']); ksort($out['bad']);
    return $out;
}

/** Savol rasmi shu o'quvchining mashq testlarida bormi (rasmni ko'rish huquqi). Sinf testi savollari — faqat natijasi kiritilgan bo'lsa */
function qb_student_can_see(int $sid, int $questionId): bool
{
    return (bool)val('SELECT 1 FROM qb_items i JOIN qb_tests t ON t.id=i.test_id WHERE t.student_id=? AND i.question_id=? AND NOT (t.via="pap" AND t.status<>"done") LIMIT 1', [$sid, $questionId]);
}

/* ---------------- PDF chiqarish ---------------- */

/**
 * Testlar (savollar PDF lari, sinf testi varaqlari) orqa fonidagi yozuv. Sozlamalar → Markaz da o'zgartiriladi;
 * hech kiritilmagan bo'lsa — sayt domeni (masalan, masud-mamurovich.uz); bo'sh saqlansa — yozuvsiz.
 */
function qb_watermark(): string
{
    $v = val("SELECT v FROM meta WHERE k='set_qb_wm'");
    if ($v !== null) return trim((string)$v);
    $host = (string)parse_url(trim(app_setting('public_url')), PHP_URL_HOST);
    if ($host === '') $host = (string)preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
    $host = strtolower((string)preg_replace('/^www\./i', '', $host));
    if ($host === '' || $host === 'localhost' || filter_var($host, FILTER_VALIDATE_IP)) return '';
    return $host;
}

/** Sinf testi varaqlari uchun fon yozuvi: [SVG naqsh, ekrandagi qatlam (har varaqda), chop etishdagi qatlam (har betda)] */
function qb_watermark_svg(string $text): array
{
    if ($text === '') return ['', '', ''];
    $t = e($text);
    $fs = 19;
    $w = (int)max(260, ceil(mb_strlen($text) * $fs * 0.62) + 90);   // yozuv naqsh katagiga sig'sin (kesilib qolmasin)
    $half = intdiv($w, 2);
    $txt = fn(int $x, int $y) => '<text x="' . $x . '" y="' . $y . '">' . $t . '</text>';
    $defs = '<svg class="pq-wm-defs" width="0" height="0" aria-hidden="true" focusable="false"><defs><pattern id="pqWm" patternUnits="userSpaceOnUse" width="' . $w . '" height="150" patternTransform="rotate(-30)">'
        . '<g font-family="Inter, Arial, Helvetica, sans-serif" font-size="' . $fs . '" font-weight="700" fill="#000" fill-opacity=".085">'
        . $txt(0, 45) . $txt($half, 120) . $txt($half - $w, 120) . '</g></pattern></defs></svg>';
    $layer = '<svg width="100%" height="100%" aria-hidden="true" focusable="false"><rect width="100%" height="100%" fill="url(#pqWm)"/></svg>';
    return [$defs, '<div class="pq-wm-s" aria-hidden="true">' . $layer . '</div>', '<div class="pq-wm-p" aria-hidden="true">' . $layer . '</div>'];
}

/**
 * Juda sodda PDF yozuvchi: A4 sahifalar, matn (Helvetica) va JPEG rasmlar. Tashqi kutubxonasiz.
 * Koordinatalar punktda, y yuqoridan hisoblanadi.
 */
final class MiniPdf
{
    const W = 595.28; const H = 841.89;
    private $objs = [];      // raqam => matn yoki ['stream'=>..., 'dict'=>...]
    private $pages = [];     // sahifa obyekt raqamlari
    private $content = '';
    private $xobjs = [];     // joriy sahifadagi rasmlar [nom => obyekt raqami]
    private $open = false;
    private $imgN = 0;
    private $wm = '';        // fon yozuvi — har sahifada, juda och rangda, qiya qatorlab

    /** Fon yozuvi (bo'sh — yo'q). Mazmun ustidan shaffof chiziladi: savol rasmlarining oq foni uni yashirib qo'ymaydi */
    public function watermark(string $text): void { $this->wm = trim($text); }

    private function wmOps(): string
    {
        $t = self::enc($this->wm);
        if ($t === '') return '';
        $size = 20.0;
        $tw = max(80.0, strlen($t) * $size * 0.58);   // Helvetica-Bold: o'rtacha ~0,58 em
        $stepX = $tw + 64.0; $stepY = 112.0; $R = 560.0;  // R — sahifa diagonalining yarmidan katta: burchaklar ham qoplanadi
        $o = sprintf("q /GW gs 0.12 g 1 0 0 1 %.2F %.2F cm 0.8660 0.5000 -0.5000 0.8660 0 0 cm BT /F2 %.1F Tf\n", self::W / 2, self::H / 2, $size);
        $row = 0;
        for ($y = -$R; $y <= $R; $y += $stepY, $row++) {
            for ($x = -$R - $tw + ($row % 2) * $stepX / 2; $x <= $R; $x += $stepX) $o .= sprintf("1 0 0 1 %.2F %.2F Tm (%s) Tj\n", $x, $y, $t);
        }
        return $o . "ET Q\n";
    }

    private function add($body): int { $this->objs[] = $body; return count($this->objs) + 2; }   // 1 — Catalog, 2 — Pages

    public function newPage(): void
    {
        $this->closePage();
        $this->content = ''; $this->xobjs = []; $this->open = true;
    }

    private function closePage(): void
    {
        if (!$this->open) return;
        if ($this->wm !== '') $this->content .= $this->wmOps();
        $c = $this->add(['stream' => $this->content, 'dict' => '']);
        $xo = '';
        foreach ($this->xobjs as $n => $ref) $xo .= "/$n $ref 0 R ";
        $gs = $this->wm !== '' ? '/ExtGState << /GW __GW__ 0 R >> ' : '';
        $pg = $this->add('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Contents ' . $c . ' 0 R /Resources << /Font << /F1 __F1__ 0 R /F2 __F2__ 0 R >> /XObject << ' . $xo . '>> ' . $gs . '>> >>');
        $this->pages[] = $pg;
        $this->open = false;
    }

    private static function enc(string $s): string
    {
        $s = str_replace(['ʻ', 'ʼ', '‘', '’', '`', '“', '”', '—', '–', '›', '→', '…'], ["'", "'", "'", "'", "'", '"', '"', '-', '-', '>', '->', '...'], $s);
        $t = function_exists('iconv') ? @iconv('UTF-8', 'CP1252//TRANSLIT//IGNORE', $s) : false;
        if ($t === false) $t = preg_replace('/[^\x20-\x7E]/', '?', $s);
        return str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\\(', '\\)', '', ' '], $t);
    }

    public function text(float $x, float $y, float $size, string $s, bool $bold = false): void
    {
        $this->content .= sprintf("BT /%s %.2F Tf %.2F %.2F Td (%s) Tj ET\n", $bold ? 'F2' : 'F1', $size, $x, self::H - $y, self::enc($s));
    }

    public function line(float $x1, float $y1, float $x2, float $y2, float $w = 0.5): void
    {
        $this->content .= sprintf("%.2F w %.2F %.2F m %.2F %.2F l S\n", $w, $x1, self::H - $y1, $x2, self::H - $y2);
    }

    public function rect(float $x, float $y, float $w, float $h, float $lw = 0.5): void
    {
        $this->content .= sprintf("%.2F w %.2F %.2F %.2F %.2F re S\n", $lw, $x, self::H - $y - $h, $w, $h);
    }

    /** JPEG rasm: (x, y) — chap-yuqori burchak, $w × $h punkt */
    public function image(string $jpeg, int $pw, int $ph, float $x, float $y, float $w, float $h): void
    {
        $ref = $this->add(['stream' => $jpeg, 'dict' => '/Type /XObject /Subtype /Image /Width ' . $pw . ' /Height ' . $ph . ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode']);
        $name = 'Im' . (++$this->imgN);
        $this->xobjs[$name] = $ref;
        $this->content .= sprintf("q %.2F 0 0 %.2F %.2F %.2F cm /%s Do Q\n", $w, $h, $x, self::H - $y - $h, $name);
    }

    public function output(): string
    {
        $this->closePage();
        $f1 = $this->add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
        $f2 = $this->add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
        $gw = $this->add('<< /Type /ExtGState /ca 0.08 /CA 0.08 >>');   // fon yozuvi shaffofligi
        $kids = implode(' ', array_map(fn($n) => $n . ' 0 R', $this->pages));
        $all = [1 => '<< /Type /Catalog /Pages 2 0 R >>', 2 => '<< /Type /Pages /Kids [' . $kids . '] /Count ' . count($this->pages) . ' >>'];
        foreach ($this->objs as $i => $o) $all[$i + 3] = $o;
        $out = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $off = [];
        foreach ($all as $n => $o) {
            $off[$n] = strlen($out);
            if (is_array($o)) {
                $out .= "$n 0 obj\n<< " . $o['dict'] . ' /Length ' . strlen($o['stream']) . " >>\nstream\n" . $o['stream'] . "\nendstream\nendobj\n";
            } else {
                $o = str_replace(['__F1__', '__F2__', '__GW__'], [(string)$f1, (string)$f2, (string)$gw], $o);
                $out .= "$n 0 obj\n$o\nendobj\n";
            }
        }
        $xref = strlen($out);
        $out .= "xref\n0 " . (count($all) + 1) . "\n0000000000 65535 f \n";
        foreach ($all as $n => $_) $out .= sprintf("%010d 00000 n \n", $off[$n]);
        $out .= "trailer\n<< /Size " . (count($all) + 1) . " /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n";
        return $out;
    }
}

/** PNG faylni oq fonli JPEG ga aylantiradi: [jpeg bayt, w, h] yoki null (GD yo'q/xato) */
function qb_png_to_jpeg(string $path): ?array
{
    if (!function_exists('imagecreatefrompng') || !is_file($path)) return null;
    $im = @imagecreatefrompng($path);
    if (!$im) return null;
    $w = imagesx($im); $h = imagesy($im);
    $bg = imagecreatetruecolor($w, $h);
    imagefill($bg, 0, 0, imagecolorallocate($bg, 255, 255, 255));
    imagecopy($bg, $im, 0, 0, 0, 0, $w, $h);
    ob_start(); imagejpeg($bg, null, 88); $jpg = (string)ob_get_clean();
    if (PHP_VERSION_ID < 80000) { imagedestroy($im); imagedestroy($bg); }   // PHP 8.5 da eskirgan
    return [$jpg, $w, $h];
}

/**
 * Savollar to'plami PDF: $title, $subtitle, $qs — [['id','img','kind','nopt','answer','label'], …] (tartib bilan).
 * $withKey: oxirida javoblar kaliti sahifasi; aks holda javob belgilash jadvali.
 */
function qb_pdf(string $title, string $subtitle, array $qs, bool $withKey = false, string $code = ''): ?string
{
    @ini_set('memory_limit', '256M'); @set_time_limit(120);   // katta skan rasmlari
    if (!function_exists('imagecreatefrompng')) return null;
    $pdf = new MiniPdf();
    $pdf->watermark(qb_watermark());
    $L = 42.0; $R = MiniPdf::W - 42.0; $maxW = $R - $L - 22; $top = 70.0; $bottom = MiniPdf::H - 48.0;
    $pageNo = 0;
    $tw = $code !== '' ? 58 : 72;
    $head = function () use ($pdf, $title, $subtitle, $L, $R, &$pageNo, $code, $tw) {
        $pdf->newPage(); $pageNo++;
        $pdf->text($L, 34, 12, mb_strimwidth($title, 0, $tw, '…'), true);
        $pdf->text($L, 48, 8.5, mb_strimwidth($subtitle, 0, 120, '…'));
        if ($code !== '') {   // test kodi — javoblarni botga shu kod bilan yuborish uchun
            $pdf->rect($R - 96, 22, 96, 26, 1.2);
            $pdf->text($R - 90, 33, 7.5, 'TEST KODI');
            $pdf->text($R - 90, 45, 14, $code, true);
        }
        $pdf->line($L, 54, $R, 54, 0.8);
        $pdf->text($R - 40, MiniPdf::H - 24, 8, 'Sahifa ' . $pageNo);
        if ($code !== '') $pdf->text($L, MiniPdf::H - 24, 8, 'Test kodi ' . $code);
    };
    $head(); $y = $top;
    foreach ($qs as $i => $q) {
        $j = qb_png_to_jpeg(qb_dir() . '/' . basename((string)$q['img']));
        if (!$j) continue;
        [$jpg, $pw, $ph] = $j;
        $scale = min(1.0, $maxW / ($pw * 0.5), 1.0);   // 200% da qirqilgan deb hisoblab: 1 px = 0.5 pt
        $dw = $pw * 0.5 * $scale; $dh = $ph * 0.5 * $scale;
        $maxH = $bottom - $top;
        if ($dh > $maxH) { $k = $maxH / $dh; $dw *= $k; $dh *= $k; }
        if ($y + $dh > $bottom) { $head(); $y = $top; }
        $pdf->text($L, $y + 11, 11, (int)($q['no'] ?? $i + 1) . '.', true);   // 'no' — testdagi haqiqiy raqam (o'chirilgan savol bo'lsa ham siljimasin)
        $pdf->image($jpg, $pw, $ph, $L + 22, $y, $dw, $dh);
        $y += $dh + 14;
    }
    // javoblar sahifasi
    $head(); $y = $top;
    $pdf->text($L, $y + 6, 12, $withKey ? 'Javoblar kaliti' : 'Javoblar varaqasi', true); $y += 26;
    if ($code !== '' && !$withKey) {   // botga yuborish namunasi
        $openPos = 0;
        foreach (array_values($qs) as $i => $x) if (($x['kind'] ?? '') === 'open') { $openPos = (int)($x['no'] ?? $i + 1); break; }
        $pdf->text($L, $y, 9, 'Javoblarni Telegram botga bitta xabarda yuboring:  ' . ($openPos ? $code . ' 1:A 2:C ' . $openPos . ':12   (raqam:javob)' : $code . ' ABCD...   (har harf - bitta savol)'));
        $y += 18;
    }
    $colW = ($R - $L) / 2;
    foreach ($qs as $i => $q) {
        $col = $i % 2; $row = intdiv($i, 2);
        if ($col === 0 && $row > 0 && $y + 22 > $bottom) { $head(); $y = $top; }
        $x = $L + $col * $colW; $yy = $y;
        if ($col === 1) { /* ikkinchi ustun — o'sha qator */ }
        $pdf->text($x, $yy + 10, 10, str_pad((string)(int)($q['no'] ?? $i + 1), 2, ' ', STR_PAD_LEFT) . '.', true);
        if ($withKey) $pdf->text($x + 24, $yy + 10, 10, (string)$q['answer']);
        elseif ($q['kind'] === 'open') $pdf->rect($x + 24, $yy - 1, 110, 15);
        else {
            $n = (int)$q['nopt'] === 6 ? 6 : 4;
            for ($k = 0; $k < $n; $k++) { $pdf->rect($x + 26 + $k * 28, $yy - 1, 15, 15); $pdf->text($x + 30 + $k * 28, $yy + 10, 9, chr(65 + $k)); }
        }
        if ($col === 1) $y += 22;
    }
    return $pdf->output();
}
