<?php
defined('APP_ROOT') || exit;
/**
 * Telegram bot ichida javob kiritish (3-bosqich).
 * Yopiq savollar — inline tugmalar (A–D / A–F), ochiq topshiriqlar — oddiy matn.
 * Javoblar saytdagi bilan bitta `responses` yozuviga saqlanadi (tekshiruvlari api&a=online_save bilan bir xil),
 * shuning uchun o'quvchi istalgan payt botdan saytga (yoki aksincha) o'tishi mumkin. Baholash kodiga tegilmaydi.
 */

/** Holatni saqlash: qaysi testning nechanchi savoli ochiq va qaysi xabar tahrirlanadi */
function tg_ans_state(int $chat, int $testId, int $idx, int $msgId): void
{
    q('REPLACE INTO tg_state (chat_id, step, data, msg_id) VALUES (?,?,?,?)', [$chat, 'ans', $testId . ':' . $idx, $msgId]);
}

/** O'quvchining javob yozuvi; kerak bo'lsa (test ochiq paytda) yangisini boshlaydi */
function tg_ans_resp(array $test, int $sid, bool $mayStart): ?array
{
    $r = row('SELECT * FROM responses WHERE test_id=? AND student_id=?', [$test['id'], $sid]);
    if (!$r && $mayStart && online_open($test) && tg_in_audience($test, $sid)) {   // 2.5: auditoriya; to'lov sharti — qulf ostida
        $st = mock_start_online($sid, $test);
        $r = $st['resp'];
    }
    return $r;
}

/** Muddat tugagan bo'lsa javobni yopadi (api&a=online_save dagi qoida: muddat + 60 s zaxira). true = yopildi */
function tg_ans_expired(array $test, array $resp): bool
{
    if ($resp['status'] !== 'in_progress' || time() <= online_deadline($test, $resp) + 60) return false;
    $up = q('UPDATE responses SET status="submitted", submitted_at=NOW() WHERE id=? AND status="in_progress"', [$resp['id']]);
    if ($up->rowCount()) q('UPDATE tests SET dirty=1 WHERE id=?', [$test['id']]);
    return true;
}

/** Bitta javobni saqlaydi (sayt API sidagi bilan bir xil tozalash qoidalari) */
function tg_ans_save(array $test, array $resp, array $it, string $val): void
{
    if ($it['type'] === 'mc') $val = in_array($val, $it['opts'], true) ? $val : '';
    else $val = trim(mb_substr(str_replace('#', '', $val), 0, 40));
    $cur = json_decode((string)val('SELECT answers FROM responses WHERE id=?', [$resp['id']]) ?: '{}', true) ?: [];
    $cur[$it['label']] = $val;
    q('UPDATE responses SET answers=? WHERE id=? AND status="in_progress"', [json_encode($cur, JSON_UNESCAPED_UNICODE), $resp['id']]);
}

function tg_ans_counts(array $items, array $ans): int
{
    $n = 0;
    foreach ($items as $it) if (trim((string)($ans[$it['label']] ?? '')) !== '') $n++;
    return $n;
}

/** Savol ko'rinishi: [matn, klaviatura] */
function tg_ans_render(array $test, array $resp, int $idx): array
{
    $items = test_items($test);
    $N = count($items);
    $idx = max(0, min($N - 1, $idx));
    $it = $items[$idx];
    $ans = json_decode($resp['answers'] ?: '{}', true) ?: [];
    $cur = trim((string)($ans[$it['label']] ?? ''));
    $done = tg_ans_counts($items, $ans);
    $left = max(0, online_deadline($test, $resp) - time());
    $t = "✏️ <b>" . tg_h($test['title']) . "</b>\n";
    $t .= "Savol <b>" . tg_h($it['label']) . "</b>  ·  belgilandi " . $done . " / " . $N . "  ·  ⏳ ~" . (int)ceil($left / 60) . " daqiqa\n\n";
    if ($it['type'] === 'mc') {
        $t .= $cur !== '' ? "Javobingiz: <b>" . tg_h($cur) . "</b>  (bekor qilish — shu harfni qayta bosing)" : "Javob tugmasini bosing:";
    } else {
        $t .= $cur !== '' ? "Javobingiz: <code>" . tg_h($cur) . "</code>\nO'zgartirish uchun yangisini yozib yuboring." : "Javobni <b>yozib yuboring</b>.";
        $t .= "\n<i>Eng sodda ko'rinishda: butun son, 0.5, 3/4, 2√3; bir nechta qiymat bo'lsa ; bilan: 2;3</i>";
    }
    if ($done >= $N) $t .= "\n\n✅ Hammasi belgilandi — «Yakunlash» tugmasini bosing.";
    $kb = [];
    $p = 'ans:' . (int)$test['id'] . ':';
    if ($it['type'] === 'mc') {
        $row = [];
        foreach ($it['opts'] as $o) {
            $row[] = ['text' => ($cur === $o ? '✅ ' : '') . $o, 'callback_data' => $p . 'set:' . $idx . ':' . $o];
            if (count($row) === 4) { $kb[] = $row; $row = []; }
        }
        if ($row) $kb[] = $row;
    } elseif ($cur !== '') {
        $kb[] = [['text' => '🧹 Javobni o\'chirish', 'callback_data' => $p . 'clr:' . $idx]];
    }
    $kb[] = [
        ['text' => '⬅️', 'callback_data' => $p . 'nav:' . ($idx > 0 ? $idx - 1 : $N - 1)],
        ['text' => '📋 ' . ($idx + 1) . '/' . $N, 'callback_data' => $p . 'sheet:' . $idx],
        ['text' => '➡️', 'callback_data' => $p . 'nav:' . ($idx < $N - 1 ? $idx + 1 : 0)],
    ];
    $kb[] = [['text' => '✅ Yakunlash', 'callback_data' => $p . 'fin:' . $idx]];
    return [$t, ['inline_keyboard' => $kb]];
}

/** Varaq ko'rinishi: barcha savollar bo'yicha tugmalar (• — javob berilgan) */
function tg_ans_render_sheet(array $test, array $resp, int $idx): array
{
    $items = test_items($test);
    $ans = json_decode($resp['answers'] ?: '{}', true) ?: [];
    $done = tg_ans_counts($items, $ans);
    $t = "📋 <b>" . tg_h($test['title']) . "</b> — javoblar varaqasi\nBelgilandi: <b>" . $done . " / " . count($items) . "</b>. Savolga o'tish uchun raqamini bosing (• — javob berilgan).";
    $kb = []; $row = [];
    $p = 'ans:' . (int)$test['id'] . ':';
    foreach ($items as $i => $it) {
        $has = trim((string)($ans[$it['label']] ?? '')) !== '';
        $row[] = ['text' => $it['label'] . ($has ? '•' : ''), 'callback_data' => $p . 'nav:' . $i];
        if (count($row) === 7) { $kb[] = $row; $row = []; }
    }
    if ($row) $kb[] = $row;
    $kb[] = [['text' => '⬅️ Savolga qaytish', 'callback_data' => $p . 'nav:' . $idx], ['text' => '✅ Yakunlash', 'callback_data' => $p . 'fin:' . $idx]];
    return [$t, ['inline_keyboard' => $kb]];
}

/** Xabarni tahrirlaydi; bo'lmasa yangisini yuboradi. Qaytaradi: amaldagi message_id */
function tg_ans_show(int $chat, array $view, int $msgId): int
{
    [$text, $kb] = $view;
    if ($msgId) {
        $p = ['chat_id' => $chat, 'message_id' => $msgId, 'text' => $text, 'parse_mode' => 'HTML'];
        if ($kb) $p['reply_markup'] = $kb;
        $r = tg_call('editMessageText', $p);
        if ($r['ok'] || strpos($r['desc'], 'not modified') !== false) return $msgId;
    }
    $r = tg_send($chat, $text, $kb);
    return (int)($r['result']['message_id'] ?? 0);
}

/** Muddat tugaganda ko'rinadigan xabar */
function tg_ans_closed(int $chat, array $test, array $resp, int $msgId): void
{
    $items = test_items($test);
    $ans = json_decode($resp['answers'] ?: '{}', true) ?: [];
    $t = "⏹ Vaqt tugadi. Oxirgi saqlangan javoblaringiz qabul qilindi: <b>" . tg_ans_counts($items, $ans) . " / " . count($items) . "</b>.\nNatija e'lon qilinganda shu yerga keladi.";
    tg_ans_show($chat, [$t, null], $msgId);
    q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
}

/**
 * «ans:…» tugmalari. $parts: [testId, amal (nav|set|clr|sheet|fin|fin2 yoki bo'sh), …]
 * $cb — answerCallbackQuery yuboruvchi yopilma.
 */
function tg_ans_cb(int $chat, array $st, string $data, callable $cb): void
{
    if (!preg_match('/^ans:(\d+)(?::(nav|set|clr|sheet|fin2|fin):?(\d*)(?::(.*))?)?$/u', $data, $m)) { $cb(); return; }
    $test = test_by_id((int)$m[1]);
    $act = $m[2] ?? '';
    $idx = (int)($m[3] ?? 0);
    $opt = (string)($m[4] ?? '');
    if (!$test || !$test['online'] || !$test['tg_enabled']) { $cb('Bu test bot orqali o\'tkazilmaydi', true); return; }
    $sid = (int)$st['id'];
    $resp = tg_ans_resp($test, $sid, true);
    if (!$resp) {
        $can = mock_can_start($sid, $test);
        if (!$can['ok']) { $cb($can['reason'], true); return; }
        if (!tg_in_audience($test, $sid)) { $cb('Siz bu MOCK ro\'yxatida yo\'qsiz. Markaz bilan bog\'laning.', true); return; }
        $cb(empty($test['online_start']) || time() >= strtotime((string)$test['online_start']) ? 'Test vaqti tugagan' : 'Test hali boshlanmagan', true);
        return;
    }
    $state = row('SELECT * FROM tg_state WHERE chat_id=?', [$chat]);
    $msgId = $state && $state['step'] === 'ans' ? (int)$state['msg_id'] : 0;
    if ($resp['status'] === 'submitted') { $cb('Siz bu testni topshirgansiz', true); q('DELETE FROM tg_state WHERE chat_id=?', [$chat]); return; }
    if (tg_ans_expired($test, $resp)) { $cb('Vaqt tugadi', true); tg_ans_closed($chat, $test, $resp, $msgId); return; }
    $items = test_items($test);
    $N = count($items);
    $idx = max(0, min($N - 1, $idx));

    if ($act === 'set' || $act === 'clr') {
        $it = $items[$idx];
        $cur = json_decode($resp['answers'] ?: '{}', true) ?: [];
        $val = $act === 'clr' || (string)($cur[$it['label']] ?? '') === $opt ? '' : $opt;   // tanlangan harfni qayta bosish — bekor qilish
        tg_ans_save($test, $resp, $it, $val);
        $resp = row('SELECT * FROM responses WHERE id=?', [$resp['id']]);
        $cb($val !== '' ? $it['label'] . ' → ' . $val : $it['label'] . ' tozalandi');
        if ($val !== '' && $it['type'] === 'mc' && $idx < $N - 1) $idx++;   // keyingi savolga o'tamiz
        $view = tg_ans_render($test, $resp, $idx);
    } elseif ($act === 'sheet') {
        $cb();
        $view = tg_ans_render_sheet($test, $resp, $idx);
    } elseif ($act === 'fin') {
        $cb();
        $done = tg_ans_counts($items, json_decode($resp['answers'] ?: '{}', true) ?: []);
        $t = "Testni yakunlaysizmi?\nBelgilangan: <b>$done / $N</b>." . ($done < $N ? "\n⚠️ " . ($N - $done) . " ta savol javobsiz." : '') . "\nYakunlagandan keyin o'zgartirib bo'lmaydi.";
        $p = 'ans:' . (int)$test['id'] . ':';
        $view = [$t, ['inline_keyboard' => [
            [['text' => '✅ Ha, yakunlash', 'callback_data' => $p . 'fin2:' . $idx]],
            [['text' => '⬅️ Yo\'q, davom etaman', 'callback_data' => $p . 'nav:' . $idx]],
        ]]];
    } elseif ($act === 'fin2') {
        $up = q('UPDATE responses SET status="submitted", submitted_at=NOW() WHERE id=? AND status="in_progress"', [$resp['id']]);
        if ($up->rowCount()) q('UPDATE tests SET dirty=1 WHERE id=?', [$test['id']]);
        $done = tg_ans_counts($items, json_decode($resp['answers'] ?: '{}', true) ?: []);
        $cb('Qabul qilindi!');
        tg_ans_show($chat, ["✅ <b>" . tg_h($test['title']) . "</b> topshirildi.\nJavob berilgan: <b>$done / $N</b> ta savol.\nNatija e'lon qilinganda shu yerga keladi.", null], $msgId);
        q('DELETE FROM tg_state WHERE chat_id=?', [$chat]);
        return;
    } else {
        $cb();
        $view = tg_ans_render($test, $resp, $idx);
    }
    $msgId = tg_ans_show($chat, $view, $msgId);
    tg_ans_state($chat, (int)$test['id'], $idx, $msgId);
}

/** «ans» rejimida kelgan oddiy matn: ochiq savolga javob (yoki yopiq savolga harf). true = qabul qilindi */
function tg_ans_text(int $chat, array $st, array $state, string $text): bool
{
    if (!preg_match('/^(\d+):(\d+)$/', (string)$state['data'], $m)) return false;
    $test = test_by_id((int)$m[1]);
    if (!$test || !$test['online']) return false;
    $resp = tg_ans_resp($test, (int)$st['id'], false);
    if (!$resp || $resp['status'] !== 'in_progress') return false;
    $msgId = (int)$state['msg_id'];
    if (tg_ans_expired($test, $resp)) { tg_ans_closed($chat, $test, $resp, $msgId); return true; }
    $items = test_items($test);
    $idx = max(0, min(count($items) - 1, (int)$m[2]));
    $it = $items[$idx];
    $val = trim($text);
    if ($it['type'] === 'mc') {
        $val = strtoupper($val);
        if (!in_array($val, $it['opts'], true)) { tg_send($chat, 'Bu savolga tugmalar bilan javob bering (' . tg_h(implode('/', $it['opts'])) . ').'); return true; }
    } elseif (mb_strlen($val) > 40) {
        tg_send($chat, 'Javob juda uzun (40 belgigacha). Eng sodda ko\'rinishda yozing.');
        return true;
    }
    tg_ans_save($test, $resp, $it, $val);
    $resp = row('SELECT * FROM responses WHERE id=?', [$resp['id']]);
    if ($idx < count($items) - 1) $idx++;
    $msgId = tg_ans_show($chat, tg_ans_render($test, $resp, $idx), $msgId);
    tg_ans_state($chat, (int)$test['id'], $idx, $msgId);
    return true;
}
