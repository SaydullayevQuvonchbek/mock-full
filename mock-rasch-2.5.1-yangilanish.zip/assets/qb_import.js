/* Savollar bazasi: PDF/rasm dan savollarni qirqish va yuklash (hammasi brauzerda; serverga tayyor PNG ketadi).
   2.4: bet oralig'i; ustunlar o'zi aniqlanadi; PDF matnidagi savol raqamlari bo'yicha bo'lish (bo'lmasa — bo'sh joy bo'yicha);
   bet sarlavhasi va bet raqami tashlab ketiladi; natija betning o'zida ko'rsatiladi (bosib belgilash, chizib qo'shish);
   bo'lakni ikkiga bo'lish; bo'lim darajasi avtomatik; sozlamalar eslab qolinadi. */
(function () {
  'use strict';
  const cfg = window.QB;
  const csrf = document.querySelector('meta[name=csrf]').content;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const toBlob = (c, type) => new Promise(r => c.toBlob(r, type || 'image/png'));

  /* piece: {blob,url,w,h,label,src,sel,lv,parts:[{fi,pn,rect}],key:[fi,pn,col,y],note,orig,num,showOrig}
     lv: null — umumiy daraja (bo'lim darajasi yoki yuqoridagi tanlov) */
  let pieces = [];
  let docs = [];            // [{name, pdf|null, img|null, n}]
  let pageInfo = {};        // 'fi:pn' → {w, h, split}
  let pages = [];           // ko'rib chiqiladigan betlar: [{fi, pn}]
  let view = null;          // joriy bet {fi, pn}
  let manualMode = false;   // «faqat qo'lda» — bo'laklar chizilgan tartibda qoladi (kalit shu tartibda)
  let showTok = 0;          // betni ko'rsatish navbati (eski so'rov yangisining ustiga chizmasin)
  let busy = false;
  let pdfLoading = null;
  let prep = null;          // tanlangan bitta PDF (bet sonini ko'rsatish uchun oldindan ochilgan): {file, pdf}
  const cache = new Map();  // 'fi:pn' → canvas (oxirgi 3 tasi)
  const LV = cfg.levels || { 1: 'Oson', 2: "O'rta", 3: 'Qiyin' };
  const secLv = () => +((cfg.secLevels || {})[$('qbSec').value]) || 0;
  const batchLevel = () => secLv() || +($('qbLevel') && $('qbLevel').value) || 0;
  const pieceLevel = p => (secLv() ? 0 : p.lv) || batchLevel();
  const pk = (fi, pn) => fi + ':' + pn;

  /* ---------- sozlamalar (shu brauzerda eslab qolinadi) ---------- */
  const SKEY = 'qbImportOpts';
  function opts() {
    return {
      mode: (document.querySelector('input[name=qbMode]:checked') || {}).value || 'auto',
      cols: +$('qbCols').value || 0, gap: +$('qbGap').value > 0 ? Math.max(4, +$('qbGap').value) : 0,   // 0 — avtomatik
      top: Math.max(0, Math.min(30, +$('qbTop').value || 0)), bot: Math.max(0, Math.min(30, +$('qbBot').value || 0)),
      strip: !$('qbStrip') || $('qbStrip').checked, nums: !$('qbNumSplit') || $('qbNumSplit').checked,
      kind: $('qbKind').value,
    };
  }
  function saveOpts() { try { localStorage.setItem(SKEY, JSON.stringify(opts())); } catch (e) { /* e'tiborsiz */ } }
  function loadOpts() {
    let o = null;
    try { o = JSON.parse(localStorage.getItem(SKEY) || 'null'); } catch (e) { o = null; }
    if (!o || typeof o !== 'object') return;
    const r = document.querySelector('input[name=qbMode][value="' + (o.mode === 'page' || o.mode === 'manual' ? o.mode : 'auto') + '"]');
    if (r) r.checked = true;
    if ([0, 1, 2].indexOf(+o.cols) >= 0) $('qbCols').value = String(+o.cols);
    if (+o.gap >= 4 && +o.gap <= 120) $('qbGap').value = +o.gap;
    if (+o.top >= 0 && +o.top <= 30) $('qbTop').value = +o.top;
    if (+o.bot >= 0 && +o.bot <= 30) $('qbBot').value = +o.bot;
    if (typeof o.strip === 'boolean') $('qbStrip').checked = o.strip;
    if (typeof o.nums === 'boolean') $('qbNumSplit').checked = o.nums;
    if (['mc4', 'mc6', 'open'].indexOf(o.kind) >= 0) $('qbKind').value = o.kind;
    if (o.mode !== 'auto' || +o.cols || +o.top || +o.bot || o.nums === false || o.strip === false || +o.gap) $('qbAdv').open = true;   // odatdagidan farqli — ko'rinib tursin
  }

  /* ---------- pdf.js ---------- */
  function loadPdfJs() {
    if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
    if (pdfLoading) return pdfLoading;
    pdfLoading = new Promise((res, rej) => {
      const s = document.createElement('script');
      s.src = cfg.pdfjs;
      s.onload = () => { window.pdfjsLib.GlobalWorkerOptions.workerSrc = cfg.worker; res(window.pdfjsLib); };
      s.onerror = () => { pdfLoading = null; rej(new Error('PDF o\'quvchi yuklanmadi. PNG/JPG rasm yuklab ko\'ring.')); };
      document.head.appendChild(s);
    });
    return pdfLoading;
  }
  async function openPdf(f) {
    const lib = await loadPdfJs();
    return lib.getDocument({ data: await f.arrayBuffer(), isEvalSupported: false }).promise;
  }

  /* ---------- kalit matnini tahlil qilish (server bilan bir xil qoida) ---------- */
  function parseKey(s) {
    s = (s || '').trim();
    const out = {};
    if (!s) return out;
    const compact = s.replace(/[\s,]+/g, '');
    if (/^[A-Fa-f]+$/.test(compact)) { compact.toUpperCase().split('').forEach((c, i) => { out[i + 1] = c; }); return out; }
    if (/^(?:\d{1,3}[A-Fa-f])+$/.test(compact)) { compact.replace(/(\d{1,3})([A-Fa-f])/g, (_, n, c) => { out[+n] = c.toUpperCase(); return ''; }); return out; }
    let pos = 0;
    s.split(/\s+/).filter(Boolean).forEach(tok => {
      const m = tok.match(/^(\d{1,3})[:=)](.+)$/);
      let v;
      if (m) { pos = +m[1]; v = m[2]; } else { pos++; v = tok; }
      out[pos] = v;
    });
    return out;
  }

  /* ---------- sahifani rasmga aylantirish ---------- */
  function newCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h));
    const x = c.getContext('2d', { willReadFrequently: true });
    x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
    return c;
  }

  /** PDF matn qatlami: [{x, y (tayanch chiziq), fh, s}] — canvas koordinatalarida */
  async function textItems(page, vp) {
    let tc;
    try { tc = await page.getTextContent(); } catch (e) { return []; }
    const out = [];
    for (const it of tc.items) {
      const s = it.str || '';
      if (!s.trim()) continue;
      const t = window.pdfjsLib.Util.transform(vp.transform, it.transform);
      out.push({ x: t[4], y: t[5], fh: Math.hypot(t[2], t[3]) || 10, s });
    }
    return out;
  }

  async function renderPdfPage(pdf, n) {
    const page = await pdf.getPage(n);
    const v0 = page.getViewport({ scale: 1 });
    const scale = Math.max(1, Math.min(2, 1800 / v0.width));
    const vp = page.getViewport({ scale });
    const c = newCanvas(vp.width, vp.height);
    const x = c.getContext('2d', { willReadFrequently: true });
    await page.render({ canvasContext: x, viewport: vp }).promise;
    c.qbNums = window.QBStrip ? await window.QBStrip.pageNumbers(page, vp, window.pdfjsLib) : [];   // savol raqamlari joyi (raqamni olib tashlash uchun)
    c.qbItems = await textItems(page, vp);                                                            // savol boshlarini topish uchun
    return c;
  }

  function loadImage(file) {
    return new Promise((res, rej) => {
      const url = URL.createObjectURL(file);
      const im = new Image();
      im.onload = () => {
        const w = Math.min(im.naturalWidth, 2400), k = w / im.naturalWidth;
        const c = newCanvas(w, im.naturalHeight * k);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url); res(c);
      };
      im.onerror = () => { URL.revokeObjectURL(url); rej(new Error(file.name + ' — rasm ochilmadi')); };
      im.src = url;
    });
  }

  /** Bet rasmi (oxirgi 3 tasi xotirada) */
  async function pageCanvas(fi, pn) {
    const d = docs[fi];
    if (!d) throw new Error('Fayl topilmadi');
    if (d.img) return d.img;
    const k = pk(fi, pn);
    if (cache.has(k)) { const c = cache.get(k); cache.delete(k); cache.set(k, c); return c; }
    const c = await renderPdfPage(d.pdf, pn);
    cache.set(k, c);
    while (cache.size > 3) { const first = cache.keys().next().value; const c0 = cache.get(first); cache.delete(first); c0.width = c0.height = 1; }
    return c;
  }

  /* ---------- tahlil: qora piksellar profili ---------- */
  function inkProfile(canvas, box) {
    const d = canvas.getContext('2d', { willReadFrequently: true }).getImageData(box.x, box.y, box.w, box.h).data;
    const rows = new Uint32Array(box.h), cols = new Uint32Array(box.w);
    for (let j = 0; j < box.h; j++) {
      for (let i = 0; i < box.w; i++) {
        const k = (j * box.w + i) * 4;
        if (d[k + 3] > 40 && (d[k] * 3 + d[k + 1] * 6 + d[k + 2]) / 10 < 215) { rows[j]++; cols[i]++; }
      }
    }
    return { rows, cols };
  }

  /** Qator profilidan bo'sh oraliqlar bo'yicha bloklar: [{y0,y1}] */
  function splitRows(rows, gapMin, minH) {
    const out = [];
    let start = -1, gap = 0, last = -1;
    for (let j = 0; j < rows.length; j++) {
      if (rows[j] > 0) { if (start < 0) start = j; last = j; gap = 0; }
      else if (start >= 0) { gap++; if (gap >= gapMin) { out.push({ y0: start, y1: last }); start = -1; gap = 0; } }
    }
    if (start >= 0) out.push({ y0: start, y1: last });
    return out.filter(b => b.y1 - b.y0 + 1 >= minH);
  }

  /**
   * Ikki ustun orasidagi bo'sh yo'lak (markazga yaqin): x yoki 0.
   * force — «2 ustun» tanlangan (tor yo'lak ham bo'ladi); aks holda yo'lak keng va ikki tomonda ham yozuv yetarli bo'lsin.
   * Ustunlar ustidan o'tgan sarlavha (bir-ikki qator) yo'lakni «yopib» qo'ymasin — kam piksel bo'lsa ham bo'sh hisoblanadi.
   */
  function findGutter(canvas, box, force) {
    const prof = inkProfile(canvas, box).cols;
    const W = prof.length, lo = Math.floor(W * 0.3), hi = Math.floor(W * 0.7);
    const thr = force ? 0 : Math.max(1, Math.round(box.h * 0.02));
    let best = 0, bestStart = 0, run = 0, runStart = 0;
    for (let i = lo; i <= hi; i++) {
      if (prof[i] <= thr) { if (!run) runStart = i; run++; if (run > best) { best = run; bestStart = runStart; } } else run = 0;
    }
    if (best < (force ? 8 : Math.max(10, Math.round(W * 0.012)))) return 0;
    const x = Math.round(bestStart + best / 2);
    if (!force) {
      let l = 0, r = 0;
      for (let i = 0; i < W; i++) { if (i < x) l += prof[i]; else r += prof[i]; }
      const t = l + r;
      if (!t || l < t * 0.18 || r < t * 0.18) return 0;
    }
    return box.x + x;
  }

  /* ---------- savol boshlari (PDF matnidagi raqamlar) ---------- */
  const QNUM = /^\(?\s*(\d{1,3})\s*(?:[.)]|-\s*(?:masala|misol|savol|topshiriq|mashq))/i;

  /** Har ustundagi qatorlar boshidagi raqamlar: [{col, x0, y0, num, fh}] (ustun, keyin y bo'yicha) */
  function qStarts(items, cols, box) {
    const out = [];
    cols.forEach((col, ci) => {
      const its = items.filter(it => it.x >= col.x - 2 && it.x < col.x + col.w - 4 && it.y >= box.y && it.y - it.fh <= box.y + box.h)
                       .sort((a, b) => a.y - b.y || a.x - b.x);
      const lines = [];
      for (const it of its) {
        let L = null;
        for (let k = lines.length - 1; k >= Math.max(0, lines.length - 3); k--) if (Math.abs(lines[k].y - it.y) < 0.35 * Math.max(lines[k].fh, it.fh)) { L = lines[k]; break; }
        if (L) L.items.push(it); else lines.push({ y: it.y, fh: it.fh, items: [it] });
      }
      if (!lines.length) return;
      const starts = [];
      for (const L of lines) {
        L.items.sort((a, b) => a.x - b.x);
        let txt = '';
        for (const it of L.items.slice(0, 4)) txt += it.s;
        starts.push({ x0: L.items[0].x, y: L.y, fh: L.fh, txt: txt.trim() });
      }
      // ustundagi matnning chap cheti (qatorlar boshining 10-persentili) — savol raqami shu chetda bo'ladi, ichki ro'yxatlar suriladi
      const xs = starts.map(s => s.x0).sort((a, b) => a - b);
      const left = xs[Math.floor(xs.length * 0.1)];
      for (const s of starts) {
        const m = s.txt.match(QNUM);
        if (!m) continue;
        if (s.x0 > left + Math.max(10, s.fh * 0.8)) continue;
        out.push({ col: ci, x0: s.x0, base: s.y, num: +m[1], fh: s.fh });
      }
    });
    return out;
  }

  /** Eng ishonchli zanjir: raqamlar ketma-ket (+1) o'sadi; oldingi betdan davom etgani afzal. Bir xil — bo'sh */
  function bestChain(cands, expect) {
    const n = cands.length;
    if (!n) return [];
    const len = new Array(n).fill(1), prev = new Array(n).fill(-1), head = cands.map((_, i) => i);
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < i; j++) if (cands[j].num + 1 === cands[i].num && len[j] + 1 > len[i]) { len[i] = len[j] + 1; prev[i] = j; head[i] = head[j]; }
    }
    let best = -1, bestScore = -1;
    for (let i = 0; i < n; i++) {
      const sc = len[i] * 10 + (expect && cands[head[i]].num === expect ? 15 : 0);
      if (sc > bestScore) { bestScore = sc; best = i; }
    }
    const chain = [];
    for (let k = best; k >= 0; k = prev[k]) chain.unshift(cands[k]);
    return chain.length >= 2 || (expect && chain[0].num === expect) ? chain : [];
  }

  /**
   * Bet sarlavhasi va bet raqamini tashlab ketish. Faqat bittadan: boshidagi blok — betning yuqori 7% ida, bir qatorli va keyingi yozuvdan
   * aniq bo'sh joy bilan ajralgan; oxiridagi blok — pastki 7% da, bir qatorli, ajralgan va tor (bet raqami; savolning «A) … D) …» qatori emas).
   * Yolg'iz blok (bo'lakda boshqa yozuv yo'q) tashlanmaydi. blocks — [{y0, y1}] betdagi koordinatalarda (joyida o'zgaradi).
   */
  function dropMargins(canvas, x, w, blocks, H, top, bottom) {
    const sep = H * 0.012, small = b => b.y1 - b.y0 < H * 0.025;
    if (top && blocks.length > 1 && blocks[0].y1 < H * 0.07 && small(blocks[0]) && blocks[1].y0 - blocks[0].y1 >= sep) blocks.shift();
    if (bottom && blocks.length > 1) {
      const b = blocks[blocks.length - 1], prev = blocks[blocks.length - 2];
      if (b.y0 > H * 0.93 && small(b) && b.y0 - prev.y1 >= sep) {
        const cols = inkProfile(canvas, { x, y: b.y0, w, h: b.y1 - b.y0 + 1 }).cols;
        let x0 = -1, x1 = -1;
        for (let i = 0; i < cols.length; i++) if (cols[i]) { if (x0 < 0) x0 = i; x1 = i; }
        if (x0 >= 0 && x1 - x0 + 1 < w * 0.5) blocks.pop();
      }
    }
    return blocks;
  }

  /**
   * Bo'lak boshidagi bet sarlavhasi (dropMargins dagi shartlar bilan): { lone, sig }. sig — joyi va matni (raqamlar «#»).
   * Yolg'iz sarlavha (savol boshigacha boshqa yozuv yo'q) oldingi savolning davomi ham bo'lishi mumkin — u bo'lak bo'lib qoladi
   * va faqat boshqa betda ham xuddi shu joyda xuddi shunday sarlavha bo'lsa olib tashlanadi (dropRunningHeaders).
   */
  function topHeader(canvas, rect, H) {
    if (rect.h < 8 || rect.w < 8) return null;
    const blocks = splitRows(inkProfile(canvas, rect).rows, 12, 4).map(b => ({ y0: rect.y + b.y0, y1: rect.y + b.y1 }));
    const b = blocks[0];
    if (!b || b.y1 >= H * 0.07 || b.y1 - b.y0 >= H * 0.025) return null;
    if (blocks.length > 1 && blocks[1].y0 - b.y1 < H * 0.012) return null;
    const cols = inkProfile(canvas, { x: rect.x, y: b.y0, w: rect.w, h: b.y1 - b.y0 + 1 }).cols;
    let x0 = -1, x1 = -1;
    for (let i = 0; i < cols.length; i++) if (cols[i]) { if (x0 < 0) x0 = i; x1 = i; }
    const raw = (canvas.qbItems || []).filter(t => t.y >= b.y0 - 1 && t.y - t.fh * 0.8 <= b.y1 + 1 && t.x >= rect.x - 2 && t.x < rect.x + rect.w)
      .sort((p, q) => p.x - q.x).map(t => t.s).join(' ');
    const ok = (raw.match(/\d+/g) || []).length <= 3 && !/(^|[\s(])[A-Fa-f]\)/.test(raw);   // «A) 5 B) 7» — javob variantlari, sarlavha emas
    return { lone: blocks.length === 1, sig: { y0: b.y0 / H, y1: b.y1 / H, x0: (rect.x + x0) / canvas.width, x1: (rect.x + x1) / canvas.width,
      t: raw.toLowerCase().replace(/\d+/g, '#').replace(/\s+/g, ''), ok } };
  }

  function sameHeader(a, b) {
    if (!a.ok || !b.ok || Math.abs(a.y0 - b.y0) > 0.008 || Math.abs(a.y1 - b.y1) > 0.008) return false;
    if (a.t || b.t) return a.t === b.t;
    return Math.abs(a.x0 - b.x0) < 0.01 && Math.abs(a.x1 - b.x1) < 0.01;   // matnsiz (chiziq, rasm) — joyi bir xil
  }

  /** Boshqa betda ham takrorlangan yolg'iz sarlavha bo'laklari — bu bet sarlavhasi, ro'yxatdan olib tashlanadi */
  function dropRunningHeaders(list) {
    const rm = pieces.filter(p => p.hdr && list.some(h => h.k !== pk(p.parts[0].fi, p.parts[0].pn) && sameHeader(h.sig, p.hdr)));
    if (!rm.length) return 0;
    pieces = pieces.filter(p => !rm.includes(p));
    setTimeout(() => rm.forEach(freePiece), 3000);   // ro'yxatda hali yuklanayotgan rasmi bo'lishi mumkin
    return rm.length;
  }

  /**
   * To'rtburchak ichidagi yozuv chegarasi; edges.top — boshidagi sarlavha, edges.bottom — oxiridagi bet raqami tashlab ketiladi (dropMargins).
   * Qaytaradi: yangi to'rtburchak yoki null (yozuv qolmasa)
   */
  function trimMargins(canvas, rect, H, edges) {
    if (rect.h < 8 || rect.w < 8) return null;
    const blocks = dropMargins(canvas, rect.x, rect.w, splitRows(inkProfile(canvas, rect).rows, 12, 4).map(b => ({ y0: rect.y + b.y0, y1: rect.y + b.y1 })), H, edges.top, edges.bottom);
    if (!blocks.length) return null;
    const y0 = Math.max(rect.y, blocks[0].y0 - 2), y1 = Math.min(rect.y + rect.h, blocks[blocks.length - 1].y1 + 3);
    return { x: rect.x, y: y0, w: rect.w, h: y1 - y0 };
  }

  /**
   * Raqamsiz (skaner) betlar: savollar orasidagi bo'sh joyni o'zi topadi — qatorlar oralig'i va savollar oralig'i
   * bir-biridan aniq farq qilsa, o'rtasi chegara bo'ladi; aks holda 26 px (oldingi odatiy qiymat).
   */
  function autoGap(rows) {
    const gaps = [];
    let j = 0, blank = 0;
    while (j < rows.length && !rows[j]) j++;
    for (; j < rows.length; j++) { if (rows[j]) { if (blank) { gaps.push(blank); blank = 0; } } else blank++; }
    if (gaps.length < 4) return 26;
    gaps.sort((a, b) => a - b);
    const line = gaps[Math.floor(gaps.length * 0.3)];      // odatiy qatorlar oralig'i
    let best = -1, ratio = 1;
    for (let i = 0; i < gaps.length - 1; i++) {
      if (gaps[i] < line) continue;
      const a = Math.max(gaps[i], 3), b = gaps[i + 1];
      if (b - a >= 6 && b / a > ratio) { ratio = b / a; best = i; }
    }
    if (best < 0 || ratio < 1.45) return 26;
    return Math.max(10, Math.min(80, Math.round((gaps[best] + gaps[best + 1]) / 2)));
  }

  /** Berilgan to'rtburchak ichidagi yozuv chegarasi bo'yicha qirqib, PNG qiladi. piece.box — betdagi aniq joyi */
  async function cropPiece(canvas, rect, pad, label, src) {
    rect = { x: Math.max(0, Math.floor(rect.x)), y: Math.max(0, Math.floor(rect.y)), w: Math.floor(rect.w), h: Math.floor(rect.h) };
    rect.w = Math.min(rect.w, canvas.width - rect.x); rect.h = Math.min(rect.h, canvas.height - rect.y);
    if (rect.w < 4 || rect.h < 4) return null;
    const prof = inkProfile(canvas, rect);
    let x0 = -1, x1 = -1, y0 = -1, y1 = -1;
    for (let i = 0; i < prof.cols.length; i++) if (prof.cols[i] > 0) { if (x0 < 0) x0 = i; x1 = i; }
    for (let j = 0; j < prof.rows.length; j++) if (prof.rows[j] > 0) { if (y0 < 0) y0 = j; y1 = j; }
    if (x0 < 0) return null;
    const sx = Math.max(0, rect.x + x0 - pad), sy = Math.max(0, rect.y + y0 - pad);
    const ex = Math.min(canvas.width, rect.x + x1 + pad + 1), ey = Math.min(canvas.height, rect.y + y1 + pad + 1);
    const w = ex - sx, h = ey - sy;
    if (w < 20 || h < 14) return null;
    const box = { x: sx, y: sy, w, h };
    const c = newCanvas(w, h);
    c.getContext('2d').drawImage(canvas, sx, sy, w, h, 0, 0, w, h);
    let p;
    // PDF matnida bu joyda savol raqami bo'lmasa (masalan, oldingi savolning «A) 15 B) …» davomi) — rasmga tegilmaydi
    const hint = canvas.qbNums ? window.QBStrip && window.QBStrip.hintFor(canvas.qbNums, box) : null;
    const textLayer = !!(canvas.qbItems && canvas.qbItems.length);
    const r = opts().strip && window.QBStrip && (hint || !textLayer) ? window.QBStrip.strip(c, hint, pad) : null;
    if (r && r.changed) {
      const orig = await makePiece(c, label, src);
      p = await makePiece(r.canvas, label + (r.num ? ' №' + r.num : ''), src);
      p.orig = orig; p.num = r.num || null;
    } else p = await makePiece(c, label, src);
    p.box = box;
    return p;
  }

  async function makePiece(c, label, src) {
    let blob = await toBlob(c);
    if (blob.size > 3.8 * 1024 * 1024) {           // juda katta — sifatni biroz tushiramiz
      const k = 0.7, d = newCanvas(c.width * k, c.height * k);
      d.getContext('2d').drawImage(c, 0, 0, d.width, d.height);
      blob = await toBlob(d); c = d;
    }
    return { blob, url: URL.createObjectURL(blob), w: c.width, h: c.height, label, src, sel: true, lv: null, parts: [], key: [0, 0, 0, 0], note: null };
  }

  function placePiece(p, fi, pn, col) {
    p.parts = [{ fi, pn, rect: p.box }];
    p.key = [fi, pn, col, p.box.y];
    return p;
  }

  /* ---------- betni savollarga ajratish ---------- */
  function contentBox(c, o) {
    const y = Math.floor(c.height * o.top / 100);
    const h = Math.max(10, Math.min(c.height - y, Math.floor(c.height * (1 - (o.top + o.bot) / 100))));
    return { x: 0, y, w: c.width, h };
  }

  /** Bir bet: avtomatik (savol raqami, bo'lmasa bo'sh joy bo'yicha) yoki «har bet — bitta savol». ctx.expect — keyingi kutilayotgan raqam */
  async function pagePieces(c, fi, pn, o, ctx) {
    const W = c.width, H = c.height, box = contentBox(c, o);
    const name = docs[fi].name, src = docs[fi].pdf ? name + ' ' + pn + '-bet' : name;
    const base = docs[fi].pdf ? 's' + pn : name.replace(/\.[^.]+$/, '').slice(0, 20);
    pageInfo[pk(fi, pn)] = { w: W, h: H, split: 0 };
    const out = [];
    if (o.mode === 'page') {
      const p = await cropPiece(c, box, 10, base, src);
      if (p) out.push(placePiece(p, fi, pn, 0));
      return out;
    }
    const split = o.cols === 1 ? 0 : findGutter(c, box, o.cols === 2);
    pageInfo[pk(fi, pn)].split = split;
    const cols = split ? [{ x: 0, w: split }, { x: split, w: W - split }] : [{ x: 0, w: W }];
    const chain = o.nums && c.qbItems && c.qbItems.length ? bestChain(qStarts(c.qbItems, cols, box), ctx.expect) : [];
    let n = 0;
    const lab = () => base + '-' + (++n);
    if (chain.length) {
      ctx.byNum++;
      for (let ci = 0; ci < cols.length; ci++) {
        const col = cols[ci];
        const marks = chain.filter(t => t.col === ci);
        const prof = marks.length ? inkProfile(c, { x: col.x, y: box.y, w: col.w, h: box.h }).rows : null;
        /* kesish joyi: raqam qatori ustidagi eng keng bo'sh oraliq (oldingi qatorning quyi qismi kesilmasin); bo'sh qator bo'lmasa — eng kam yozuvli qator */
        const cutAt = t => {
          const lo = Math.max(box.y, Math.floor(t.base - t.fh * 2)), hi = Math.min(box.y + box.h - 1, Math.floor(t.base - t.fh * 0.72));
          let best = -1, bestLen = 0, run = 0, runStart = 0;
          for (let y = lo; y <= hi; y++) {
            if (!prof[y - box.y]) { if (!run) runStart = y; run++; if (run >= bestLen) { bestLen = run; best = runStart + Math.floor(run / 2); } } else run = 0;
          }
          if (best >= 0) return best;
          let m = Infinity, at = Math.max(lo, hi);
          for (let y = hi; y >= lo; y--) { const v = prof[y - box.y]; if (v < m) { m = v; at = y; } }
          return at;
        };
        const cuts = marks.map(cutAt);
        for (let k = 1; k < cuts.length; k++) if (cuts[k] <= cuts[k - 1] + 4) cuts[k] = cuts[k - 1] + 4;
        const segs = [];
        if (!marks.length) segs.push({ y0: box.y, y1: box.y + box.h, pre: true });
        else {
          if (cuts[0] > box.y) segs.push({ y0: box.y, y1: cuts[0], pre: true });
          cuts.forEach((y, k) => segs.push({ y0: y, y1: k + 1 < cuts.length ? cuts[k + 1] : box.y + box.h, pre: false, num: marks[k].num }));
        }
        for (let k = 0; k < segs.length; k++) {
          const s = segs[k];
          const rect = { x: col.x, y: s.y0, w: col.w, h: s.y1 - s.y0 };
          const hd = s.pre ? topHeader(c, rect, H) : null;
          if (hd) ctx.hdrs.push({ k: pk(fi, pn), sig: hd.sig });
          const r = trimMargins(c, rect, H, { top: s.pre, bottom: k === segs.length - 1 });
          if (!r) continue;
          const p = await cropPiece(c, r, 9, hd && hd.lone ? base + '-0' : lab(), src);
          if (!p) continue;
          if (s.pre) { p.sel = false; p.note = ctx.seen || out.length ? 'davomi?' : 'savol emas?'; if (hd && hd.lone) p.hdr = hd.sig; }
          else p.num = p.num || s.num;
          out.push(placePiece(p, fi, pn, ci));
        }
      }
      ctx.expect = chain[chain.length - 1].num + 1;
    } else {
      for (let ci = 0; ci < cols.length; ci++) {
        const col = cols[ci];
        const b = { x: col.x, y: box.y, w: col.w, h: box.h };
        const rows = inkProfile(c, b).rows;
        const gap = o.gap || autoGap(rows);
        ctx.gaps.push(gap);
        const blocks = dropMargins(c, b.x, b.w, splitRows(rows, gap, 10).map(r => ({ y0: b.y + r.y0, y1: b.y + r.y1 })), H, true, true);   // bet sarlavhasi / raqami
        for (const r of blocks) {
          const p = await cropPiece(c, { x: b.x, y: r.y0, w: b.w, h: r.y1 - r.y0 + 1 }, 9, lab(), src);
          if (p) out.push(placePiece(p, fi, pn, ci));
        }
      }
    }
    if (out.some(p => p.sel)) ctx.seen = true;
    return out;
  }

  /* ---------- asosiy oqim ---------- */
  function setStatus(t) { $('qbStatus').textContent = t || ''; const v = $('qbViewMsg'); if (v) v.textContent = t || ''; }   // betda ishlayotganda ham ko'rinsin
  function isPdf(f) { return f.type === 'application/pdf' || /\.pdf$/i.test(f.name); }
  /** Nomi yoki turi PDF demasa ham (masalan, kengaytmasiz yoki noto'g'ri tur) — fayl boshidagi «%PDF-» belgisi bo'yicha */
  async function sniffPdf(f) {
    if (isPdf(f)) return true;
    if (/^image\//.test(f.type) || /\.(png|jpe?g)$/i.test(f.name)) return false;
    try { return /%PDF-/.test(await f.slice(0, 1024).text()); } catch (e) { return false; }
  }
  const scrollToView = () => { try { $('qbView').scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e) { $('qbView').scrollIntoView(); } };

  function rangeOf(fi) {
    const d = docs[fi];
    if (!d.pdf) return [1, 1];
    if (docs.length !== 1 || $('qbRange').hidden) return [1, d.n];
    let a = Math.max(1, Math.min(d.n, Math.floor(+$('qbFrom').value || 1)));
    let b = Math.max(1, Math.min(d.n, Math.floor(+$('qbTo').value || d.n)));
    if (b < a) { const t = a; a = b; b = t; }
    return [a, b];
  }

  async function run() {
    if (busy) { setStatus('Kuting — oldingi amal tugamoqda…'); return; }
    const files = [...$('qbFile').files];
    if (!files.length) { setStatus('Avval faylni tanlang.'); return; }
    const left = pieces.filter(p => !p.done).length;   // qayta bosilsa chizilgan/qirqilgan savollar bexosdan yo'qolmasin
    if (left && !confirm('Ro\'yxatdagi ' + left + ' ta yuklanmagan savol o\'chadi va fayl qaytadan ochiladi. Davom etasizmi?')) return;
    const o = opts();
    saveOpts();
    busy = true; $('qbGo').disabled = true;
    clearAll();
    try {
      for (const f of files) {
        if (await sniffPdf(f)) {
          setStatus(f.name + ' ochilmoqda…');
          const pdf = prep && prep.file === f ? prep.pdf : await openPdf(f);
          docs.push({ name: f.name, pdf, img: null, n: pdf.numPages });
        } else docs.push({ name: f.name, pdf: null, img: await loadImage(f), n: 1 });
      }
      pages = [];
      docs.forEach((d, fi) => { const [a, b] = rangeOf(fi); for (let pn = a; pn <= b; pn++) pages.push({ fi, pn }); });
      manualMode = o.mode === 'manual';
      $('qbManualTip').hidden = !manualMode;
      if (manualMode && touchScreen()) setDraw(true);   // qo'lda rejimda sensorli ekranda ham darhol chiziladi
      if (manualMode) {
        $('qbPieces').hidden = false; renderPieces();
        await showPage(pages[0]);
        setStatus('Bet pastda ochildi: savol atrofini sichqoncha bilan chizing — ro\'yxatga qo\'shiladi. Betlar: ← →');
        scrollToView();
        return;
      }
      const ctx = { expect: 0, seen: false, byNum: 0, gaps: [], hdrs: [] };
      let k = 0;
      for (const pg of pages) {
        k++;
        setStatus((docs.length > 1 ? docs[pg.fi].name + ': ' : '') + k + ' / ' + pages.length + ' bet…');
        const c = await pageCanvas(pg.fi, pg.pn);
        pieces.push(...await pagePieces(c, pg.fi, pg.pn, o, ctx));
        if (k % 3 === 0) renderPieces();
      }
      dropRunningHeaders(ctx.hdrs);
      const on = pieces.filter(p => p.sel).length, off = pieces.length - on;
      setStatus(pieces.length
        ? 'Tayyor: ' + on + ' ta savol' + (off ? ', ' + off + ' ta bo\'lak belgilanmadi (savol boshi topilmadi — davomi yoki sarlavha bo\'lishi mumkin)' : '') + '. '
          + (ctx.byNum ? 'Savol raqamlari bo\'yicha bo\'lindi (' + ctx.byNum + ' / ' + pages.length + ' bet). ' : '') + 'Betda tekshirib, yuklang.'
        : 'Savol topilmadi. Betda qo\'lda chizing yoki «Qo\'shimcha sozlamalar» da bo\'sh joyni kamaytiring.');
      $('qbPieces').hidden = false; renderPieces();
      const first = pieces.length ? pieces[0].parts[0] : pages[0];
      await showPage(first ? { fi: first.fi, pn: first.pn } : pages[0]);
      scrollToView();
    } catch (e) {
      setStatus('Xato: ' + e.message);
    } finally { busy = false; $('qbGo').disabled = false; }
  }

  function freePiece(p) { URL.revokeObjectURL(p.url); if (p.orig) URL.revokeObjectURL(p.orig.url); }
  function clearAll() {
    pieces.forEach(freePiece); pieces = [];
    for (const c of cache.values()) c.width = c.height = 1;
    cache.clear(); docs = []; pageInfo = {}; pages = []; view = null;
    $('qbView').hidden = true; $('qbMsg').textContent = '';
    renderPieces();
  }

  /* ---------- ro'yxat ---------- */
  function keyCmp(a, b) { for (let i = 0; i < 4; i++) if (a[i] !== b[i]) return a[i] - b[i]; return 0; }
  function insertPiece(p) {
    let i = pieces.findIndex(q => keyCmp(q.key, p.key) > 0);
    if (i < 0) i = pieces.length;
    pieces.splice(i, 0, p);
    return i;
  }

  function renderPieces() {
    $('qbCount').textContent = pieces.length;
    const nSel = pieces.filter(p => p.sel).length;
    $('qbSelCount').textContent = pieces.length ? '· yuklanadi: ' + nSel : '';
    const g = $('qbGrid');
    g.innerHTML = '';
    const bl = batchLevel(), mixed = !secLv();
    pieces.forEach((p, i) => {
      const d = document.createElement('div');
      const lv = pieceLevel(p);
      d.className = 'qb-piece' + (p.sel ? '' : ' off') + (lv ? ' plv' + lv : ' plv0');
      d.id = 'qbp' + i;
      const lvSel = mixed ? '<select class="qb-plv" aria-label="Qiyinlik darajasi" title="Shu savolning qiyinlik darajasi">' +
        '<option value="">' + (bl ? 'Umumiy: ' + esc(LV[bl]) : 'Daraja?') + '</option>' +
        Object.keys(LV).map(k => '<option value="' + k + '"' + (+p.lv === +k ? ' selected' : '') + '>' + esc(LV[k]) + '</option>').join('') + '</select> ' : '';
      const pg = p.parts[0];
      d.innerHTML = '<div class="qb-ph"><label class="check"><input type="checkbox" ' + (p.sel ? 'checked' : '') + '> <b>' + (i + 1) + '</b> <span class="muted small">' + esc(p.label) + '</span>' +
        (p.note ? ' <span class="tag amber" title="Bu bo\'lakda savol raqami topilmadi">' + esc(p.note) + '</span>' : '') + '</label>' +
        '<span class="qb-pact">' + lvSel +
        (pg ? '<button type="button" class="btn sm ghost" data-a="see" title="Betda ko\'rsatish">' + pg.pn + '-bet</button>' : '') +
        (p.orig ? '<button type="button" class="btn sm ghost" data-a="orig" title="' + (p.showOrig ? 'Raqamni olib tashlash' : 'Raqam bilan, asl holida yuklash') + '">' + (p.showOrig ? '✂ raqamsiz' : '↺ asl holi') + '</button>' : '') +
        (p.note && i > 0 ? '<button type="button" class="btn sm ghost" data-a="up" title="Oldingi savolning davomi — unga qo\'shish">↑ oldingisiga qo\'shish</button>' : '') +
        '<button type="button" class="btn sm ghost" data-a="split" title="Ikki savol qo\'shilib qolgan bo\'lsa — eng katta bo\'sh joydan ikkiga bo\'lish">✂ bo\'lish</button>' +
        '<button type="button" class="btn sm ghost" data-a="merge" ' + (i === pieces.length - 1 ? 'disabled' : '') + ' title="Keyingi bo\'lak bilan bitta savol qilish">↓ birlashtirish</button>' +
        '<button type="button" class="btn sm ghost" data-a="del" title="Olib tashlash" aria-label="Olib tashlash">✕</button></span></div>' +
        '<img alt="Savol ' + (i + 1) + '" src="' + p.url + '">';
      d.querySelector('input').onchange = e => { p.sel = e.target.checked; d.classList.toggle('off', !p.sel); drawOverlay(); counts(); };
      const ls = d.querySelector('.qb-plv');
      if (ls) ls.onchange = e => { p.lv = +e.target.value || null; renderPieces(); };
      d.querySelector('[data-a=del]').onclick = () => { if (busy) return; freePiece(p); pieces.splice(i, 1); renderPieces(); drawOverlay(); };
      const ob = d.querySelector('[data-a=orig]');
      if (ob) ob.onclick = () => {   // raqamsiz ⇄ asl holi
        const o = p.orig;
        ['blob', 'url', 'w', 'h'].forEach(k => { const t = p[k]; p[k] = o[k]; o[k] = t; });
        p.showOrig = !p.showOrig; renderPieces();
      };
      const sb = d.querySelector('[data-a=see]');
      if (sb) sb.onclick = () => focusPiece(i);
      const ub = d.querySelector('[data-a=up]');
      if (ub) ub.onclick = () => mergeWithNext(i - 1, true);
      d.querySelector('[data-a=split]').onclick = () => splitPiece(i);
      d.querySelector('[data-a=merge]').onclick = () => mergeWithNext(i);
      g.appendChild(d);
    });
  }
  function counts() {
    const nSel = pieces.filter(p => p.sel).length;
    $('qbSelCount').textContent = pieces.length ? '· yuklanadi: ' + nSel : '';
  }

  function blobImage(p) {
    return new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = rej; im.src = p.url; });
  }

  async function mergeWithNext(i, keepSel) {
    const a = pieces[i], b = pieces[i + 1];
    if (!a || !b || busy) return;
    busy = true;   // ikki marta bosilsa keyingi bo'lak yo'qolmasin
    try { await doMerge(i, a, b, keepSel); } finally { busy = false; }
  }
  async function doMerge(i, a, b, keepSel) {
    const [ia, ib] = await Promise.all([blobImage(a), blobImage(b)]);
    const gap = 12, c = newCanvas(Math.max(a.w, b.w), a.h + gap + b.h);
    const x = c.getContext('2d');
    x.drawImage(ia, 0, 0); x.drawImage(ib, 0, a.h + gap);
    const m = await makePiece(c, a.label + '+', a.src);
    m.sel = keepSel ? a.sel : (a.sel || b.sel); m.lv = a.lv || b.lv || null; m.num = a.num || null;
    m.parts = a.parts.concat(b.parts); m.key = a.key; m.note = a.note && b.note ? a.note : null;
    if (a.note && !b.note) m.note = null;
    const at = pieces.indexOf(a);   // bu orada ro'yxat o'zgargan bo'lishi mumkin (masalan, betda yangi savol chizildi)
    if (at < 0 || pieces[at + 1] !== b) { freePiece(m); return; }
    freePiece(a); freePiece(b);
    pieces.splice(at, 2, m);
    renderPieces(); drawOverlay();
  }

  /** Ikkiga bo'lish: birlashtirilgan bo'lak — qismlariga; oddiy bo'lak — ichidagi eng katta bo'sh qatordan */
  async function splitPiece(i) {
    const p = pieces[i];
    if (!p || busy) return;
    busy = true;
    try {
      const out = [];
      if (p.parts.length > 1) {
        for (const pt of p.parts) {
          const c = await pageCanvas(pt.fi, pt.pn);
          const q = await cropPiece(c, pt.rect, 9, p.label.replace(/\+$/, '') + '·' + (out.length + 1), p.src);
          if (q) { q.parts = [{ fi: pt.fi, pn: pt.pn, rect: q.box }]; q.key = [pt.fi, pt.pn, colOf(pt.fi, pt.pn, q.box), q.box.y]; q.sel = p.sel; q.lv = p.lv; out.push(q); }
        }
      } else if (p.parts.length === 1) {
        const pt = p.parts[0], c = await pageCanvas(pt.fi, pt.pn);
        const rows = inkProfile(c, pt.rect).rows;
        let first = -1, last = -1;
        for (let j = 0; j < rows.length; j++) if (rows[j]) { if (first < 0) first = j; last = j; }
        let best = 0, at = -1, run = 0;
        for (let j = first; j <= last; j++) { if (!rows[j]) { run++; if (run > best) { best = run; at = j - Math.floor(run / 2); } } else run = 0; }
        if (best < 3) { $('qbMsg').textContent = (i + 1) + '-bo\'lak ichida bo\'sh qator topilmadi — betda kerakli joyni qo\'lda chizing.'; return; }
        const cut = pt.rect.y + at;
        for (const r of [{ x: pt.rect.x, y: pt.rect.y, w: pt.rect.w, h: cut - pt.rect.y }, { x: pt.rect.x, y: cut, w: pt.rect.w, h: pt.rect.y + pt.rect.h - cut }]) {
          const q = await cropPiece(c, r, 9, p.label + '·' + (out.length + 1), p.src);
          if (q) { q.parts = [{ fi: pt.fi, pn: pt.pn, rect: q.box }]; q.key = [pt.fi, pt.pn, p.key[2], q.box.y]; q.sel = p.sel; q.lv = p.lv; out.push(q); }
        }
      }
      if (out.length < 2) { out.forEach(freePiece); $('qbMsg').textContent = 'Bo\'lib bo\'lmadi — betda kerakli joyni qo\'lda chizing.'; return; }
      const at = pieces.indexOf(p);   // bu orada betda yangi savol chizilgan bo'lishi mumkin
      if (at < 0) { out.forEach(freePiece); return; }
      freePiece(p);
      pieces.splice(at, 1, ...out);
      $('qbMsg').textContent = (at + 1) + '-bo\'lak ' + out.length + ' qismga bo\'lindi.';
      renderPieces(); drawOverlay();
    } catch (e) {
      $('qbMsg').textContent = 'Xato: ' + e.message;
    } finally { busy = false; }
  }

  function colOf(fi, pn, r) {
    const inf = pageInfo[pk(fi, pn)];
    if (!inf) return 0;
    if (inf.split) return r.x + r.w / 2 > inf.split ? 1 : 0;
    return r.x > inf.w * 0.45 ? 1 : 0;   // ustunlar aniqlanmagan betda o'ng yarmiga chizilgani — o'ng ustun
  }

  /* ---------- betda tekshirish ---------- */
  function pageLabel(pg) {
    const n = pieces.filter(p => p.parts.some(t => t.fi === pg.fi && t.pn === pg.pn)).length;
    return (docs.length > 1 ? docs[pg.fi].name.slice(0, 18) + ' · ' : '') + (docs[pg.fi].pdf ? pg.pn + '-bet' : 'rasm') + (n ? ' · ' + n + ' ta' : '');
  }

  function fillPageSel() {
    const s = $('qbPageSel');
    s.innerHTML = pages.map((pg, i) => '<option value="' + i + '"' + (view && pg.fi === view.fi && pg.pn === view.pn ? ' selected' : '') + '>' + esc(pageLabel(pg)) + '</option>').join('');
  }

  async function showPage(pg) {
    if (!pg) return;
    const tok = ++showTok;
    $('qbView').hidden = false;
    const c = await pageCanvas(pg.fi, pg.pn);
    if (tok !== showTok) return;   // bu orada boshqa bet so'raldi
    view = { fi: pg.fi, pn: pg.pn };
    if (!pageInfo[pk(pg.fi, pg.pn)]) pageInfo[pk(pg.fi, pg.pn)] = { w: c.width, h: c.height, split: 0 };
    const cv = $('qbCanvas');
    cv.width = c.width; cv.height = c.height;
    cv.getContext('2d').drawImage(c, 0, 0);
    const idx = pages.findIndex(x => x.fi === pg.fi && x.pn === pg.pn);
    $('qbPrev').disabled = idx <= 0; $('qbNext').disabled = idx < 0 || idx >= pages.length - 1;
    fillPageSel();
    drawOverlay();
  }

  function drawOverlay() {
    const ov = $('qbOv');
    ov.innerHTML = '';
    if (!view) return;
    const inf = pageInfo[pk(view.fi, view.pn)];
    if (!inf) return;
    pieces.forEach((p, i) => p.parts.forEach(pt => {
      if (pt.fi !== view.fi || pt.pn !== view.pn) return;
      const b = document.createElement('div');
      b.className = 'qb-box' + (p.sel ? '' : ' off') + (p.note ? ' note' : '');
      b.style.left = (100 * pt.rect.x / inf.w) + '%'; b.style.top = (100 * pt.rect.y / inf.h) + '%';
      b.style.width = (100 * pt.rect.w / inf.w) + '%'; b.style.height = (100 * pt.rect.h / inf.h) + '%';
      b.dataset.i = i;
      b.title = (i + 1) + '-bo\'lak' + (p.note ? ' (' + p.note + ')' : '') + ' — bosing: ' + (p.sel ? 'yuklanmasin' : 'yuklansin');
      b.innerHTML = '<span>' + (i + 1) + '</span>';
      ov.appendChild(b);
    }));
    if (pages.length) fillPageSel();
  }

  async function focusPiece(i) {
    const p = pieces[i];
    if (!p || !p.parts.length) return;
    await showPage({ fi: p.parts[0].fi, pn: p.parts[0].pn });
    $('qbView').scrollIntoView({ behavior: 'smooth', block: 'start' });
    const b = $('qbOv').querySelector('.qb-box[data-i="' + i + '"]');
    if (b) { b.classList.add('flash'); setTimeout(() => b.classList.remove('flash'), 1600); }
  }

  /** Sensorli ekranda barmoq bilan chizish (o'chiq bo'lsa — barmoq betni suradi) */
  function setDraw(on) { $('qbViewer').classList.toggle('draw', on); $('qbDraw').setAttribute('aria-pressed', on ? 'true' : 'false'); }
  const touchScreen = () => { try { return matchMedia('(pointer: coarse), (any-pointer: coarse)').matches; } catch (e) { return false; } };

  (function setupViewer() {
    const vw = $('qbViewer'), cv = $('qbCanvas'), sel = $('qbSel');
    let st = null;
    const local = e => { const r = cv.getBoundingClientRect(); return { px: e.clientX - r.left, py: e.clientY - r.top, x: Math.max(0, Math.min(cv.width, (e.clientX - r.left) * cv.width / r.width)), y: Math.max(0, Math.min(cv.height, (e.clientY - r.top) * cv.height / r.height)) }; };
    vw.addEventListener('pointerdown', e => {
      if (!view || (e.button !== undefined && e.button > 0)) return;
      st = { p: local(e), box: e.target.closest('.qb-box'), drag: false };
      try { vw.setPointerCapture(e.pointerId); } catch (x) { /* e'tiborsiz */ }
      e.preventDefault();
    });
    vw.addEventListener('pointermove', e => {
      if (!st) return;
      const p = local(e);
      if (!st.drag && Math.hypot(p.px - st.p.px, p.py - st.p.py) < 6) return;
      st.drag = true; sel.hidden = false;
      sel.style.left = Math.min(st.p.px, p.px) + 'px'; sel.style.top = Math.min(st.p.py, p.py) + 'px';
      sel.style.width = Math.abs(p.px - st.p.px) + 'px'; sel.style.height = Math.abs(p.py - st.p.py) + 'px';
    });
    const end = async e => {
      if (!st) return;
      const s = st; st = null; sel.hidden = true;
      if (!s.drag) {
        if (s.box) { const p = pieces[+s.box.dataset.i]; if (p) { p.sel = !p.sel; renderPieces(); drawOverlay(); } }
        else setStatus('Savol qo\'shish uchun sichqonchani bosib turib, savol atrofini chizing (torting).');
        return;
      }
      const p = local(e);
      const rect = { x: Math.floor(Math.min(s.p.x, p.x)), y: Math.floor(Math.min(s.p.y, p.y)), w: Math.ceil(Math.abs(p.x - s.p.x)), h: Math.ceil(Math.abs(p.y - s.p.y)) };
      if (rect.w < 24 || rect.h < 16) { setStatus('Juda kichik — savol atrofini kattaroq chizing.'); return; }
      const v = view, c = await pageCanvas(v.fi, v.pn);
      const d = docs[v.fi];
      const n = pieces.filter(q => q.parts.some(t => t.fi === v.fi && t.pn === v.pn)).length + 1;
      const q = await cropPiece(c, rect, 9, (d.pdf ? 's' + v.pn : d.name.replace(/\.[^.]+$/, '').slice(0, 20)) + '-q' + n, d.pdf ? d.name + ' ' + v.pn + '-bet' : d.name);
      if (!q) { setStatus('Tanlangan joyda yozuv topilmadi.'); return; }
      placePiece(q, v.fi, v.pn, colOf(v.fi, v.pn, q.box));
      let i;
      if (manualMode) { pieces.push(q); i = pieces.length - 1; } else i = insertPiece(q);   // qo'lda — chizilgan tartibda
      $('qbPieces').hidden = false;
      renderPieces(); drawOverlay();
      setStatus((i + 1) + '-savol qo\'shildi. Jami: ' + pieces.length + '.');
    };
    vw.addEventListener('pointerup', end);
    vw.addEventListener('pointercancel', () => { st = null; sel.hidden = true; });
    const go = d => {
      if (!view) return;
      const i = pages.findIndex(x => x.fi === view.fi && x.pn === view.pn) + d;
      if (i >= 0 && i < pages.length) showPage(pages[i]);
    };
    $('qbDraw').onclick = () => setDraw(!vw.classList.contains('draw'));
    $('qbPrev').onclick = () => go(-1);
    $('qbNext').onclick = () => go(1);
    $('qbPageSel').onchange = e => { const pg = pages[+e.target.value]; if (pg) showPage(pg); };
    document.addEventListener('keydown', e => {
      if ($('qbView').hidden || /^(INPUT|SELECT|TEXTAREA)$/.test((e.target || {}).tagName || '')) return;
      if (e.key === 'ArrowLeft') go(-1); else if (e.key === 'ArrowRight') go(1);
    });
  })();

  /* ---------- yuklash ---------- */
  async function upload() {
    if (busy) return;
    const sel = pieces.filter(p => p.sel);
    if (!sel.length) { $('qbMsg').textContent = 'Yuklash uchun kamida bitta savolni belgilang.'; return; }
    const noLv = sel.filter(p => !pieceLevel(p)).length;
    if (noLv) {   // daraja majburiy: topshiriqlar daraja bo'yicha tuziladi
      $('qbMsg').textContent = 'Qiyinlik darajasini tanlang: yuqoridagi «Qiyinlik darajasi» (hammasiga) yoki har bir savoldagi tanlov orqali. Darajasi yo\'q savollar: ' + noLv + ' ta.';
      $('qbLevel').classList.add('lv-need'); $('qbLevel').focus();
      return;
    }
    const kindSel = $('qbKind').value, kind = kindSel === 'open' ? 'open' : 'mc', nopt = kindSel === 'mc6' ? 6 : 4;
    const key = parseKey($('qbKey').value);
    const keyN = Object.keys(key).length;
    busy = true; $('qbUpload').disabled = true;
    const prog = $('qbProg');
    try { await uploadSel(sel, kind, nopt, key, keyN, prog); }
    catch (e) { $('qbMsg').textContent = 'Xato: ' + e.message; }
    finally { busy = false; $('qbUpload').disabled = false; prog.hidden = true; }
  }

  async function uploadSel(sel, kind, nopt, key, keyN, prog) {
    prog.hidden = false; prog.max = sel.length; prog.value = 0;
    let ok = 0, fail = 0, noKey = 0, lastErr = '';
    for (let i = 0; i < sel.length; i++) {
      const p = sel[i];
      const fd = new FormData();
      fd.append('action', 'upload'); fd.append('section_id', $('qbSec').value);
      fd.append('kind', kind); fd.append('nopt', nopt); fd.append('label', p.label); fd.append('src', p.src); fd.append('level', pieceLevel(p));
      if (!p.keyed) { p.keyed = true; p.ans = key[i + 1] != null ? key[i + 1] : ''; }   // kalit bir marta, birinchi urinishda biriktiriladi (qayta urinishda siljimasin)
      if (p.ans) fd.append('answer', p.ans); else noKey++;
      fd.append('img', p.blob, 'q.png');
      try {
        const r = await fetch(cfg.api, { method: 'POST', body: fd, headers: { 'X-CSRF': csrf }, credentials: 'same-origin' });
        const t = await r.text(); let j = null;
        try { j = JSON.parse(t); } catch (e) { /* HTML — sessiya tugagan bo'lishi mumkin */ }
        if (j && j.ok) { ok++; p.done = true; } else { fail++; lastErr = j ? j.error : 'Sessiya tugagan bo\'lishi mumkin — sahifani yangilab, qayta kiring'; if (!j) break; }
      } catch (e) { fail++; lastErr = 'Tarmoq xatosi'; break; }
      prog.value = i + 1;
      $('qbMsg').textContent = 'Yuklanmoqda: ' + (i + 1) + ' / ' + sel.length;
    }
    if (keyN) $('qbKey').value = '';   // kalit ishlatildi — qayta yuklashda boshqa savolga tushib qolmasin
    // yuklanganlarni ro'yxatdan olib tashlaymiz
    pieces.filter(p => p.done).forEach(freePiece);
    pieces = pieces.filter(p => !p.done);
    renderPieces(); drawOverlay();
    const secId = $('qbSec').value;
    if (ok && cfg.secCounts) { cfg.secCounts[secId] = (+cfg.secCounts[secId] || 0) + ok; secInfo(); }
    let msg = ok + ' ta savol yuklandi' + (fail ? ', ' + fail + ' tasi yuklanmadi (' + lastErr + ')' : '') + '. ';
    if (keyN && keyN !== sel.length) msg += 'Eslatma: kalitda ' + keyN + ' ta javob, yuklangan savollar ' + sel.length + ' ta. ';
    const out = $('qbMsg'); out.textContent = msg;
    if (ok) { const a = document.createElement('a'); a.className = 'btn sm primary'; a.href = cfg.list.replace('__S__', secId); a.textContent = 'Savollarni ko\'rish va kalitni kiritish →'; out.appendChild(a); }
  }

  /* ---------- bo'lim va fayl tanlovi ---------- */
  function secInfo() {
    const lv = secLv(), id = $('qbSec').value;
    $('qbLvFixed').hidden = !lv; $('qbLvPick').hidden = !!lv;
    if (lv) $('qbLvTag').innerHTML = '<span class="lv lv' + lv + '">' + esc(LV[lv]) + '</span>';
    const n = cfg.secCounts ? +cfg.secCounts[id] || 0 : null;
    if (n !== null) $('qbHave').textContent = 'Hozir bu bo\'limda ' + n + ' ta savol bor — yangilari oxiriga qo\'shiladi.';
  }

  let fileTok = 0;
  async function onFile() {
    const files = [...$('qbFile').files];
    $('qbGo').disabled = !files.length; setStatus('');
    prep = null; $('qbRange').hidden = true;
    if (!files.length) return;
    const tok = ++fileTok;
    try {
      if (files.length === 1 && await sniffPdf(files[0])) {
        if (tok !== fileTok) return;
        setStatus('Fayl o\'qilmoqda…');
        const pdf = await openPdf(files[0]);
        if (tok !== fileTok) return;
        prep = { file: files[0], pdf };
        $('qbFrom').max = $('qbTo').max = pdf.numPages;
        $('qbFrom').value = 1; $('qbTo').value = pdf.numPages;
        $('qbPages').textContent = 'jami ' + pdf.numPages + ' bet' + (pdf.numPages > 30 ? ' — kitob katta: faqat kerakli betlarni kiriting' : '');
        $('qbRange').hidden = false;
      }
      if (tok !== fileTok) return;
      if (opts().mode === 'manual' && !busy && !pieces.some(p => !p.done)) run();   // qo'lda: bet darhol ochiladi
      else {
        const left = pieces.filter(p => !p.done).length;
        setStatus('Fayl tayyor — «' + $('qbGoTxt').textContent + '» tugmasini bosing.' + (left ? ' Ro\'yxatdagi yuklanmagan ' + left + ' ta savol o\'chadi.' : ''));
      }
    } catch (e) { if (tok === fileTok) setStatus('Xato: ' + e.message); }
  }

  /* ---------- hodisalar ---------- */
  loadOpts();
  secInfo();
  $('qbFile').addEventListener('change', onFile);
  $('qbGo').addEventListener('click', run);
  $('qbUpload').addEventListener('click', upload);
  $('qbAll').onclick = () => { pieces.forEach(p => { p.sel = true; }); renderPieces(); drawOverlay(); };
  $('qbNone').onclick = () => { pieces.forEach(p => { p.sel = false; }); renderPieces(); drawOverlay(); };
  $('qbLevel').addEventListener('change', () => { $('qbLevel').classList.toggle('lv-need', !batchLevel()); renderPieces(); });
  $('qbKind').addEventListener('change', saveOpts);
  $('qbSec').addEventListener('change', () => {
    secInfo(); renderPieces();
    try { history.replaceState(null, '', location.pathname + '?p=qb_import&s=' + $('qbSec').value); } catch (e) { /* e'tiborsiz */ }
  });
  const modeUpd = ev => {
    const m = opts().mode, auto = m === 'auto';
    ['qbCols', 'qbGap', 'qbNumSplit'].forEach(id => { $(id).disabled = !auto; });
    $('qbGoTxt').textContent = m === 'manual' ? 'Betni ochish' : 'Qirqish';
    if (ev && m === 'manual' && $('qbFile').files.length && !pieces.length && !busy && $('qbView').hidden) run();   // fayl tanlangan — bet darhol ochilsin
  };
  /* kutilmagan xato jim o'tib ketmasin — holat qatorida ko'rinsin (skrinshot bilan yuborish mumkin) */
  window.addEventListener('error', e => { if (e.filename && /\/assets\//.test(e.filename) && !/ResizeObserver/.test(e.message || '')) setStatus('Xato: ' + e.message); });
  window.addEventListener('unhandledrejection', e => { const r = e.reason; setStatus('Xato: ' + ((r && r.message) || String(r))); });
  document.querySelectorAll('input[name=qbMode]').forEach(r => r.addEventListener('change', modeUpd));
  modeUpd();
  if ($('qbFile').files.length) onFile();   // brauzer sahifani yangilaganda tanlangan faylni tiklagan bo'lsa ham ishlasin
})();
