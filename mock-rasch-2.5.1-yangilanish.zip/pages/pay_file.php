<?php
defined('APP_ROOT') || exit;
/**
 * 2.5: To'lov cheki faylini berish — faqat «Moliya» huquqi bor admin yoki chekning egasi (o'quvchi).
 * Fayllar uploads/pay/ da tasodifiy nom va «.r» kengaytma bilan saqlanadi: to'g'ridan-to'g'ri havola ishlamaydi (nginx ham bermaydi).
 * ?t=1 — kichik nusxa (ro'yxat uchun, JPEG, keshlanadi), ?dl=1 — yuklab olish.
 */
$r = row('SELECT id, student_id, file, file_type FROM pay_requests WHERE id=?', [(int)($_GET['id'] ?? 0)]);
$a = admin();
$s = student();
if ($a) require_admin();   // sessiya imzosi (parol o'zgargan / admin o'chirilgan bo'lsa chiqaradi)
$ok = $r && (($a && can_finance()) || ($s && (int)$s['id'] === (int)$r['student_id']));
if (!$ok) { http_response_code(403); header('Content-Type: text/plain; charset=utf-8'); exit('Ruxsat yo\'q'); }
$path = pay_file_path($r);
if ($path === '' || !is_file($path)) { http_response_code(404); header('Content-Type: text/plain; charset=utf-8'); exit('Fayl topilmadi'); }
$type = isset(PAY_FILE_TYPES[$r['file_type']]) ? (string)$r['file_type'] : 'application/octet-stream';
if (!empty($_GET['t']) && strncmp($type, 'image/', 6) === 0) {
    $th = pay_thumb($path, $type);
    if ($th !== '') { $path = $th; $type = 'image/jpeg'; }
}
header('Content-Type: ' . $type);
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
header('Content-Disposition: ' . (!empty($_GET['dl']) ? 'attachment' : 'inline') . '; filename="chek-' . (int)$r['id'] . '.' . (PAY_FILE_TYPES[$type] ?? 'bin') . '"');
header('Cache-Control: private, max-age=600');
header('X-Robots-Tag: noindex');
readfile($path);
exit;
