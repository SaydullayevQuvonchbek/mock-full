<?php
defined('APP_ROOT') || exit;
/**
 * Bot bergan bir martalik havola orqali o'quvchi sessiyasini ochadi (ID/parol qayta so'ralmaydi).
 * Token bazada faqat xesh ko'rinishida; 15 daqiqa amal qiladi va bir marta ishlaydi.
 */
$t = (string)($_GET['t'] ?? '');
$tk = null;
if (preg_match('/^[a-f0-9]{32}$/', $t)) {
    $h = hash('sha256', $t);
    $up = q('UPDATE tg_tokens SET used_at=NOW() WHERE token_hash=? AND used_at IS NULL AND expires_at>NOW()', [$h]);
    if ($up->rowCount() === 1) $tk = row('SELECT * FROM tg_tokens WHERE token_hash=?', [$h]);
}
$s = $tk ? row('SELECT * FROM students WHERE id=? AND archived_at IS NULL', [$tk['student_id']]) : null;
if ($tk && $s) {
    // Kabinet havolasi: vaqtinchalik parol bo'lsa avval almashtiriladi. Test/natija/topshiriq havolalari (imtihon vaqti) — to'sqinliksiz.
    $mc = in_array($tk['go'], ['home', 'wallet', 'moc', 'profile'], true) && (int)$s['must_change'] === 1;
    student_session_start($s, $mc);   // parol versiyasi bilan (aks holda sessiya darhol yopilardi)
    if ($mc) { $_SESSION['after_pass'] = null; redirect('student_setpass'); }
    if ($tk['go'] === 'home') redirect('student_home');
    if ($tk['go'] === 'wallet' || $tk['go'] === 'moc') redirect($tk['go'] === 'wallet' ? 'student_wallet' : 'moc');   // 2.5
    if ($tk['go'] === 'profile') redirect('student_profile');   // 2.5.1: botdagi «Profil»
    redirect($tk['go'] === 'result' ? 'student_result' : ($tk['go'] === 'qb' ? 'student_practice_do' : 'student_test'), ['id' => (int)$tk['test_id']]);
}
usleep(300000);
page_header('Havola yaroqsiz', ['main' => 'narrow-main']);
?>
<div class="card narrow">
  <h1>Havola yaroqsiz</h1>
  <p class="muted">Bu havola eskirgan (15 daqiqa) yoki allaqachon ishlatilgan. Telegram botga qaytib, tugmani qayta bosing — yangi havola yuboriladi.</p>
  <p class="small muted">Yoki <a href="<?= e(url('student_login')) ?>">ID va parol bilan kiring</a>.</p>
</div>
<?php page_footer();
