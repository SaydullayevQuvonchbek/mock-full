<?php
defined('APP_ROOT') || exit;
if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    if ($act === 'create') {
        $title = trim($_POST['title'] ?? '');
        if ($title === '') { flash('Test nomini kiriting', 'err'); redirect('tests'); }
        q('INSERT INTO tests (title, subject, test_date, n_closed, n_match, n_open, method, key_json) VALUES (?,?,?,?,?,?,?,?)', [
            $title, trim($_POST['subject'] ?? 'Matematika') ?: 'Matematika', $_POST['test_date'] ?: null,
            max(0, min(35, (int)$_POST['n_closed'])), max(0, min(35, (int)$_POST['n_match'])),
            max(0, min(10, (int)$_POST['n_open'])), isset(method_names()[$_POST['method'] ?? '']) ? $_POST['method'] : 'tscore', '{}',
        ]);
        $id = (int)db()->lastInsertId();
        flash('Test yaratildi. Endi javoblar kalitini kiriting.');
        redirect('test_edit', ['id' => $id]);
    }
    if ($act === 'delete') {
        $t = test_by_id((int)$_POST['id']);
        if ($t) {
            // 2.5: hali o'tkazilmagan pullik MOCK o'chirilsa — to'laganlarning puli hamyoniga qaytadi. Oxirgi tekshiruv va o'chirish bitta
            // tranzaksiyada: test va ro'yxat qatorlari qulflanadi — shu payt to'langan (masalan, chek tasdiqlanib) qator qaytarilmay o'chib ketmaydi
            $over = mock_is_over($t);
            $n = 0; $sum = 0; $done = false;
            for ($try = 0; $try < 3 && !$done; $try++) {
                if (!$over) foreach (rows('SELECT student_id FROM test_registrations WHERE test_id=? AND pay_status="paid" AND paid_amount>0', [$t['id']]) as $g) {
                    $r = mock_cancel((int)$g['student_id'], (int)$t['id'], 'admin', ['refund' => true, 'note' => 'MOCK bekor qilindi']);
                    if ($r['ok']) { $n++; $sum += (int)$r['refund']; }
                }
                $done = db_tx(function () use ($t, $over) {
                    if (!row('SELECT id FROM tests WHERE id=? FOR UPDATE', [$t['id']])) return true;
                    if (!$over && (int)val('SELECT COUNT(*) FROM test_registrations WHERE test_id=? AND pay_status="paid" AND paid_amount>0 FOR UPDATE', [$t['id']]) > 0) return false;
                    q('DELETE FROM tests WHERE id=?', [$t['id']]);
                    return true;
                });
            }
            if ($done) {
                audit('test_delete', 'test', (int)$t['id'], ['title' => $t['title'], 'price' => (int)$t['price']], ['refunds' => $n, 'refund_sum' => $sum]);
                flash('Test o\'chirildi' . ($n ? '. ' . $n . ' ta o\'quvchiga to\'lovi hamyoniga qaytarildi (jami ' . som($sum) . ')' : ''));
            } else flash('Test o\'chirilmadi: to\'lovlar o\'zgarib turibdi. Bir oz kutib qayta urinib ko\'ring.', 'err');
        }
        redirect('tests');
    }
}
$tests = rows('SELECT t.*, (SELECT COUNT(*) FROM responses r WHERE r.test_id=t.id AND r.status="submitted") n
               FROM tests t ORDER BY t.id DESC');
page_header('Testlar');
?>
<div class="page-head"><div><h1>Testlar</h1><p class="muted" style="margin:0">Har bir test — kalit, javoblar, Rasch hisobi va natijalar.</p></div><a class="btn primary" href="#new"><?= icon('plus', 16) ?>Yangi test</a></div>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>#</th><th>Test</th><th>Sana</th><th>Format</th><th class="num">Ishtirokchi</th><th>Holat</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($tests as $t): ?>
  <tr>
    <td><?= (int)$t['id'] ?></td>
    <td><a href="<?= e(url('test_edit', ['id' => $t['id']])) ?>"><b><?= e($t['title']) ?></b></a><div class="muted small"><?= e($t['subject']) ?></div></td>
    <td class="nowrap"><?= e($t['test_date']) ?></td>
    <td class="small"><?= (int)$t['n_closed'] ?> + <?= (int)$t['n_match'] ?> yopiq, <?= (int)$t['n_open'] ?> ochiq (<?= count(test_items($t)) ?> item)</td>
    <td class="num"><?= (int)$t['n'] ?></td>
    <td>
      <?php if ($t['online']): ?><span class="tag blue">Onlayn</span><?php endif; ?>
      <?php if ($t['published']): ?><span class="tag green">E'lon qilingan</span><?php endif; ?>
    </td>
    <td class="right nowrap">
      <a class="btn sm" href="<?= e(url('results', ['id' => $t['id']])) ?>">Natijalar</a>
      <?php $cm = 'Test va unga tegishli barcha javoblar o\'chirilsinmi?' . ((int)$t['price'] > 0 ? ' Hali o\'tkazilmagan bo\'lsa, to\'laganlarning puli hamyoniga qaytariladi.' : ''); ?>
      <form method="post" class="inline" onsubmit="return confirm(<?= e(json_encode($cm, JSON_UNESCAPED_UNICODE)) ?>)">
        <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
        <button class="btn sm danger-ghost">O'chirish</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
  <?php if (!$tests): ?><tr><td colspan="7" class="empty">Hali test yo'q</td></tr><?php endif; ?>
  </tbody>
</table></div>

<div class="card mt" id="new">
  <h2>Yangi test yaratish</h2>
  <form method="post" class="form">
    <?= csrf_field() ?><input type="hidden" name="action" value="create">
    <div class="grid3">
      <label class="span2">Test nomi <input name="title" placeholder="Masalan: MOCK EXAM-13" required></label>
      <label>Sana <input type="date" name="test_date" value="<?= date('Y-m-d') ?>"></label>
      <label>Fan <input name="subject" value="Matematika"></label>
      <label>Yopiq (A–D) soni <input type="number" name="n_closed" value="32" min="0" max="35"></label>
      <label>Moslashtirish (A–F) soni <input type="number" name="n_match" value="3" min="0" max="35"></label>
      <label>Ochiq topshiriqlar (a+b) <input type="number" name="n_open" value="10" min="0" max="10"></label>
      <label class="span2">Ballga o'tkazish usuli
        <select name="method"><?php foreach (method_names() as $k => $v): ?><option value="<?= e($k) ?>"><?= e($v) ?></option><?php endforeach; ?></select>
      </label>
    </div>
    <p class="muted small">Standart milliy sertifikat formati: 1–32 yopiq (A–D), 33–35 moslashtirish (A–F), 36–45 ochiq topshiriqlar (a va b). Jami 55 ta item. Yopiq + moslashtirish ≤ 35 bo'lishi kerak (javoblar varaqasi shunga mo'ljallangan).</p>
    <button class="btn primary">Yaratish</button>
  </form>
</div>
<?php page_footer();
