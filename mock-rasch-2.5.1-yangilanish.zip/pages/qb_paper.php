<?php
defined('APP_ROOT') || exit;
/**
 * Sinf testi (2.4): har o'quvchiga ismli varaq (o'z tartibida), barcha kalitlar bitta varaqda, kalitlar ekranga (proyektor),
 * o'qituvchi javoblarni kiritsa — baholanadi (natija, o'zlashtirish). v = sheets | keys | screen | entry
 */
$aid = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$as = $aid ? row('SELECT * FROM qb_assign WHERE id=?', [$aid]) : null;
if (!$as || !qb_assign_is_paper($as)) { flash('Sinf testi topilmadi', 'err'); redirect('qb_assign'); }
$v = (string)($_GET['v'] ?? 'entry');
$anon = qb_assign_is_anon($as);   // 2.4.2: ismsiz variantlar — ism varaqqa qo'lda yoziladi
$center = (string)app_setting('center');
$date = date('d.m.Y', strtotime((string)$as['created_at']));
$norm = function (string $s): string { return (string)preg_replace('/\s+/u', '', mb_strtoupper($s)); };

/* ---------------- Javoblarni saqlash ---------------- */
if (is_post()) {
    csrf_check();
    $byTid = [];
    foreach (qb_paper_rows($aid) as $r) $byTid[(int)$r['tid']] = $r;
    $saved = 0; $cleared = 0; $errs = []; $keep = [];
    foreach ((array)($_POST['ans'] ?? []) as $tid => $txt) {
        $tid = (int)$tid;
        if (!isset($byTid[$tid]) || !is_string($txt)) continue;
        $txt = mb_substr(trim($txt), 0, 600);
        if ($norm($txt) === $norm(qb_paper_answers_str($byTid[$tid]['items'], $byTid[$tid]['status'] === 'done'))) continue;   // o'zgarmagan
        $r = qb_paper_save($tid, $txt);
        if (!$r['ok']) { $errs[] = ($byTid[$tid]['full_name'] !== '' ? $byTid[$tid]['full_name'] : 'Variant ' . (int)$byTid[$tid]['var_no']) . ' — ' . $r['error']; $keep[$tid] = $txt; }
        elseif (!empty($r['cleared'])) $cleared++;
        else $saved++;
    }
    if ($saved || $cleared) flash(($saved ? $saved . ($anon ? ' ta variantning' : ' ta o\'quvchining') . ' javoblari saqlandi va tekshirildi' : '') . ($cleared ? ($saved ? ' · ' : '') . $cleared . ' tasining javoblari o\'chirildi' : ''));
    elseif (!$errs) flash('O\'zgarish yo\'q', 'warn');
    if ($errs) { flash('Saqlanmadi: ' . implode(' · ', array_slice($errs, 0, 4)) . (count($errs) > 4 ? ' · yana ' . (count($errs) - 4) . ' ta' : ''), 'err'); $_SESSION['pq_keep'] = ['aid' => $aid, 'rows' => $keep]; }
    redirect('qb_paper', ['id' => $aid, 'v' => 'entry']);
}

$rowsP = qb_paper_rows($aid);
$N = (int)$as['n'];
$sheet = (string)$as['sheet'] === 'write' ? 'write' : 'bubble';
$back = url('qb_assign', ['id' => $aid]);
$imgUrl = fn(array $it) => url('qb_img', ['id' => $it['question_id'], 'v' => substr((string)$it['img'], 1, 8)]);

/* ---------------- Varaqlar ---------------- */
if ($v === 'sheets') {
    $only = (int)($_GET['t'] ?? 0);
    if (in_array($_GET['as'] ?? '', ['bubble', 'write'], true)) $sheet = (string)$_GET['as'];   // chop etishda boshqa ko'rinish (sozlama o'zgarmaydi)
    if ($only) $rowsP = array_values(array_filter($rowsP, fn($r) => (int)$r['tid'] === $only));
    page_header('Varaqlar — ' . $as['title'], ['bare' => true, 'body' => 'print-page pq-page']);
    [$wmDefs, $wmScreen, $wmPrint] = qb_watermark_svg(qb_watermark());
    ?>
<div class="no-print toolbar">
  <button class="btn primary" onclick="print()"><?= icon('print', 16) ?>Chop etish</button>
  <label class="small">Savollar o'lchami <select id="pqK" aria-label="Savollar o'lchami"><option value="1">100% (kitobdagidek)</option><option value="0.9">90%</option><option value="0.8">80% — qog'oz tejaladi</option><option value="0.7">70%</option></select></label>
  <span class="small">Javob qatori: <?php foreach (QB_SHEETS as $sk => $sn): ?><?= $sk === $sheet ? '<b>' . e(explode(' ', $sn)[0]) . '</b>' : '<a href="' . e(url('qb_paper', ['id' => $aid, 'v' => 'sheets', 'as' => $sk] + ($only ? ['t' => $only] : []))) . '">' . e(explode(' ', $sn)[0]) . '</a>' ?><?= $sk === 'bubble' ? ' / ' : '' ?><?php endforeach; ?></span>
  <span class="small"><?= count($rowsP) ?> ta <?= $anon ? 'variant' : 'o\'quvchi' ?> · har biri yangi betdan · A4</span>
  <?php if ($only): ?><a class="small" href="<?= e(url('qb_paper', ['id' => $aid, 'v' => 'sheets'])) ?>">Hammasi</a><?php endif; ?>
  <a class="small" href="<?= e(url('qb_paper', ['id' => $aid, 'v' => 'keys'])) ?>" target="_blank">Kalitlar varag'i</a>
  <a class="small" href="<?= e($back) ?>">← Sinf testiga qaytish</a>
  <span class="small muted">PDF kerak bo'lsa: «Chop etish» → printer o'rniga «Save as PDF» (PDF sifatida saqlash)</span>
</div>
<?= $wmDefs . $wmPrint ?>
<?php foreach ($rowsP as $r): $items = $r['items']; $n = count($items); ?>
<section class="pq-wrap"><?= $wmScreen ?>
<table class="pq-sheet">
  <thead><tr><td>
    <div class="pq-head">
      <?php if ($r['student_id'] === null): ?>
      <div><div class="pq-blank">F.I.Sh: <span class="pq-line"></span></div><div class="pq-blank pq-sub">Guruh: <span class="pq-line s"></span></div></div>
      <?php else: ?>
      <div><div class="pq-name"><?= e($r['full_name']) ?></div><div class="pq-sub">ID <b><?= e($r['code']) ?></b><?= $r['group_name'] !== '' ? ' · ' . e($r['group_name']) : '' ?></div></div>
      <?php endif; ?>
      <div class="pq-r"><div class="pq-var">Variant <b><?= (int)$r['var_no'] ?></b></div><div class="pq-sub"><?= e(mb_strimwidth($as['title'], 0, 60, '…')) ?> · <?= e($date) ?> · <?= $n ?> ta savol</div></div>
    </div>
  </td></tr></thead>
  <tfoot><tr><td class="pq-foot"></td></tr></tfoot>
  <tbody><tr><td>
    <?php if ($sheet === 'bubble'):
        $maxOpt = 4; foreach ($items as $it) if (($it['kind'] ?? 'mc') !== 'open' && (int)$it['nopt'] === 6) $maxOpt = 6;
        $cols = $maxOpt === 6 ? 4 : 5;
        $rowsN = max((int)ceil($n / $cols), min($n, 5)); ?>
    <p class="pq-note">Javoblar — to'g'ri javob doirachasini to'liq bo'yang. Ochiq savol javobini katakka yozing.</p>
    <div class="pq-ans pq-ans-bubble" style="--rows: <?= $rowsN ?>">
      <?php foreach ($items as $it): ?>
      <div class="pq-cell"><b><?= (int)$it['pos'] ?></b><?php if (($it['kind'] ?? 'mc') === 'open'): ?><span class="pq-box"></span><?php else: for ($k = 0; $k < ((int)$it['nopt'] === 6 ? 6 : 4); $k++): ?><i><?= chr(65 + $k) ?></i><?php endfor; endif; ?></div>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
    <p class="pq-note">Javoblar — har savol javobini o'z katagiga aniq yozing (A, B, C, D; ochiq savolda — son).</p>
    <div class="pq-ans pq-ans-write">
      <?php foreach ($items as $it): ?><div class="pq-wcell<?= ($it['kind'] ?? 'mc') === 'open' ? ' open' : '' ?>"><b><?= (int)$it['pos'] ?></b><span></span></div><?php endforeach; ?>
    </div>
    <?php endif; ?>
    <div class="pq-qs">
      <?php foreach ($items as $it):
          if (!$it['img']) { ?><div class="pq-q"><b><?= (int)$it['pos'] ?>.</b><span class="pq-gone">(savol bazadan o'chirilgan — hisobga olinmaydi)</span></div><?php continue; }
          $mm = (int)$it['w'] * 0.5 * 25.4 / 72;            // qirqilgan rasmning asl o'lchami (1 px = 0,5 pt)
          $wide = $mm > 105;                                    // ustunga 85% gacha kichraytirib sig'masa — butun eniga
          $wmm = $wide ? min($mm, 179) : min($mm, 83); ?>
      <div class="pq-q<?= $wide ? ' wide' : '' ?>" data-mm="<?= number_format($mm, 1, '.', '') ?>"><b><?= (int)$it['pos'] ?>.</b><img src="<?= e($imgUrl($it)) ?>" alt="<?= (int)$it['pos'] ?>-savol" style="width: <?= number_format($wmm, 1, '.', '') ?>mm"></div>
      <?php endforeach; ?>
    </div>
  </td></tr></tbody>
</table>
</section>
<?php endforeach; ?>
<?php if (!$rowsP): ?><div class="card narrow empty">O'quvchi topilmadi.</div><?php endif; ?>
<script>
(function () {   // savollar o'lchami: kichikroq — ikkitasi yonma-yon sig'adi, qog'oz tejaladi
  var sel = document.getElementById('pqK'); if (!sel) return;
  function apply(k) {
    document.querySelectorAll('.pq-q[data-mm]').forEach(function (q) {
      var mm = +q.getAttribute('data-mm') * k, wide = mm > 105, w = wide ? Math.min(mm, 179) : Math.min(mm, 83);
      q.classList.toggle('wide', wide);
      var im = q.querySelector('img'); if (im) im.style.width = w.toFixed(1) + 'mm';
    });
  }
  var k = 1;
  try { k = +localStorage.getItem('pqK') || 1; } catch (e) { k = 1; }
  if ([1, 0.9, 0.8, 0.7].indexOf(k) < 0) k = 1;
  sel.value = String(k); if (k !== 1) apply(k);
  sel.addEventListener('change', function () { var v = +sel.value || 1; apply(v); try { localStorage.setItem('pqK', String(v)); } catch (e) {} });
})();
</script>
    <?php
    page_footer();
    return;
}

/** Kalitlar jadvali: [['var','tid','code','name','keys'=>[[pos, kalit, ochiqmi],…]],…] */
$keyRows = [];
$hasOpen = false;
foreach ($rowsP as $r) {
    $k = [];
    foreach ($r['items'] as $it) { $open = ($it['kind'] ?? 'mc') === 'open'; if ($open) $hasOpen = true; $k[] = [(int)$it['pos'], $it['kind'] === null ? '×' : qb_paper_key($it['kind'], $it['answer']), $open]; }
    $keyRows[] = ['var' => (int)$r['var_no'], 'tid' => (int)$r['tid'], 'code' => (string)$r['code'], 'name' => (string)$r['full_name'], 'keys' => $k];
}

/* ---------------- Kalitlar varag'i ---------------- */
if ($v === 'keys') {
    $per = $hasOpen ? 15 : 25;
    $blocks = max(1, (int)ceil($N / $per));
    $size = max(1, (int)ceil($N / $blocks));
    page_header('Kalitlar — ' . $as['title'], ['bare' => true, 'body' => 'print-page pq-page']);
    ?>
<div class="no-print toolbar">
  <button class="btn primary" onclick="print()"><?= icon('print', 16) ?>Chop etish</button>
  <a class="btn" href="<?= e(url('qb_paper', ['id' => $aid, 'v' => 'screen'])) ?>" target="_blank">Ekranga chiqarish</a>
  <a class="small" href="<?= e($back) ?>">← Sinf testiga qaytish</a>
</div>
<section class="pq-keys">
  <header>
    <div><small><?= e($center) ?><?= $center !== '' ? ' · ' : '' ?><?= e($as['title']) ?></small><h1>Javoblar kalitlari</h1></div>
    <div class="pq-r small"><?= e($date) ?><br><?= count($keyRows) ?> ta <?= $anon ? 'variant' : 'o\'quvchi' ?> · <?= $N ?> ta savol</div>
  </header>
  <p class="pq-note"><?= $anon ? 'Har variantda savollar tartibi boshqa — tekshirishda varaqdagi <b>variant</b> raqami bo\'yicha qatorni toping.' : 'Har o\'quvchida savollar tartibi boshqa — tekshirishda o\'quvchi varag\'idagi <b>ID</b> yoki <b>variant</b> raqami bo\'yicha qatorni toping.' ?></p>
  <?php for ($b = 0; $b < $blocks; $b++): $from = $b * $size; $to = min($N, $from + $size); if ($from >= $to) break; ?>
  <table class="pq-ktbl">
    <colgroup><col style="width:<?= $anon ? 14 : 9 ?>mm"><?php if (!$anon): ?><col style="width:16mm"><col style="width:<?= $blocks > 1 ? 34 : 38 ?>mm"><?php endif; ?><?php for ($i = $from; $i < $to; $i++): ?><col><?php endfor; ?></colgroup>
    <thead><tr><th><?= $anon ? 'Variant' : 'Var.' ?></th><?php if (!$anon): ?><th>ID</th><th class="pq-kname">F.I.Sh</th><?php endif; ?><?php for ($i = $from; $i < $to; $i++): ?><th class="<?= ($i + 1) % 5 === 0 ? 'c5' : '' ?>"><?= $i + 1 ?></th><?php endfor; ?></tr></thead>
    <tbody>
    <?php foreach ($keyRows as $kr): ?>
      <tr><td><b><?= $kr['var'] ?></b></td><?php if (!$anon): ?><td class="mono"><?= e($kr['code']) ?></td><td class="pq-kname"><?= e($kr['name']) ?></td><?php endif; ?>
        <?php for ($i = $from; $i < $to; $i++): $kk = $kr['keys'][$i] ?? [0, '', false]; ?><td class="<?= $kk[2] ? 'ko' : 'k' ?><?= ($i + 1) % 5 === 0 ? ' c5' : '' ?>"><?= e($kk[1]) ?></td><?php endfor; ?></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endfor; ?>
</section>
    <?php
    page_footer();
    return;
}

/* ---------------- Kalitlar — ekranga (proyektor) ---------------- */
if ($v === 'screen') {
    page_header('Kalitlar — ' . $as['title'], ['bare' => true, 'body' => 'pq-screen']);
    ?>
<div class="pq-scr-bar">
  <b class="pq-scr-t"><?= e($as['title']) ?></b>
  <div class="pq-seg" role="group" aria-label="Ko'rinish"><button type="button" data-m="all" class="on">Jadval</button><button type="button" data-m="one">Bittadan</button></div>
  <?php if (!$anon): ?><label class="pq-chk"><input type="checkbox" id="pqNames" checked> Ismlar</label><?php endif; ?>
  <span class="pq-zoom"><button type="button" id="pqMinus" aria-label="Kichikroq">A−</button><button type="button" id="pqPlus" aria-label="Kattaroq">A+</button></span>
  <button type="button" id="pqFull">To'liq ekran</button>
  <a href="<?= e($back) ?>">Qaytish</a>
</div>
<main class="pq-scr-main">
  <div id="pqAll" class="pq-scr-all">
    <table class="pq-stbl">
      <thead><tr><th><?= $anon ? 'Variant' : 'Var.' ?></th><?php if (!$anon): ?><th>ID</th><th class="pq-sname">F.I.Sh</th><?php endif; ?><?php for ($i = 1; $i <= $N; $i++): ?><th class="<?= $i % 5 === 0 ? 'c5' : '' ?>"><?= $i ?></th><?php endfor; ?></tr></thead>
      <tbody>
      <?php foreach ($keyRows as $kr): ?>
        <tr><td><b><?= $kr['var'] ?></b></td><?php if (!$anon): ?><td class="mono"><?= e($kr['code']) ?></td><td class="pq-sname"><?= e($kr['name']) ?></td><?php endif; ?>
          <?php foreach ($kr['keys'] as $i => $kk): ?><td class="<?= $kk[2] ? 'ko' : '' ?><?= ($i + 1) % 5 === 0 ? ' c5' : '' ?>"><?= e($kk[1]) ?></td><?php endforeach; ?></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div id="pqOne" class="pq-scr-one" hidden>
    <div class="pq-one-top">
      <button type="button" id="pqPrev" aria-label="Oldingi">‹</button>
      <div class="pq-one-who"><div class="pq-one-var">Variant <b id="pqOV"></b></div><div class="pq-one-name" id="pqON"></div><div class="pq-one-id"<?= $anon ? ' hidden' : '' ?>>ID <b id="pqOI"></b></div></div>
      <button type="button" id="pqNext" aria-label="Keyingi">›</button>
    </div>
    <div class="pq-one-grid" id="pqOG"></div>
    <div class="pq-one-pick"><label><?= $anon ? 'Variant' : 'O\'quvchi' ?>: <select id="pqSel"><?php foreach ($keyRows as $i => $kr): ?><option value="<?= $i ?>"><?= $anon ? 'Variant ' . $kr['var'] : $kr['var'] . ' · ' . e($kr['code']) . ' · ' . e($kr['name']) ?></option><?php endforeach; ?></select></label>
      <label><?= $anon ? 'Variant raqami' : 'ID yoki variant' ?>: <input id="pqFind" inputmode="numeric" autocomplete="off" placeholder="<?= $anon ? 'masalan: 7' : 'ID' ?>"></label></div>
  </div>
</main>
<script>
(function () {
  var R = <?= json_encode(array_map(fn($k) => ['v' => $k['var'], 'c' => $k['code'], 'n' => $k['name'], 'k' => array_map(fn($x) => [$x[0], $x[1]], $k['keys'])], $keyRows), JSON_UNESCAPED_UNICODE) ?>;
  var $ = function (id) { return document.getElementById(id); };
  var cur = 0, fs = 1;
  try { fs = +localStorage.getItem('pqFs') || 1; } catch (e) { fs = 1; }
  function zoom(d) { fs = Math.max(.6, Math.min(2.4, Math.round((fs + d) * 10) / 10)); document.body.style.setProperty('--pq-fs', fs); try { localStorage.setItem('pqFs', String(fs)); } catch (e) {} }
  function one(i) {
    if (!R.length) return;
    cur = (i + R.length) % R.length;
    var r = R[cur];
    $('pqOV').textContent = r.v; $('pqON').textContent = r.n; $('pqOI').textContent = r.c; $('pqSel').value = cur;
    $('pqOG').innerHTML = r.k.map(function (x) { return '<div><span>' + x[0] + '</span><b>' + String(x[1]).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; }) + '</b></div>'; }).join('');
  }
  function mode(m) {
    document.querySelectorAll('.pq-seg button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-m') === m); });
    $('pqAll').hidden = m !== 'all'; $('pqOne').hidden = m !== 'one';
    if (m === 'one') one(cur);
  }
  document.querySelectorAll('.pq-seg button').forEach(function (b) { b.addEventListener('click', function () { mode(b.getAttribute('data-m')); }); });
  if ($('pqNames')) $('pqNames').addEventListener('change', function () { document.body.classList.toggle('pq-nonames', !this.checked); });
  $('pqMinus').addEventListener('click', function () { zoom(-.1); });
  $('pqPlus').addEventListener('click', function () { zoom(.1); });
  $('pqFull').addEventListener('click', function () { var d = document.documentElement; if (document.fullscreenElement) document.exitFullscreen(); else if (d.requestFullscreen) d.requestFullscreen(); });
  $('pqPrev').addEventListener('click', function () { one(cur - 1); });
  $('pqNext').addEventListener('click', function () { one(cur + 1); });
  $('pqSel').addEventListener('change', function () { one(+this.value); });
  $('pqFind').addEventListener('input', function () {   // 1–2 xonali — variant raqami, 3+ — ID boshi
    var q = this.value.trim(); if (!q) return;
    for (var i = 0; i < R.length; i++) if (q.length < 3 || !R[i].c ? String(R[i].v) === q : R[i].c.indexOf(q) === 0) { one(i); break; }
  });
  document.addEventListener('keydown', function (e) {
    if ($('pqOne').hidden || /^(INPUT|SELECT)$/.test(e.target.tagName)) return;
    if (e.key === 'ArrowLeft') one(cur - 1); else if (e.key === 'ArrowRight' || e.key === ' ') { e.preventDefault(); one(cur + 1); }
  });
  $('pqOG').style.setProperty('--cols', R.length && R[0].k.length > 20 ? 10 : 5);
  function barH() { var b = document.querySelector('.pq-scr-bar'); if (b) document.body.style.setProperty('--pq-bar', b.offsetHeight + 'px'); }
  window.addEventListener('resize', barH); barH();
  zoom(0);
})();
</script>
    <?php
    page_footer();
    return;
}

/* ---------------- Javoblarni kiritish ---------------- */
$keep = (isset($_SESSION['pq_keep']) && (int)($_SESSION['pq_keep']['aid'] ?? 0) === $aid) ? (array)$_SESSION['pq_keep']['rows'] : [];
unset($_SESSION['pq_keep']);
$closed = $as['closed_at'] !== null;
$doneN = count(array_filter($rowsP, fn($r) => $r['status'] === 'done'));
page_header('Javoblarni kiritish — ' . $as['title']);
?>
<?= crumbs([['Topshiriqlar', url('qb_assign')], [$as['title'], $back], 'Javoblarni kiritish']) ?>
<div class="page-head">
  <div><h1>Javoblarni kiritish</h1>
    <p class="muted">Har <?= $anon ? 'variant' : 'o\'quvchi' ?> varag'idagi javoblarni <b>o'z tartibida</b> yozing: <code>ABCDA BCD-A</code> — har harf bitta test savoli, <code>-</code> — javobsiz (bo'sh joylar e'tiborsiz). Ochiq savol javobi — son bilan, o'z o'rnida: <code>ABCDA 12 BCDA</code> (harflar ochiq savolni o'tkazib ketadi); aniq joy: <code>6:12</code>. Yozishingiz bilan natija ko'rinadi; «Saqlash» — baholanadi<?= $anon ? ' (sinf testi sahifasida har variant natijasi va savollar statistikasi)' : ' va o\'zlashtirishga qo\'shiladi' ?>. Kiritish ixtiyoriy: kalitlar bilan qog'ozda tekshirsangiz ham bo'ladi.</p></div>
  <div class="row gap wrap"><a class="btn ghost" target="_blank" href="<?= e(url('qb_paper', ['id' => $aid, 'v' => 'keys'])) ?>"><?= icon('key', 16) ?>Kalitlar varag'i</a></div>
</div>
<?php if ($closed): ?><div class="alert info"><?= icon('alert') ?><span>Sinf testi yakunlangan. Javob kiritsangiz yoki tuzatsangiz — natija yangilanadi.</span></div><?php endif; ?>
<form method="post" class="card pq-entry-card" id="pqEntry"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $aid ?>">
  <div class="row between center-v wrap pq-entry-head"><span class="small muted">Tekshirildi: <b><?= $doneN ?></b> / <?= count($rowsP) ?> · Enter — keyingi <?= $anon ? 'variant' : 'o\'quvchi' ?></span><button class="btn primary"><?= icon('check', 16) ?>Saqlash</button></div>
  <div class="table-wrap"><table class="tbl pq-entry">
    <thead><tr><th class="num"><?= $anon ? 'Variant' : 'Var.' ?></th><?php if (!$anon): ?><th>O'quvchi</th><?php endif; ?><th>Javoblar (varaqdagi tartibda)</th><th class="num">Natija</th></tr></thead>
    <tbody>
    <?php foreach ($rowsP as $r): $tid = (int)$r['tid']; $val = array_key_exists($tid, $keep) ? (string)$keep[$tid] : qb_paper_answers_str($r['items'], $r['status'] === 'done'); ?>
      <tr class="<?= array_key_exists($tid, $keep) ? 'pq-bad' : '' ?>">
        <td class="num"><b><?= (int)$r['var_no'] ?></b></td>
        <?php if (!$anon): ?><td><?= e($r['full_name']) ?><div class="small muted mono"><?= e($r['code']) ?><?= $r['status'] === 'missed' ? ' · <span class="tag red">kelmadi</span>' : '' ?></div></td><?php endif; ?>
        <td class="pq-in-cell"><input class="pq-in mono" name="ans[<?= $tid ?>]" value="<?= e($val) ?>" data-tid="<?= $tid ?>" autocomplete="off" spellcheck="false" autocapitalize="characters" aria-label="<?= e($anon ? 'Variant ' . (int)$r['var_no'] : $r['full_name']) ?> javoblari"><div class="pq-cells" data-for="<?= $tid ?>"></div></td>
        <td class="num pq-res" data-res="<?= $tid ?>"><?= $r['status'] === 'done' ? '<b>' . (int)$r['correct'] . '</b> / ' . (int)$r['n'] : '—' ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <div class="row gap wrap mt"><button class="btn primary"><?= icon('check', 16) ?>Saqlash</button><a class="btn ghost" href="<?= e($back) ?>">← Sinf testiga qaytish</a></div>
</form>
<script>
(function () {
  var K = <?= json_encode((object)array_combine(array_map(fn($r) => (string)$r['tid'], $rowsP), array_map(fn($r) => array_map(fn($it) => [($it['kind'] ?? 'mc') === 'open' ? 'o' : 'm', (string)$it['answer'], (int)$it['nopt'] === 6 ? 6 : 4, $it['kind'] === null ? 0 : 1], $r['items']), $rowsP)), JSON_UNESCAPED_UNICODE) ?>;
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function fmt(x) { var s = x.toFixed(9); return s.indexOf('.') >= 0 ? s.replace(/0+$/, '').replace(/\.$/, '') : s; }
  function normOpen(s) {
    s = String(s).trim().toLowerCase().replace(/[\s ]/g, '').replace(/,/g, '.').replace(/[−–]/g, '-');
    var m = s.match(/^(-?\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)$/);
    if (m && +m[2] !== 0) return fmt(+m[1] / +m[2]);
    if (s !== '' && /^[-+]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?$/.test(s)) return fmt(+s);
    return s;
  }
  function check(it, g) {
    if (g === '' || it[1] === '' || !it[3]) return null;
    if (it[0] !== 'o') return g.toUpperCase() === it[1].trim().toUpperCase();
    var n = normOpen(g);
    return it[1].split(';').some(function (a) { return n !== '' && n === normOpen(a); });
  }
  /* server bilan bir xil qoida (qb_paper_parse): harflar — test savollariga (ochiqlar o'tkazib yuboriladi), boshqa bo'lak — keyingi ochiq savolga, «6:5» — aniq joyga */
  function parse(items, text) {
    var out = { vals: {}, bad: {} }, raw = {}, cur = 0, n = items.length, blank = ['-', '_', '*', '?', ''];
    function next(from, wantOpen) { for (var p = from + 1; p <= n; p++) if ((items[p - 1][0] === 'o') === wantOpen) return p; return 0; }
    var toks = String(text).trim().split(/\s+/).filter(Boolean);
    outer: for (var t = 0; t < toks.length; t++) {
      var tok = toks[t], m = tok.match(/^(\d{1,3})[:=)](.*)$/);
      if (m) { cur = +m[1]; raw[cur] = blank.indexOf(m[2]) >= 0 ? '' : m[2]; continue; }
      if (/^[A-Fa-f\-_*?]+$/.test(tok)) {
        for (var i = 0; i < tok.length; i++) {
          var p = next(cur, false);
          if (!p) { out.bad[n + 1] = 1; break outer; }
          raw[p] = /[A-Fa-f]/.test(tok[i]) ? tok[i].toUpperCase() : ''; cur = p;
        }
        continue;
      }
      var q = next(cur, true);
      if (!q) { out.bad[cur + 1] = 1; continue; }
      raw[q] = tok; cur = q;
    }
    Object.keys(raw).forEach(function (k) {
      var p = +k, it = items[p - 1], v = raw[k];
      if (!it) { out.bad[p] = 1; return; }
      if (v === '') { out.vals[p] = ''; return; }
      if (it[0] === 'o') { if (v.length > 80) out.bad[p] = 1; else out.vals[p] = v; return; }
      v = v.toUpperCase();
      if (!/^[A-F]$/.test(v) || v > (it[2] === 6 ? 'F' : 'D')) { out.bad[p] = 1; return; }
      out.vals[p] = v;
    });
    return out;
  }
  function upd(inp) {
    var tid = inp.getAttribute('data-tid'), items = K[tid] || [], res = document.querySelector('[data-res="' + tid + '"]'), cells = document.querySelector('[data-for="' + tid + '"]');
    var p = parse(items, inp.value), ok = 0, graded = 0, h = '', nbad = Object.keys(p.bad).length;
    items.forEach(function (it, i) {
      var g = p.vals[i + 1] !== undefined ? p.vals[i + 1] : '', r = check(it, g);
      if (it[3] && it[1] !== '') graded++;
      if (r) ok++;
      h += '<i class="' + (p.bad[i + 1] ? 'x' : (g === '' ? 'e' : (r ? 'g' : 'w'))) + '" title="' + esc((i + 1) + '-savol: ' + (g === '' ? 'javobsiz' : g)) + '">' + (i + 1) + '</i>';
    });
    cells.innerHTML = inp.value.trim() === '' ? '' : h;
    inp.classList.toggle('bad', nbad > 0);
    res.innerHTML = inp.value.trim() === '' ? '—' : (nbad ? '<span class="critical-t">xato</span>' : '<b>' + ok + '</b> / ' + graded);
  }
  var ins = [].slice.call(document.querySelectorAll('.pq-in'));
  ins.forEach(function (inp, idx) {
    upd(inp);
    inp.addEventListener('input', function (e) {
      upd(inp);
      var items = K[inp.getAttribute('data-tid')] || [], allMc = items.every(function (it) { return it[0] !== 'o'; });
      var c = inp.value.replace(/\s+/g, '');
      if (allMc && e.inputType === 'insertText' && /^[A-Fa-f\-_*?]+$/.test(c) && c.length === items.length && ins[idx + 1]) ins[idx + 1].focus();   // to'ldi — keyingi o'quvchi
    });
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); if (ins[idx + 1]) ins[idx + 1].focus(); else { var f = document.getElementById('pqEntry'); if (f.requestSubmit) f.requestSubmit(); else f.submit(); } } });
  });
})();
</script>
<?php page_footer();
