<?php
defined('APP_ROOT') || exit;
$me = student();
$test = test_by_id((int)($_GET['id'] ?? $_POST['id'] ?? 0));
if (!$test || !$test['online']) { flash('Test topilmadi yoki onlayn emas', 'err'); redirect('student_home'); }
$resp = row('SELECT * FROM responses WHERE test_id=? AND student_id=?', [$test['id'], $me['id']]);

$can = $resp ? ['ok' => true, 'reason' => '', 'code' => ''] : mock_can_start((int)$me['id'], $test);   // 2.5: pullik MOCK — faqat to'laganlar
if (is_post() && ($_POST['action'] ?? '') === 'start') {
    csrf_check();
    if (!$resp) {
        $st = mock_start_online((int)$me['id'], $test);   // 2.5: qulf ostida (to'lov sharti va bekor qilish bilan poyga yo'q)
        if (!$st['ok'] && $st['reason'] !== '') flash($st['reason'], 'err');
    }
    redirect('student_test', ['id' => $test['id']]);
}
if ($resp && $resp['status'] === 'submitted') {
    flash('Siz bu testni topshirgansiz. Natijalar e\'lon qilinganda shu yerda ko\'rinadi.');
    redirect('student_home');
}
if ($resp && $resp['status'] === 'in_progress' && time() > online_deadline($test, $resp) + 60) {
    q('UPDATE responses SET status="submitted", submitted_at=NOW() WHERE id=?', [$resp['id']]);
    q('UPDATE tests SET dirty=1 WHERE id=?', [$test['id']]);
    flash('Vaqt tugagan. Saqlangan javoblaringiz qabul qilindi.', 'warn');
    redirect('student_home');
}
$items = test_items($test);
if (!$resp) {
    page_header($test['title']);
    ?>
    <div class="card narrow">
      <h1><?= e($test['title']) ?></h1>
      <?php if (!online_open($test)): ?>
        <div class="alert warn">Test hozir ochiq emas.</div>
      <?php elseif (!$can['ok']): ?>
        <div class="alert warn"><?= icon('alert') ?><span><?= e($can['reason']) ?></span></div>
        <a class="btn primary wide" href="<?= e(url($can['code'] === 'unpaid' ? 'student_wallet' : 'moc', $can['code'] === 'noreg' && !empty($test['reg_open']) ? ['test' => $test['id'], 'confirm' => 1] : [])) ?>"><?= $can['code'] === 'unpaid' ? 'Hisobni to\'ldirish' : 'Ro\'yxatdan o\'tish' ?></a>
      <?php else: ?>
        <ul>
          <li>Davomiyligi: <b><?= (int)$test['duration_min'] ?> daqiqa</b> (boshlash tugmasini bosgan paytdan).</li>
          <li><?= count($items) ?> ta baholanadigan element: <?= closed_count($test) ?> ta yopiq, <?= (int)$test['n_open'] ?> ta ochiq topshiriq (a va b).</li>
          <li>Javoblar avtomatik saqlanadi. Internet uzilsa, sahifani qayta oching — javoblar joyida qoladi.</li>
          <li>Vaqt tugaganda test avtomatik yakunlanadi.</li>
        </ul>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="start"><input type="hidden" name="id" value="<?= (int)$test['id'] ?>">
          <button class="btn primary wide">Testni boshlash</button></form>
      <?php endif; ?>
    </div>
    <?php
    page_footer();
    return;
}
$ans = json_decode($resp['answers'] ?: '{}', true) ?: [];
$deadline = online_deadline($test, $resp);
page_header($test['title'], ['body' => 'exam-mode', 'main' => 'wide']);
?>
<div class="exam-bar">
  <b><?= e($test['title']) ?></b>
  <span id="saveState" class="small muted">saqlangan</span>
  <span class="timer" id="timer">--:--</span>
  <button class="btn success" id="finish">Yakunlash</button>
</div>
<div class="exam-layout <?= $test['pdf_file'] ? '' : 'no-pdf' ?>">
  <?php if ($test['pdf_file']): ?>
  <div class="exam-pdf"><iframe src="<?= e(url('pdf', ['id' => $test['id']])) ?>#view=FitH" title="Savollar kitobi"></iframe>
    <a class="small" href="<?= e(url('pdf', ['id' => $test['id']])) ?>" target="_blank">PDF ni alohida oynada ochish</a></div>
  <?php endif; ?>
  <form class="exam-sheet card" id="sheet" onsubmit="return false">
    <h3>Javoblar varaqasi</h3>
    <div class="key-grid compact exam-grid">
      <?php foreach ($items as $it): if ($it['type'] !== 'mc') continue; $lab = $it['label']; ?>
        <div class="key-row"><span class="qno"><?= e($lab) ?></span>
          <?php foreach ($it['opts'] as $o): ?><label class="bub"><input type="radio" name="<?= e($lab) ?>" value="<?= $o ?>" <?= (($ans[$lab] ?? '') === $o) ? 'checked' : '' ?>><span><?= $o ?></span></label><?php endforeach; ?>
        </div>
      <?php endforeach; ?>
    </div>
    <?php if ((int)$test['n_open']): ?>
    <h3 class="mt">Ochiq topshiriqlar</h3>
    <p class="small muted">Javobni eng sodda ko'rinishda yozing: butun son, o'nli kasr (0.5), oddiy kasr (3/4), ildiz uchun √ (masalan 2√3). Bir nechta qiymat bo'lsa <b>;</b> bilan ajrating (masalan 2;3). Yaxlitlamang: 8/3 ni 2,67 deb yozmang.</p>
    <div class="open-key-grid">
      <?php foreach ($items as $it): if ($it['type'] !== 'open') continue; $lab = $it['label']; ?>
        <label class="open-key"><span class="qno"><?= e($lab) ?></span><input name="<?= e($lab) ?>" value="<?= e($ans[$lab] ?? '') ?>" class="mono" maxlength="40" autocomplete="off"></label>
      <?php endforeach; ?>
    </div>
    <div class="row gap small mt"><span>Belgi qo'shish:</span><?php foreach (['√', 'π', '/', '-', ';', '(', ')'] as $sym): ?><button type="button" class="btn sm ghost sym" data-s="<?= $sym ?>"><?= $sym ?></button><?php endforeach; ?></div>
    <?php endif; ?>
  </form>
</div>
<script>
(function(){
  const testId = <?= (int)$test['id'] ?>, deadline = <?= $deadline ?> * 1000, serverNow = <?= time() ?> * 1000, drift = Date.now() - serverNow;
  const csrf = document.querySelector('meta[name=csrf]').content;
  const form = document.getElementById('sheet'), state = document.getElementById('saveState'), timer = document.getElementById('timer');
  let dirty = false, sending = false, done = false, lastFocus = null;
  function collect(){ const a = {}; new FormData(form).forEach((v,k)=>a[k]=v); return a; }
  async function send(final){
    if (done) return;
    sending = true; state.textContent = 'saqlanmoqda…';
    try {
      const r = await fetch('index.php?p=api&a=online_save', {method:'POST', headers:{'Content-Type':'application/json','X-CSRF':csrf}, body: JSON.stringify({test:testId, answers:collect(), final:!!final})}).then(r=>r.json());
      if (r.submitted) { done = true; alert(r.error || 'Javoblaringiz qabul qilindi!'); location.href = 'index.php?p=student_home'; return; }
      if (!r.ok) throw new Error(r.error||'xato');
      dirty = false; state.textContent = 'saqlandi ' + r.saved_at;
    } catch(e) { state.textContent = '⚠ saqlanmadi — internetni tekshiring'; }
    sending = false;
  }
  form.addEventListener('input', ()=>{ dirty = true; state.textContent = 'o\'zgartirildi'; clearTimeout(form._t); form._t = setTimeout(()=>send(false), 1200); });
  form.querySelectorAll('input.mono').forEach(i=>i.addEventListener('focus', ()=>lastFocus=i));
  document.querySelectorAll('.sym').forEach(b=>b.addEventListener('click', ()=>{ if(!lastFocus) return; lastFocus.value += b.dataset.s; lastFocus.focus(); form.dispatchEvent(new Event('input')); }));
  setInterval(()=>{ if(dirty && !sending) send(false); }, 20000);
  function tick(){
    const left = Math.max(0, deadline - (Date.now() - drift));
    const m = Math.floor(left/60000), s = Math.floor(left/1000)%60;
    timer.textContent = (m>=60? Math.floor(m/60)+':'+String(m%60).padStart(2,'0') : m) + ':' + String(s).padStart(2,'0');
    timer.classList.toggle('low', left < 5*60000);
    if (left <= 0 && !done) { send(true); return; }
    setTimeout(tick, 500);
  }
  tick();
  document.getElementById('finish').addEventListener('click', ()=>{
    const a = collect(); const total = <?= count($items) ?>; const filled = Object.values(a).filter(v=>v!=='').length;
    if (confirm('Testni yakunlaysizmi? Belgilangan: ' + filled + ' / ' + total + '. Yakunlagandan keyin o\'zgartirib bo\'lmaydi.')) send(true);
  });
  window.addEventListener('beforeunload', e=>{ if(dirty && !done){ e.preventDefault(); e.returnValue=''; } });
})();
</script>
<?php page_footer();
