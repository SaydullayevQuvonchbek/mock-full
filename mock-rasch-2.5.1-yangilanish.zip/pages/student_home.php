<?php
defined('APP_ROOT') || exit;
/** O'quvchi kabineti: MOCK larim (xona/o'rin), onlayn testlar, natijalar bo'limlar bo'yicha, o'sish grafigi */
$me = student();
if (is_post() && ($_POST['action'] ?? '') === 'enroll') {
    csrf_check();
    $tid = (int)$_POST['test_id'];
    $t = mock_test_row($tid);
    if ($t && mock_price($t) > 0) redirect('moc', ['test' => $tid, 'confirm' => 1]);   // 2.5: pullik — tasdiqlash oynasi
    $r = mock_register((int)$me['id'], $tid, 'web', ['pay' => 'wallet', 'expect_price' => 0]);
    flash($r['ok'] ? 'MOCK ga ro\'yxatdan o\'tdingiz' : $r['error'], $r['ok'] ? 'ok' : 'err');
    redirect('student_home');
}
wallet_tick(true);
$st = row('SELECT * FROM students WHERE id=?', [$me['id']]);
$mine = mock_student_list((int)$me['id']);   // 2.5: sayt va bot uchun bitta ro'yxat (to'lov holati bilan)
$openToJoin = mock_open_list((int)$me['id']);
$bal = (int)$st['balance'];
$pendPay = (int)val('SELECT COUNT(*) FROM pay_requests WHERE student_id=? AND status="pending"', [$me['id']]);
$nUnpaid = count(array_filter($mine, fn($x) => $x['pay_status'] === 'unpaid' && !$x['over']));
$online = rows('SELECT t.*, r.status rstatus FROM tests t LEFT JOIN responses r ON r.test_id=t.id AND r.student_id=? WHERE t.online=1 ORDER BY t.id DESC', [$me['id']]);
$results = rows('SELECT t.id, t.title, t.test_date, t.published, res.ball, res.grade, res.rank_no, res.raw, r.status
                 FROM responses r JOIN tests t ON t.id=r.test_id LEFT JOIN results res ON res.test_id=t.id AND res.student_id=r.student_id
                 WHERE r.student_id=? ORDER BY t.id DESC', [$me['id']]);
$hist = student_history((int)$me['id']);
$histBy = [];
foreach ($hist as $h) $histBy[$h['test_id']] = $h;
$avg = student_section_avg($hist);
$needPhone = $st['phone'] !== '' && !$st['phone_verified_at'] && phone_proof_channels($st['phone']);
$qbReady = qb_pool_size([]);
$qbLast = $qbReady ? row('SELECT * FROM qb_tests WHERE student_id=? AND status="done" ORDER BY id DESC LIMIT 1', [$me['id']]) : null;
$qbOpen = $qbReady ? (int)val('SELECT COUNT(*) FROM qb_tests WHERE student_id=? AND status="open" AND assign_id IS NULL', [$me['id']]) : 0;
qb_assign_tick();
$asgOpen = rows('SELECT t.id, t.title, t.n, a.deadline FROM qb_tests t JOIN qb_assign a ON a.id=t.assign_id WHERE t.student_id=? AND t.status="open" AND a.mode<>"paper" ORDER BY a.deadline', [$me['id']]);   // sinf testi qog'ozda yechiladi
$mTop = array_values(array_filter(qb_mastery((int)$me['id']), fn($x) => $x['depth'] === 0));
$needTg = $st['tg_chat_id'] === null && tg_ready() && tg_meta('bot') !== '';
page_header('Mening sahifam');
?>
<?php $lastH = null; foreach ($hist as $h) if ($lastH === null || (int)$h['test_id'] > (int)$lastH['test_id']) $lastH = $h; $wrongN = $qbReady ? qb_wrong_count((int)$me['id']) : 0; ?>
<section class="cab-hero">
  <div class="ch-who">
    <h1>Salom, <?= e(trim((string)$st['first_name']) ?: ($st['full_name'] ?: 'o\'quvchi')) ?>!</h1>
    <p class="muted"><?= e($st['full_name']) ?> · ID <span class="mono"><?= e($st['code']) ?></span><?= $st['group_name'] ? ' · ' . e($st['group_name']) : '' ?> · <a href="<?= e(url('student_profile')) ?>">Profil</a></p>
  </div>
  <div class="ch-tiles t4">
    <?php if ($lastH): ?>
      <a class="ch-tile" href="<?= e(url('student_result', ['id' => $lastH['test_id']])) ?>"><span>Oxirgi MOCK</span><b><?= fmt($lastH['ball']) ?> <?= grade_badge($lastH['grade']) ?></b><small><?= e($lastH['title']) ?></small></a>
    <?php else: ?>
      <a class="ch-tile" href="<?= e(url('moc')) ?>"><span>Oxirgi MOCK</span><b>—</b><small>Natija hali yo'q — keyingi MOCK ga yoziling</small></a>
    <?php endif; ?>
    <a class="ch-tile" href="<?= e(url('student_practice')) ?>"><span>Ochiq topshiriqlar</span><b><?= count($asgOpen) ?></b><small><?= $asgOpen ? 'eng yaqin muddat: ' . e(date('d.m.Y H:i', strtotime((string)$asgOpen[0]['deadline']))) : 'hozircha topshiriq yo\'q' ?></small></a>
    <a class="ch-tile" href="<?= e(url('student_practice')) ?>"><span>Takrorlash kerak</span><b><?= $wrongN ?></b><small><?= $wrongN ? 'savolda xato qilgansiz — mashqda qayta beriladi' : 'xato qilingan savol yo\'q' ?></small></a>
    <a class="ch-tile" href="<?= e(url('student_wallet')) ?>"><span>Hamyon</span><b class="nowrap"><?= e(som($bal)) ?></b><small><?= $nUnpaid ? $nUnpaid . ' ta MOCK to\'lov kutmoqda' : ($pendPay ? $pendPay . ' ta chek tekshirilmoqda' : 'MOCK to\'lovlari shu balansdan') ?></small></a>
  </div>
</section>

<?php if ($needTg || $needPhone): ?>
<div class="alert info"><?= icon('alert') ?><span>
  <?php if ($needTg): ?><b>Telegramni ulang</b> — savollar kitobi, eslatma va natija o'zingizga botda keladi. <?php endif; ?>
  <?php if ($needPhone): ?><b>Telefon raqamingizni tasdiqlang</b> — parolni tiklash ishonchli bo'ladi. <?php endif; ?>
  <a href="<?= e(url('student_profile')) ?>">Profilga o'tish →</a></span></div>
<?php endif; ?>

<h2 class="mt">Mening MOCK larim</h2>
<?php if (!$mine): ?><div class="card empty">Siz hali hech qaysi MOCK ga yozilmagansiz.</div><?php endif; ?>
<?php foreach ($mine as $t): ?>
  <div class="card row between center-v">
    <div>
      <b><?= e($t['title']) ?></b>
      <div class="small muted"><?= e($t['test_date'] ? date('d.m.Y', strtotime($t['test_date'])) : 'sana belgilanmagan') ?><?= $t['online_start'] ? ' · onlayn: ' . e(substr($t['online_start'], 0, 16)) : '' ?></div>
      <?php if ($t['room'] !== null && $t['seat'] !== null): ?>
        <div class="seat-line"><?= icon('pin', 15) ?><b><?= e($t['room']) ?></b> · <b><?= (int)$t['seat'] ?>-o'rin</b><?= $t['proctor'] ? ' <span class="muted small">· nazoratchi: ' . e($t['proctor']) . '</span>' : '' ?></div>
      <?php elseif (!$t['published'] && !$t['online']): ?><div class="small muted">Xona va o'rin hali belgilanmagan.</div><?php endif; ?>
    </div>
    <div class="right">
      <?php if ($t['published']): ?><span class="tag green">Natija e'lon qilingan</span>
      <?php elseif ($t['rstatus'] === 'submitted'): ?><span class="tag green">Topshirildi</span>
      <?php elseif ($t['rstatus'] === 'in_progress'): ?><span class="tag">Test davom etmoqda</span>
      <?php elseif ($t['pay_status'] === 'unpaid' && !$t['over']): ?><span class="tag amber">Band — to'lov kutilmoqda</span> <a class="btn primary sm" href="<?= e(url('moc')) ?>"><?= $bal >= mock_price($t) ? 'To\'lash' : 'Hisobni to\'ldirish' ?></a>
      <?php elseif ($t['pay_status'] === 'unpaid'): ?><span class="tag">To'lanmagan</span>
      <?php else: ?><span class="tag green">Ro'yxatdasiz</span><?php endif; ?>
    </div>
  </div>
<?php endforeach; ?>
<?php if ($openToJoin): ?>
  <div class="row between center-v mt"><h3 style="margin:0">Yozilish mumkin</h3><a class="small" href="<?= e(url('moc')) ?>">Barcha ochiq MOCK lar →</a></div>
  <?php foreach ($openToJoin as $t): $pr = mock_price($t); ?>
  <div class="card row between center-v">
    <div><b><?= e($t['title']) ?></b><div class="small muted"><?= e($t['test_date'] ? date('d.m.Y', strtotime((string)$t['test_date'])) : 'sana belgilanmagan') ?><?= $t['online'] ? ' · onlayn' : '' ?></div></div>
    <div class="row gap center-v"><span class="price-tag<?= $pr ? '' : ' free' ?>"><?= e(mock_price_label($t)) ?></span>
    <?php if ($pr > 0): ?><a class="btn primary sm" href="<?= e(url('moc', ['test' => $t['id'], 'confirm' => 1])) ?>#confirm">Yozilish</a>
    <?php else: ?><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="enroll"><input type="hidden" name="test_id" value="<?= (int)$t['id'] ?>"><button class="btn primary sm">Yozilish</button></form><?php endif; ?></div>
  </div>
  <?php endforeach; ?>
<?php endif; ?>

<h2 class="mt">Onlayn testlar</h2>
<?php $shown = 0; foreach ($online as $t): if (!online_open($t) && $t['rstatus'] !== 'in_progress') continue; $shown++; ?>
  <div class="card row between center-v">
    <div><b><?= e($t['title']) ?></b><div class="small muted"><?= (int)$t['duration_min'] ?> daqiqa<?= $t['online_end'] ? ' · ' . e(substr($t['online_end'], 0, 16)) . ' gacha' : '' ?></div></div>
    <?php if ($t['rstatus'] === 'submitted'): ?><span class="tag green">Topshirildi</span>
    <?php elseif ($t['rstatus'] === 'in_progress'): ?><a class="btn primary" href="<?= e(url('student_test', ['id' => $t['id']])) ?>">Davom ettirish</a>
    <?php elseif (!($cs = mock_can_start((int)$me['id'], $t))['ok']): ?><span class="row gap center-v"><span class="tag amber" title="<?= e($cs['reason']) ?>"><?= $cs['code'] === 'unpaid' ? 'To\'lov kutilmoqda' : 'Pullik: ' . e(som(mock_price($t))) ?></span><a class="btn sm" href="<?= e(url('moc', $cs['code'] === 'noreg' && $t['reg_open'] ? ['test' => $t['id'], 'confirm' => 1] : [])) ?>"><?= $cs['code'] === 'noreg' ? 'Ro\'yxatdan o\'tish' : 'To\'lash' ?></a></span>
    <?php else: ?><a class="btn primary" href="<?= e(url('student_test', ['id' => $t['id']])) ?>">Boshlash</a><?php endif; ?>
  </div>
<?php endforeach; ?>
<?php if (!$shown): ?><div class="card empty">Hozir ochiq onlayn test yo'q.</div><?php endif; ?>

<?php if ($asgOpen): ?>
<h2 class="mt">Topshiriqlar</h2>
<?php foreach ($asgOpen as $a): ?>
  <div class="card row between center-v">
    <div><b><?= e($a['title']) ?></b><div class="small muted"><?= (int)$a['n'] ?> ta savol · muddat: <b><?= e(date('d.m.Y H:i', strtotime((string)$a['deadline']))) ?></b></div></div>
    <a class="btn primary" href="<?= e(url('student_practice_do', ['id' => $a['id']])) ?>">Yechish</a>
  </div>
<?php endforeach; ?>
<?php endif; ?>

<?php if ($qbReady): ?>
<h2 class="mt">Mashq testlari</h2>
<div class="card row between center-v">
  <div><b>Bo'limlar bo'yicha mashq</b>
    <div class="small muted">Bazada <?= $qbReady ?> ta savol. <?php if ($qbLast): ?>Oxirgi mashq: <b><?= (int)$qbLast['correct'] ?> / <?= (int)$qbLast['n'] ?></b> to'g'ri (<?= e(date('d.m.Y', strtotime((string)$qbLast['finished_at']))) ?>).<?php else: ?>Hali mashq qilmagansiz.<?php endif; ?><?= $qbOpen ? ' Yakunlanmagan: ' . $qbOpen . ' ta.' : '' ?></div></div>
  <a class="btn primary" href="<?= e(url('student_practice')) ?>">Mashq qilish</a>
</div>
<?php if ($mTop): ?>
<div class="card">
  <div class="card-head"><h3>O'zlashtirishim — bo'limlar bo'yicha</h3><a class="small" href="<?= e(url('student_practice')) ?>">Batafsil →</a></div>
  <div class="qb-secbars">
  <?php foreach ($mTop as $x): $p = (int)$x['pct']; ?>
    <div class="qb-secbar"><span><?= e($x['name']) ?></span><div class="qb-track" role="img" aria-label="<?= $p ?>%"><i style="width:<?= $p ?>%" class="<?= pct_cls($p) ?>"></i></div><b><?= $p ?>%</b></div>
  <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>
<?php endif; ?>

<h2 class="mt">Natijalarim</h2>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>Test</th><th>Sana</th><th class="num">Ball</th><th>Daraja</th><th class="num">O'rin</th><th class="num" title="To'g'ri javoblar / savollar">Algebra</th><th class="num">Geometriya</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($results as $r): $h = $histBy[(int)$r['id']] ?? null; ?>
    <tr>
      <td><?= e($r['title']) ?></td><td><?= e($r['test_date']) ?></td>
      <?php if ($r['published'] && $r['ball'] !== null): ?>
        <td class="num"><b><?= fmt($r['ball']) ?></b></td><td><?= grade_badge($r['grade']) ?></td><td class="num"><?= (int)$r['rank_no'] ?></td>
        <td class="num"><?= $h && isset($h['sec']['A']) ? (int)$h['sec']['A']['ok'] . ' / ' . (int)$h['sec']['A']['total'] : '—' ?></td>
        <td class="num"><?= $h && isset($h['sec']['G']) ? (int)$h['sec']['G']['ok'] . ' / ' . (int)$h['sec']['G']['total'] : '—' ?></td>
        <td class="right nowrap"><a class="btn sm" href="<?= e(url('student_result', ['id' => $r['id']])) ?>">Batafsil tahlil</a> <a class="btn sm ghost" target="_blank" href="<?= e(url('certificate', ['id' => $r['id']])) ?>"><?= (float)$r['ball'] >= 46 ? 'Sertifikat' : 'Natija varaqasi' ?></a></td>
      <?php else: ?>
        <td colspan="6" class="muted"><?= $r['status'] === 'submitted' ? 'Natijalar hali e\'lon qilinmagan' : 'Test davom etmoqda' ?></td>
      <?php endif; ?>
    </tr>
  <?php endforeach; ?>
  <?php if (!$results): ?><tr><td colspan="8" class="empty">Hali natija yo'q</td></tr><?php endif; ?>
  </tbody>
</table></div>

<?php if ($hist): $labels = array_map(fn($h) => $h['date'] ? date('d.m', strtotime($h['date'])) : '#' . $h['test_id'], $hist); ?>
<h2 class="mt">Mening o'sishim</h2>
<div class="grid2">
  <div class="card">
    <div class="card-head"><h3>Ball</h3><span class="small muted"><?= count($hist) ?> ta MOCK</span></div>
    <?= svg_line_chart($labels, [['cls' => 'ln-ball', 'name' => 'Ball', 'pts' => array_map(fn($h) => round($h['ball'], 1), $hist)]], 80, ['values' => true, 'title' => 'Ball o\'sishi', 'threshold' => [46, 'sertifikat 46'], 'ticks' => 4]) ?>
    <?php if (count($hist) >= 2): $d = $hist[count($hist) - 1]['ball'] - $hist[count($hist) - 2]['ball']; ?>
      <p class="small mt" style="margin-bottom:0">Oxirgi MOCK: <b><?= fmt($hist[count($hist) - 1]['ball']) ?></b> ball
        (<?= $d >= 0 ? '<span class="ok-t">+' . fmt($d) . '</span>' : '<span class="critical-t">' . fmt($d) . '</span>' ?> oldingisiga nisbatan).</p>
    <?php endif; ?>
  </div>
  <div class="card">
    <div class="card-head"><h3>Bo'limlar: to'g'ri javoblar, %</h3><span class="small muted">Algebra va Geometriya</span></div>
    <?php
      $pctOf = function (array $h, string $k) { return isset($h['sec'][$k]) && $h['sec'][$k]['total'] > 0 ? round(100 * $h['sec'][$k]['ok'] / $h['sec'][$k]['total']) : null; };
      echo svg_line_chart($labels, [
          ['cls' => 'ln-a', 'name' => 'Algebra', 'pts' => array_map(fn($h) => $pctOf($h, 'A'), $hist)],
          ['cls' => 'ln-g', 'name' => 'Geometriya', 'pts' => array_map(fn($h) => $pctOf($h, 'G'), $hist)],
      ], 100, ['title' => 'Bo\'limlar bo\'yicha o\'sish', 'ticks' => 4]);
    ?>
    <?php if (count($avg) > 1): $a = $avg['A']['pct'] ?? 0; $g = $avg['G']['pct'] ?? 0; ?>
      <p class="small mt" style="margin-bottom:0">O'rtacha: Algebra <b><?= $a ?>%</b> · Geometriya <b><?= $g ?>%</b>.
        <?php if (abs($a - $g) >= 8): ?><?= $a < $g ? 'Algebra' : 'Geometriya' ?> ustida ko'proq ishlash foydali.<?php endif; ?></p>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>
<?php page_footer();
