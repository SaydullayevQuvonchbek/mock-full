<?php
defined('APP_ROOT') || exit;
$test = get_test_or_404();
$items = test_items($test);
if (is_post()) {
    csrf_check();
    $act = $_POST['action'] ?? '';
    if ($act === 'settings') {
        tg_test_prepare_post();
        $nc = max(0, min(35, (int)$_POST['n_closed']));
        $nm = max(0, min(35 - $nc, (int)$_POST['n_match']));
        $no = max(0, min(10, (int)$_POST['n_open']));
        q('UPDATE tests SET title=?, subject=?, test_date=?, n_closed=?, n_match=?, n_open=?, method=?, cap75=?, online=?, online_start=?, online_end=?, duration_min=?, published=?, reg_open=?, t_mean=?, t_sd=?, dirty=1 WHERE id=?', [
            trim($_POST['title'] ?? '') ?: $test['title'], trim($_POST['subject'] ?? '') ?: 'Matematika', ($_POST['test_date'] ?? '') ?: null,
            $nc, $nm, $no, isset(method_names()[$_POST['method'] ?? '']) ? $_POST['method'] : 'tscore', isset($_POST['cap75']) ? 1 : 0, isset($_POST['online']) ? 1 : 0,
            ($_POST['online_start'] ?? '') ? str_replace('T', ' ', $_POST['online_start']) : null,
            ($_POST['online_end'] ?? '') ? str_replace('T', ' ', $_POST['online_end']) : null,
            max(10, (int)$_POST['duration_min']), isset($_POST['published']) ? 1 : 0, isset($_POST['reg_open']) ? 1 : 0,
            max(30, min(70, (float)str_replace(',', '.', $_POST['t_mean'] ?? 50))), max(5, min(20, (float)str_replace(',', '.', $_POST['t_sd'] ?? 10))), $test['id'],
        ]);
        tg_test_save((int)$test['id']);
        // 2.5: narx (faqat «Moliya» huquqi bor admin o'zgartiradi); ro'yxat yopilsa — to'lanmagan bandlar bekor
        if (isset($_POST['price']) && can_finance()) {
            $np = trim((string)$_POST['price']) === '' ? 0 : money_in($_POST['price']);
            if ($np > PAY_MAX_AMOUNT) $np = (int)$test['price'];
            if ($np !== (int)$test['price']) {
                q('UPDATE tests SET price=? WHERE id=?', [$np, $test['id']]);
                mock_price_changed((int)$test['id'], (int)$test['price'], $np);
                $nUnp = $np > 0 ? mock_unpaid_count((int)$test['id']) : 0;
                if ($nUnp) flash($nUnp . ' ta band qilingan (to\'lanmagan) o\'quvchi yangi narx — ' . som($np) . ' bo\'yicha to\'laydi (hisobi to\'ldirilganda avtomatik). Oldin to\'laganlarniki o\'zgarmaydi.', 'warn');
                $nFree = $np > 0 && (int)$test['price'] === 0 ? (int)val('SELECT COUNT(*) FROM test_registrations WHERE test_id=? AND pay_status="free"', [$test['id']]) : 0;
                if ($nFree) flash($nFree . ' ta o\'quvchi narx qo\'yilishidan oldin bepul yozilgan — ular qatnasha oladi. To\'lov talab qilish kerak bo\'lsa: «Ro\'yxat» sahifasida «To\'lov» ustuni.', 'warn');
            }
        }
        if ((int)$test['reg_open'] === 1 && !isset($_POST['reg_open'])) {
            $nx = mock_expire_unpaid((int)$test['id']);
            if ($nx) flash('Ro\'yxat yopildi: ' . $nx . ' ta to\'lanmagan band bekor qilindi (kutilayotgan cheki borlar chek ko\'rib chiqilguncha saqlanadi)', 'warn');
        }
        if (!empty($_FILES['pdf']['tmp_name']) && is_uploaded_file($_FILES['pdf']['tmp_name'])) {
            $ext = strtolower(pathinfo($_FILES['pdf']['name'], PATHINFO_EXTENSION));
            $head = (string)file_get_contents($_FILES['pdf']['tmp_name'], false, null, 0, 5);
            if ($ext !== 'pdf' || $head !== '%PDF-') { flash('Faqat haqiqiy PDF fayl yuklash mumkin', 'err'); }
            elseif ($_FILES['pdf']['size'] > 40 * 1024 * 1024) { flash('PDF hajmi 40 MB dan oshmasin', 'err'); }
            else {
                $name = 'test_' . $test['id'] . '_' . bin2hex(random_bytes(6)) . '.pdf';
                if (!is_dir(APP_ROOT . '/uploads')) mkdir(APP_ROOT . '/uploads', 0775, true);
                move_uploaded_file($_FILES['pdf']['tmp_name'], APP_ROOT . '/uploads/' . $name);
                remove_test_pdf($test);   // eski fayl diskda qolmasin
                q('UPDATE tests SET pdf_file=? WHERE id=?', [$name, $test['id']]);
            }
        }
        flash('Sozlamalar saqlandi');
        redirect('test_edit', ['id' => $test['id']]);
    }
    if ($act === 'key') {
        $key = [];
        $quick = strtoupper(preg_replace('/[^A-Fa-f]/', '', $_POST['quick'] ?? ''));
        foreach ($items as $idx => $it) {
            $lab = $it['label'];
            $v = trim((string)($_POST['k'][$lab] ?? ''));
            if ($it['type'] === 'mc') {
                $v = strtoupper($v);
                if (!in_array($v, $it['opts'], true)) $v = '';
            }
            if ($v !== '') $key[$lab] = $v;
        }
        q('UPDATE tests SET key_json=?, dirty=1 WHERE id=?', [json_encode($key, JSON_UNESCAPED_UNICODE), $test['id']]);
        flash('Javoblar kaliti saqlandi (' . count($key) . ' / ' . count($items) . ')');
        redirect('test_edit', ['id' => $test['id']]);
    }
    if ($act === 'sections') {
        $str = strtoupper(preg_replace('/[^AaGg]/', '', $_POST['sec'] ?? ''));
        $sec = [];
        $nTasks = (int)$test['n_closed'] + (int)$test['n_match'] + (int)$test['n_open'];
        for ($t = 1; $t <= $nTasks; $t++) $sec[(string)$t] = ($str[$t - 1] ?? 'A') === 'G' ? 'G' : 'A';
        q('UPDATE tests SET sections_json=? WHERE id=?', [json_encode($sec), $test['id']]);
        $ng = count(array_filter($sec, fn($v) => $v === 'G'));
        flash("Bo'limlar saqlandi: " . ($nTasks - $ng) . " ta algebra, $ng ta geometriya topshirig'i");
        redirect('test_edit', ['id' => $test['id']]);
    }
    if ($act === 'tg_invite') {
        if (!(int)$test['reg_open']) {   // 2.5: «Qatnashaman» ham saytdagi kabi ro'yxat ochiq bo'lsagina yozadi — taklif yuborilsa ro'yxat ochiladi
            q('UPDATE tests SET reg_open=1 WHERE id=?', [$test['id']]);
            flash('Ro\'yxat ochildi — taklifdagi «Qatnashaman» tugmasi ishlashi uchun. Yopish: «Ro\'yxat» sahifasida yoki shu yerda.', 'warn');
        }
        q('DELETE FROM tg_queue WHERE kind="invite" AND test_id=?', [$test['id']]);
        $aud = tg_audience($test, true);
        foreach ($aud as $s) tg_enqueue('invite', (int)$test['id'], (int)$s['id'], (int)$s['tg_chat_id']);
        $r = tg_tick(20);
        if (!empty($r['off'])) flash('Avval bot tokenini kiriting (Sozlamalar → Telegram)', 'err');
        else flash(count($aud) . " ta ulangan o'quvchiga taklif yuborildi" . (!empty($r['failed']) ? ' (' . $r['failed'] . ' tasiga yetmadi)' : ''));
        redirect('test_edit', ['id' => $test['id']]);
    }
    if ($act === 'tg_now') {
        $r = tg_tick(20);
        if (!empty($r['off'])) flash('Avval bot tokenini kiriting (Sozlamalar → Telegram)', 'err');
        elseif (!empty($r['busy'])) flash('Navbat hozir band — bir oz kutib qayta urining', 'warn');
        else flash('Yuborildi: ' . ($r['sent'] ?? 0) . ', xato: ' . ($r['failed'] ?? 0) . ', yangi navbat: ' . ($r['queued_start'] ?? 0));
        redirect('test_edit', ['id' => $test['id']]);
    }
    if ($act === 'delete_pdf') {
        remove_test_pdf($test);
        q('UPDATE tests SET pdf_file=NULL WHERE id=?', [$test['id']]);
        redirect('test_edit', ['id' => $test['id']]);
    }
}
$key = $test['key'];
$nResp = (int)val('SELECT COUNT(*) FROM responses WHERE test_id=?', [$test['id']]);
$dt = fn($v) => $v ? str_replace(' ', 'T', substr($v, 0, 16)) : '';
page_header($test['title']);
test_tabs($test, 'test_edit');
?>
<div class="grid-side">
<div class="card">
  <h2>Javoblar kaliti</h2>
  <form method="post" class="form" id="keyForm">
    <?= csrf_field() ?><input type="hidden" name="action" value="key">
    <?php $mc = array_filter($items, fn($i) => $i['type'] === 'mc'); if ($mc): ?>
    <label>Tez kiritish (yopiq savollar ketma-ket): <input id="quickKey" name="quick" placeholder="Masalan: BACDDABC..." autocomplete="off" class="mono"
       value="<?= e(implode('', array_map(fn($i) => $key[$i['label']] ?? '_', $mc))) ?>"></label>
    <div class="key-grid">
      <?php foreach ($mc as $it): $lab = $it['label']; ?>
        <div class="key-row">
          <span class="qno"><?= e($lab) ?></span>
          <?php foreach ($it['opts'] as $o): ?>
            <label class="bub"><input type="radio" name="k[<?= e($lab) ?>]" value="<?= $o ?>" <?= (($key[$lab] ?? '') === $o) ? 'checked' : '' ?>><span><?= $o ?></span></label>
          <?php endforeach; ?>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php $op = array_filter($items, fn($i) => $i['type'] === 'open'); if ($op): ?>
    <h3 class="mt">Ochiq topshiriqlar javoblari</h3>
    <p class="muted small">Bir nechta to'g'ri shakl bo'lsa <code>|</code> bilan ajrating: <code>0.5|1/2</code>, <code>2√2|2sqrt2</code>. Sonlar avtomatik solishtiriladi (0,5 = 0.5 = 1/2). Skaner va qo'lda kiritishda ochiq javoblar tekshiruvchi belgisi bo'yicha (to'g'ri/noto'g'ri) baholanadi.</p>
    <div class="open-key-grid">
      <?php foreach ($op as $it): $lab = $it['label']; ?>
        <label class="open-key"><span class="qno"><?= e($lab) ?></span><input name="k[<?= e($lab) ?>]" value="<?= e($key[$lab] ?? '') ?>" class="mono"></label>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <button class="btn primary mt">Kalitni saqlash</button>
  </form>
</div>

<div>
<div class="card">
  <h2>Sozlamalar</h2>
  <form method="post" class="form" enctype="multipart/form-data">
    <?= csrf_field() ?><input type="hidden" name="action" value="settings">
    <label>Nomi <input name="title" value="<?= e($test['title']) ?>" required></label>
    <div class="grid2">
      <label>Fan <input name="subject" value="<?= e($test['subject']) ?>"></label>
      <label>Sana <input type="date" name="test_date" value="<?= e($test['test_date']) ?>"></label>
    </div>
    <div class="grid3">
      <label>A–D <input type="number" name="n_closed" value="<?= (int)$test['n_closed'] ?>" min="0" max="35"></label>
      <label>A–F <input type="number" name="n_match" value="<?= (int)$test['n_match'] ?>" min="0" max="35"></label>
      <label>Ochiq <input type="number" name="n_open" value="<?= (int)$test['n_open'] ?>" min="0" max="10"></label>
    </div>
    <?php if ($nResp): ?><p class="warn small">Diqqat: bu testda <?= $nResp ?> ta javob bor. Formatni o'zgartirsangiz, savol raqamlari mos kelmay qolishi mumkin.</p><?php endif; ?>
    <label>Ballga o'tkazish usuli
      <select name="method"><?php foreach (method_names() as $k => $v): ?><option value="<?= e($k) ?>" <?= $test['method'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select>
    </label>
    <label class="check"><input type="checkbox" name="cap75" <?= ($test['cap75'] ?? 1) ? 'checked' : '' ?>> Ballni 75 bilan cheklash (ixtiyoriy — rasmiy sertifikatlarda ball 75 dan oshishi mumkin)</label>
    <fieldset><legend>Markaz balli (standart ball usuli)</legend>
      <div class="grid2">
        <label>O'rtacha ball M <input type="number" step="0.5" min="30" max="70" name="t_mean" value="<?= e((string)($test['t_mean'] ?? 50)) ?>"></label>
        <label>Tarqoqlik S <input type="number" step="0.5" min="5" max="20" name="t_sd" value="<?= e((string)($test['t_sd'] ?? 10)) ?>"></label>
      </div>
      <p class="small muted" style="margin-top:-.3rem">Ball = M + S·Z. Rasmiy prognoz baribir 50 + 10·Z bo'yicha alohida ko'rsatiladi. M ni oshirsangiz ko'proq o'quvchi sertifikat oladi — ta'sirini "Natijalar" sahifasida ko'rasiz.</p>
    </fieldset>
    <label class="check"><input type="checkbox" name="reg_open" <?= !empty($test['reg_open']) ? 'checked' : '' ?>> Onlayn ro'yxat ochiq (o'quvchilar saytda va botda shu MOCK ga yozila oladi)</label>
    <?php $fin = can_finance(); ?>
    <label>Narxi, so'm <input name="price" inputmode="numeric" autocomplete="off" value="<?= (int)$test['price'] > 0 ? e(number_format((int)$test['price'], 0, '.', ' ')) : '' ?>" placeholder="0 — bepul" <?= $fin ? '' : 'disabled' ?>></label>
    <p class="small muted" style="margin-top:-.4rem"><?= $fin
      ? 'Onlayn va oflayn MOCK uchun bir xil. Yozilishda o\'quvchi hamyonidan yechiladi; balans yetmasa — joy band qilinadi va hisob to\'ldirilgach avtomatik to\'lanadi. Narx o\'zgarsa, oldin to\'laganlarniki o\'zgarmaydi.'
      : 'Narxni faqat «Moliya» huquqi bor administrator o\'zgartiradi.' ?></p>
    <fieldset><legend>Onlayn test</legend>
      <label class="check"><input type="checkbox" name="online" <?= $test['online'] ? 'checked' : '' ?>> O'quvchilar onlayn ishlay oladi</label>
      <div class="grid2">
        <label>Boshlanish <input type="datetime-local" name="online_start" value="<?= e($dt($test['online_start'])) ?>"></label>
        <label>Tugash <input type="datetime-local" name="online_end" value="<?= e($dt($test['online_end'])) ?>"></label>
      </div>
      <label>Davomiyligi (daqiqa) <input type="number" name="duration_min" value="<?= (int)$test['duration_min'] ?>" min="10"></label>
      <label>Savollar kitobi (PDF) <input type="file" name="pdf" accept="application/pdf"></label>
      <?php if ($test['pdf_file']): ?>
        <p class="small">Yuklangan: <a href="<?= e(url('pdf', ['id' => $test['id']])) ?>" target="_blank">PDF ni ochish</a></p>
      <?php endif; ?>
    </fieldset>
    <?php tg_test_fields($test); ?>
    <label class="check"><input type="checkbox" name="published" <?= $test['published'] ? 'checked' : '' ?>> Natijalar o'quvchilarga ko'rinsin (e'lon qilish)</label>
    <button class="btn primary">Saqlash</button>
  </form>
</div>
<?php tg_test_panel($test); ?>
<?php $secs = test_sections($test); ?>
<div class="card">
  <h2>Bo'limlar</h2>
  <p class="small muted">Sertifikatdagi kabi ball bo'limlarga ajratiladi. Topshiriqni bosib <b>A</b> (algebra va analiz) yoki <b>G</b> (geometriya) qiling.</p>
  <form method="post" class="form" id="secForm">
    <?= csrf_field() ?><input type="hidden" name="action" value="sections">
    <input type="hidden" name="sec" id="secStr" value="<?= e(implode('', $secs)) ?>">
    <div class="sec-grid">
      <?php foreach ($secs as $t => $v): ?><button type="button" class="sec-btn <?= $v === 'G' ? 'g' : '' ?>" data-t="<?= $t ?>"><b><?= $t ?></b><small><?= $v ?></small></button><?php endforeach; ?>
    </div>
    <div class="small muted mt"><span class="legend-dot a"></span> Algebra va matematik analiz asoslari · <span class="legend-dot g"></span> Geometriya</div>
    <button class="btn primary mt">Bo'limlarni saqlash</button>
  </form>
</div>
</div>
</div>
<script>
(function(){
  const inp=document.getElementById('secStr'); if(!inp) return;
  document.querySelectorAll('.sec-btn').forEach(b=>b.addEventListener('click',()=>{
    const i=+b.dataset.t-1; const s=inp.value.split(''); s[i]=s[i]==='G'?'A':'G'; inp.value=s.join('');
    b.classList.toggle('g', s[i]==='G'); b.querySelector('small').textContent=s[i];
  }));
})();
</script>
<script>
(function(){
  const q = document.getElementById('quickKey'); if(!q) return;
  const rows = [...document.querySelectorAll('.key-row')];
  q.addEventListener('input', () => {
    const s = q.value.toUpperCase().replace(/[^A-F_]/g,'');
    rows.forEach((r,i) => {
      const ch = s[i];
      r.querySelectorAll('input').forEach(inp => inp.checked = (inp.value === ch));
    });
  });
  document.querySelectorAll('.key-row input').forEach(inp => inp.addEventListener('change', () => {
    q.value = rows.map(r => (r.querySelector('input:checked')||{value:'_'}).value).join('');
  }));
})();
</script>
<?php page_footer();
