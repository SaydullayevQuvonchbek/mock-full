<?php
defined('APP_ROOT') || exit;
/**
 * Oldin ro'yxatdan o'tgan (ID + parol bilan kirgan) o'quvchi uchun MOCK tanlash.
 * Yangi foydalanuvchi p=register da MOCK ni tanlab, ma'lumotlarini kiritadi.
 * 2.5: pullik MOCK — tasdiqlash oynasi, hamyondan to'lash yoki joyni band qilish; chiqishda (muddat ichida) pul qaytadi.
 * Qoida sayt, bot va admin uchun bitta: inc/mock_reg.php.
 */
$me = student();
if ($me) { student_session_guard(); $me = student(); }   // parol almashtirilgan / majburiy almashtirish
// POST da faqat formadagi MOCK (manzildagi ?test= emas — formalar boshqa MOCK sahifasidan ham yuborilishi mumkin)
$tid = is_post() ? (int)($_POST['test'] ?? 0) : (int)($_GET['test'] ?? 0);
if (!$me && !is_post()) redirect('register', $tid ? ['test' => $tid] : []);

if (is_post()) {
    csrf_check();
    if (!$me) redirect('student_login', ['next' => 'moc', 'test' => $tid]);
    $sid = (int)$me['id'];
    $act = $_POST['action'] ?? '';
    if ($act === 'enroll') {
        $mode = ($_POST['pay'] ?? '') === 'reserve' ? 'auto' : 'wallet';
        $o = ['pay' => $mode, 'expect_price' => (int)($_POST['price'] ?? -1)];   // narx formada bo'lmasa ham — tasdiqlanmagan narx yechilmaydi
        $r = mock_register($sid, $tid, 'web', $o);
        if ($r['ok'] && $r['status'] === 'paid') flash('Siz «' . $r['title'] . '» ga ro\'yxatdan o\'tdingiz. Balansdan ' . som($r['price']) . ' yechildi, qoldi: ' . som((int)$r['balance']) . '.');
        elseif ($r['ok'] && $r['status'] === 'unpaid') flash('«' . $r['title'] . '» ga joyingiz band qilindi. Hisobni to\'ldiring — chek tasdiqlangach to\'lov avtomatik yechiladi.', 'warn');
        elseif ($r['ok'] && $r['status'] === 'exists') flash('Siz bu MOCK ro\'yxatidasiz', 'warn');
        elseif ($r['ok']) flash('Siz «' . $r['title'] . '» ga ro\'yxatdan o\'tdingiz');
        elseif ($r['status'] === 'insufficient' || $r['status'] === 'price') { flash($r['error'], 'warn'); redirect('moc', ['test' => $tid, 'confirm' => 1]); }
        else flash($r['error'], 'err');
        if ($r['ok'] && $r['status'] === 'unpaid') redirect('student_wallet');
    }
    if ($act === 'cancel') {
        $r = mock_cancel($sid, $tid, 'student');
        flash($r['ok'] ? 'Ro\'yxatdan chiqdingiz' . ($r['refund'] > 0 ? '. Hamyoningizga ' . som($r['refund']) . ' qaytarildi.' : '') : $r['error'], $r['ok'] ? 'warn' : 'err');
    }
    if ($act === 'payres') {
        $r = mock_pay_unpaid($sid, $tid, null, (int)($_POST['price'] ?? -1));
        flash($r['ok'] ? '«' . $r['title'] . '» uchun ' . som($r['price']) . ' to\'landi — siz ro\'yxatdasiz' : $r['error'], $r['ok'] ? 'ok' : 'err');
    }
    redirect('moc');
}

wallet_tick(true);
$sid = (int)$me['id'];
$bal = wallet_balance($sid);
$mine = array_values(array_filter(mock_student_list($sid), fn($x) => !$x['over']));
$open = mock_open_list($sid);
$confirm = null;
if ($tid) {
    foreach ($open as $t) if ((int)$t['id'] === $tid) $confirm = $t;
    $isMine = (bool)array_filter($mine, fn($x) => (int)$x['id'] === $tid);
    if (!$confirm && !$isMine) { flash('Bu MOCK ga ro\'yxat ochiq emas', 'warn'); redirect('moc'); }
    if ($confirm && mock_price($confirm) === 0 && empty($_GET['confirm'])) $confirm = null;   // bepul — ro'yxatdagi tugma yetarli
}
$cancelWin = pay_cancel_min();
page_header('MOCK ga ro\'yxatdan o\'tish', ['main' => 'narrow-main']);
?>
<?php if ($confirm): $pr = mock_price($confirm); ?>
<div class="card narrow moc-confirm" id="confirm">
  <div class="eyebrow">Ro'yxatdan o'tishni tasdiqlang</div>
  <h1 style="margin:.2rem 0"><?= e($confirm['title']) ?></h1>
  <p class="small muted"><?= e($confirm['test_date'] ? date('d.m.Y', strtotime((string)$confirm['test_date'])) : 'sana keyinroq e\'lon qilinadi') ?><?= $confirm['online'] ? ' · onlayn' . ($confirm['online_start'] ? ': ' . e(date('d.m.Y H:i', strtotime((string)$confirm['online_start']))) : '') : ' · markazda' ?></p>
  <?php if ($pr === 0): ?>
    <p>Bu MOCK bepul.</p>
    <form method="post" action="<?= e(url('moc')) ?>"><?= csrf_field() ?><input type="hidden" name="action" value="enroll"><input type="hidden" name="test" value="<?= (int)$confirm['id'] ?>"><input type="hidden" name="price" value="0"><button class="btn primary wide">Ro'yxatdan o'tish</button></form>
  <?php else: ?>
    <dl class="mc-sum">
      <div><dt>Narxi</dt><dd><?= e(som($pr)) ?></dd></div>
      <div><dt>Balansingiz</dt><dd><?= e(som($bal)) ?></dd></div>
      <?php if ($bal >= $pr): ?><div class="mc-after"><dt>To'lovdan keyin</dt><dd><?= e(som($bal - $pr)) ?></dd></div><?php else: ?><div class="mc-need"><dt>Yetmaydi</dt><dd><?= e(som($pr - $bal)) ?></dd></div><?php endif; ?>
    </dl>
    <?php if ($bal >= $pr): ?>
      <form method="post" action="<?= e(url('moc')) ?>"><?= csrf_field() ?><input type="hidden" name="action" value="enroll"><input type="hidden" name="test" value="<?= (int)$confirm['id'] ?>"><input type="hidden" name="price" value="<?= $pr ?>"><input type="hidden" name="pay" value="wallet">
        <button class="btn primary wide"><?= icon('check', 16) ?>Tasdiqlash — balansdan <?= e(som($pr)) ?></button></form>
      <?php if ($cancelWin > 0): ?><p class="small muted">Fikringiz o'zgarsa, to'lovdan keyin <?= e(mock_minutes_label($cancelWin)) ?> ichida shu sahifada bekor qilsangiz, pul to'liq qaytadi.</p><?php endif; ?>
    <?php else: ?>
      <div class="mc-choice">
        <a class="btn primary wide" href="<?= e(url('student_wallet')) ?>#topup"><?= icon('wallet', 16) ?>Hisobni to'ldirish</a>
        <form method="post" action="<?= e(url('moc')) ?>"><?= csrf_field() ?><input type="hidden" name="action" value="enroll"><input type="hidden" name="test" value="<?= (int)$confirm['id'] ?>"><input type="hidden" name="price" value="<?= $pr ?>"><input type="hidden" name="pay" value="reserve">
          <button class="btn wide"><?= icon('pin', 16) ?>Joyni band qilish</button></form>
      </div>
      <p class="small muted">Band qilsangiz, ro'yxatda joyingiz saqlanadi: hisobni to'ldirganingizda (chek tasdiqlangach) to'lov avtomatik yechiladi. Ro'yxat yopilguncha to'lanmasa, band bekor bo'ladi.</p>
    <?php endif; ?>
  <?php endif; ?>
  <p class="small"><a href="<?= e(url('moc')) ?>">← Barcha MOCK lar</a></p>
</div>
<?php endif; ?>

<div class="card narrow moc-card">
  <div class="row between center-v wrap gap"><h1 style="margin:0">MOCK lar</h1><a class="wallet-pill" href="<?= e(url('student_wallet')) ?>" title="Hamyon"><?= icon('wallet', 15) ?><?= e(som($bal)) ?></a></div>
  <p class="muted"><b><?= e($me['name'] ?? '') ?></b> (ID <span class="mono"><?= e($me['code']) ?></span>) — ma'lumotlaringiz saqlangan. MOCK ni tanlab, «Ro'yxatdan o'tish» ni bosing.</p>

  <?php if ($mine): ?>
    <h2 class="moc-h">Mening MOCK larim</h2>
    <?php foreach ($mine as $t): $pr = mock_price($t); $ps = (string)$t['pay_status']; $cc = $t['cancel']; ?>
      <div class="moc-item">
        <div>
          <b><?= e($t['title']) ?></b>
          <div class="small muted"><?= e($t['test_date'] ? date('d.m.Y', strtotime((string)$t['test_date'])) : 'sana keyinroq e\'lon qilinadi') ?><?= $t['online'] ? ' · onlayn' : '' ?><?= $ps === 'paid' ? ' · to\'langan: ' . e(som((int)$t['paid_amount'])) : '' ?></div>
          <?php if ($ps === 'paid' && $cc['ok'] && $cc['until']): ?><div class="small muted">Bekor qilsangiz pul qaytadi: <?= e(date('d.m H:i', $cc['until'])) ?> gacha</div><?php endif; ?>
        </div>
        <div class="row gap center-v wrap">
          <?php if ($ps === 'unpaid'): ?>
            <span class="tag amber">Band — to'lov kutilmoqda</span>
            <?php if ($bal >= $pr): ?><form method="post" action="<?= e(url('moc')) ?>" onsubmit="return confirm(<?= e(json_encode(som($pr) . ' balansdan yechilsinmi?', JSON_UNESCAPED_UNICODE)) ?>)"><?= csrf_field() ?><input type="hidden" name="action" value="payres"><input type="hidden" name="test" value="<?= (int)$t['id'] ?>"><input type="hidden" name="price" value="<?= $pr ?>"><button class="btn primary sm">To'lash (<?= e(som($pr)) ?>)</button></form>
            <?php else: ?><a class="btn primary sm" href="<?= e(url('student_wallet')) ?>#topup">Hisobni to'ldirish</a><?php endif; ?>
          <?php else: ?>
            <span class="tag green">Ro'yxatdasiz</span><?php if ($ps === 'waived'): ?><span class="tag blue">imtiyoz</span><?php endif; ?>
          <?php endif; ?>
          <?php if ($cc['ok']): ?>
            <form method="post" action="<?= e(url('moc')) ?>" onsubmit="return confirm(<?= e(json_encode('Ro\'yxatdan chiqasizmi?' . ($cc['refund'] > 0 ? ' ' . som($cc['refund']) . ' hamyoningizga qaytadi.' : ''), JSON_UNESCAPED_UNICODE)) ?>)"><?= csrf_field() ?><input type="hidden" name="action" value="cancel"><input type="hidden" name="test" value="<?= (int)$t['id'] ?>"><button class="btn sm danger-ghost"><?= $ps === 'unpaid' ? 'Bandni bekor qilish' : 'Bekor qilish' ?></button></form>
          <?php elseif ($ps === 'paid' && !$t['rstatus'] && $t['reg_open']): ?><span class="small muted" title="<?= e($cc['reason']) ?>">Chiqish — markaz orqali</span><?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>

  <?php if ($open): ?>
    <h2 class="moc-h">Yozilish mumkin</h2>
    <?php foreach ($open as $t): $pr = mock_price($t); ?>
      <div class="moc-item<?= $tid === (int)$t['id'] ? ' hl' : '' ?>">
        <div>
          <b><?= e($t['title']) ?></b>
          <div class="small muted"><?= e($t['subject']) ?> · <?= e($t['test_date'] ? date('d.m.Y', strtotime((string)$t['test_date'])) : 'sana keyinroq e\'lon qilinadi') ?><?= $t['online'] ? ' · onlayn' : '' ?> · <?= (int)$t['n_reg'] ?> kishi ro'yxatda</div>
        </div>
        <div class="row gap center-v">
          <span class="price-tag<?= $pr ? '' : ' free' ?>"><?= e(mock_price_label($t)) ?></span>
          <?php if ($pr > 0): ?><a class="btn primary sm" href="<?= e(url('moc', ['test' => $t['id'], 'confirm' => 1])) ?>#confirm">Ro'yxatdan o'tish</a>
          <?php else: ?><form method="post" action="<?= e(url('moc')) ?>"><?= csrf_field() ?><input type="hidden" name="action" value="enroll"><input type="hidden" name="test" value="<?= (int)$t['id'] ?>"><input type="hidden" name="price" value="0"><button class="btn primary sm">Ro'yxatdan o'tish</button></form><?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
  <?php if (!$open && !$mine): ?>
    <p class="empty">Hozir ro'yxati ochiq MOCK yo'q. Yangi MOCK e'lon qilinganda shu yerda paydo bo'ladi.</p>
  <?php elseif (!$open): ?><p class="small muted mt">Hozir ro'yxati ochiq boshqa MOCK yo'q.</p><?php endif; ?>
  <p class="small muted mt"><a href="<?= e(url('student_home')) ?>">← Mening sahifam</a></p>
</div>
<?php page_footer();
