<?php
defined('APP_ROOT') || exit;
/**
 * 2.5: Moliya → To'lovlar. O'quvchilar yuborgan cheklar navbati: ko'rish, tasdiqlash (summani o'zgartirib) yoki rad etish (sabab bilan).
 * Birinchi qaror kuchda: ikki admin bir vaqtda bossa, ikkinchisiga «allaqachon ko'rib chiqilgan» chiqadi.
 */
require_finance();
if (is_post()) {
    csrf_check();
    $id = (int)($_POST['id'] ?? 0);
    $dec = (string)($_POST['decision'] ?? '');
    if ($dec === 'approve') {
        $r = pay_request_decide($id, 'approve', money_in($_POST['amount'] ?? ''), (string)($_POST['note'] ?? ''));
    } else {
        $why = (string)($_POST['reason'] ?? '');
        $txt = trim((string)($_POST['reason_text'] ?? ''));
        $note = $why === 'boshqa' || !isset(PAY_REJECT_REASONS[$why]) ? $txt : PAY_REJECT_REASONS[$why] . ($txt !== '' ? ': ' . $txt : '');
        $r = pay_request_decide($id, 'reject', 0, $note);
    }
    if (!$r['ok']) { flash($r['error'], 'err'); redirect('pay', ['id' => $id]); }
    if ($r['status'] === 'approved') {
        $msg = 'Chek #' . $id . ' tasdiqlandi. Balans: ' . som((int)$r['balance']);
        if ($r['settled']) $msg .= '. Avtomatik to\'landi: ' . implode(', ', array_map(fn($x) => '«' . $x['title'] . '» (' . som($x['price']) . ')', $r['settled']));
        flash($msg);
    } else flash('Chek #' . $id . ' rad etildi', 'warn');
    $next = val('SELECT id FROM pay_requests WHERE status="pending" ORDER BY created_at, id LIMIT 1');
    if ($next) redirect('pay', ['id' => (int)$next]);
    redirect('pay');
}

$view = row('SELECT p.*, s.full_name, s.code, s.group_name, s.phone, s.balance, s.archived_at FROM pay_requests p JOIN students s ON s.id=p.student_id WHERE p.id=?', [(int)($_GET['id'] ?? 0)]);
$tabs = ['pending' => 'Kutilmoqda', 'approved' => 'Tasdiqlangan', 'rejected' => 'Rad etilgan', 'canceled' => 'Bekor qilingan', 'all' => 'Hammasi'];
$cnt = [];
foreach (rows('SELECT status, COUNT(*) n FROM pay_requests GROUP BY status') as $c) $cnt[$c['status']] = (int)$c['n'];
$isImg = fn(array $r) => strncmp((string)$r['file_type'], 'image/', 6) === 0;

if ($view):
    $flags = pay_flags($view);
    $pend = $view['status'] === 'pending';
    $ids = array_map('intval', array_column(rows('SELECT id FROM pay_requests WHERE status="pending" ORDER BY created_at, id'), 'id'));
    $pos = array_search((int)$view['id'], $ids, true);
    $prevId = $pos !== false && $pos > 0 ? $ids[$pos - 1] : 0;
    $nextId = $pos !== false && $pos < count($ids) - 1 ? $ids[$pos + 1] : 0;
    $unpaid = rows('SELECT t.id, t.title, t.price, t.online, t.online_end, t.test_date, t.published FROM test_registrations g JOIN tests t ON t.id=g.test_id
                    WHERE g.student_id=? AND g.pay_status="unpaid" ORDER BY g.created_at', [$view['student_id']]);
    $unpaid = array_values(array_filter($unpaid, fn($x) => !mock_is_over($x)));
    $others = rows('SELECT id, amount, approved_amount, status, created_at FROM pay_requests WHERE student_id=? AND id<>? ORDER BY id DESC LIMIT 6', [$view['student_id'], $view['id']]);
    page_header('Chek #' . (int)$view['id']);
    ?>
    <div class="page-head"><div>
      <?= crumbs([['To\'lovlar', url('pay')], 'Chek #' . (int)$view['id']]) ?>
      <h1>Chek #<?= (int)$view['id'] ?> <span class="tag <?= ['pending' => 'amber', 'approved' => 'green', 'rejected' => 'red'][$view['status']] ?? '' ?>"><?= e(PAY_STATUS[$view['status']] ?? $view['status']) ?></span></h1>
    </div>
    <?php if ($pend && count($ids) > 1): ?><div class="row gap"><?php if ($prevId): ?><a class="btn sm ghost" href="<?= e(url('pay', ['id' => $prevId])) ?>">← Oldingi</a><?php endif; ?><span class="small muted"><?= $pos + 1 ?> / <?= count($ids) ?></span><?php if ($nextId): ?><a class="btn sm ghost" href="<?= e(url('pay', ['id' => $nextId])) ?>">Keyingi →</a><?php endif; ?></div><?php endif; ?>
    </div>
    <div class="pay-view">
      <div class="card pv-file">
        <?php if ($isImg($view)): ?>
          <a href="<?= e(url('pay_file', ['id' => $view['id']])) ?>" target="_blank" title="To'liq o'lchamda ochish"><img src="<?= e(url('pay_file', ['id' => $view['id']])) ?>" alt="Chek #<?= (int)$view['id'] ?>"></a>
        <?php else: ?>
          <iframe src="<?= e(url('pay_file', ['id' => $view['id']])) ?>" title="Chek #<?= (int)$view['id'] ?> (PDF)"></iframe>
        <?php endif; ?>
        <div class="row gap small mt"><a target="_blank" href="<?= e(url('pay_file', ['id' => $view['id']])) ?>">Yangi oynada ochish</a><a href="<?= e(url('pay_file', ['id' => $view['id'], 'dl' => 1])) ?>">Yuklab olish</a><span class="muted"><?= e(strtoupper(PAY_FILE_TYPES[$view['file_type']] ?? '')) ?> · <?= e(number_format((int)$view['file_size'] / 1024, 0, '.', ' ')) ?> KB</span></div>
      </div>
      <div class="pv-side">
        <div class="card">
          <div class="pv-amount"><span>O'quvchi yozgan summa</span><b><?= e(som((int)$view['amount'])) ?></b>
            <?php if ($view['status'] === 'approved' && (int)$view['approved_amount'] !== (int)$view['amount']): ?><small>Tasdiqlangan: <b><?= e(som((int)$view['approved_amount'])) ?></b></small><?php endif; ?></div>
          <dl class="pv-dl">
            <dt>O'quvchi</dt><dd><b><?= e($view['full_name']) ?></b> · ID <span class="mono"><?= e($view['code']) ?></span><?= $view['group_name'] !== '' ? ' · ' . e($view['group_name']) : '' ?><?= $view['archived_at'] ? ' <span class="tag red">arxivda</span>' : '' ?>
              <div class="small"><a href="<?= e(url('wallets', ['sid' => $view['student_id']])) ?>">Hamyoni: <?= e(som((int)$view['balance'])) ?> →</a><?= $view['phone'] !== '' ? ' · ' . e(fmt_phone($view['phone'])) : '' ?></div></dd>
            <dt>Usul</dt><dd><?= e(PAY_METHODS[$view['method']] ?? $view['method']) ?><?= $view['card_to'] !== '' ? ' → <span class="mono">' . e($view['card_to']) . '</span>' : '' ?></dd>
            <dt>To'lov vaqti</dt><dd><?= $view['paid_at'] ? e(date('d.m.Y H:i', strtotime((string)$view['paid_at']))) : '<span class="muted">ko\'rsatilmagan</span>' ?></dd>
            <?php if ($view['receipt_no'] !== ''): ?><dt>Chek raqami</dt><dd class="mono"><?= e($view['receipt_no']) ?></dd><?php endif; ?>
            <dt>Yuborilgan</dt><dd><?= e(date('d.m.Y H:i', strtotime((string)$view['created_at']))) ?> · <?= $view['source'] === 'bot' ? 'bot orqali' : 'saytdan' ?></dd>
            <?php if ($view['note'] !== ''): ?><dt>Izoh</dt><dd><?= e($view['note']) ?></dd><?php endif; ?>
          </dl>
          <?php if ($flags): ?>
            <div class="pv-flags">
              <?php foreach ($flags as $f): ?><div class="pv-flag <?= $f['lvl'] ?>"><?= icon('alert', 15) ?><span><?= e($f['text']) ?><?php if (!empty($f['ref'])): ?> · <a href="<?= e(url('pay', ['id' => $f['ref']])) ?>" target="_blank">ko'rish</a><?php endif; ?></span></div><?php endforeach; ?>
            </div>
          <?php endif; ?>
          <p class="small muted" style="margin:.6rem 0 0">Bank ilovangizda shu summa va vaqt bilan kirim borligini tekshiring. Tizim faqat ogohlantiradi — qaror sizniki.</p>
        </div>

        <?php if ($pend): ?>
        <div class="card pv-decide">
          <form method="post" class="form" onsubmit="return confirm('Chek tasdiqlanib, ' + this.amount.value + ' so\'m balansga yozilsinmi?')">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$view['id'] ?>"><input type="hidden" name="decision" value="approve">
            <h3 style="margin:0">Tasdiqlash</h3>
            <label>Balansga yoziladigan summa <input name="amount" id="apAmount" inputmode="numeric" required value="<?= e(number_format((int)$view['amount'], 0, '.', ' ')) ?>" autocomplete="off"></label>
            <p class="small muted" id="apPrev" data-bal="<?= (int)$view['balance'] ?>" style="margin-top:-.3rem">Balans: <?= e(som((int)$view['balance'])) ?> → <b><?= e(som((int)$view['balance'] + (int)$view['amount'])) ?></b></p>
            <label>Izoh <span class="muted">(ixtiyoriy; summa farq qilsa — sababini yozing)</span> <input name="note" maxlength="200"></label>
            <?php if ($unpaid): ?><p class="small" style="margin:0">Tasdiqlansa, band qilingan MOCK lar avtomatik to'lanadi (balans yetsa): <?= e(implode(', ', array_map(fn($u) => '«' . $u['title'] . '» — ' . som(mock_price($u)), $unpaid))) ?></p><?php endif; ?>
            <button class="btn primary wide"><?= icon('check', 16) ?>Tasdiqlash</button>
          </form>
          <form method="post" class="form pv-reject" onsubmit="var r=this.querySelector('input[name=reason]:checked'); if(!r){alert('Sababni tanlang');return false;} if(r.value==='boshqa' && !this.reason_text.value.trim()){alert('Sababni yozing');return false;} return confirm('Chek rad etilsinmi?')">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$view['id'] ?>"><input type="hidden" name="decision" value="reject">
            <h3 style="margin:0">Rad etish</h3>
            <div class="reason-list">
              <?php foreach (PAY_REJECT_REASONS as $k => $v): ?><label class="check"><input type="radio" name="reason" value="<?= $k ?>"> <?= e($v) ?></label><?php endforeach; ?>
            </div>
            <label>Qo'shimcha izoh <span class="muted">(o'quvchiga boradi)</span> <input name="reason_text" maxlength="200"></label>
            <button class="btn danger-ghost wide"><?= icon('close', 16) ?>Rad etish</button>
          </form>
        </div>
        <?php else: ?>
        <div class="card">
          <h3 style="margin-top:0">Qaror</h3>
          <p style="margin:0"><?= e(PAY_STATUS[$view['status']] ?? $view['status']) ?><?= $view['reviewed_by'] !== '' ? ' — ' . e(actor_label((string)$view['reviewed_by'])) : '' ?><?= $view['reviewed_at'] ? ', ' . e(date('d.m.Y H:i', strtotime((string)$view['reviewed_at']))) : '' ?></p>
          <?php if ($view['review_note'] !== ''): ?><p class="small" style="margin:.3rem 0 0"><?= e($view['review_note']) ?></p><?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ($others): ?>
        <div class="card">
          <h3 style="margin-top:0">Shu o'quvchining boshqa cheklari</h3>
          <?php foreach ($others as $o): ?>
            <div class="row between small pv-other"><a href="<?= e(url('pay', ['id' => $o['id']])) ?>">#<?= (int)$o['id'] ?> · <?= e(date('d.m.Y', strtotime((string)$o['created_at']))) ?></a><span><?= e(som((int)($o['status'] === 'approved' ? $o['approved_amount'] : $o['amount']))) ?> <span class="tag <?= ['pending' => 'amber', 'approved' => 'green', 'rejected' => 'red'][$o['status']] ?? '' ?>"><?= e(PAY_STATUS[$o['status']] ?? $o['status']) ?></span></span></div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <script>
    (function () {
      var a = document.getElementById('apAmount'), p = document.getElementById('apPrev');
      if (!a || !p) return;
      var bal = parseInt(p.getAttribute('data-bal'), 10) || 0;
      var fmt = function (n) { return (n < 0 ? '−' : '') + String(Math.abs(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' so\'m'; };
      a.addEventListener('input', function () {
        var d = a.value.replace(/\D/g, '').slice(0, 9);
        a.value = d.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
        p.innerHTML = 'Balans: ' + fmt(bal) + ' → <b>' + fmt(bal + (parseInt(d, 10) || 0)) + '</b>';
      });
    })();
    </script>
    <?php
    page_footer();
    return;
endif;

// Ro'yxat
$tab = isset($tabs[$_GET['s'] ?? '']) ? (string)$_GET['s'] : 'pending';
$q = trim((string)($_GET['q'] ?? ''));
$w = []; $p = [];
if ($tab !== 'all') { $w[] = 'p.status=?'; $p[] = $tab; }
if ($q !== '') { [$sw, $sp] = student_search_sql($q); $w[] = $sw; $p = array_merge($p, $sp); }
$page = max(1, (int)($_GET['pg'] ?? 1));
$per = 40;
$whereSql = $w ? ' WHERE ' . implode(' AND ', $w) : '';
$total = (int)val('SELECT COUNT(*) FROM pay_requests p JOIN students s ON s.id=p.student_id' . $whereSql, $p);
$list = rows('SELECT p.*, s.full_name, s.code, s.group_name FROM pay_requests p JOIN students s ON s.id=p.student_id' . $whereSql
    . ($tab === 'pending' ? ' ORDER BY p.created_at, p.id' : ' ORDER BY p.id DESC') . ' LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), $p);
$today = row('SELECT COUNT(*) n, COALESCE(SUM(approved_amount),0) s FROM pay_requests WHERE status="approved" AND reviewed_at >= CURDATE()');
page_header('To\'lovlar');
?>
<div class="page-head"><div><h1>To'lovlar</h1><p class="muted" style="margin:0">O'quvchilar yuborgan cheklar. Bugun tasdiqlangan: <b><?= (int)$today['n'] ?></b> ta, <b><?= e(som((int)$today['s'])) ?></b>.</p></div>
  <a class="btn ghost" href="<?= e(url('wallets')) ?>"><?= icon('wallet', 16) ?>Hamyonlar</a></div>
<?php if (!pay_cards()): ?><div class="alert warn"><?= icon('alert') ?><span>O'quvchilarga ko'rsatiladigan to'lov kartasi kiritilmagan. <a href="<?= e(url('settings')) ?>#tolov">Sozlamalar → To'lov</a></span></div><?php endif; ?>
<nav class="tabs pay-tabs">
  <?php foreach ($tabs as $k => $v): ?><a href="<?= e(url('pay', ['s' => $k] + ($q !== '' ? ['q' => $q] : []))) ?>"<?= $tab === $k ? ' class="active"' : '' ?>><?= e($v) ?><?php if ($k !== 'all' && !empty($cnt[$k])): ?> <span class="tab-n"><?= $cnt[$k] ?></span><?php endif; ?></a><?php endforeach; ?>
</nav>
<form class="row gap wrap filter" method="get"><input type="hidden" name="p" value="pay"><input type="hidden" name="s" value="<?= e($tab) ?>">
  <input name="q" value="<?= e($q) ?>" placeholder="Ism, ID yoki telefon" aria-label="Qidirish"><button class="btn sm">Qidirish</button>
  <?php if ($q !== ''): ?><a class="small" href="<?= e(url('pay', ['s' => $tab])) ?>">Tozalash</a><?php endif; ?>
  <span class="small muted"><?= $total ?> ta</span></form>
<?php if (!$list): ?>
  <div class="card empty"><?= $tab === 'pending' ? 'Tekshirilishi kerak bo\'lgan chek yo\'q ✓' : 'Chek topilmadi' ?></div>
<?php else: ?>
<div class="pay-list">
  <?php foreach ($list as $r): $fl = $r['status'] === 'pending' ? array_filter(pay_flags($r), fn($f) => $f['lvl'] === 'warn') : []; ?>
  <a class="pay-row card" href="<?= e(url('pay', ['id' => $r['id']])) ?>">
    <span class="pr-thumb"><?php if ($isImg($r)): ?><img loading="lazy" src="<?= e(url('pay_file', ['id' => $r['id'], 't' => 1])) ?>" alt=""><?php else: ?><?= icon('file', 26) ?><small>PDF</small><?php endif; ?></span>
    <span class="pr-who"><b><?= e($r['full_name']) ?></b><small>ID <?= e($r['code']) ?><?= $r['group_name'] !== '' ? ' · ' . e($r['group_name']) : '' ?> · #<?= (int)$r['id'] ?> · <?= e(date('d.m H:i', strtotime((string)$r['created_at']))) ?><?= $r['source'] === 'bot' ? ' · bot' : '' ?></small></span>
    <span class="pr-sum"><b><?= e(som((int)($r['status'] === 'approved' ? $r['approved_amount'] : $r['amount']))) ?></b><small><?= e(PAY_METHODS[$r['method']] ?? $r['method']) ?></small></span>
    <span class="pr-st"><?php if ($fl): ?><span class="tag red" title="<?= e(implode("\n", array_column($fl, 'text'))) ?>"><?= icon('alert', 13) ?><?= count($fl) ?></span><?php endif; ?><span class="tag <?= ['pending' => 'amber', 'approved' => 'green', 'rejected' => 'red'][$r['status']] ?? '' ?>"><?= e(PAY_STATUS[$r['status']] ?? $r['status']) ?></span></span>
  </a>
  <?php endforeach; ?>
</div>
<?php if ($total > $per): ?><div class="row gap mt"><?php for ($i = 1; $i <= (int)ceil($total / $per); $i++): ?><a class="btn sm <?= $i === $page ? 'primary' : 'ghost' ?>" href="<?= e(url('pay', ['s' => $tab, 'pg' => $i] + ($q !== '' ? ['q' => $q] : []))) ?>"><?= $i ?></a><?php endfor; ?></div><?php endif; ?>
<?php endif; ?>
<?php page_footer();
