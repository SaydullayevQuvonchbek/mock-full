<?php
defined('APP_ROOT') || exit;
/**
 * 2.5: O'quvchi hamyoni — balans, hisobni to'ldirish (kartaga o'tkazma + chek), cheklar holati, kirim-chiqim tarixi,
 * to'lov kutayotgan (band qilingan) MOCK lar.
 */
$me = student();
$sid = (int)$me['id'];
if (is_post()) {
    csrf_check();
    $act = (string)($_POST['action'] ?? '');
    if ($act === 'topup') {
        $f = $_FILES['file'] ?? null;
        $err = (int)($f['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) flash('Fayl juda katta (server chegarasi ' . ini_get('upload_max_filesize') . '). Skrinshot yuboring yoki rasmni kichraytiring.', 'err');
        elseif ($err === UPLOAD_ERR_NO_FILE) flash('Chek rasmini yoki PDF ni tanlang', 'err');
        elseif ($err !== UPLOAD_ERR_OK) flash('Fayl yuklanmadi (xato ' . $err . '). Qayta urinib ko\'ring.', 'err');
        else {
            $r = pay_request_create($sid, $_POST, ['tmp' => (string)$f['tmp_name'], 'size' => (int)$f['size']], 'web');
            if ($r['ok']) {
                flash('Chek yuborildi (#' . $r['id'] . '). Admin tekshirgach summa balansingizga tushadi' . (tg_ready() ? ' — natija botga ham keladi' : '') . '.');
                redirect('student_wallet');
            }
            flash($r['error'], 'err');
            $_SESSION['wallet_form'] = array_intersect_key($_POST, array_flip(['amount', 'method', 'card_to', 'paid_at', 'receipt_no', 'note']));
        }
        header('Location: ' . url('student_wallet') . '#topup');
        exit;
    }
    if ($act === 'cancel') {
        flash(pay_request_cancel((int)$_POST['id'], $sid) ? 'Chek bekor qilindi' : 'Bu chek allaqachon ko\'rib chiqilgan', 'warn');
        redirect('student_wallet');
    }
    if ($act === 'payres') {
        $r = mock_pay_unpaid($sid, (int)$_POST['test'], null, (int)($_POST['price'] ?? -1));
        flash($r['ok'] ? '«' . $r['title'] . '» uchun ' . som($r['price']) . ' to\'landi — siz ro\'yxatdasiz' : $r['error'], $r['ok'] ? 'ok' : 'err');
        redirect('student_wallet');
    }
    redirect('student_wallet');
}

wallet_tick(true);
$st = row('SELECT id, balance, full_name, code FROM students WHERE id=?', [$sid]);
$bal = (int)$st['balance'];
$pending = rows('SELECT * FROM pay_requests WHERE student_id=? AND status="pending" ORDER BY id DESC', [$sid]);
$pendSum = array_sum(array_map(fn($x) => (int)$x['amount'], $pending));
$reqs = rows('SELECT * FROM pay_requests WHERE student_id=? ORDER BY id DESC LIMIT 12', [$sid]);
$hist = wallet_history($sid, 100);
$unpaid = array_values(array_filter(mock_student_list($sid), fn($x) => $x['pay_status'] === 'unpaid' && !$x['over']));
$needAll = max(0, array_sum(array_map(fn($x) => mock_price($x), $unpaid)) - $bal);
$cards = pay_cards();
$note = pay_note();
$form = $_SESSION['wallet_form'] ?? []; unset($_SESSION['wallet_form']);
$amountDefault = (string)($form['amount'] ?? ($needAll > 0 ? number_format(max($needAll, pay_min()), 0, '.', ' ') : ''));
$canSend = count($pending) < pay_max_pending();
page_header('Hamyon');
?>
<section class="wallet-hero">
  <div class="wh-main">
    <span class="wh-label"><?= icon('wallet', 16) ?>Hamyon balansi</span>
    <b class="wh-bal<?= $bal < 0 ? ' neg' : '' ?>"><?= e(som($bal)) ?></b>
    <?php if ($pending): ?><span class="wh-pend"><?= icon('clock', 15) ?>Tekshirilmoqda: <b><?= e(som($pendSum)) ?></b> (<?= count($pending) ?> ta chek)</span><?php endif; ?>
  </div>
  <p class="wh-help small muted">MOCK larga yozilganda to'lov shu balansdan yechiladi. Balansni to'ldirish uchun kartaga pul o'tkazib, chekni shu yerga yuklang — admin tekshirgach summa balansga tushadi.</p>
</section>

<?php if ($unpaid): ?>
<div class="card wallet-due">
  <h2 style="margin-top:0">To'lov kutayotgan MOCK lar</h2>
  <?php foreach ($unpaid as $u): $pr = mock_price($u); ?>
    <div class="due-row">
      <div><b><?= e($u['title']) ?></b><div class="small muted"><?= e($u['test_date'] ? date('d.m.Y', strtotime((string)$u['test_date'])) : 'sana keyinroq') ?> · joy band qilingan · <?= $u['reg_open'] ? 'ro\'yxat yopilguncha to\'lang' : 'ro\'yxat yopilgan — chekingiz tekshirilmoqda' ?></div></div>
      <div class="due-act">
        <b class="nowrap"><?= e(som($pr)) ?></b>
        <?php if ($bal >= $pr): ?>
          <form method="post" onsubmit="return confirm(<?= e(json_encode('«' . $u['title'] . '» uchun ' . som($pr) . ' balansdan yechilsinmi?', JSON_UNESCAPED_UNICODE)) ?>)"><?= csrf_field() ?><input type="hidden" name="action" value="payres"><input type="hidden" name="test" value="<?= (int)$u['id'] ?>"><input type="hidden" name="price" value="<?= $pr ?>"><button class="btn primary sm">To'lash</button></form>
        <?php else: ?><span class="tag amber">yana <?= e(som($pr - $bal)) ?></span><?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if ($needAll > 0): ?><p class="small muted" style="margin-bottom:0">Hisobni kamida <b><?= e(som($needAll)) ?></b> ga to'ldiring — chek tasdiqlangach to'lov avtomatik yechiladi.</p><?php endif; ?>
</div>
<?php endif; ?>

<div class="wallet-grid">
  <section class="card" id="topup">
    <h2 style="margin-top:0">Hisobni to'ldirish</h2>
    <?php if (!$canSend): ?>
      <div class="alert warn small"><?= icon('alert') ?><span>Sizda <?= count($pending) ?> ta chek tekshirilmoqda. Admin ko'rib chiqqach yangisini yuborishingiz mumkin.</span></div>
    <?php endif; ?>
    <ol class="pay-steps">
      <li><b>Pulni o'tkazing</b><?= $cards ? ' — quyidagi kartalardan biriga (Click, Payme, bank ilovasi orqali):' : '' ?>
        <?php if ($cards): ?>
        <div class="pay-cards">
          <?php foreach ($cards as $c): ?>
            <div class="pay-card">
              <div><span class="pc-no mono"><?= e($c['no']) ?></span><small><?= e(trim($c['owner'] . ($c['bank'] !== '' ? ' · ' . $c['bank'] : ''), ' ·')) ?></small></div>
              <button type="button" class="btn sm ghost copy-btn" data-copy="<?= e(preg_replace('/\s+/', '', $c['no'])) ?>" aria-label="Karta raqamini nusxalash"><?= icon('copy', 15) ?><span>Nusxa</span></button>
            </div>
          <?php endforeach; ?>
        </div>
        <?php else: ?><div class="small muted">Karta raqamini o'quv markazidan so'rang yoki naqd to'lang (naqd to'lovni admin o'zi balansingizga yozadi).</div><?php endif; ?>
      </li>
      <li><b>Chekni yuklang</b> — to'lov ilovasidagi chek skrinshoti yoki PDF.</li>
    </ol>
    <?php if ($note !== ''): ?><div class="pay-note small"><?= nl2br(e($note)) ?></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data" class="form pay-form" id="payForm">
      <?= csrf_field() ?><input type="hidden" name="action" value="topup">
      <div class="grid2">
        <label>Summa, so'm * <input name="amount" id="payAmount" required inputmode="numeric" autocomplete="off" value="<?= e($amountDefault) ?>" placeholder="masalan: 50 000"></label>
        <label>Qanday to'ladingiz
          <select name="method"><?php foreach (PAY_METHODS as $k => $v): ?><option value="<?= $k ?>" <?= ($form['method'] ?? 'karta') === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></label>
      </div>
      <?php if (count($cards) > 1): ?>
        <fieldset class="pay-to"><legend>Qaysi kartaga</legend>
          <?php foreach ($cards as $i => $c): $lab = pay_card_label($c); ?>
            <label class="check"><input type="radio" name="card_to" value="<?= e($lab) ?>" <?= ($form['card_to'] ?? '') === $lab || (!isset($form['card_to']) && $i === 0) ? 'checked' : '' ?>> <span class="mono nowrap"><?= e($c['no']) ?></span><?= $c['bank'] !== '' ? ' <span class="muted small">' . e($c['bank']) . '</span>' : '' ?></label>
          <?php endforeach; ?>
        </fieldset>
      <?php elseif ($cards): ?><input type="hidden" name="card_to" value="<?= e(pay_card_label($cards[0])) ?>"><?php endif; ?>
      <div class="grid2">
        <label>To'lov vaqti <input type="datetime-local" name="paid_at" value="<?= e($form['paid_at'] ?? date('Y-m-d\TH:i')) ?>" max="<?= date('Y-m-d\TH:i', time() + 3600) ?>"></label>
        <label>Chek raqami <span class="muted">(ixtiyoriy)</span> <input name="receipt_no" maxlength="64" value="<?= e($form['receipt_no'] ?? '') ?>" autocomplete="off"></label>
      </div>
      <label class="file-drop" id="payDrop">
        <input type="file" name="file" id="payFile" accept="image/jpeg,image/png,image/webp,application/pdf" required>
        <span class="fd-empty"><?= icon('upload', 22) ?><b>Chek rasmini yoki PDF ni tanlang</b><small>JPG, PNG, WebP yoki PDF · 8 MB gacha</small></span>
        <span class="fd-file" hidden><img alt="Chek ko'rinishi" id="payPrev" hidden><span class="fd-name" id="payName"></span><small>Boshqasini tanlash uchun bosing</small></span>
      </label>
      <label>Izoh <span class="muted">(ixtiyoriy)</span> <input name="note" maxlength="200" value="<?= e($form['note'] ?? '') ?>" placeholder="masalan: «MOCK 5» uchun, otam to'ladi"></label>
      <button class="btn primary wide" <?= $canSend ? '' : 'disabled' ?>><?= icon('send', 16) ?>Chekni yuborish</button>
      <p class="small muted" style="margin:.2rem 0 0">Eng kam summa — <?= e(som(pay_min())) ?>. Soxta yoki boshqa odamning chekini yuborish hisob bloklanishiga olib keladi.</p>
    </form>
    <?php if (tg_ready() && tg_meta('bot') !== ''): $tgOn = val('SELECT tg_chat_id FROM students WHERE id=?', [$sid]) !== null; ?>
      <p class="small muted pay-bot-hint"><?= icon('send', 14) ?> <?= $tgOn ? 'Chekni Telegram botga ham yuborishingiz mumkin: <b>«💰 Hamyon» → «➕ Hisobni to\'ldirish»</b> — rasmni summa bilan yuborasiz.'
        : 'Telegramni ulasangiz, chekni botga yuborasiz va natija o\'sha yerga keladi — <a href="' . e(url('student_profile')) . '">Profil → «Telegramni ulash»</a>.' ?></p>
    <?php endif; ?>
  </section>

  <div>
    <section class="card">
      <h2 style="margin-top:0">Cheklarim</h2>
      <?php if (!$reqs): ?><p class="empty" style="padding:1rem">Hali chek yuborilmagan.</p><?php endif; ?>
      <div class="rcpt-list">
      <?php foreach ($reqs as $r): $stt = (string)$r['status']; ?>
        <div class="rcpt">
          <div class="rcpt-main">
            <b><?= e(som((int)($stt === 'approved' ? $r['approved_amount'] : $r['amount']))) ?></b>
            <span class="tag <?= ['pending' => 'amber', 'approved' => 'green', 'rejected' => 'red', 'canceled' => ''][$stt] ?? '' ?>"><?= e(PAY_STATUS[$stt] ?? $stt) ?></span>
            <div class="small muted">#<?= (int)$r['id'] ?> · <?= e(date('d.m.Y H:i', strtotime((string)$r['created_at']))) ?> · <?= e(PAY_METHODS[$r['method']] ?? $r['method']) ?><?= $r['source'] === 'bot' ? ' · bot orqali' : '' ?></div>
            <?php if ($stt === 'approved' && (int)$r['approved_amount'] !== (int)$r['amount']): ?><div class="small">Siz yozgan: <?= e(som((int)$r['amount'])) ?><?= $r['review_note'] !== '' ? ' — ' . e($r['review_note']) : '' ?></div><?php endif; ?>
            <?php if ($stt === 'rejected'): ?><div class="small critical-t">Sabab: <?= e($r['review_note']) ?></div><?php endif; ?>
          </div>
          <div class="rcpt-act">
            <a class="btn sm ghost" target="_blank" href="<?= e(url('pay_file', ['id' => $r['id']])) ?>"><?= icon('file', 14) ?>Chek</a>
            <?php if ($stt === 'pending'): ?><form method="post" onsubmit="return confirm('Chek bekor qilinsinmi?')"><?= csrf_field() ?><input type="hidden" name="action" value="cancel"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn sm danger-ghost">Bekor qilish</button></form><?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
      </div>
    </section>
    <section class="card">
      <h2 style="margin-top:0">Kirim va chiqimlar</h2>
      <?php if (!$hist): ?><p class="empty" style="padding:1rem">Hali yozuv yo'q.</p><?php else: ?>
      <div class="table-wrap"><table class="tbl compact-tbl tx-tbl stu">
        <thead><tr><th>Sana</th><th>Izoh</th><th class="num">Summa</th><th class="num">Balans</th></tr></thead>
        <tbody>
        <?php foreach ($hist as $t): ?>
          <tr><td class="nowrap small"><?= e(date('d.m.Y H:i', strtotime((string)$t['created_at']))) ?></td><td class="small"><?= e(wallet_tx_label($t)) ?></td>
            <td class="num nowrap <?= (int)$t['amount'] > 0 ? 'ok-t' : '' ?>"><?= (int)$t['amount'] > 0 ? '+' : '' ?><?= e(som((int)$t['amount'])) ?></td><td class="num nowrap muted"><?= e(som((int)$t['balance_after'])) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
      <?php endif; ?>
    </section>
  </div>
</div>
<script>
(function () {
  // Karta raqamini nusxalash
  document.querySelectorAll('.copy-btn').forEach(function (b) {
    b.addEventListener('click', function () {
      var t = b.getAttribute('data-copy'), lab = b.querySelector('span');
      var done = function () { lab.textContent = 'Nusxalandi'; setTimeout(function () { lab.textContent = 'Nusxa'; }, 1800); };
      if (navigator.clipboard) navigator.clipboard.writeText(t).then(done, function () { prompt('Karta raqami:', t); });
      else prompt('Karta raqami:', t);
    });
  });
  // Summa: 50000 → 50 000
  var am = document.getElementById('payAmount');
  if (am) am.addEventListener('input', function () {
    var d = am.value.replace(/\D/g, '').slice(0, 9);
    var pos = am.value.length - am.selectionStart;
    am.value = d.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    try { am.setSelectionRange(am.value.length - pos, am.value.length - pos); } catch (e) {}
  });
  // Chek fayli: ko'rinish; katta rasm (> 2 MB yoki > 2400 px) yuborishdan oldin kichraytiriladi
  var inp = document.getElementById('payFile'), prev = document.getElementById('payPrev'), nm = document.getElementById('payName'), drop = document.getElementById('payDrop');
  if (!inp) return;
  function show(file) {
    drop.querySelector('.fd-empty').hidden = true; drop.querySelector('.fd-file').hidden = false;
    nm.textContent = file.name + ' · ' + (file.size / 1048576).toFixed(file.size > 1048576 ? 1 : 2) + ' MB';
    if (/^image\//.test(file.type)) { prev.src = URL.createObjectURL(file); prev.hidden = false; } else { prev.hidden = true; }
  }
  function shrink(file) {
    return new Promise(function (res) {
      if (!/^image\/(jpeg|png|webp)$/.test(file.type) || !window.createImageBitmap || !window.DataTransfer) return res(null);
      createImageBitmap(file).then(function (bmp) {
        var max = Math.max(bmp.width, bmp.height);
        if (file.size <= 2 * 1048576 && max <= 2400) return res(null);
        var k = Math.min(1, 2000 / max), c = document.createElement('canvas');
        c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
        var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
        c.toBlob(function (b) { res(b ? new File([b], file.name.replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }) : null); }, 'image/jpeg', 0.88);
      }, function () { res(null); });
    });
  }
  inp.addEventListener('change', function () {
    var f = inp.files && inp.files[0];
    if (!f) return;
    show(f);
    shrink(f).then(function (small) {
      if (!small || small.size >= f.size) return;
      var dt = new DataTransfer(); dt.items.add(small); inp.files = dt.files; show(small);
    });
  });
  document.getElementById('payForm').addEventListener('submit', function (e) {
    var f = inp.files && inp.files[0];
    if (f && f.size > 8 * 1048576) { e.preventDefault(); alert('Fayl 8 MB dan katta. Skrinshot yuboring.'); return; }
    var b = this.querySelector('button.primary'); setTimeout(function () { b.disabled = true; b.lastChild.textContent = 'Yuborilmoqda…'; }, 0);
  });
})();
</script>
<?php page_footer();
