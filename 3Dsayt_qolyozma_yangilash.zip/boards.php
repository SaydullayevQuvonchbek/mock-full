<?php
// Doska darslari: kirgan o‘qituvchining darslari serverda, private/boards/<foydalanuvchi>/ ichida saqlanadi.
// So‘rovlar faqat saytning o‘zidan (X-Doska sarlavhasi bilan) qabul qilinadi; PHP 7.4 va undan yangi.
//   GET  boards.php?a=list               — darslar ro‘yxati
//   GET  boards.php?a=get&id=…           — bitta dars
//   POST boards.php?a=save&name=…        — tanasi: darsning o‘zi (JSON), shundayligicha saqlanadi
//   POST boards.php?a=del                — tanasi: {"id": …}
//   GET  boards.php?a=hw                 — o‘qituvchining qo‘lyozma namunalari (doska, «Qo‘lyozmani o‘rgatish»)
//   POST boards.php?a=hw                 — tanasi: namunalar (JSON), 1 MB gacha
declare(strict_types=1);
require __DIR__ . '/auth.php';

const BOARD_MAX_BYTES = 8000000;   // bitta dars (rasmlar bilan) — taxminan 8 MB
const BOARD_MAX_COUNT = 200;       // bitta o‘qituvchining darslari soni
const BOARD_MAX_NAME = 80;

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function board_out(int $code, array $data): void {
  http_response_code($code);
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}
function board_fail(int $code, string $err): void { board_out($code, ['ok' => false, 'err' => $err]); }

$user = auth_user();
if ($user === null) board_fail(401, 'auth');
// boshqa saytdan yuborilgan so‘rov bu sarlavhani qo‘sha olmaydi (brauzer avval ruxsat so‘raydi, server bermaydi)
if (($_SERVER['HTTP_X_DOSKA'] ?? '') !== '1') board_fail(403, 'origin');
$origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
if ($origin !== '') {
  // so‘rov saytning o‘z sahifasidan kelgan bo‘lishi kerak (proksi Host ni o‘zgartirsa, X-Forwarded-Host ham qabul qilinadi)
  $oh = strtolower((string)parse_url($origin, PHP_URL_HOST));
  $op = parse_url($origin, PHP_URL_PORT);
  $ok = false;
  foreach ([(string)($_SERVER['HTTP_HOST'] ?? ''), trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_HOST'] ?? ''))[0]), (string)($_SERVER['SERVER_NAME'] ?? '')] as $h) {
    $h = strtolower($h);
    if ($h !== '' && $oh !== '' && ($h === $oh || $h === $oh . ($op ? ':' . $op : ''))) $ok = true;
  }
  if (!$ok) board_fail(403, 'origin');
}

function board_dir(string $user): string {
  $base = auth_private_dir();
  if ($base === null) board_fail(500, 'disk');
  $dir = $base . '/boards/' . substr(hash('sha256', $user), 0, 16);
  if (!is_dir($dir) && !@mkdir($dir, 0700, true)) board_fail(500, 'disk');
  return $dir;
}
function board_lower(string $s): string { return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s); }
function board_id(string $name): string { return substr(hash('sha256', board_lower($name)), 0, 16); }
function board_clean_name($name): string {
  if (!is_string($name)) return '';
  $name = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $name);
  $name = trim((string)preg_replace('/\s+/u', ' ', (string)$name));
  if (function_exists('mb_substr')) $name = mb_substr($name, 0, BOARD_MAX_NAME, 'UTF-8');
  else $name = substr($name, 0, BOARD_MAX_NAME);
  return $name;
}
function board_read_index(string $dir): array {
  $f = $dir . '/index.json';
  if (!is_file($f)) return [];
  $d = json_decode((string)@file_get_contents($f), true);
  return is_array($d) ? array_values(array_filter($d, 'is_array')) : [];
}
function board_write(string $file, string $data): bool {
  $tmp = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
  if (@file_put_contents($tmp, $data, LOCK_EX) === false) { @unlink($tmp); return false; }
  @chmod($tmp, 0600);
  if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
  return true;
}
// ro‘yxat bir vaqtda ikki joydan o‘zgarmasin
function board_lock(string $dir) {
  $h = @fopen($dir . '/.lock', 'c');
  if ($h) flock($h, LOCK_EX);
  return $h;
}
function board_unlock($h): void { if ($h) { flock($h, LOCK_UN); fclose($h); } }

$a = (string)($_GET['a'] ?? '');
$method = (string)($_SERVER['REQUEST_METHOD'] ?? 'GET');
$dir = board_dir($user);

if ($a === 'list' && $method === 'GET') {
  $list = board_read_index($dir);
  usort($list, function ($x, $y) { return (int)($y['t'] ?? 0) <=> (int)($x['t'] ?? 0); });
  board_out(200, ['ok' => true, 'items' => $list]);
}

if ($a === 'hw' && $method === 'GET') {
  $f = $dir . '/hw.json';
  $raw = is_file($f) ? (string)@file_get_contents($f) : '';
  http_response_code(200);
  echo '{"ok":true,"data":' . ($raw !== '' && $raw[0] === '{' ? $raw : 'null') . '}';
  exit;
}

if ($a === 'get' && $method === 'GET') {
  $id = (string)($_GET['id'] ?? '');
  if (!preg_match('/^[a-f0-9]{16}$/', $id)) board_fail(400, 'id');
  $f = $dir . '/' . $id . '.json';
  if (!is_file($f)) board_fail(404, 'missing');
  $raw = (string)@file_get_contents($f);
  if ($raw === '' || $raw[0] !== '{') board_fail(500, 'disk');
  $name = '';
  foreach (board_read_index($dir) as $it) if (($it['id'] ?? '') === $id) $name = (string)($it['name'] ?? '');
  // dars fayli tayyor JSON: qayta o‘qib-yozilmaydi
  http_response_code(200);
  echo '{"ok":true,"id":' . json_encode($id) . ',"name":' . json_encode($name, JSON_UNESCAPED_UNICODE) . ',"data":' . $raw . '}';
  exit;
}

if ($method !== 'POST') board_fail(405, 'method');
// PHP o‘zi qabul qiladigan hajm (post_max_size) undan kichik bo‘lsa, so‘rov tanasi kelmaydi
function board_ini_bytes(string $v): int {
  $v = trim($v);
  if ($v === '' || $v === '0') return PHP_INT_MAX;
  $n = (int)$v;
  $u = strtolower(substr($v, -1));
  if ($u === 'g') $n *= 1073741824; elseif ($u === 'm') $n *= 1048576; elseif ($u === 'k') $n *= 1024;
  return $n > 0 ? $n : PHP_INT_MAX;
}
$len = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($len > BOARD_MAX_BYTES + 4096 || $len > board_ini_bytes((string)ini_get('post_max_size'))) board_fail(413, 'size');
$body = (string)file_get_contents('php://input', false, null, 0, BOARD_MAX_BYTES + 4097);
if (strlen($body) > BOARD_MAX_BYTES + 4096) board_fail(413, 'size');
// katta darsni tekshirish uchun xotira yetsin
if (board_ini_bytes((string)ini_get('memory_limit')) < 268435456) @ini_set('memory_limit', '256M');

if ($a === 'save') {
  $name = board_clean_name($_GET['name'] ?? '');
  if ($name === '') board_fail(400, 'name');
  if (strlen($body) > BOARD_MAX_BYTES) board_fail(413, 'size');
  // dars to‘g‘ri JSON va unda sahifalar bor; fayl o‘zi qayta yozilmay saqlanadi
  $data = json_decode($body, false, 64);
  if (!is_object($data) || !isset($data->pages) || !is_array($data->pages) || count($data->pages) < 1 || count($data->pages) > 300) board_fail(400, 'data');
  $pages = count($data->pages);
  unset($data);
  $json = $body;
  $id = board_id($name);
  $lock = board_lock($dir);
  $list = board_read_index($dir);
  $found = false;
  foreach ($list as $i => $it) if (($it['id'] ?? '') === $id) $found = $i;
  if ($found === false && count($list) >= BOARD_MAX_COUNT) { board_unlock($lock); board_fail(400, 'limit'); }
  if (!board_write($dir . '/' . $id . '.json', $json)) { board_unlock($lock); board_fail(500, 'disk'); }
  $entry = ['id' => $id, 'name' => $name, 't' => time(), 'pages' => $pages, 'size' => strlen($json)];
  if ($found === false) $list[] = $entry; else $list[$found] = $entry;
  $ok = board_write($dir . '/index.json', (string)json_encode(array_values($list), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  board_unlock($lock);
  if (!$ok) board_fail(500, 'disk');
  board_out(200, ['ok' => true, 'id' => $id, 't' => $entry['t']]);
}

if ($a === 'hw') {
  if (strlen($body) > 1000000) board_fail(413, 'size');
  $in = json_decode($body, true, 8);
  if (!is_array($in) || !isset($in['t']) || !is_array($in['t']) || count($in['t']) > 600) board_fail(400, 'data');
  foreach ($in['t'] as $q) if (!is_array($q) || !isset($q['ch'], $q['s']) || !is_string($q['ch']) || !is_array($q['s'])) board_fail(400, 'data');
  if (!board_write($dir . '/hw.json', $body)) board_fail(500, 'disk');
  board_out(200, ['ok' => true]);
}

if ($a === 'del') {
  $in = json_decode($body, true, 4);
  if (!is_array($in)) board_fail(400, 'json');
  $id = (string)($in['id'] ?? '');
  if (!preg_match('/^[a-f0-9]{16}$/', $id)) board_fail(400, 'id');
  $lock = board_lock($dir);
  $list = array_values(array_filter(board_read_index($dir), function ($it) use ($id) { return ($it['id'] ?? '') !== $id; }));
  @unlink($dir . '/' . $id . '.json');
  $ok = board_write($dir . '/index.json', (string)json_encode($list, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  board_unlock($lock);
  if (!$ok) board_fail(500, 'disk');
  board_out(200, ['ok' => true]);
}

board_fail(400, 'action');
