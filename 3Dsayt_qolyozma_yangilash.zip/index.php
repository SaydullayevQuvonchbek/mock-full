<?php
// Kirgan foydalanuvchiga saytni beradi, kirmaganni login sahifasiga yuboradi.
// Saytning o‘zi app/index.inc faylida (nginx .html fayllarni Apache'siz, ya’ni .htaccess'siz berib yuboradi — .inc ni
// bermaydi); app/.htaccess papkani yopib turadi. Eski app/index.html ham o‘qiladi, lekin uni serverdan o‘chirgan ma’qul.
declare(strict_types=1);
require __DIR__ . '/auth.php';
$user = auth_user();
if ($user === null) { header('Location: login.php', true, 302); exit; }
$file = is_file(__DIR__ . '/app/index.inc') ? __DIR__ . '/app/index.inc' : __DIR__ . '/app/index.html';
$html = @file_get_contents($file);
if ($html === false) { http_response_code(500); exit('app/index.inc topilmadi: sayt fayllarini (app papkasini) yuklang.'); }
$who = htmlspecialchars($user, ENT_QUOTES, 'UTF-8');
$html = str_replace('<!--AUTH-->', '<div class="auth"><span title="Kirgan foydalanuvchi">' . $who . '</span><a class="btn ghost" href="logout.php">Chiqish</a></div>', $html);
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
echo $html;
